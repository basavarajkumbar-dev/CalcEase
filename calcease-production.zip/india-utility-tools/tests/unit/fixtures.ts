/**
 * Loads the hand-derived fixtures and converts their exact decimal / fraction
 * strings ("100/3") into numbers. This file must never call the code under test.
 */
import data from "../fixtures/percentage.json";

export type FixtureMode =
  "percentOf" | "whatPercent" | "percentChange" | "increaseBy" | "decreaseBy";

interface RawCase {
  mode: string;
  inputs: Record<string, number | string>;
  expected?: string;
  expectedError?: string;
  note?: string;
}

/** Parses "a/b" or a decimal string to a number. */
export function parseExpected(text: string): number {
  const [numerator, denominator] = text.split("/");
  const value = Number(numerator) / (denominator === undefined ? 1 : Number(denominator));
  if (!Number.isFinite(value)) throw new Error(`Bad expected value in fixture: ${text}`);
  return value;
}

/** JSON cannot hold NaN or Infinity, so fixtures write them as strings. */
export function toInputNumber(value: number | string): number {
  return typeof value === "number" ? value : Number(value);
}

/** The two inputs of a case in the order the calculation functions take them. */
export function orderedInputs(
  mode: string,
  inputs: Record<string, number | string>,
): [number, number] {
  const order: Record<string, [string, string]> = {
    percentOf: ["percent", "value"],
    whatPercent: ["part", "whole"],
    percentChange: ["from", "to"],
    increaseBy: ["value", "percent"],
    decreaseBy: ["value", "percent"],
  };
  const keys = order[mode];
  if (!keys) throw new Error(`Unknown mode in fixture: ${mode}`);
  const a = inputs[keys[0]];
  const b = inputs[keys[1]];
  if (a === undefined || b === undefined) throw new Error(`Missing inputs for ${mode}`);
  return [toInputNumber(a), toInputNumber(b)];
}

export const calculationCases = data.cases as RawCase[];
export const invalidInputCases = data.invalidInputs as RawCase[];
export const parsingCases = data.parsing as {
  text: string;
  expected?: number;
  expectedError?: string;
  note?: string;
}[];
export const formattingCases = data.formatting as {
  value: number;
  expected: string;
  rounded?: boolean;
  note?: string;
}[];

/** Relative tolerance 1e-12, absolute 1e-9 near zero (spec, section 7). */
export function closeTo(actual: number, expected: number): boolean {
  const diff = Math.abs(actual - expected);
  return diff <= 1e-9 || diff <= 1e-12 * Math.abs(expected);
}
