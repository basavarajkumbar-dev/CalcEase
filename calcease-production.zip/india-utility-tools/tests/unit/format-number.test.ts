import { describe, expect, it } from "vitest";
import { formatNumber, formatPercent } from "@/lib/format/number";
import { formattingCases } from "./fixtures";

describe("formatNumber (fixtures)", () => {
  it.each(formattingCases.map((c) => [`${c.value}${c.note ? ` — ${c.note}` : ""}`, c]))(
    "%s",
    (_label, c) => {
      const formatted = formatNumber(c.value);
      expect(formatted.text).toBe(c.expected);
      expect(formatted.isRounded).toBe(c.rounded ?? false);
    },
  );
});

describe("formatNumber edge cases", () => {
  it("shows negative zero, and values that round to zero from below, as 0", () => {
    expect(formatNumber(-0).text).toBe("0");
  });

  it("never shows a tiny non-zero value as 0", () => {
    expect(formatNumber(1e-10).text).not.toBe("0");
    expect(formatNumber(-1e-10).text).not.toBe("0");
  });

  it("refuses non-finite values so they cannot leak into the UI", () => {
    expect(() => formatNumber(Number.NaN)).toThrow(RangeError);
    expect(() => formatNumber(Number.POSITIVE_INFINITY)).toThrow(RangeError);
  });
});

describe("formatPercent", () => {
  it("appends a percent sign and keeps the rounding flag", () => {
    expect(formatPercent(100 / 6)).toEqual({ text: "16.67%", isRounded: true });
    expect(formatPercent(20)).toEqual({ text: "20%", isRounded: false });
  });
});
