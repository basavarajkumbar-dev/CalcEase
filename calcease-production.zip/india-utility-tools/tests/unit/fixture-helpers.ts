/** Shared helpers for fixture-driven tests. Never calls the code under test. */

/** Parses "a/b" (parts may be decimals) or a decimal string. */
export function parseExpected(text: string): number {
  const [numerator, denominator] = text.split("/");
  const value = Number(numerator) / (denominator === undefined ? 1 : Number(denominator));
  if (!Number.isFinite(value)) throw new Error(`Bad expected value in fixture: ${text}`);
  return value;
}

/** Relative tolerance 1e-12, absolute 1e-9 near zero (same policy as the Percentage spec §7). */
export function closeTo(actual: number, expected: number, relative = 1e-12): boolean {
  const diff = Math.abs(actual - expected);
  return diff <= 1e-9 || diff <= relative * Math.abs(expected);
}

/** Asserts each expected key of a fixture case against an actual result object. */
export function compareFields(
  actual: Record<string, number>,
  expected: Record<string, string>,
): string[] {
  const problems: string[] = [];
  for (const [key, text] of Object.entries(expected)) {
    const want = parseExpected(text);
    const got = actual[key];
    if (got === undefined || !closeTo(got, want))
      problems.push(`${key}: got ${got}, expected ${want}`);
  }
  return problems;
}
