import fc from "fast-check";
import { describe, expect, it } from "vitest";
import data from "../fixtures/ctc.json";
import { ctcToInHand, incomeTax, type CtcInput } from "@/lib/calc/salary";
import { CURRENT_EPF_RULES, EPF_RULE_SETS, epfRulesOn } from "@/lib/rules/epf/rates";
import { CURRENT_INCOME_TAX_RULES as TAX } from "@/lib/rules/income-tax/rates";
import { closeTo, parseExpected } from "./fixture-helpers";

function compare(actual: Record<string, unknown>, expected: Record<string, string>) {
  for (const [key, want] of Object.entries(expected))
    expect(
      closeTo(actual[key] as number, parseExpected(want)),
      `${key}: ${actual[key]} vs ${want}`,
    ).toBe(true);
}

describe("CTC fixtures (UNDER REVIEW; hand-worked, independently verified)", () => {
  it.each(data.tax.map((c) => [`${c.regime} ₹${c.taxable}`, c]))("tax %s", (_l, c) => {
    const regime = c.regime === "new" ? TAX.newRegime : TAX.oldRegime;
    compare({ ...incomeTax(c.taxable, regime, TAX.cessRate) }, c.expected);
  });

  it.each(data.ctc.map((c) => [`₹${c.inputs.ctc} ${c.inputs.regime}`, c]))("ctc %s", (_l, c) => {
    const r = ctcToInHand(c.inputs as CtcInput, TAX, CURRENT_EPF_RULES);
    expect(r.ok).toBe(true);
    if (r.ok) compare({ ...r.value }, c.expected);
  });

  it.each(data.invalid.map((c) => [c.expectedError, c]))("rejects %s", (_l, c) => {
    expect(ctcToInHand(c.inputs as CtcInput, TAX, CURRENT_EPF_RULES)).toEqual({
      ok: false,
      error: c.expectedError,
    });
  });
});

describe("rule data", () => {
  it("is marked under review and records official sources", () => {
    expect(TAX.status).toBe("under-review");
    for (const s of TAX.sources)
      expect(s.url).toMatch(
        /^https:\/\/(www\.)?(incometax\.gov\.in|incometaxindia\.gov\.in|indiabudget\.gov\.in)\//,
      );
    for (const set of EPF_RULE_SETS) expect(set.status).toBe("under-review");
  });

  it("uses the EPF wage ceiling in force on the date", () => {
    expect(epfRulesOn("2026-09-16")?.wageCeiling).toBe(15_000);
    expect(epfRulesOn("2026-09-17")?.wageCeiling).toBe(25_000);
  });
});

const income = fc.integer({ min: 0, max: 5_000_000 });

describe("tax invariants", () => {
  it("tax never falls as income rises, in either regime", () => {
    fc.assert(
      fc.property(income, fc.integer({ min: 1, max: 100_000 }), fc.boolean(), (x, d, isNew) => {
        const r = isNew ? TAX.newRegime : TAX.oldRegime;
        return (
          incomeTax(x + d, r, TAX.cessRate).totalTax >=
          incomeTax(x, r, TAX.cessRate).totalTax - 1e-9
        );
      }),
    );
  });

  it("with marginal relief, tax before cess never exceeds the income over ₹12 lakh", () => {
    fc.assert(
      fc.property(fc.integer({ min: 1_200_001, max: 1_400_000 }), (x) => {
        const t = incomeTax(x, TAX.newRegime, TAX.cessRate);
        return t.slabTax - t.rebate <= x - 1_200_000 + 1e-9;
      }),
    );
  });
});
