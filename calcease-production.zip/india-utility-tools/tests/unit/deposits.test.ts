import fc from "fast-check";
import { describe, expect, it } from "vitest";
import data from "../fixtures/deposits.json";
import {
  compoundInterest,
  fixedDeposit,
  recurringDeposit,
  type Compounding,
  type FdInput,
} from "@/lib/calc/deposit";
import { addDays, addMonths, parseIsoDate, type PlainDate } from "@/lib/calc/date";
import { closeTo, parseExpected } from "./fixture-helpers";

const d = (text: string): PlainDate => parseIsoDate(text)!;

function fdInput(i: (typeof data.fd)[number]["inputs"]): FdInput {
  return {
    principal: i.principal,
    rate: i.rate,
    start: d(i.start),
    maturity: d(i.maturity),
    payout: i.payout as FdInput["payout"],
    simpleBelowMonths: i.simpleBelowMonths as FdInput["simpleBelowMonths"],
  };
}

function compare(actual: Record<string, unknown>, expected: Record<string, unknown>) {
  for (const [key, want] of Object.entries(expected)) {
    const got = actual[key];
    if (typeof want === "string")
      expect(closeTo(got as number, parseExpected(want)), `${key}: ${got} vs ${want}`).toBe(true);
    else expect(got, key).toBe(want);
  }
}

describe("deposit fixtures (independently verified)", () => {
  it.each(data.compound.map((c) => [JSON.stringify(c.inputs), c]))("compound %s", (_l, c) => {
    const i = c.inputs;
    const r = compoundInterest(i.principal, i.rate, i.years, i.compounding as Compounding);
    expect(r.ok).toBe(true);
    if (r.ok) compare({ ...r.value }, c.expected);
  });

  it.each(data.fd.map((c) => [`${c.inputs.start}→${c.inputs.maturity} ${c.note ?? ""}`, c]))(
    "fd %s",
    (_l, c) => {
      const r = fixedDeposit(fdInput(c.inputs));
      expect(r.ok).toBe(true);
      if (!r.ok) return;
      compare({ ...r.value }, c.expected);
      if (c.reference) expect(Math.round(r.value.maturityAmount)).toBe(c.reference.rupees);
    },
  );

  it.each(data.fdInvalid.map((c) => [c.expectedError, c]))("fd rejects: %s", (_l, c) => {
    expect(fixedDeposit(fdInput(c.inputs))).toEqual({ ok: false, error: c.expectedError });
  });

  it.each(data.rd.map((c) => [JSON.stringify(c.inputs), c]))("rd %s", (_l, c) => {
    const r = recurringDeposit(c.inputs.instalment, c.inputs.rate, c.inputs.months);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    compare({ ...r.value }, c.expected);
    if (c.reference) expect(Math.round(r.value.maturity)).toBe(c.reference.rupees);
  });

  it.each(data.rdInvalid.map((c) => [c.expectedError, c]))("rd rejects: %s", (_l, c) => {
    const i = c.inputs;
    expect(recurringDeposit(i.instalment, i.rate, i.months)).toEqual({
      ok: false,
      error: c.expectedError,
    });
  });
});

const amount = fc.integer({ min: 100, max: 1_000_000_000 });
const rate = fc.integer({ min: 1, max: 2000 }).map((n) => n / 100);

describe("deposit invariants", () => {
  it("compound interest year rows add up to the total and end at the final amount", () => {
    fc.assert(
      fc.property(
        amount,
        rate,
        fc.integer({ min: 1, max: 600 }).map((m) => m / 12),
        fc.constantFrom<Compounding>("yearly", "halfYearly", "quarterly", "monthly"),
        (p, r, years, freq) => {
          const res = compoundInterest(p, r, years, freq);
          if (!res.ok) return false;
          const sum = res.value.years.reduce((s, y) => s + y.interest, 0);
          const last = res.value.years[res.value.years.length - 1]!;
          return (
            closeTo(sum, res.value.interest, 1e-9) &&
            closeTo(last.balance, res.value.amount, 1e-12) &&
            // Compound ≥ simple once at least one compounding period has passed. (For less
            // than one period, the fractional power gives slightly less: spec §5.)
            (years * { yearly: 1, halfYearly: 2, quarterly: 4, monthly: 12 }[freq] < 1 ||
              res.value.interest >= res.value.simpleInterest - p * 1e-12)
          );
        },
      ),
    );
  });

  it("an FD of whole quarters equals quarterly compound interest", () => {
    fc.assert(
      fc.property(amount, rate, fc.integer({ min: 1, max: 40 }), (p, r, q) => {
        const start = { year: 2026, month: 1, day: 15 };
        const fd = fixedDeposit({
          principal: p,
          rate: r,
          start,
          maturity: addMonths(start, 3 * q).date,
          payout: "cumulative",
          simpleBelowMonths: 3,
        });
        const ci = compoundInterest(p, r, q / 4, "quarterly");
        return fd.ok && ci.ok && closeTo(fd.value.maturityAmount, ci.value.amount, 1e-12);
      }),
    );
  });

  it("FD interest never decreases when the deposit is held one more day", () => {
    // Includes the switch from simple to compound interest and every quarter boundary.
    fc.assert(
      fc.property(
        amount,
        rate,
        fc.integer({ min: 7, max: 3600 }),
        fc.constantFrom<FdInput["simpleBelowMonths"]>(3, 6, 12),
        (p, r, days, below) => {
          const start = { year: 2026, month: 10, day: 31 };
          const at = (n: number) =>
            fixedDeposit({
              principal: p,
              rate: r,
              start,
              maturity: addDays(start, n),
              payout: "cumulative",
              simpleBelowMonths: below,
            });
          const today = at(days);
          const tomorrow = at(days + 1);
          if (!tomorrow.ok) return true; // past 10 years
          return today.ok && tomorrow.value.interest >= today.value.interest;
        },
      ),
    );
  });

  it("RD maturity equals the sum of every instalment's own growth", () => {
    fc.assert(
      fc.property(amount, rate, fc.integer({ min: 1, max: 40 }), (p, r, quarters) => {
        const months = quarters * 3;
        const res = recurringDeposit(p, r, months);
        let sum = 0;
        for (let k = 1; k <= months; k += 1) sum += p * Math.pow(1 + r / 400, k / 3);
        return res.ok && closeTo(res.value.maturity, sum, 1e-10);
      }),
    );
  });
});
