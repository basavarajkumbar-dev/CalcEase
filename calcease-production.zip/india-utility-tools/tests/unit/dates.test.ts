import fc from "fast-check";
import { describe, expect, it } from "vitest";
import data from "../fixtures/dates.json";
import {
  DATE_RANGE,
  addDays,
  addMonths,
  ageOn,
  calendarDifference,
  dateDifference,
  formatIsoDate,
  fromDayNumber,
  isLeapYear,
  isoWeekday,
  parseIsoDate,
  shiftDate,
  toDayNumber,
  weekdaysBetween,
  type PlainDate,
} from "@/lib/calc/date";
import { formatLongDate, formatYmd } from "@/lib/format/date";

const d = (text: string): PlainDate => {
  const parsed = parseIsoDate(text);
  if (!parsed) throw new Error(`Bad fixture date ${text}`);
  return parsed;
};

describe("date fixtures (hand-worked, independently verified)", () => {
  it.each(data.weekdays.map((c) => [c.date, c]))("weekday of %s", (_l, c) => {
    expect(isoWeekday(d(c.date))).toBe(c.isoWeekday);
  });

  it("leap years", () => {
    for (const y of data.leapYears.leap) expect(isLeapYear(y), String(y)).toBe(true);
    for (const y of data.leapYears.common) expect(isLeapYear(y), String(y)).toBe(false);
  });

  it.each(
    data.difference.map((c) => [`${c.first} → ${c.second}${c.includeEnd ? " (incl.)" : ""}`, c]),
  )("difference %s", (_l, c) => {
    const result = dateDifference(d(c.first), d(c.second), c.includeEnd);
    for (const [key, value] of Object.entries(c.expected))
      expect(result[key as keyof typeof result], key).toBe(value);
  });

  it.each(data.age.map((c) => [`${c.birth} on ${c.asOf}`, c]))("age %s", (_l, c) => {
    const result = ageOn(d(c.birth), d(c.asOf));
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    for (const [key, value] of Object.entries(c.expected)) {
      const actual = result.value[key as keyof typeof result.value];
      expect(typeof actual === "object" ? formatIsoDate(actual) : actual, key).toBe(value);
    }
  });

  it("age is an error when the date of birth is after the date", () => {
    for (const c of data.ageInvalid)
      expect(ageOn(d(c.birth), d(c.asOf))).toEqual({ ok: false, error: c.expectedError });
  });

  const shiftOf = (s: Record<string, number>) => ({
    years: s.years ?? 0,
    months: s.months ?? 0,
    weeks: s.weeks ?? 0,
    days: s.days ?? 0,
  });

  it.each(data.shift.map((c) => [`${c.date} ${c.direction} ${JSON.stringify(c.shift)}`, c]))(
    "shift %s",
    (_l, c) => {
      const result = shiftDate(d(c.date), shiftOf(c.shift), c.direction as "add" | "subtract");
      expect(result.ok).toBe(true);
      if (!result.ok) return;
      expect(formatIsoDate(result.value.date)).toBe(c.expected.date);
      expect(result.value.clamped).toBe(c.expected.clamped);
    },
  );

  it("shifting past the supported range is an error", () => {
    for (const c of data.shiftInvalid)
      expect(shiftDate(d(c.date), shiftOf(c.shift), c.direction as "add" | "subtract")).toEqual({
        ok: false,
        error: c.expectedError,
      });
  });
});

describe("parsing and formatting", () => {
  it("accepts real dates only", () => {
    expect(parseIsoDate("2024-02-29")).toEqual({ year: 2024, month: 2, day: 29 });
    for (const bad of ["2023-02-29", "2026-13-01", "2026-04-31", "2026-1-01", "", "abcd-ef-gh"])
      expect(parseIsoDate(bad), bad).toBeUndefined();
  });

  it("formats dates and durations in words", () => {
    expect(formatLongDate({ year: 2026, month: 10, day: 7 })).toBe("7 October 2026");
    expect(formatYmd({ years: 1, months: 2, days: 3 })).toBe("1 year, 2 months and 3 days");
    expect(formatYmd({ years: 36, months: 0, days: 1 })).toBe("36 years and 1 day");
    expect(formatYmd({ years: 0, months: 0, days: 0 })).toBe("0 days");
    // Regression: a DateDifference also carries weeks, which must not leak into the wording.
    expect(formatYmd(dateDifference(d("2024-01-01"), d("2024-12-31"), true))).toBe("1 year");
  });
});

const MIN = toDayNumber(DATE_RANGE.min);
const MAX = toDayNumber(DATE_RANGE.max);
const dayNumber = fc.integer({ min: MIN, max: MAX });
const date = dayNumber.map(fromDayNumber);

describe("date engine invariants", () => {
  it("day numbers match Date.UTC (time-zone free) across the whole range", () => {
    fc.assert(
      fc.property(date, (p) => {
        return toDayNumber(p) === Date.UTC(p.year, p.month - 1, p.day) / 86_400_000;
      }),
    );
    // And at the boundaries, explicitly.
    for (const p of [DATE_RANGE.min, DATE_RANGE.max])
      expect(toDayNumber(p)).toBe(Date.UTC(p.year, p.month - 1, p.day) / 86_400_000);
  });

  it("day number ↔ date round trip", () => {
    fc.assert(fc.property(dayNumber, (n) => toDayNumber(fromDayNumber(n)) === n));
  });

  it("start + (years, months) + days lands exactly on the end date", () => {
    fc.assert(
      fc.property(date, date, (a, b) => {
        const [start, end] = toDayNumber(a) <= toDayNumber(b) ? [a, b] : [b, a];
        const ymd = calendarDifference(start, end);
        const anchor = addMonths(start, ymd.years * 12 + ymd.months).date;
        return (
          ymd.months >= 0 &&
          ymd.months < 12 &&
          ymd.days >= 0 &&
          ymd.days < 31 &&
          toDayNumber(addDays(anchor, ymd.days)) === toDayNumber(end)
        );
      }),
    );
  });

  it("the difference does not depend on the order the dates are entered", () => {
    fc.assert(
      fc.property(date, date, fc.boolean(), (a, b, inc) => {
        const x = dateDifference(a, b, inc);
        const y = dateDifference(b, a, inc);
        return (
          x.years === y.years &&
          x.months === y.months &&
          x.days === y.days &&
          x.totalDays === y.totalDays
        );
      }),
    );
  });

  it("weekday counts match a day-by-day count", () => {
    fc.assert(
      fc.property(dayNumber, fc.integer({ min: 0, max: 60 }), (n, span) => {
        let brute = 0;
        for (let i = 0; i < span; i += 1) if (isoWeekday(fromDayNumber(n + i)) <= 5) brute += 1;
        return weekdaysBetween(fromDayNumber(n), fromDayNumber(n + span)) === brute;
      }),
    );
  });

  it("adding then subtracting days returns the same date", () => {
    fc.assert(
      fc.property(date, fc.integer({ min: 0, max: 5000 }), (p, days) => {
        const there = shiftDate(p, { years: 0, months: 0, weeks: 0, days }, "add");
        if (!there.ok) return true; // past the range
        const back = shiftDate(
          there.value.date,
          { years: 0, months: 0, weeks: 0, days },
          "subtract",
        );
        return back.ok && toDayNumber(back.value.date) === toDayNumber(p);
      }),
    );
  });

  it("age in whole years only goes up on the birthday", () => {
    fc.assert(
      fc.property(date, fc.integer({ min: 0, max: 40_000 }), (birth, offset) => {
        const asOf = addDays(birth, offset);
        if (toDayNumber(asOf) > MAX) return true;
        const today = ageOn(birth, asOf);
        const yesterday = offset > 0 ? ageOn(birth, addDays(asOf, -1)) : undefined;
        if (!today.ok) return false;
        if (!yesterday || !yesterday.ok) return true;
        const increased = today.value.years > yesterday.value.years;
        return increased === (today.value.daysToNextBirthday === 0);
      }),
    );
  });
});
