import fc from "fast-check";
import { describe, expect, it } from "vitest";
import data from "../fixtures/discount.json";
import { discountByPercent, discountFromSalePrice, stackedDiscount } from "@/lib/calc/discount";
import { compareFields, closeTo } from "./fixture-helpers";

type Case = (typeof data.cases)[number];

function run(c: Case) {
  const i = c.inputs as Record<string, number>;
  if (c.mode === "percentOff") return discountByPercent(i.price!, i.discount!);
  if (c.mode === "fromSalePrice") return discountFromSalePrice(i.price!, i.sale!);
  return stackedDiscount(i.price!, i.first!, i.extra!);
}

describe("discount fixtures (hand-worked, independently verified)", () => {
  it.each(
    data.cases.map((c) => [
      `${c.mode} ${JSON.stringify(c.inputs)}${c.note ? ` — ${c.note}` : ""}`,
      c,
    ]),
  )("%s", (_label, c) => {
    const result = run(c);
    if ("expectedError" in c) {
      expect(result).toEqual({ ok: false, error: c.expectedError });
      return;
    }
    expect(result.ok).toBe(true);
    if (result.ok)
      expect(compareFields({ ...result.value }, c.expected as Record<string, string>)).toEqual([]);
  });
});

describe("discount boundaries and invalid input", () => {
  it("rejects a zero or negative price", () => {
    expect(discountByPercent(0, 10)).toEqual({ ok: false, error: "PRICE_NOT_POSITIVE" });
    expect(discountByPercent(-5, 10)).toEqual({ ok: false, error: "PRICE_NOT_POSITIVE" });
    expect(discountFromSalePrice(0, 0)).toEqual({ ok: false, error: "PRICE_NOT_POSITIVE" });
  });

  it("rejects discounts outside 0–100%", () => {
    expect(discountByPercent(100, -1)).toEqual({ ok: false, error: "DISCOUNT_OUT_OF_RANGE" });
    expect(discountByPercent(100, 100.01)).toEqual({ ok: false, error: "DISCOUNT_OUT_OF_RANGE" });
    expect(stackedDiscount(100, 50, 101)).toEqual({ ok: false, error: "DISCOUNT_OUT_OF_RANGE" });
  });

  it("rejects a negative sale price and values beyond ±10^12", () => {
    expect(discountFromSalePrice(100, -1)).toEqual({ ok: false, error: "SALE_NEGATIVE" });
    expect(discountByPercent(1e12 + 1, 10)).toEqual({ ok: false, error: "OUT_OF_RANGE" });
    expect(discountByPercent(Number.NaN, 10)).toEqual({ ok: false, error: "NOT_A_NUMBER" });
  });

  it("never returns negative zero", () => {
    const r = discountByPercent(500, 100);
    expect(r.ok && Object.is(r.value.final, -0)).toBe(false);
  });
});

const price = fc.integer({ min: 1, max: 100_000_000 }).map((n) => n / 100);
const pct = fc.integer({ min: 0, max: 10_000 }).map((n) => n / 100);

describe("discount invariants", () => {
  it("saving + price paid = original price", () => {
    // A discount only splits the price; nothing is created or lost.
    fc.assert(
      fc.property(price, pct, (p, d) => {
        const r = discountByPercent(p, d);
        return r.ok && closeTo(r.value.saving + r.value.final, p, 1e-12);
      }),
    );
  });

  it("the sale-price mode recovers the percentage the price was reduced by", () => {
    // Modes A and B are inverses; a disagreement means one has a bug.
    fc.assert(
      fc.property(price, pct, (p, d) => {
        const off = discountByPercent(p, d);
        if (!off.ok) return false;
        const back = discountFromSalePrice(p, off.value.final);
        return back.ok && closeTo(back.value.percent, d, 1e-9);
      }),
    );
  });

  it("stacked discounts: order doesn't matter, and the total is never the plain sum (unless one is 0)", () => {
    // (1−a)(1−b) is symmetric, and 1 − (1−a)(1−b) = a + b − ab ≤ a + b.
    fc.assert(
      fc.property(price, pct, pct, (p, a, b) => {
        const ab = stackedDiscount(p, a, b);
        const ba = stackedDiscount(p, b, a);
        if (!ab.ok || !ba.ok) return false;
        const sameEitherWay = closeTo(ab.value.final, ba.value.final, 1e-12);
        const notMoreThanSum = ab.value.percent <= a + b + 1e-9;
        const atLeastLarger = ab.value.percent >= Math.max(a, b) - 1e-9;
        return sameEitherWay && notMoreThanSum && atLeastLarger;
      }),
    );
  });
});
