import fc from "fast-check";
import { describe, expect, it } from "vitest";
import data from "../fixtures/hike.json";
import { convertPeriod, hikeBetweenSalaries, salaryAfterHike } from "@/lib/calc/hike";
import { closeTo, compareFields, parseExpected } from "./fixture-helpers";

describe("hike fixtures (hand-worked, independently verified)", () => {
  it.each(
    data.cases.map((c) => [
      `${c.mode} ${JSON.stringify(c.inputs)}${c.note ? ` — ${c.note}` : ""}`,
      c,
    ]),
  )("%s", (_label, c) => {
    const i = c.inputs as Record<string, number>;
    const result =
      c.mode === "byPercent"
        ? salaryAfterHike(i.current!, i.hike!)
        : hikeBetweenSalaries(i.current!, i.new!);
    expect(result.ok).toBe(true);
    if (result.ok) {
      const { change, result: next, percent } = result.value;
      expect(
        compareFields({ change, result: next, percent }, c.expected as Record<string, string>),
      ).toEqual([]);
    }
  });

  it.each(data.periods.map((p) => [`${p.amount} per ${p.from}`, p]))("period %s", (_l, p) => {
    expect(
      closeTo(convertPeriod(p.amount, p.from as "month" | "year"), parseExpected(p.expected)),
    ).toBe(true);
  });
});

describe("hike direction, boundaries and errors", () => {
  it("labels hikes, cuts and no change", () => {
    const up = salaryAfterHike(100, 5);
    const down = hikeBetweenSalaries(100, 90);
    const same = hikeBetweenSalaries(100, 100);
    expect(up.ok && up.value.direction).toBe("increase");
    expect(down.ok && down.value.direction).toBe("decrease");
    expect(same.ok && same.value.direction).toBe("none");
  });

  it("rejects a current salary of zero or less, hikes outside −100% to 1,000%, and negative new salaries", () => {
    expect(salaryAfterHike(0, 10)).toEqual({ ok: false, error: "SALARY_NOT_POSITIVE" });
    expect(salaryAfterHike(100, -100.5)).toEqual({ ok: false, error: "HIKE_OUT_OF_RANGE" });
    expect(salaryAfterHike(100, 1000.01)).toEqual({ ok: false, error: "HIKE_OUT_OF_RANGE" });
    expect(hikeBetweenSalaries(100, -1)).toEqual({ ok: false, error: "NEW_SALARY_NEGATIVE" });
    expect(hikeBetweenSalaries(Number.POSITIVE_INFINITY, 1)).toEqual({
      ok: false,
      error: "NOT_A_NUMBER",
    });
  });
});

const salary = fc.integer({ min: 1, max: 1_000_000_000 }).map((n) => n / 100);
const hike = fc.integer({ min: -10_000, max: 100_000 }).map((n) => n / 100);

describe("hike invariants", () => {
  it("applying a hike and measuring it back gives the same percentage", () => {
    // The two modes must agree, or one of them is wrong.
    fc.assert(
      fc.property(salary, hike, (c, h) => {
        const after = salaryAfterHike(c, h);
        if (!after.ok) return false;
        const back = hikeBetweenSalaries(c, after.value.result);
        return back.ok && closeTo(back.value.percent, h, 1e-9);
      }),
    );
  });

  it("monthly → yearly → monthly returns the same amount", () => {
    fc.assert(
      fc.property(salary, (m) =>
        closeTo(convertPeriod(convertPeriod(m, "month"), "year"), m, 1e-12),
      ),
    );
  });
});
