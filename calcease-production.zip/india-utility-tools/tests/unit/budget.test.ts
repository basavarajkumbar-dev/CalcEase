import fc from "fast-check";
import { describe, expect, it } from "vitest";
import data from "../fixtures/budget.json";
import { BUDGET_DEFAULTS, salaryBudget, type BudgetInput } from "@/lib/calc/budget";
import { closeTo, parseExpected } from "./fixture-helpers";

const input = (raw: Record<string, number>): BudgetInput =>
  ({ ...BUDGET_DEFAULTS, goal: 0, ...raw }) as BudgetInput;

function get(obj: unknown, path: string): unknown {
  return path.split(".").reduce((o, k) => (o as Record<string, unknown>)[k], obj);
}

describe("budget fixtures (hand-worked, independently verified)", () => {
  it.each(data.cases.map((c) => [c.name, c]))("%s", (_l, c) => {
    const r = salaryBudget(input(c.inputs));
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    for (const [key, want] of Object.entries(c.expected)) {
      const got = get(r.value, key);
      if (want === null) expect(got, key).toBeNull();
      else
        expect(closeTo(got as number, parseExpected(want)), `${key}: ${got} vs ${want}`).toBe(true);
    }
  });

  it.each(data.invalid.map((c) => [c.expectedError, c]))("rejects: %s", (_l, c) => {
    expect(salaryBudget(input(c.inputs))).toEqual({ ok: false, error: c.expectedError });
  });

  it("rejects non-numbers", () => {
    expect(salaryBudget(input({ income: Number.NaN }))).toEqual({
      ok: false,
      error: "NOT_A_NUMBER",
    });
  });
});

const amount = fc.integer({ min: 0, max: 50_000_000 }).map((n) => n / 100);

describe("budget invariants", () => {
  it("the plan and the reference both account for every rupee of income when there is a surplus", () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 1, max: 100_000_000 }).map((n) => n / 100),
        amount,
        amount,
        amount,
        amount,
        (income, ess, emi, wants, inv) => {
          const r = salaryBudget(
            input({ income, essentials: ess, emi, wants, investments: inv, emergencySavings: 0 }),
          );
          if (!r.ok) return false;
          const v = r.value;
          const sum = (a: typeof v.plan) => a.needs + a.debt + a.wants + a.savings + a.investments;
          const refOk = ess + emi > income || closeTo(sum(v.reference), income, 1e-9);
          const planOk = v.unallocated < 0 || closeTo(sum(v.plan), income, 1e-9);
          const split = closeTo(
            v.suggested.toEmergency + v.suggested.toInvestments,
            v.suggested.available,
            1e-9,
          );
          return (
            refOk && planOk && split && v.suggested.toEmergency <= v.emergency.shortfall + 1e-9
          );
        },
      ),
    );
  });
});
