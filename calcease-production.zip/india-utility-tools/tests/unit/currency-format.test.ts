import { describe, expect, it } from "vitest";
import data from "../fixtures/currency-format.json";
import {
  amountInWords,
  compactIndian,
  formatCurrency,
  integerToIndianWords,
  roundToPaise,
} from "@/lib/format/currency";

describe("formatCurrency (fixtures)", () => {
  it.each(data.currency.map((c) => [`${c.value} (${c.paise})`, c]))("%s", (_l, c) => {
    expect(formatCurrency(c.value, c.paise as "auto" | "always" | "never").text).toBe(c.expected);
  });

  it("flags rounding and never shows -₹0", () => {
    expect(formatCurrency(1104.15).isRounded).toBe(false);
    expect(formatCurrency(1104.156).isRounded).toBe(true);
    expect(formatCurrency(-0.001).text).toBe("₹0");
    expect(() => formatCurrency(Number.NaN)).toThrow(RangeError);
  });
});

describe("amountInWords (fixtures)", () => {
  it.each(data.words.map((c) => [String(c.value), c]))("%s", (_l, c) => {
    expect(amountInWords(c.value) ?? null).toBe(c.expected);
  });

  it("rejects negative or fractional input to the integer helper", () => {
    expect(() => integerToIndianWords(-1)).toThrow();
    expect(() => integerToIndianWords(1.5)).toThrow();
  });
});

describe("roundToPaise and compactIndian", () => {
  it("rounds half away from zero at the paise", () => {
    expect(roundToPaise(1.005 * 1000) / 1000).toBeCloseTo(1.005, 10);
    expect(roundToPaise(-2.675)).toBe(-2.68);
    expect(Object.is(roundToPaise(-0.001), -0)).toBe(false);
  });

  it("labels lakh and crore", () => {
    expect(compactIndian(1250000)).toBe("12.5 lakh");
    expect(compactIndian(12500000)).toBe("1.25 crore");
    expect(compactIndian(85000)).toBe("85,000");
  });
});
