import fc from "fast-check";
import { describe, expect, it } from "vitest";
import data from "../fixtures/calculator.json";
import { EXPRESSION_LIMITS, evaluateExpression, plainNumber } from "@/lib/calc/expression";
import { closeTo, parseExpected } from "./fixture-helpers";

describe("calculator fixtures (hand-worked, independently verified)", () => {
  it.each(data.cases.map((c) => [c.expression, c]))("%s", (_l, c) => {
    const r = evaluateExpression(c.expression);
    expect(r.ok).toBe(true);
    if (r.ok) expect(closeTo(r.value, parseExpected(c.expected), 1e-14), `${r.value}`).toBe(true);
  });

  it.each(data.invalid.map((c) => [JSON.stringify(c.expression), c]))("rejects %s", (_l, c) => {
    expect(evaluateExpression(c.expression)).toEqual({ ok: false, error: c.expectedError });
  });
});

describe("calculator boundaries and safety", () => {
  it("shows 0.1 + 0.2 as 0.3 and never prints an exponent", () => {
    const r = evaluateExpression("0.1 + 0.2");
    expect(r.ok && plainNumber(r.value)).toBe("0.3");
    expect(plainNumber(0.0000001)).toBe("0.0000001");
    expect(plainNumber(-0)).toBe("0");
  });

  it("results can be fed back in", () => {
    const first = evaluateExpression("1 ÷ 8");
    expect(first.ok && plainNumber(first.value)).toBe("0.125");
    const again = evaluateExpression(`${first.ok ? plainNumber(first.value) : ""} × 8`);
    expect(again).toEqual({ ok: true, value: 1 });
  });

  it("limits length and nesting", () => {
    expect(evaluateExpression("1+".repeat(150) + "1")).toEqual({ ok: false, error: "TOO_LONG" });
    expect(evaluateExpression("(".repeat(40) + "1" + ")".repeat(40))).toEqual({
      ok: false,
      error: "TOO_LONG",
    });
    expect(
      evaluateExpression(
        "(".repeat(EXPRESSION_LIMITS.maxDepth) + "1" + ")".repeat(EXPRESSION_LIMITS.maxDepth),
      ),
    ).toEqual({ ok: true, value: 1 });
  });

  it("accepts the largest allowed value and rejects anything beyond", () => {
    expect(evaluateExpression("1000000000000000")).toEqual({ ok: true, value: 1e15 });
    expect(evaluateExpression("1000000000000001").ok).toBe(false);
  });

  it("never returns NaN, Infinity or −0, whatever is typed", () => {
    const alphabet = fc.constantFrom(..."0123456789.+-−*×/÷%() ,x".split(""));
    fc.assert(
      fc.property(fc.array(alphabet, { maxLength: 40 }), (chars) => {
        const r = evaluateExpression(chars.join(""));
        return !r.ok || (Number.isFinite(r.value) && !Object.is(r.value, -0));
      }),
      { numRuns: 2000 },
    );
  });

  it("agrees with ordinary arithmetic on random a ○ b", () => {
    const n = fc.integer({ min: -100000, max: 100000 });
    fc.assert(
      fc.property(n, n, fc.constantFrom("+", "−", "×", "÷"), (a, b, op) => {
        const r = evaluateExpression(`${a} ${op} (${b})`);
        if (op === "÷" && b === 0) return !r.ok && r.error === "DIVIDE_BY_ZERO";
        const want = op === "+" ? a + b : op === "−" ? a - b : op === "×" ? a * b : a / b;
        return r.ok && closeTo(r.value, want, 1e-15);
      }),
    );
  });
});
