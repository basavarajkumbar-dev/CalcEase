import { describe, expect, it, vi } from "vitest";
import { clipboardText, shareOrCopy, type ShareData } from "@/lib/share/share";

const DATA: ShareData = {
  title: "Percentage Calculator",
  text: "20% of 500 is 100.",
  url: "https://example.in/p",
};

function abortError() {
  const error = new Error("cancelled");
  error.name = "AbortError";
  return error;
}

describe("shareOrCopy", () => {
  it("uses the Web Share API when available", async () => {
    const share = vi.fn().mockResolvedValue(undefined);
    const writeText = vi.fn();
    expect(await shareOrCopy(DATA, { share, clipboard: { writeText } })).toBe("shared");
    expect(share).toHaveBeenCalledWith(DATA);
    expect(writeText).not.toHaveBeenCalled();
  });

  it("treats closing the share sheet as cancelled, without copying", async () => {
    const writeText = vi.fn();
    const outcome = await shareOrCopy(DATA, {
      share: vi.fn().mockRejectedValue(abortError()),
      clipboard: { writeText },
    });
    expect(outcome).toBe("cancelled");
    expect(writeText).not.toHaveBeenCalled();
  });

  it("falls back to the clipboard when sharing fails for another reason", async () => {
    const writeText = vi.fn().mockResolvedValue(undefined);
    const notAllowed = Object.assign(new Error("no"), { name: "NotAllowedError" });
    const outcome = await shareOrCopy(DATA, {
      share: vi.fn().mockRejectedValue(notAllowed),
      clipboard: { writeText },
    });
    expect(outcome).toBe("copied");
    expect(writeText).toHaveBeenCalledWith("20% of 500 is 100.\nhttps://example.in/p");
  });

  it("copies when the browser has no Web Share API (most desktops)", async () => {
    const writeText = vi.fn().mockResolvedValue(undefined);
    expect(await shareOrCopy(DATA, { clipboard: { writeText } })).toBe("copied");
  });

  it("respects canShare returning false", async () => {
    const share = vi.fn();
    const writeText = vi.fn().mockResolvedValue(undefined);
    expect(
      await shareOrCopy(DATA, { share, canShare: () => false, clipboard: { writeText } }),
    ).toBe("copied");
    expect(share).not.toHaveBeenCalled();
  });

  it("reports unavailable when neither sharing nor the clipboard works", async () => {
    expect(await shareOrCopy(DATA, {})).toBe("unavailable");
    expect(
      await shareOrCopy(DATA, {
        clipboard: { writeText: vi.fn().mockRejectedValue(new Error("denied")) },
      }),
    ).toBe("unavailable");
  });

  it("clipboard text is the message then the link", () => {
    expect(clipboardText(DATA)).toBe("20% of 500 is 100.\nhttps://example.in/p");
  });
});
