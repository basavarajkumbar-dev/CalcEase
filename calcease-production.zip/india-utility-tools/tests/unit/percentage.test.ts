import { describe, expect, it } from "vitest";
import {
  calculateDecreaseBy,
  calculateIncreaseBy,
  calculatePercentChange,
  calculatePercentOf,
  calculateWhatPercent,
  changeDirection,
  getMode,
  PERCENTAGE_MODES,
  MAX_ABS_INPUT,
  type PercentageMode,
} from "@/lib/calc/percentage";
import {
  calculationCases,
  closeTo,
  invalidInputCases,
  orderedInputs,
  parseExpected,
} from "./fixtures";

function run(mode: string, a: number, b: number) {
  return getMode(mode as PercentageMode).calculate(a, b);
}

describe("percentage fixtures (hand-derived, independently verified)", () => {
  it.each(
    calculationCases.map((c) => [
      `${c.mode} ${JSON.stringify(c.inputs)}${c.note ? ` — ${c.note}` : ""}`,
      c,
    ]),
  )("%s", (_label, c) => {
    const [a, b] = orderedInputs(c.mode, c.inputs);
    const result = run(c.mode, a, b);
    if (c.expectedError) {
      expect(result).toEqual({ ok: false, error: c.expectedError });
      return;
    }
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    const expected = parseExpected(c.expected!);
    expect(closeTo(result.value, expected), `got ${result.value}, expected ${expected}`).toBe(true);
  });

  it.each(invalidInputCases.map((c) => [`${c.mode} ${JSON.stringify(c.inputs)}`, c]))(
    "rejects invalid input: %s",
    (_label, c) => {
      const [a, b] = orderedInputs(c.mode, c.inputs);
      expect(run(c.mode, a, b)).toEqual({ ok: false, error: c.expectedError });
    },
  );
});

describe("exactness of the brief's examples", () => {
  // These examples have exact decimal answers, so they must be exactly equal,
  // not merely within tolerance (spec, section 1: multiply before dividing).
  it("20% of 500 is exactly 100", () =>
    expect(calculatePercentOf(20, 500)).toEqual({ ok: true, value: 100 }));
  it("10% of 1000 is exactly 100", () =>
    expect(calculatePercentOf(10, 1000)).toEqual({ ok: true, value: 100 }));
  it("25% of 80 is exactly 20", () =>
    expect(calculatePercentOf(25, 80)).toEqual({ ok: true, value: 20 }));
  it("12.5% of 80 is exactly 10", () =>
    expect(calculatePercentOf(12.5, 80)).toEqual({ ok: true, value: 10 }));
  it("7.5% of 200 is exactly 15", () =>
    expect(calculatePercentOf(7.5, 200)).toEqual({ ok: true, value: 15 }));
  it("100 is exactly 20% of 500", () =>
    expect(calculateWhatPercent(100, 500)).toEqual({ ok: true, value: 20 }));
  it("500 → 600 is exactly +20%", () =>
    expect(calculatePercentChange(500, 600)).toEqual({ ok: true, value: 20 }));
  it("500 + 20% is exactly 600", () =>
    expect(calculateIncreaseBy(500, 20)).toEqual({ ok: true, value: 600 }));
  it("500 − 20% is exactly 400", () =>
    expect(calculateDecreaseBy(500, 20)).toEqual({ ok: true, value: 400 }));
  it("600 → 500 is −16.666…% to full double precision", () => {
    const result = calculatePercentChange(600, 500);
    expect(result.ok && result.value).toBe(-100 / 6);
  });
});

describe("zero handling", () => {
  it("never returns negative zero", () => {
    const results = [
      calculatePercentOf(0, -500),
      calculatePercentOf(-20, 0),
      calculateWhatPercent(0, -5),
      calculatePercentChange(-5, -5),
      calculateIncreaseBy(-0, 20),
      calculateDecreaseBy(0, 150),
    ];
    for (const result of results) {
      expect(result.ok).toBe(true);
      if (result.ok) expect(Object.is(result.value, -0)).toBe(false);
    }
  });

  it("whole = 0 and from = 0 are division-by-zero errors, not Infinity or NaN", () => {
    expect(calculateWhatPercent(5, 0)).toEqual({ ok: false, error: "DIVISION_BY_ZERO" });
    expect(calculateWhatPercent(0, 0)).toEqual({ ok: false, error: "DIVISION_BY_ZERO" });
    expect(calculatePercentChange(0, 5)).toEqual({ ok: false, error: "DIVISION_BY_ZERO" });
    expect(calculatePercentChange(-0, 0)).toEqual({ ok: false, error: "DIVISION_BY_ZERO" });
  });
});

describe("range boundaries", () => {
  const fns = [
    calculatePercentOf,
    calculateWhatPercent,
    calculatePercentChange,
    calculateIncreaseBy,
    calculateDecreaseBy,
  ];

  it.each(fns.map((fn) => [fn.name, fn]))("%s accepts exactly ±10^12", (_name, fn) => {
    expect(fn(MAX_ABS_INPUT, MAX_ABS_INPUT).ok).toBe(true);
    expect(fn(-MAX_ABS_INPUT, -MAX_ABS_INPUT).ok).toBe(true);
  });

  it.each(fns.map((fn) => [fn.name, fn]))("%s rejects values just beyond ±10^12", (_name, fn) => {
    const justAbove = MAX_ABS_INPUT + 1;
    expect(fn(justAbove, 1)).toEqual({ ok: false, error: "OUT_OF_RANGE" });
    expect(fn(1, -justAbove)).toEqual({ ok: false, error: "OUT_OF_RANGE" });
  });

  it.each(fns.map((fn) => [fn.name, fn]))("%s rejects NaN and Infinity", (_name, fn) => {
    expect(fn(Number.NaN, 1)).toEqual({ ok: false, error: "NOT_A_NUMBER" });
    expect(fn(1, Number.POSITIVE_INFINITY)).toEqual({ ok: false, error: "NOT_A_NUMBER" });
    expect(fn(Number.NEGATIVE_INFINITY, 1)).toEqual({ ok: false, error: "NOT_A_NUMBER" });
  });

  it("reports NOT_A_NUMBER before OUT_OF_RANGE when both apply", () => {
    expect(calculatePercentOf(2e12, Number.NaN)).toEqual({ ok: false, error: "NOT_A_NUMBER" });
  });

  it("largest possible result (10^12 % of 10^12) is finite and exact", () => {
    expect(calculatePercentOf(MAX_ABS_INPUT, MAX_ABS_INPUT)).toEqual({ ok: true, value: 1e22 });
  });

  it("rejects values passed as strings at runtime (no string arithmetic)", () => {
    // Simulates an untyped caller such as a future API handing over raw JSON strings.
    const unsafe = calculatePercentOf as unknown as (a: unknown, b: unknown) => unknown;
    expect(unsafe("20", "500")).toEqual({ ok: false, error: "NOT_A_NUMBER" });
  });
});

describe("regressions", () => {
  // Every bug found becomes a permanent test (Phase 2 brief, section 9).

  it("2026-10-07: change from a subnormal start overflows to RESULT_TOO_LARGE, not NOT_A_NUMBER", () => {
    // Found by the property test. (to − from) × 100 ÷ 5e-324 is −Infinity in doubles.
    expect(calculatePercentChange(5e-324, -8.881784197001253e-18)).toEqual({
      ok: false,
      error: "RESULT_TOO_LARGE",
    });
    expect(calculateWhatPercent(1e12, 1e-320)).toEqual({ ok: false, error: "RESULT_TOO_LARGE" });
  });
});

describe("changeDirection", () => {
  it("labels increases, decreases and no change", () => {
    expect(changeDirection(20)).toBe("increase");
    expect(changeDirection(-16.67)).toBe("decrease");
    expect(changeDirection(0)).toBe("none");
  });
});

describe("mode registry", () => {
  it("exposes five modes with unique ids, each wired to a calculation", () => {
    const ids = PERCENTAGE_MODES.map((m) => m.id);
    expect(new Set(ids).size).toBe(5);
    for (const mode of PERCENTAGE_MODES) expect(typeof mode.calculate).toBe("function");
  });

  it("each mode's own example inputs produce a valid result", () => {
    for (const mode of PERCENTAGE_MODES) {
      const result = mode.calculate(Number(mode.inputs[0].example), Number(mode.inputs[1].example));
      expect(result.ok, mode.id).toBe(true);
    }
  });

  it("throws for an unknown mode id (programmer error, not user error)", () => {
    expect(() => getMode("nope" as PercentageMode)).toThrow();
  });
});
