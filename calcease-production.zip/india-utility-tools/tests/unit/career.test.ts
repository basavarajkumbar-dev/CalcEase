import fc from "fast-check";
import { describe, expect, it } from "vitest";
import data from "../fixtures/career.json";
import { noticePeriod, workExperience } from "@/lib/calc/career";
import {
  addDays,
  formatIsoDate,
  fromDayNumber,
  parseIsoDate,
  toDayNumber,
  type PlainDate,
} from "@/lib/calc/date";

const d = (t: string): PlainDate => parseIsoDate(t)!;

describe("career fixtures (hand-worked, independently verified)", () => {
  it.each(
    data.experience.map((c) => [`${c.joining} → ${c.end}${c.includeEnd ? " incl." : ""}`, c]),
  )("experience %s", (_l, c) => {
    const r = workExperience(d(c.joining), d(c.end), c.includeEnd);
    expect(r.ok).toBe(true);
    if (r.ok)
      for (const [k, v] of Object.entries(c.expected))
        expect(r.value[k as keyof typeof r.value], k).toBe(v);
  });

  it("experience: an end date before the joining date is an error", () => {
    for (const c of data.experienceInvalid)
      expect(workExperience(d(c.joining), d(c.end))).toEqual({ ok: false, error: c.expectedError });
  });

  it.each(
    data.notice.map((c) => [
      `${c.resignation} + ${c.days}${c.countResignationDay ? " (day 1)" : ""}`,
      c,
    ]),
  )("notice %s", (_l, c) => {
    const r = noticePeriod(
      d(c.resignation),
      c.days,
      c.countResignationDay,
      c.today ? d(c.today) : undefined,
    );
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    for (const [k, v] of Object.entries(c.expected)) {
      const got = r.value[k as keyof typeof r.value];
      expect(typeof got === "object" ? formatIsoDate(got) : got, k).toBe(v);
    }
  });

  it("notice: days outside 1 to 365 are rejected", () => {
    for (const c of data.noticeInvalid)
      expect(noticePeriod(d(c.resignation), c.days)).toEqual({ ok: false, error: c.expectedError });
    expect(noticePeriod(d("2026-10-08"), 30.5)).toEqual({
      ok: false,
      error: "NOTICE_OUT_OF_RANGE",
    });
  });
});

const day = fc.integer({ min: toDayNumber(d("1950-01-01")), max: toDayNumber(d("2150-01-01")) });

describe("career invariants", () => {
  it("a notice period of N days spans exactly N calendar days", () => {
    fc.assert(
      fc.property(day, fc.integer({ min: 1, max: 365 }), fc.boolean(), (n, days, day1) => {
        const r = noticePeriod(fromDayNumber(n), days, day1);
        return (
          r.ok &&
          toDayNumber(r.value.lastWorkingDay) - toDayNumber(r.value.firstNoticeDay) + 1 === days
        );
      }),
    );
  });

  it("inclusive experience is one day more than exclusive", () => {
    fc.assert(
      fc.property(day, fc.integer({ min: 0, max: 15000 }), (n, span) => {
        const a = fromDayNumber(n);
        const b = addDays(a, span);
        const inc = workExperience(a, b, true);
        const exc = workExperience(a, b, false);
        return inc.ok && exc.ok && inc.value.totalDays === exc.value.totalDays + 1;
      }),
    );
  });
});
