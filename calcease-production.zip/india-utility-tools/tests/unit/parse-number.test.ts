import { describe, expect, it } from "vitest";
import { parseNumberInput } from "@/lib/validation/parse-number";
import { parsingCases } from "./fixtures";

describe("parseNumberInput (fixtures)", () => {
  it.each(parsingCases.map((c) => [JSON.stringify(c.text) + (c.note ? ` — ${c.note}` : ""), c]))(
    "%s",
    (_label, c) => {
      const result = parseNumberInput(c.text);
      if (c.expectedError) {
        expect(result).toEqual({ ok: false, error: c.expectedError });
      } else {
        expect(result).toEqual({ ok: true, value: c.expected });
      }
    },
  );

  it("normalises -0 to 0", () => {
    const result = parseNumberInput("-0");
    expect(result.ok && Object.is(result.value, -0)).toBe(false);
  });
});
