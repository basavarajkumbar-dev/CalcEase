import fc from "fast-check";
import { describe, expect, it } from "vitest";
import data from "../fixtures/emi-sip.json";
import { sipValue, type MonthlyRateMethod } from "@/lib/calc/invest";
import { balanceAfter, emiAmount, loanEmi } from "@/lib/calc/loan";
import { closeTo, parseExpected } from "./fixture-helpers";

function compare(actual: Record<string, unknown>, expected: Record<string, unknown>) {
  for (const [key, want] of Object.entries(expected)) {
    const got = actual[key];
    if (typeof want === "string")
      expect(closeTo(got as number, parseExpected(want), 1e-11), `${key}: ${got} vs ${want}`).toBe(
        true,
      );
    else expect(got, key).toBe(want);
  }
}

type EmiInputs = {
  principal: number;
  rate: number;
  months: number;
  prepayAfter?: number;
  prepay?: number;
};
const runEmi = (i: EmiInputs) =>
  loanEmi(
    i.principal,
    i.rate,
    i.months,
    i.prepayAfter !== undefined ? { afterMonth: i.prepayAfter, amount: i.prepay! } : undefined,
  );

describe("EMI and SIP fixtures (independently verified)", () => {
  it.each(data.emi.map((c) => [JSON.stringify(c.inputs), c]))("emi %s", (_l, c) => {
    const r = runEmi(c.inputs);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    compare({ ...r.value }, c.expected);
    const last = r.value.schedule[r.value.schedule.length - 1]!;
    expect(last.balance).toBe(0);
    if (c.reference) expect(Math.round(r.value.emi)).toBe(c.reference.rupees);
  });

  it.each(data.emiInvalid.map((c) => [c.expectedError, c]))("emi rejects %s", (_l, c) => {
    expect(runEmi(c.inputs)).toEqual({ ok: false, error: c.expectedError });
  });

  it.each(data.sip.map((c) => [JSON.stringify(c.inputs), c]))("sip %s", (_l, c) => {
    const i = c.inputs;
    const r = sipValue(
      i.instalment,
      i.annualReturn,
      i.years,
      i.stepUp,
      i.method as MonthlyRateMethod,
    );
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    compare({ ...r.value }, c.expected);
    if (c.reference) expect(Math.trunc(r.value.value)).toBe(c.reference.rupees);
  });

  it.each(data.sipInvalid.map((c) => [c.expectedError, c]))("sip rejects %s", (_l, c) => {
    const i = c.inputs;
    expect(
      sipValue(i.instalment, i.annualReturn, i.years, i.stepUp, i.method as MonthlyRateMethod),
    ).toEqual({ ok: false, error: c.expectedError });
  });
});

const principal = fc.integer({ min: 1000, max: 1_000_000_000 });
const rate = fc.integer({ min: 0, max: 3000 }).map((n) => n / 100);
const months = fc.integer({ min: 1, max: 480 });

describe("EMI invariants", () => {
  it("the schedule repays exactly the loan and closes at zero", () => {
    fc.assert(
      fc.property(principal, rate, months, (p, r, n) => {
        const res = loanEmi(p, r, n);
        if (!res.ok) return false;
        const s = res.value.schedule;
        const repaid = s.reduce((sum, row) => sum + row.principal, 0);
        const interest = s.reduce((sum, row) => sum + row.interest, 0);
        return (
          s.length === n &&
          s[s.length - 1]!.balance === 0 &&
          closeTo(repaid, p, 1e-9) &&
          closeTo(interest, res.value.totalInterest, 1e-9) &&
          // emi × n − P and the month-by-month sum differ only by floating-point error,
          // which compounds with (1 + r)^n: at most ~1e-11 of everything repaid at 30% over
          // 40 years (fast-check, 20,000 runs). Allow 1e-10: under a paisa for any loan up
          // to ₹1 crore. Exact-fraction fixtures check the values themselves.
          Math.abs(res.value.emi * n - p - res.value.totalInterest) <=
            res.value.emi * n * 1e-10 + 1e-9 &&
          s.every((row) => row.balance >= 0)
        );
      }),
    );
  });

  it("the balance formula agrees with the schedule", () => {
    fc.assert(
      fc.property(principal, rate, months, fc.nat(), (p, r, n, k) => {
        const res = loanEmi(p, r, n);
        if (!res.ok || n < 2) return true;
        const after = (k % (n - 1)) + 1;
        // Near the end the balance is small, so compare against the loan's size: the
        // closed form and the month-by-month schedule round differently (≤ 1e-10 of P).
        const diff = Math.abs(
          balanceAfter(p, r, n, after) - res.value.schedule[after - 1]!.balance,
        );
        return diff <= p * 1e-10;
      }),
    );
  });

  it("a prepayment shortens the loan and never increases the interest", () => {
    fc.assert(
      fc.property(
        principal,
        rate,
        fc.integer({ min: 12, max: 360 }),
        fc.double({ min: 0.01, max: 0.9, noNaN: true }),
        (p, r, n, share) => {
          const base = loanEmi(p, r, n);
          if (!base.ok) return false;
          const after = Math.floor(n / 2);
          const amount = Math.round(balanceAfter(p, r, n, after) * share);
          if (amount <= 0) return true;
          const pre = loanEmi(p, r, n, { afterMonth: after, amount });
          return (
            pre.ok &&
            pre.value.months <= n &&
            pre.value.totalInterest <= base.value.totalInterest + 1e-6 &&
            pre.value.schedule[pre.value.schedule.length - 1]!.balance === 0
          );
        },
      ),
    );
  });

  it("EMI at 0% is the loan divided by the months", () => {
    expect(emiAmount(120000, 0, 12)).toBe(10000);
  });
});

describe("SIP invariants", () => {
  it("matches adding up every instalment's growth", () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 100, max: 1_000_000 }),
        fc.integer({ min: 0, max: 3000 }).map((n) => n / 100),
        fc.integer({ min: 1, max: 30 }),
        fc.integer({ min: 0, max: 20 }),
        fc.constantFrom<MonthlyRateMethod>("divide12", "equivalent"),
        (p, r, years, step, method) => {
          const res = sipValue(p, r, years, step, method);
          if (!res.ok) return false;
          const i = res.value.monthlyRate / 100;
          const n = years * 12;
          let sum = 0;
          for (let k = 1; k <= n; k += 1)
            sum +=
              p * Math.pow(1 + step / 100, Math.floor((k - 1) / 12)) * Math.pow(1 + i, n - k + 1);
          return closeTo(res.value.value, sum, 1e-10);
        },
      ),
    );
  });

  it("the monthly equivalent compounds back to the yearly return", () => {
    const res = sipValue(1000, 12, 1, 0, "equivalent");
    expect(res.ok && closeTo(Math.pow(1 + res.value.monthlyRate / 100, 12), 1.12, 1e-14)).toBe(
      true,
    );
  });
});
