import { describe, expect, it } from "vitest";
import { MAX_RESULTS, normaliseQuery, SEARCH_SUGGESTIONS, searchTools } from "@/lib/tools/search";
import { TOOLS, type ToolDefinition } from "@/lib/tools/registry";

function active(
  overrides: Partial<ToolDefinition> & { slug: string; name: string },
): ToolDefinition {
  return {
    id: overrides.slug,
    category: "math",
    shortDescription: "",
    keywords: [],
    status: "active",
    title: "",
    metaDescription: "",
    related: [],
    featured: false,
    lastReviewed: "2026-10-07",
    ...overrides,
  } as ToolDefinition;
}

function planned(
  overrides: Partial<ToolDefinition> & { slug: string; name: string },
): ToolDefinition {
  return {
    id: overrides.slug,
    category: "finance",
    shortDescription: "",
    keywords: [],
    ...overrides,
    status: "coming-soon",
  } as ToolDefinition;
}

const SAMPLE = [
  active({
    slug: "percentage",
    name: "Percentage Calculator",
    keywords: ["discount", "hike"],
    shortDescription: "Percent of a number",
  }),
  planned({
    slug: "emi",
    name: "EMI Calculator",
    keywords: ["loan"],
    shortDescription: "Monthly loan instalment",
  }),
  active({ slug: "alpha", name: "Alpha", keywords: ["calculator"] }),
];

describe("searchTools (sample registry)", () => {
  it("returns nothing for empty or whitespace-only queries", () => {
    expect(searchTools("", SAMPLE)).toEqual([]);
    expect(searchTools("   \t ", SAMPLE)).toEqual([]);
  });

  it("is case-insensitive and tolerant of extra whitespace", () => {
    for (const q of ["PERC", "perc", "  Percentage   calculator  "]) {
      expect(searchTools(q, SAMPLE)[0]?.slug, q).toBe("percentage");
    }
  });

  it("matches keywords, descriptions and category names", () => {
    expect(searchTools("discount", SAMPLE).map((t) => t.slug)).toEqual(["percentage"]);
    expect(searchTools("instalment", SAMPLE).map((t) => t.slug)).toEqual(["emi"]);
    expect(searchTools("everyday", SAMPLE).map((t) => t.slug)).toContain("percentage");
  });

  it("requires every word to match", () => {
    expect(searchTools("loan percentage", SAMPLE)).toEqual([]);
  });

  it("lists active tools before coming-soon tools, then by score", () => {
    const slugs = searchTools("calculator", SAMPLE).map((t) => t.slug);
    expect(slugs.at(-1)).toBe("emi");
    expect(slugs.slice(0, 2).sort()).toEqual(["alpha", "percentage"]);
  });

  it("ignores punctuation and accents", () => {
    expect(normaliseQuery("  Percént-Calc! ")).toBe("percent calc");
  });
});

describe("searchTools (real registry)", () => {
  it("finds the Percentage Calculator by name, keyword and category", () => {
    for (const q of ["percentage", "Percent", "%", "hike", "math"]) {
      expect(
        searchTools(q, TOOLS).find((t) => t.slug === "percentage-calculator"),
        q,
      ).toBeDefined();
    }
  });

  it("finds planned tools honestly: 'ctc' returns the CTC calculator held under review", () => {
    const [first] = searchTools("ctc", TOOLS);
    expect(first?.name).toBe("CTC to In-Hand Salary Calculator");
    expect(first?.status).toBe("coming-soon");
  });

  it("finds published tools: 'emi' returns the EMI Calculator", () => {
    const [first] = searchTools("emi", TOOLS);
    expect(first?.name).toBe("EMI Calculator");
    expect(first?.status).toBe("active");
  });

  it("'loan' finds finance tools", () => {
    const results = searchTools("loan", TOOLS);
    expect(results.length).toBeGreaterThan(0);
    expect(results.every((t) => t.category === "finance")).toBe(true);
  });

  it("a single letter matches only the start of a name or keyword word, and results are capped", () => {
    const results = searchTools("p", TOOLS);
    expect(results.length).toBeLessThanOrEqual(MAX_RESULTS);
    // Name matches ("Percentage …", "Notice Period …") come first; ties sort by name.
    expect(results.map((t) => t.slug)).toContain("percentage-calculator");
    expect(results[0]?.name.split(" ").some((w) => w.toLowerCase().startsWith("p"))).toBe(true);
    for (const tool of results) {
      const words = [tool.name, ...tool.keywords].join(" ").toLowerCase().split(/\s+/);
      expect(
        words.some((w) => w.startsWith("p")),
        tool.name,
      ).toBe(true);
    }
    expect(searchTools("calculator", TOOLS).length).toBe(MAX_RESULTS);
  });

  it("returns nothing for nonsense", () => {
    expect(searchTools("xyzzy", TOOLS)).toEqual([]);
  });

  it.each(SEARCH_SUGGESTIONS)(
    "the no-results suggestion %s returns at least one tool",
    (suggestion) => {
      expect(searchTools(suggestion, TOOLS).length).toBeGreaterThan(0);
    },
  );
});
