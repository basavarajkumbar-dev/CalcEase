import fc from "fast-check";
import { describe, expect, it } from "vitest";
import data from "../fixtures/lumpsum.json";
import { lumpsumValue } from "@/lib/calc/invest";
import { closeTo, parseExpected } from "./fixture-helpers";

describe("lumpsum fixtures (hand-worked, independently verified)", () => {
  it.each(data.cases.map((c) => [JSON.stringify(c.inputs), c]))("%s", (_l, c) => {
    const i = c.inputs;
    const r = lumpsumValue(i.amount, i.annualReturn, i.years);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    for (const [key, want] of Object.entries(c.expected))
      expect(closeTo(r.value[key as "value" | "gains"], parseExpected(want)), key).toBe(true);
    expect(r.value.invested).toBe(i.amount);
    if (c.reference) expect(Math.round(r.value.value)).toBe(c.reference.rupees);
  });

  it.each(data.invalid.map((c) => [JSON.stringify(c.inputs), c]))("rejects %s", (_l, c) => {
    const i = c.inputs;
    expect(lumpsumValue(i.amount, i.annualReturn, i.years)).toEqual({
      ok: false,
      error: c.expectedError,
    });
  });

  it("rejects non-finite input", () => {
    expect(lumpsumValue(Number.NaN, 12, 5)).toEqual({ ok: false, error: "NOT_A_NUMBER" });
  });
});

describe("lumpsum invariants", () => {
  it("the year table ends at the value, and each year grows by the return", () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 1, max: 1_000_000_000 }),
        fc.integer({ min: 0, max: 5000 }).map((n) => n / 100),
        fc.integer({ min: 1, max: 50 }),
        (p, r, n) => {
          const res = lumpsumValue(p, r, n);
          if (!res.ok) return false;
          const rows = res.value.years;
          return (
            rows.length === n &&
            rows[n - 1]!.value === res.value.value &&
            rows.every((row, k) =>
              closeTo(row.value, (k === 0 ? p : rows[k - 1]!.value) * (1 + r / 100), 1e-12),
            ) &&
            res.value.gains >= 0
          );
        },
      ),
    );
  });
});
