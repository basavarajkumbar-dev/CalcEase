import { describe, expect, it } from "vitest";
import {
  activeTools,
  CATEGORIES,
  categoriesWithHubs,
  categoryHref,
  getActiveTool,
  isActive,
  plannedTools,
  relatedActiveTools,
  TOOLS,
  toolHref,
} from "@/lib/tools/registry";
import { SITE_PAGES } from "@/config/site";

const SLUG = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;

describe("tool registry integrity", () => {
  it("has no duplicate ids or slugs", () => {
    expect(new Set(TOOLS.map((t) => t.id)).size).toBe(TOOLS.length);
    expect(new Set(TOOLS.map((t) => t.slug)).size).toBe(TOOLS.length);
  });

  it("every slug is lower-case kebab-case and every tool's category exists", () => {
    const categories = new Set(CATEGORIES.map((c) => c.id));
    for (const tool of TOOLS) {
      expect(tool.slug, tool.id).toMatch(SLUG);
      expect(categories.has(tool.category), tool.id).toBe(true);
    }
  });

  it("tool slugs never collide with category slugs or site pages (they share the root URL space)", () => {
    const reserved = new Set([
      ...CATEGORIES.map((c) => c.slug),
      ...SITE_PAGES.map((p) => p.href.slice(1)),
      "tools",
    ]);
    for (const tool of TOOLS) expect(reserved.has(tool.slug), tool.slug).toBe(false);
  });

  it("every active tool has a valid href, title, description and review date", () => {
    for (const tool of activeTools()) {
      expect(toolHref(tool)).toBe(`/${tool.slug}`);
      expect(tool.title.length, tool.id).toBeGreaterThan(10);
      expect(tool.metaDescription.length, tool.id).toBeGreaterThanOrEqual(100);
      expect(tool.metaDescription.length, tool.id).toBeLessThanOrEqual(170);
      expect(Number.isNaN(Date.parse(tool.lastReviewed)), tool.id).toBe(false);
    }
  });

  it("the released tools are exactly the ones signed off (update this list deliberately)", () => {
    // Publishing a tool is a deliberate act: it must pass its spec, fixtures and tests,
    // and then be added here. A tool switched to active by accident fails this test.
    expect(
      activeTools()
        .map((t) => t.slug)
        .sort(),
    ).toEqual(
      [
        "age-calculator",
        "calculator",
        "compound-interest-calculator",
        "date-add-subtract-calculator",
        "date-difference-calculator",
        "discount-calculator",
        "emi-calculator",
        "experience-calculator",
        "fd-calculator",
        "gst-calculator",
        "lumpsum-calculator",
        "notice-period-calculator",
        "percentage-calculator",
        "percentage-hike-calculator",
        "rd-calculator",
        "salary-budget-planner",
        "sip-calculator",
      ].sort(),
    );
    const tool = getActiveTool("percentage-calculator");
    expect(tool.category).toBe("math");
    expect(toolHref(tool)).toBe("/percentage-calculator");
  });

  it("refuses to hand out a coming-soon tool as active (build fails instead of a broken page)", () => {
    expect(() => getActiveTool("ctc-to-in-hand-salary-calculator")).toThrow(/not active/);
    expect(() => getActiveTool("no-such-tool")).toThrow(/not registered/);
  });

  it("related-tool references all exist, never point to themselves, and only active ones are shown", () => {
    const slugs = new Set(TOOLS.map((t) => t.slug));
    for (const tool of activeTools()) {
      for (const related of tool.related) {
        expect(slugs.has(related), `${tool.slug} → ${related}`).toBe(true);
        expect(related).not.toBe(tool.slug);
      }
      expect(relatedActiveTools(tool).every(isActive)).toBe(true);
    }
  });

  it("every category has at least one tool (active or planned) and unique slugs", () => {
    expect(new Set(CATEGORIES.map((c) => c.slug)).size).toBe(CATEGORIES.length);
    for (const category of CATEGORIES) {
      expect(
        TOOLS.some((t) => t.category === category.id),
        category.id,
      ).toBe(true);
    }
  });

  it("a category gets a hub page and a link exactly when it has an active tool", () => {
    for (const category of CATEGORIES) {
      const hasActive = activeTools().some((t) => t.category === category.id);
      expect(
        categoriesWithHubs().some((c) => c.id === category.id),
        category.id,
      ).toBe(hasActive);
      expect(categoryHref(category.id), category.id).toBe(
        hasActive ? `/${category.slug}` : undefined,
      );
    }
  });

  it("planned tools carry no page fields", () => {
    for (const tool of plannedTools()) {
      expect("title" in tool, tool.id).toBe(false);
      expect("lastReviewed" in tool, tool.id).toBe(false);
    }
  });
});
