import fc from "fast-check";
import { describe, expect, it } from "vitest";
import data from "../fixtures/gst.json";
import { gstExclusive, gstInclusive } from "@/lib/calc/gst";
import { CURRENT_GST_RULES, GST_RULE_SETS, gstRulesOn } from "@/lib/rules/gst/rates";
import { closeTo, compareFields } from "./fixture-helpers";

const run = (mode: string, i: { amount: number; rate: number }) =>
  mode === "exclusive" ? gstExclusive(i.amount, i.rate) : gstInclusive(i.amount, i.rate);

describe("GST fixtures (hand-worked, independently verified)", () => {
  it.each(data.cases.map((c) => [`${c.mode} ${JSON.stringify(c.inputs)}`, c]))(
    "%s",
    (_label, c) => {
      const result = run(c.mode, c.inputs);
      expect(result.ok).toBe(true);
      if (result.ok)
        expect(compareFields({ ...result.value }, c.expected as Record<string, string>)).toEqual(
          [],
        );
    },
  );

  it.each(data.invalid.map((c) => [`${c.mode} ${JSON.stringify(c.inputs)}`, c]))(
    "rejects %s",
    (_label, c) => {
      expect(run(c.mode, c.inputs)).toEqual({ ok: false, error: c.expectedError });
    },
  );

  it("rejects non-finite input", () => {
    expect(gstExclusive(Number.NaN, 18)).toEqual({ ok: false, error: "NOT_A_NUMBER" });
    expect(gstInclusive(2e12, 18)).toEqual({ ok: false, error: "OUT_OF_RANGE" });
  });
});

const amount = fc.integer({ min: 1, max: 100_000_000_000_000 }).map((n) => n / 100);
const rate = fc.integer({ min: 0, max: 10_000 }).map((n) => n / 100);

describe("GST invariants", () => {
  it("removing GST from a price that was just taxed gives the original price back", () => {
    // Prices up to ₹50,000 crore, so the taxed total (at most double) stays within range.
    const price = fc.integer({ min: 1, max: 50_000_000_000_000 }).map((n) => n / 100);
    fc.assert(
      fc.property(price, rate, (a, r) => {
        const added = gstExclusive(a, r);
        if (!added.ok) return false;
        const removed = gstInclusive(added.value.total, r);
        return (
          removed.ok &&
          closeTo(removed.value.base, a, 1e-12) &&
          closeTo(removed.value.gst, added.value.gst, 1e-9) &&
          removed.value.total === added.value.total
        );
      }),
    );
  });

  it("base + GST = total, and the two halves add up to the GST", () => {
    fc.assert(
      fc.property(amount, rate, fc.boolean(), (a, r, inclusive) => {
        const res = inclusive ? gstInclusive(a, r) : gstExclusive(a, r);
        if (!res.ok) return false;
        const { base, gst, total, half } = res.value;
        return closeTo(base + gst, total, 1e-12) && half * 2 === gst && gst >= 0;
      }),
    );
  });
});

describe("GST rule data", () => {
  it("every rule set records its sources, retrieval dates and review date", () => {
    for (const set of GST_RULE_SETS) {
      expect(set.sources.length).toBeGreaterThan(0);
      for (const s of set.sources) {
        expect(s.url).toMatch(/^https:\/\/(www\.)?(pib\.gov\.in|gstcouncil\.gov\.in)\//);
        expect(s.retrieved).toMatch(/^\d{4}-\d{2}-\d{2}$/);
      }
      expect(set.reviewedOn).toMatch(/^\d{4}-\d{2}-\d{2}$/);
    }
  });

  it("current presets are the 56th GST Council structure (5%, 18%, 40%)", () => {
    expect(CURRENT_GST_RULES.presets.map((p) => p.rate)).toEqual([5, 18, 40]);
  });

  it("looks up the rule set by date", () => {
    expect(gstRulesOn("2025-09-22")?.version).toBe("2025-09-22");
    expect(gstRulesOn("2026-10-07")?.version).toBe("2025-09-22");
    // Before the first recorded rule set there is no data, rather than a guess.
    expect(gstRulesOn("2025-09-21")).toBeUndefined();
  });
});
