import { expect, type Page } from "@playwright/test";
import AxeBuilder from "@axe-core/playwright";

export const CALCULATOR_PATH = "/percentage-calculator";

export async function chooseMode(
  page: Page,
  question: string,
  label = "What do you want to calculate?",
) {
  await page.getByLabel(label).selectOption({ label: question });
}

/** Replaces the field's value the way a user would: select all, then type. */
export async function typeInto(page: Page, label: string, text: string) {
  const field = page.getByLabel(label, { exact: true });
  await field.fill("");
  await field.pressSequentially(text);
}

export const WCAG_TAGS = ["wcag2a", "wcag2aa", "wcag21a", "wcag21aa", "wcag22aa"];

export async function expectNoAxeViolations(page: Page) {
  const results = await new AxeBuilder({ page }).withTags(WCAG_TAGS).analyze();
  expect(results.violations.map((v) => `${v.id}: ${v.help} (${v.nodes.length})`)).toEqual([]);
}

export async function horizontalOverflow(page: Page) {
  return page.evaluate(
    () => document.documentElement.scrollWidth - document.documentElement.clientWidth,
  );
}
