import { expect, test } from "@playwright/test";
import { CALCULATOR_PATH } from "./helpers";

const WIDTHS = [360, 390, 412, 768, 1024, 1280, 1440];
const PAGES = ["/", CALCULATOR_PATH];

test.describe("Responsive layout", () => {
  test.skip(
    ({ isMobile }) => isMobile,
    "Viewport sizes are set explicitly; run once on desktop Chrome",
  );

  for (const width of WIDTHS) {
    for (const path of PAGES) {
      test(`${path} has no horizontal scrolling at ${width}px`, async ({ page }) => {
        await page.setViewportSize({ width, height: 800 });
        await page.goto(path);
        const overflow = await page.evaluate(
          () => document.documentElement.scrollWidth - document.documentElement.clientWidth,
        );
        expect(overflow).toBeLessThanOrEqual(0);
      });
    }

    test(`calculator and result are visible without scrolling sideways at ${width}px`, async ({
      page,
    }) => {
      await page.setViewportSize({ width, height: 800 });
      await page.goto(CALCULATOR_PATH);
      const result = await page.getByTestId("result-value").boundingBox();
      expect(result).not.toBeNull();
      expect(result!.x).toBeGreaterThanOrEqual(0);
      expect(result!.x + result!.width).toBeLessThanOrEqual(width);
    });
  }

  test("the calculator stays focused rather than stretching on wide screens", async ({ page }) => {
    await page.setViewportSize({ width: 1440, height: 900 });
    await page.goto(CALCULATOR_PATH);
    const calculator = await page
      .getByRole("region", { name: "Percentage calculator" })
      .boundingBox();
    expect(calculator!.width).toBeLessThanOrEqual(1152);
    const field = await page.getByLabel("Percentage", { exact: true }).boundingBox();
    expect(field!.width).toBeLessThanOrEqual(560);
  });

  test("error messages wrap inside the card at 360px", async ({ page }) => {
    await page.setViewportSize({ width: 360, height: 800 });
    await page.goto(CALCULATOR_PATH);
    await page
      .getByLabel("What do you want to calculate?")
      .selectOption({ label: "% increase or decrease" });
    await page.getByLabel("From (original value)").fill("0");
    await expect(page.getByTestId("result-message")).toBeVisible();
    const overflow = await page.evaluate(
      () => document.documentElement.scrollWidth - document.documentElement.clientWidth,
    );
    expect(overflow).toBeLessThanOrEqual(0);
  });

  test("a very long result wraps instead of overflowing at 360px", async ({ page }) => {
    await page.setViewportSize({ width: 360, height: 800 });
    await page.goto(CALCULATOR_PATH);
    await page.getByLabel("Percentage", { exact: true }).fill("1000000000000");
    await page.getByLabel("Of the number", { exact: true }).fill("1000000000000");
    await expect(page.getByTestId("result-value")).toHaveText("10,00,00,00,00,00,00,00,00,00,000");
    const overflow = await page.evaluate(
      () => document.documentElement.scrollWidth - document.documentElement.clientWidth,
    );
    expect(overflow).toBeLessThanOrEqual(0);
  });
});

test("every max-width class used on the site resolves to a real size (no silent no-ops)", async ({
  page,
}) => {
  for (const path of ["/", "/math", "/percentage-calculator"]) {
    await page.goto(path);
    const unresolved = await page.evaluate(() =>
      [...document.querySelectorAll('[class*="max-w-"]:not(.max-w-none)')]
        .filter((el) => getComputedStyle(el).maxWidth === "none")
        .map((el) => el.className.match(/max-w-[\w-]+/)?.[0]),
    );
    expect(unresolved, path).toEqual([]);
  }
});
