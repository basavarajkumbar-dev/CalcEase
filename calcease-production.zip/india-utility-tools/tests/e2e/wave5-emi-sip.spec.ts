import { expect, test, type Page } from "@playwright/test";
import { expectNoAxeViolations, horizontalOverflow, typeInto } from "./helpers";

const value = (page: Page) => page.getByTestId("result-value");
const panel = (page: Page) => page.getByTestId("result-panel");

test.describe("EMI Calculator", () => {
  const PATH = "/emi-calculator";

  test("matches ICICI Bank's published example", async ({ page }) => {
    await page.goto(PATH);
    await typeInto(page, "Loan amount", "1000000");
    await typeInto(page, "Interest rate (a year)", "7.25");
    await typeInto(page, "Years", "10");
    await expect(value(page)).toHaveText("₹11,740.10");
    await expect(panel(page)).toContainText("₹4,08,812.49");
    // The chart's figures are in text next to it.
    await expect(panel(page).getByRole("figure")).toContainText("Interest: ₹4,08,812.49");
  });

  test("the month-by-month schedule ends at a zero balance", async ({ page }) => {
    await page.goto(`${PATH}#amount=200000&rate=12&years=2`);
    await expect(value(page)).toHaveText("₹9,414.69");
    await page.locator("summary", { hasText: "Month-by-month schedule" }).click();
    const table = page.getByRole("table", { name: "Repayment schedule by month" });
    await expect(table.getByRole("row")).toHaveCount(25);
    await expect(table.getByRole("row").last()).toContainText("₹0");
  });

  test("a part-prepayment shortens the loan and shows the interest saved", async ({ page }) => {
    await page.goto(`${PATH}#amount=1000000&rate=7.25&years=10`);
    await page.getByLabel("Add a one-time part-prepayment").check();
    await typeInto(page, "Prepayment amount", "100000");
    await typeInto(page, "Made after EMI number", "12");
    await expect(page.getByTestId("result-sentence")).toContainText(
      "cuts the loan to 105 EMIs (15 months sooner) and saves ₹83,327.46 of interest",
    );
  });

  test("a prepayment larger than the balance is explained", async ({ page }) => {
    await page.goto(`${PATH}#amount=100000&rate=8&years=1&prepay=yes&prepayAmount=90000&after=6`);
    await expect(page.getByTestId("result-message")).toContainText("would close the loan");
  });

  test("has no detectable accessibility violations, with tables open", async ({ page }) => {
    await page.goto(PATH);
    await page.locator("summary", { hasText: "Year-by-year repayment" }).click();
    await page.locator("summary", { hasText: "Month-by-month schedule" }).click();
    await expectNoAxeViolations(page);
  });
});

test.describe("SIP Calculator", () => {
  const PATH = "/sip-calculator";

  test("start-of-month SIP with the yearly return ÷ 12 by default", async ({ page }) => {
    await page.goto(`${PATH}#monthly=1000&return=12&years=1`);
    await expect(value(page)).toHaveText("₹12,809.33");
    await expect(panel(page)).toContainText("Monthly rate used: 1%");
  });

  test("the monthly-equivalent method matches Groww's published example", async ({ page }) => {
    await page.goto(`${PATH}#monthly=1000&return=12&years=1`);
    await page
      .getByLabel("Monthly rate", { exact: true })
      .selectOption({ label: "Monthly equivalent (compounded)" });
    await expect(value(page)).toHaveText("₹12,766.50");
  });

  test("yearly step-up", async ({ page }) => {
    await page.goto(PATH);
    await typeInto(page, "Monthly investment", "5000");
    await typeInto(page, "Years", "3");
    await typeInto(page, "Yearly step-up (optional)", "10");
    await expect(value(page)).toHaveText("₹2,38,204.97");
    await expect(panel(page)).toContainText("₹1,98,600");
  });

  test("has no detectable accessibility violations, with the table open", async ({ page }) => {
    // With a step-up the table has four columns, the widest case.
    await page.goto(`${PATH}#monthly=25000&return=12&years=30&stepup=10`);
    await page.getByText("Year-by-year growth").click();
    await expectNoAxeViolations(page);
  });
});

test.describe("Wave 5 layout", () => {
  for (const path of ["/emi-calculator", "/sip-calculator"]) {
    test(`${path} has no horizontal scrolling at 360px, even with tables open`, async ({
      page,
      isMobile,
    }) => {
      test.skip(isMobile, "Explicit viewport");
      await page.setViewportSize({ width: 360, height: 800 });
      await page.goto(path);
      for (const summary of await page.locator("details > summary").all()) await summary.click();
      expect(await horizontalOverflow(page)).toBeLessThanOrEqual(0);
    });
  }
});
