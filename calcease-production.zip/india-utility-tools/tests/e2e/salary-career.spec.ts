import { expect, test, type Page } from "@playwright/test";
import { expectNoAxeViolations, horizontalOverflow, typeInto } from "./helpers";

const value = (page: Page) => page.getByTestId("result-value");
const panel = (page: Page) => page.getByTestId("result-panel");

async function fixToday(page: Page) {
  await page.clock.setFixedTime(new Date("2026-10-08T10:00:00"));
}

test.describe("Experience Calculator", () => {
  const PATH = "/experience-calculator";

  test("counts both dates by default: 1 Jan 2020 to 31 Dec 2024 is 5 years", async ({ page }) => {
    await fixToday(page);
    await page.goto(`${PATH}#joined=2020-01-01&until=2024-12-31`);
    await expect(value(page)).toHaveText("5 years");
    await page.getByLabel("Count the last working day").uncheck();
    await expect(value(page)).toHaveText("4 years, 11 months and 30 days");
  });

  test("defaults the end date to today and flags future end dates", async ({ page }) => {
    await fixToday(page);
    await page.goto(`${PATH}#joined=2018-07-16`);
    await expect(page.getByLabel("Last working day", { exact: true })).toHaveValue("2026-10-08");
    await expect(value(page)).toHaveText("8 years, 2 months and 23 days");
    await page.getByLabel("Last working day", { exact: true }).fill("2027-01-01");
    await expect(panel(page)).toContainText("projected experience");
  });

  test("an end date before the joining date is explained", async ({ page }) => {
    await fixToday(page);
    await page.goto(`${PATH}#joined=2026-10-09&until=2026-10-08`);
    await expect(page.getByTestId("result-message")).toHaveText(
      "The end date is before the joining date. Check the dates.",
    );
  });

  test("has no detectable accessibility violations", async ({ page }) => {
    await fixToday(page);
    await page.goto(PATH);
    await expect(value(page)).toBeVisible();
    await expectNoAxeViolations(page);
  });
});

test.describe("Notice Period Calculator", () => {
  const PATH = "/notice-period-calculator";

  test("30 days from today, starting the day after resignation", async ({ page }) => {
    await fixToday(page);
    await page.goto(PATH);
    await expect(value(page)).toHaveText("7 November 2026");
    await expect(panel(page)).toContainText("30 days from today");
    await page.getByLabel("Count the resignation date as day 1").check();
    await expect(value(page)).toHaveText("6 November 2026");
  });

  test("a past last working day and invalid notice lengths", async ({ page }) => {
    await fixToday(page);
    await page.goto(`${PATH}#resigned=2026-09-01&days=30`);
    await expect(value(page)).toHaveText("1 October 2026");
    await expect(panel(page)).toContainText("Passed 7 days ago");
    await typeInto(page, "Notice period (days)", "0");
    await expect(
      page.getByText(/Enter a number of days between 1 days and 365 days/),
    ).toBeVisible();
  });

  test("has no detectable accessibility violations", async ({ page }) => {
    await fixToday(page);
    await page.goto(PATH);
    await expect(value(page)).toBeVisible();
    await expectNoAxeViolations(page);
  });
});

test.describe("Salary Budget Planner", () => {
  const PATH = "/salary-budget-planner";

  test("₹50,000 example: surplus, suggestion, emergency fund and breakdown", async ({ page }) => {
    await page.goto(PATH);
    await expect(value(page)).toHaveText("₹15,000");
    await expect(panel(page)).toContainText("₹7,500 emergency + ₹7,500 invest");
    await expect(panel(page)).toContainText("₹1,62,000");
    const ef = page.getByRole("region", { name: "Emergency fund" });
    await expect(ef).toContainText("2.2 months");
    await expect(ef).toContainText("About 14 months");
    const table = page.getByRole("table", { name: /your plan and the reference/ });
    await expect(table.getByRole("row", { name: /^Wants/ })).toContainText("₹13,800");
  });

  test("spending more than income shows the shortfall", async ({ page }) => {
    await page.goto(PATH);
    await typeInto(page, "Monthly take-home salary", "30000");
    await typeInto(page, "Essential expenses (a month)", "25000");
    await typeInto(page, "EMIs and debt payments (a month)", "8000");
    await typeInto(page, "Wants and lifestyle (a month)", "5000");
    await expect(page.getByTestId("result-panel")).toContainText("Monthly shortfall");
    await expect(value(page)).toHaveText("₹8,000");
  });

  test("itemised essentials are added up", async ({ page }) => {
    await page.goto(PATH);
    await page.getByLabel("Break down my essential expenses").check();
    await typeInto(page, "Housing / rent", "12000");
    await typeInto(page, "Food and groceries", "6000");
    await typeInto(page, "Transport", "4000");
    await expect(value(page)).toHaveText("₹15,000");
  });

  test("negative amounts are not accepted", async ({ page }) => {
    await page.goto(PATH);
    await typeInto(page, "Wants and lifestyle (a month)", "-100");
    await page.getByLabel("Monthly take-home salary").focus();
    await expect(page.getByText(/Enter an amount between ₹0 and/)).toBeVisible();
  });

  test("has no detectable accessibility violations, with settings open", async ({ page }) => {
    await page.goto(PATH);
    await page.locator("summary", { hasText: "Reference settings and goal" }).click();
    await expectNoAxeViolations(page);
  });
});

test.describe("Salary & Career layout", () => {
  for (const width of [320, 390, 768]) {
    test(`no horizontal scrolling at ${width}px`, async ({ page, isMobile }) => {
      test.skip(isMobile, "Explicit viewport");
      await fixToday(page);
      await page.setViewportSize({ width, height: 900 });
      for (const path of [
        "/salary",
        "/salary-budget-planner",
        "/experience-calculator",
        "/notice-period-calculator",
      ]) {
        await page.goto(path);
        expect(await horizontalOverflow(page), `${path} at ${width}px`).toBeLessThanOrEqual(0);
      }
    });
  }
});
