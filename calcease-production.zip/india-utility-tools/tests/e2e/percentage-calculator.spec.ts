import { expect, test } from "@playwright/test";
import { CALCULATOR_PATH, chooseMode, typeInto } from "./helpers";

test.describe("Percentage Calculator: user flows", () => {
  test.beforeEach(async ({ page }) => {
    await page.goto(CALCULATOR_PATH);
  });

  test("shows a worked example result on first load, without typing", async ({ page }) => {
    await expect(
      page.getByRole("heading", { level: 1, name: "Percentage Calculator" }),
    ).toBeVisible();
    await expect(page.getByTestId("result-value")).toHaveText("100");
    await expect(page.getByTestId("result-sentence")).toHaveText("20% of 500 is 100.");
  });

  test("X% of a number: 12.5% of 80 = 10", async ({ page }) => {
    await typeInto(page, "Percentage", "12.5");
    await typeInto(page, "Of the number", "80");
    await expect(page.getByTestId("result-value")).toHaveText("10");
  });

  test("what percent: 100 of 500 = 20%", async ({ page }) => {
    await chooseMode(page, "A number is what % of another?");
    await typeInto(page, "Number (part)", "100");
    await typeInto(page, "Of the total (whole)", "500");
    await expect(page.getByTestId("result-value")).toHaveText("20%");
  });

  test("percentage decrease: 600 → 500 is a decrease of 16.67%, flagged as rounded", async ({
    page,
  }) => {
    await chooseMode(page, "% increase or decrease");
    await typeInto(page, "From (original value)", "600");
    await typeInto(page, "To (new value)", "500");
    const panel = page.getByTestId("result-panel");
    await expect(panel).toContainText("Your result: a decrease");
    await expect(page.getByTestId("result-value")).toHaveText("16.67%");
    await expect(panel).toContainText("Rounded to 2 decimal places");
  });

  test("percentage increase: 500 → 600 is an increase of 20%", async ({ page }) => {
    await chooseMode(page, "% increase or decrease");
    await typeInto(page, "From (original value)", "500");
    await typeInto(page, "To (new value)", "600");
    await expect(page.getByTestId("result-panel")).toContainText("Your result: an increase");
    await expect(page.getByTestId("result-value")).toHaveText("20%");
    await expect(page.getByTestId("result-sentence")).toHaveText(
      "From 500 to 600 is an increase of 20%.",
    );
  });

  test("increase and decrease by a percent, with Indian grouping", async ({ page }) => {
    await chooseMode(page, "Increase a number by X%");
    await typeInto(page, "Number", "1,25,000");
    await typeInto(page, "Increase by", "18");
    await expect(page.getByTestId("result-value")).toHaveText("1,47,500");
    const added = page
      .getByTestId("result-panel")
      .locator("dl > div")
      .filter({ hasText: "Amount added" });
    await expect(added.locator("dd")).toHaveText("22,500");

    await chooseMode(page, "Decrease a number by X%");
    await typeInto(page, "Number", "500");
    await typeInto(page, "Decrease by", "20");
    await expect(page.getByTestId("result-value")).toHaveText("400");
  });

  test("error: whole of 0 explains why instead of showing Infinity", async ({ page }) => {
    await chooseMode(page, "A number is what % of another?");
    await typeInto(page, "Number (part)", "100");
    await typeInto(page, "Of the total (whole)", "0");
    await expect(page.getByTestId("result-message")).toHaveText(
      "The whole can't be 0, because a percentage of nothing is undefined.",
    );
    await expect(page.getByTestId("result-panel")).not.toContainText(/Infinity|NaN/);
  });

  test("error: letters are rejected with an accessible message on the field", async ({ page }) => {
    const field = page.getByLabel("Percentage", { exact: true });
    await typeInto(page, "Percentage", "abc");
    await expect(field).toHaveAttribute("aria-invalid", "true");
    const describedBy = await field.getAttribute("aria-describedby");
    expect(describedBy).toBeTruthy();
    await expect(page.locator(`[id="${describedBy}"]`)).toHaveText(/Enter a number/);
    await expect(page.getByTestId("result-message")).toHaveText(
      "Fix the highlighted value to see your result.",
    );
  });

  test("error: out-of-range values are rejected", async ({ page }) => {
    await typeInto(page, "Of the number", "10000000000000");
    await expect(page.getByText(/Enter a number between/)).toBeVisible();
  });

  test("empty field asks for input without showing an error", async ({ page }) => {
    await page.getByLabel("Percentage", { exact: true }).fill("");
    await expect(page.getByTestId("result-message")).toHaveText(
      "Enter both values to see your result.",
    );
    await expect(page.getByLabel("Percentage", { exact: true })).not.toHaveAttribute(
      "aria-invalid",
      "true",
    );
  });

  test("each mode keeps its own values when switching back and forth", async ({ page }) => {
    await typeInto(page, "Percentage", "7.5");
    await typeInto(page, "Of the number", "200");
    await chooseMode(page, "A number is what % of another?");
    await chooseMode(page, "What is X% of a number?");
    await expect(page.getByTestId("result-value")).toHaveText("15");
  });

  test("works with the keyboard alone", async ({ page, isMobile }) => {
    test.skip(isMobile, "Keyboard navigation is a desktop concern");
    const select = page.getByLabel("What do you want to calculate?");
    await select.focus();
    await select.selectOption({ label: "A number is what % of another?" });
    await page.keyboard.press("Tab");
    await expect(page.getByLabel("Number (part)")).toBeFocused();
    await page.keyboard.press("ControlOrMeta+a");
    await page.keyboard.type("50");
    await page.keyboard.press("Tab");
    await expect(page.getByLabel("Of the total (whole)")).toBeFocused();
    await page.keyboard.press("ControlOrMeta+a");
    await page.keyboard.type("200");
    await expect(page.getByTestId("result-value")).toHaveText("25%");
  });

  test("inputs open the numeric keyboard on phones", async ({ page }) => {
    for (const label of ["Percentage", "Of the number"]) {
      await expect(page.getByLabel(label, { exact: true })).toHaveAttribute("inputmode", "decimal");
    }
  });
});
