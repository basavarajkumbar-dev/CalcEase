import { expect, test } from "@playwright/test";
import { CALCULATOR_PATH, typeInto } from "./helpers";

test.describe("Basic SEO", () => {
  test("calculator page has title, description, canonical and Open Graph tags", async ({
    page,
  }) => {
    await page.goto(CALCULATOR_PATH);
    await expect(page).toHaveTitle(/^Percentage Calculator – % Change, Increase, Decrease \| /);
    await expect(page.locator('meta[name="description"]')).toHaveAttribute(
      "content",
      /percentage calculator/i,
    );
    await expect(page.locator('link[rel="canonical"]')).toHaveAttribute(
      "href",
      /\/percentage-calculator$/,
    );
    await expect(page.locator('meta[property="og:title"]')).toHaveAttribute(
      "content",
      /Percentage Calculator/,
    );
    await expect(page.locator('meta[property="og:url"]')).toHaveAttribute(
      "content",
      /\/percentage-calculator$/,
    );
    await expect(page.locator("html")).toHaveAttribute("lang", "en-IN");
  });

  test("calculator content is in the server-rendered HTML (crawlable without JavaScript)", async ({
    request,
  }) => {
    const html = await (await request.get(CALCULATOR_PATH)).text();
    expect(html).toContain("<h1");
    expect(html).toContain("How it is calculated");
    expect(html).toContain("20% of 500 is 100.");
  });

  test("robots.txt and sitemap.xml are served and list the calculator", async ({ request }) => {
    const robots = await (await request.get("/robots.txt")).text();
    expect(robots).toContain("Allow: /");
    expect(robots).toMatch(/Sitemap: .*\/sitemap\.xml/);
    const sitemap = await (await request.get("/sitemap.xml")).text();
    expect(sitemap).toContain("/percentage-calculator</loc>");
  });

  test("unknown pages return 404", async ({ request }) => {
    expect((await request.get("/no-such-tool")).status()).toBe(404);
  });
});

test.describe("Privacy and runtime health", () => {
  test("typing values sends no network requests and logs no console errors", async ({ page }) => {
    const consoleErrors: string[] = [];
    page.on("console", (message) => {
      if (message.type() === "error") consoleErrors.push(message.text());
    });
    page.on("pageerror", (error) => consoleErrors.push(error.message));

    await page.goto(CALCULATOR_PATH);
    await page.waitForLoadState("networkidle");

    const requestsAfterLoad: string[] = [];
    page.on("request", (request) => requestsAfterLoad.push(request.url()));

    await typeInto(page, "Percentage", "18");
    await typeInto(page, "Of the number", "45000");
    await expect(page.getByTestId("result-value")).toHaveText("8,100");
    await page.waitForTimeout(1000);

    expect(requestsAfterLoad).toEqual([]);
    expect(consoleErrors).toEqual([]);
  });

  test("page loads only first-party resources (no third-party services)", async ({
    page,
    baseURL,
  }) => {
    const origins = new Set<string>();
    page.on("request", (request) => origins.add(new URL(request.url()).origin));
    await page.goto(CALCULATOR_PATH);
    await page.waitForLoadState("networkidle");
    expect([...origins]).toEqual([new URL(baseURL!).origin]);
  });

  test("nothing is written to cookies or browser storage", async ({ page, context }) => {
    await page.goto(CALCULATOR_PATH);
    await typeInto(page, "Percentage", "30");
    const storage = await page.evaluate(() => ({
      local: window.localStorage.length,
      session: window.sessionStorage.length,
    }));
    expect(storage).toEqual({ local: 0, session: 0 });
    expect(await context.cookies()).toEqual([]);
  });
});
