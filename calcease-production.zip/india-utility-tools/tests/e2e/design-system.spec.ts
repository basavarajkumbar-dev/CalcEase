import { expect, test } from "@playwright/test";
import { CALCULATOR_PATH, typeInto } from "./helpers";

test.describe("Header: search panel", () => {
  test("header search finds a tool by keyword and Enter opens it", async ({ page }) => {
    await page.goto("/");
    await page.getByRole("button", { name: "Search tools" }).click();
    const panel = page.locator("#header-search-panel");
    await panel.getByRole("searchbox").fill("hike");
    // "hike" matches the Percentage Hike Calculator by name (best) and the Percentage
    // Calculator by keyword; Enter opens the best match.
    await expect(panel.getByRole("link", { name: /^Percentage Hike Calculator/ })).toBeVisible();
    await expect(panel.getByRole("link", { name: /^Percentage Calculator/ })).toBeVisible();
    await page.keyboard.press("Enter");
    await expect(page).toHaveURL(/\/percentage-hike-calculator$/);
    await expect(panel).toBeHidden();
  });

  test("search explains when nothing matches and offers suggestions", async ({ page }) => {
    await page.goto("/");
    const main = page.getByRole("main");
    await main.getByRole("searchbox", { name: "Search tools" }).fill("mortgage zzz");
    await expect(main.getByRole("status")).toHaveText('No tools found for "mortgage zzz".');
    await main.getByRole("button", { name: "percentage" }).click();
    await expect(main.getByRole("searchbox", { name: "Search tools" })).toHaveValue("percentage");
    await expect(main.getByRole("link", { name: /^Percentage Calculator/ }).first()).toBeVisible();
  });
});

test.describe("Breadcrumb", () => {
  test("is a labelled navigation with the current page marked", async ({ page }) => {
    await page.goto(CALCULATOR_PATH);
    const crumbs = page.getByRole("navigation", { name: "Breadcrumb" });
    await expect(crumbs.getByRole("link", { name: "Home" })).toHaveAttribute("href", "/");
    await expect(crumbs.locator('[aria-current="page"]')).toHaveText("Percentage Calculator");
  });

  test("fits on one line at 360px", async ({ page }) => {
    await page.setViewportSize({ width: 360, height: 800 });
    await page.goto(CALCULATOR_PATH);
    const box = await page.getByRole("navigation", { name: "Breadcrumb" }).boundingBox();
    expect(box!.height).toBeLessThan(30);
  });

  test("tool page breadcrumb links to its category hub", async ({ page }) => {
    await page.goto(CALCULATOR_PATH);
    const crumbs = page.getByRole("navigation", { name: "Breadcrumb" });
    await expect(crumbs.getByRole("link", { name: "Math & Everyday" })).toHaveAttribute(
      "href",
      "/math",
    );
  });
});

test.describe("Share button", () => {
  test("copies the result and link where the Web Share API is unavailable", async ({
    page,
    context,
    browserName,
  }) => {
    test.skip(
      browserName !== "chromium",
      "Clipboard permissions are a Chromium-only Playwright API",
    );
    await context.grantPermissions(["clipboard-read", "clipboard-write"]);
    await page.goto(CALCULATOR_PATH);
    const hasNativeShare = await page.evaluate(() => typeof navigator.share === "function");
    test.skip(hasNativeShare, "This browser opens the native share sheet instead");
    await typeInto(page, "Percentage", "25");
    await typeInto(page, "Of the number", "80");
    await page.getByRole("button", { name: "Share result" }).click();
    await expect(
      page.getByRole("status").filter({ hasText: "Result and link copied" }),
    ).toBeVisible();
    const copied = await page.evaluate(() => navigator.clipboard.readText());
    // The link carries the inputs, so the recipient sees the same result.
    expect(copied).toBe(
      "25% of 80 is 20.\nhttp://127.0.0.1:3100/percentage-calculator#mode=percentOf&a=25&b=80",
    );
  });

  test("is not shown when there is no result to share", async ({ page }) => {
    await page.goto(CALCULATOR_PATH);
    await page.getByLabel("Percentage", { exact: true }).fill("");
    await expect(page.getByRole("button", { name: "Share result" })).toHaveCount(0);
  });
});

test.describe("Content components", () => {
  test("FAQ answers open and close with the keyboard", async ({ page, isMobile }) => {
    test.skip(isMobile, "Keyboard test runs on desktop");
    await page.goto(CALCULATOR_PATH);
    const summary = page.locator("summary", { hasText: "Can I type numbers with commas?" });
    const answer = page.getByText(
      "Both Indian (1,25,000) and international (125,000) grouping work.",
    );
    await expect(answer).toBeHidden();
    await summary.focus();
    await page.keyboard.press("Enter");
    await expect(answer).toBeVisible();
    await page.keyboard.press("Enter");
    await expect(answer).toBeHidden();
  });

  test("worked-examples table has a caption and row headers", async ({ page }) => {
    await page.goto(CALCULATOR_PATH);
    const table = page.getByRole("table", { name: "Everyday percentage calculations" });
    await expect(table).toBeVisible();
    await expect(table.getByRole("rowheader", { name: "432 marks out of 600" })).toBeVisible();
  });

  test("desktop shows an 'On this page' list; phones do not", async ({ page, isMobile }) => {
    await page.goto(CALCULATOR_PATH);
    const toc = page.getByRole("navigation", { name: "On this page" });
    if (isMobile) await expect(toc).toBeHidden();
    else
      await expect(toc.getByRole("link", { name: "Worked examples" })).toHaveAttribute(
        "href",
        "#examples",
      );
  });

  test("no ad placeholder is rendered in a production build", async ({ page }) => {
    await page.goto(CALCULATOR_PATH);
    await expect(page.locator("[data-ad-slot]")).toHaveCount(0);
  });

  test("unknown tool pages offer search and the available tools", async ({ page }) => {
    await page.goto("/ctc-to-in-hand-salary-calculator");
    await expect(page.getByRole("heading", { level: 1 })).toHaveText("This page isn't here");
    await expect(
      page.getByRole("main").getByRole("searchbox", { name: "Search tools" }),
    ).toBeVisible();
    await expect(
      page.getByRole("main").getByRole("link", { name: "Open calculator: Percentage Calculator" }),
    ).toBeVisible();
  });
});

test.describe("Mobile layout under an on-screen keyboard", () => {
  test("the focused field stays visible and nothing overflows when the viewport shrinks", async ({
    page,
    isMobile,
  }) => {
    test.skip(!isMobile, "Phone-only behaviour");
    await page.goto(CALCULATOR_PATH);
    // An Android keyboard leaves roughly half the screen: emulate a 412 × 420 visual viewport.
    await page.setViewportSize({ width: 412, height: 420 });
    const field = page.getByLabel("Of the number", { exact: true });
    await field.focus();
    await field.fill("750");
    await expect(field).toBeInViewport();
    const overflow = await page.evaluate(
      () => document.documentElement.scrollWidth - document.documentElement.clientWidth,
    );
    expect(overflow).toBeLessThanOrEqual(0);
  });

  test("the whole result is above the fold at 360 × 800 before scrolling", async ({
    page,
    isMobile,
  }) => {
    test.skip(!isMobile, "Phone-only behaviour");
    await page.setViewportSize({ width: 360, height: 800 });
    await page.goto(CALCULATOR_PATH);
    await expect(page.getByTestId("result-sentence")).toBeInViewport({ ratio: 1 });
    await expect(page.getByRole("button", { name: "Share result" })).toBeInViewport({ ratio: 1 });
  });
});
