import { expect, test, type Page } from "@playwright/test";
import { expectNoAxeViolations, horizontalOverflow, typeInto } from "./helpers";

const value = (page: Page) => page.getByTestId("result-value");

test.describe("CalcEase brand and homepage", () => {
  test("shows the CalcEase name, tagline, categories and highlighted tools", async ({ page }) => {
    await page.goto("/");
    await expect(page).toHaveTitle(/^CalcEase/);
    await expect(page.getByRole("heading", { level: 1 })).toHaveText(
      "Simple calculations. Clear decisions.",
    );
    await expect(page.getByRole("link", { name: "CalcEase home" })).toHaveAttribute("href", "/");
    const categories = page.getByRole("navigation", { name: "Calculator categories" });
    for (const name of ["Finance", "Salary & Career", "Math & Everyday", "Date & Time"])
      await expect(categories.getByRole("link", { name })).toBeVisible();
    const highlights = page.locator("#available").getByRole("link");
    await expect(highlights).toHaveCount(6);
    await expect(highlights.first()).toContainText("EMI Calculator");
    await expect(highlights.last()).toContainText("Calculator");
    await expect(page.getByRole("contentinfo")).toContainText(
      "Simple calculations. Clear decisions.",
    );
  });
});

test.describe("Lumpsum Calculator", () => {
  const PATH = "/lumpsum-calculator";

  test("₹1,00,000 at 12% for 10 years", async ({ page }) => {
    await page.goto(PATH);
    await expect(value(page)).toHaveText("₹3,10,584.82");
    await expect(page.getByTestId("result-panel")).toContainText("₹2,10,584.82");
    await expect(page.getByTestId("result-panel")).toContainText("Returns are not guaranteed");
  });

  test("matches Groww's published example to the rupee", async ({ page }) => {
    await page.goto(`${PATH}#amount=1500000&return=12&years=5`);
    await expect(value(page)).toHaveText("₹26,43,512.52");
  });

  test("zero, negative and fractional inputs are explained, not calculated", async ({ page }) => {
    await page.goto(PATH);
    await typeInto(page, "Initial investment", "0");
    await expect(page.getByText(/Enter an amount more than ₹0/)).toBeVisible();
    await typeInto(page, "Initial investment", "100000");
    await typeInto(page, "Expected return (a year)", "-5");
    await expect(page.getByText("Enter a return between 0% and 50%.")).toBeVisible();
    await typeInto(page, "Expected return (a year)", "12");
    await typeInto(page, "Investment period (years)", "2.5");
    await expect(page.getByText("Enter a whole number, without decimals.")).toBeVisible();
  });

  test("has no detectable accessibility violations, with the table open", async ({ page }) => {
    await page.goto(PATH);
    await page.locator("summary", { hasText: "Year-by-year growth" }).click();
    await expectNoAxeViolations(page);
  });
});

test.describe("Calculator", () => {
  const PATH = "/calculator";
  const output = (page: Page) => page.getByTestId("calculator-output");
  const field = (page: Page) => page.getByLabel("Calculation", { exact: true });

  async function tap(page: Page, ...names: string[]) {
    const keypad = page.getByRole("group", { name: "Keypad" });
    for (const name of names) await keypad.getByRole("button", { name, exact: true }).click();
  }

  test("keypad: (100 + 50) × 2 = 300, then continue from the result", async ({ page }) => {
    await page.goto(PATH);
    await tap(
      page,
      "Open bracket",
      "1",
      "0",
      "0",
      "Plus",
      "5",
      "0",
      "Close bracket",
      "Multiply",
      "2",
    );
    await expect(field(page)).toHaveValue("(100+50)×2");
    await tap(page, "Equals");
    await expect(field(page)).toHaveValue("300");
    await expect(output(page)).toHaveText("(100+50)×2 =");
    await tap(page, "Divide", "4", "Equals");
    await expect(field(page)).toHaveValue("75");
    const history = page.getByRole("region", { name: "History" });
    await expect(history.getByRole("listitem")).toHaveCount(2);
  });

  test("keyboard: typing, percent, Enter, Backspace and Escape", async ({ page }) => {
    await page.goto(PATH);
    await field(page).click();
    await page.keyboard.type("200*10%");
    await expect(field(page)).toHaveValue("200×10%");
    await expect(output(page)).toHaveText("= 20");
    await page.keyboard.press("Enter");
    await expect(field(page)).toHaveValue("20");
    await page.keyboard.type("+5");
    await page.keyboard.press("Backspace");
    await expect(field(page)).toHaveValue("20+");
    await page.keyboard.press("Escape");
    await expect(field(page)).toHaveValue("");
  });

  test("errors are explained and never show NaN or Infinity", async ({ page }) => {
    await page.goto(PATH);
    await field(page).fill("5/0");
    await page.keyboard.press("Enter");
    await expect(output(page)).toHaveText("You can't divide by zero.");
    await field(page).fill("(2+3");
    await page.keyboard.press("Enter");
    await expect(output(page)).toHaveText("Check the brackets: each ( needs a matching ).");
    await expect(page.locator("main")).not.toContainText(/NaN|Infinity|undefined/);
  });

  test("letters and code cannot be entered", async ({ page }) => {
    await page.goto(PATH);
    await field(page).fill("alert(1)+2");
    await expect(field(page)).toHaveValue("(1)+2");
  });

  test("keypad keys are at least 44 × 44 px and named for screen readers", async ({ page }) => {
    await page.setViewportSize({ width: 320, height: 700 });
    await page.goto(PATH);
    const keys = page.getByRole("group", { name: "Keypad" }).getByRole("button");
    await expect(keys).toHaveCount(21);
    for (const key of await keys.all()) {
      const box = await key.boundingBox();
      expect(box!.width).toBeGreaterThanOrEqual(44);
      expect(box!.height).toBeGreaterThanOrEqual(44);
    }
    await expect(keys.filter({ hasText: "⌫" })).toHaveAccessibleName("Backspace");
  });

  test("has no detectable accessibility violations, with history and an error", async ({
    page,
  }) => {
    await page.goto(PATH);
    await field(page).fill("2+3");
    await page.keyboard.press("Enter");
    await field(page).fill("1/0");
    await page.keyboard.press("Enter");
    await expectNoAxeViolations(page);
  });
});

test.describe("Layout at phone, tablet and desktop widths", () => {
  for (const width of [320, 360, 390, 430, 768, 1280]) {
    test(`no horizontal scrolling at ${width}px`, async ({ page, isMobile }) => {
      test.skip(isMobile, "Explicit viewport");
      await page.setViewportSize({ width, height: 900 });
      for (const path of [
        "/",
        "/calculator",
        "/lumpsum-calculator",
        "/finance",
        "/emi-calculator",
      ]) {
        await page.goto(path);
        expect(await horizontalOverflow(page), `${path} at ${width}px`).toBeLessThanOrEqual(0);
      }
    });
  }
});

test.describe("Production domain and structured data", () => {
  const ORIGIN = "https://calculatorfordailyuse.com";

  test("canonical and Open Graph URLs use the production domain", async ({ page }) => {
    await page.goto("/emi-calculator");
    await expect(page.locator('link[rel="canonical"]')).toHaveAttribute(
      "href",
      `${ORIGIN}/emi-calculator`,
    );
    await expect(page.locator('meta[property="og:url"]')).toHaveAttribute(
      "content",
      `${ORIGIN}/emi-calculator`,
    );
    await expect(page.locator('meta[property="og:site_name"]')).toHaveAttribute(
      "content",
      "CalcEase",
    );
    await expect(page.locator('meta[name="robots"]')).toHaveAttribute("content", "index, follow");
  });

  test("robots.txt and sitemap.xml point only at the production domain", async ({ request }) => {
    const robots = await (await request.get("/robots.txt")).text();
    expect(robots).toContain(`Sitemap: ${ORIGIN}/sitemap.xml`);
    const sitemap = await (await request.get("/sitemap.xml")).text();
    const locs = [...sitemap.matchAll(/<loc>([^<]+)<\/loc>/g)].map((m) => m[1]!);
    expect(locs.length).toBeGreaterThan(20);
    for (const loc of locs) expect(loc.startsWith(`${ORIGIN}/`), loc).toBe(true);
    expect(new Set(locs).size).toBe(locs.length);
    expect(sitemap).not.toMatch(/localhost|127\.0\.0\.1|vercel\.app/);
  });

  test("pages carry valid JSON-LD: WebSite on the homepage, breadcrumbs on tools", async ({
    page,
  }) => {
    await page.goto("/");
    const home = JSON.parse(
      (await page.locator('script[type="application/ld+json"]').textContent())!,
    );
    expect(home["@type"]).toBe("WebSite");
    expect(home.url).toBe(`${ORIGIN}/`);
    await page.goto("/sip-calculator");
    const crumbs = JSON.parse(
      (await page.locator('script[type="application/ld+json"]').textContent())!,
    );
    expect(crumbs["@type"]).toBe("BreadcrumbList");
    expect(crumbs.itemListElement.map((i: { item: string }) => i.item)).toEqual([
      `${ORIGIN}/`,
      `${ORIGIN}/finance`,
      `${ORIGIN}/sip-calculator`,
    ]);
  });

  test("no page logs console errors", async ({ page }) => {
    const errors: string[] = [];
    page.on("console", (m) => m.type() === "error" && errors.push(`${page.url()}: ${m.text()}`));
    page.on("pageerror", (e) => errors.push(`${page.url()}: ${e.message}`));
    for (const path of [
      "/",
      "/tools",
      "/finance",
      "/salary",
      "/math",
      "/date-time",
      "/calculator",
      "/salary-budget-planner",
      "/fd-calculator",
      "/age-calculator",
    ]) {
      await page.goto(path);
      await expect(page.locator("h1")).toBeVisible();
    }
    expect(errors).toEqual([]);
  });
});
