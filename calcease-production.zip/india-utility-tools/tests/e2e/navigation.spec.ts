import { expect, test, type Page } from "@playwright/test";
import { typeInto } from "./helpers";

async function htmlOverflow(page: Page) {
  return page.evaluate(() => getComputedStyle(document.documentElement).overflow);
}

test.describe("Discovery journeys", () => {
  test("Homepage → Math category → Percentage Calculator → calculate", async ({ page }) => {
    await page.goto("/");
    await page
      .getByRole("link", { name: /^Math & Everyday/ })
      .first()
      .click();
    await expect(page).toHaveURL(/\/math$/);
    await expect(page.getByRole("heading", { level: 1 })).toHaveText("Math & Everyday");
    await page.getByRole("link", { name: "Open calculator: Percentage Calculator" }).click();
    await expect(page).toHaveURL(/\/percentage-calculator$/);
    await typeInto(page, "Percentage", "15");
    await typeInto(page, "Of the number", "1299");
    await expect(page.getByTestId("result-value")).toHaveText("194.85");
  });

  test("Homepage → search → Percentage Calculator → open tool", async ({ page }) => {
    await page.goto("/");
    const main = page.getByRole("main");
    await main.getByRole("searchbox", { name: "Search tools" }).fill("  PERCENT  ");
    // Percentage, Percentage Hike and the general Calculator (which handles percent).
    await expect(main.getByRole("status")).toHaveText("3 tools found.");
    // The first match is the search result (the highlights below have the same name).
    await main
      .getByRole("link", { name: /^Percentage Calculator/ })
      .first()
      .click();
    await expect(page).toHaveURL(/\/percentage-calculator$/);
    await expect(page.getByTestId("result-value")).toHaveText("100");
  });

  test("the homepage features the Percentage Calculator with a clear action", async ({ page }) => {
    await page.goto("/");
    await page
      .locator("#available")
      .getByRole("link", { name: /^Percentage Calculator/ })
      .click();
    await expect(page).toHaveURL(/\/percentage-calculator$/);
  });

  test("every category now has published tools, so each links to its hub", async ({ page }) => {
    await page.goto("/");
    const categories = page.locator("#categories");
    for (const [name, href] of [
      ["Finance", "/finance"],
      ["Salary & Career", "/salary"],
      ["Math & Everyday", "/math"],
      ["Date & Time", "/date-time"],
    ]) {
      await expect(categories.getByRole("link", { name: new RegExp(`^${name}`) })).toHaveAttribute(
        "href",
        href!,
      );
    }
    await expect(categories.getByText("Coming soon", { exact: true })).toHaveCount(0);
  });

  test("search shows planned tools as 'Coming soon' without links", async ({ page }) => {
    await page.goto("/");
    const main = page.getByRole("main");
    // The CTC calculator is held under review, so it is still listed as coming soon.
    await main.getByRole("searchbox", { name: "Search tools" }).fill("ctc");
    await expect(main.getByText("CTC to In-Hand Salary Calculator")).toBeVisible();
    await expect(main.getByRole("link", { name: /CTC to In-Hand/ })).toHaveCount(0);
    await expect(main.getByRole("status")).toHaveText("1 coming soon.");
  });

  test("search results can be reached and walked with the arrow keys", async ({
    page,
    isMobile,
  }) => {
    test.skip(isMobile, "Keyboard test runs on desktop");
    await page.goto("/");
    const search = page.getByRole("main").getByRole("searchbox", { name: "Search tools" });
    await search.fill("calculator");
    await search.press("ArrowDown");
    const results = page.getByRole("main").locator("search ul").first().getByRole("link");
    await expect(results.first()).toBeFocused();
    await page.keyboard.press("ArrowDown");
    await expect(results.nth(1)).toBeFocused();
    await page.keyboard.press("ArrowUp");
    await expect(results.first()).toBeFocused();
    await page.keyboard.press("ArrowUp");
    await expect(search).toBeFocused();
  });

  test("tool page links back to its category and to all tools", async ({ page }) => {
    await page.goto("/percentage-calculator");
    const footer = page.getByRole("main").locator("footer");
    await expect(footer.getByRole("link", { name: "Math & Everyday" })).toHaveAttribute(
      "href",
      "/math",
    );
    await expect(footer.getByRole("link", { name: "See all tools" })).toHaveAttribute(
      "href",
      "/tools",
    );
  });
});

test.describe("Header navigation", () => {
  test("phones show brand, search and menu only; the brand stays on one line", async ({
    page,
    isMobile,
  }) => {
    test.skip(!isMobile, "Phone header");
    await page.setViewportSize({ width: 360, height: 800 });
    await page.goto("/");
    const header = page.getByRole("banner");
    await expect(header.getByRole("button", { name: "Categories" })).toBeHidden();
    await expect(header.getByRole("link", { name: "All tools" })).toBeHidden();
    await expect(header.getByRole("button", { name: "Search tools" })).toBeVisible();
    await expect(header.getByRole("button", { name: "Menu", exact: true })).toBeVisible();
    const headerBox = await header.boundingBox();
    expect(headerBox!.height).toBeLessThanOrEqual(57);
  });

  test("desktop: Categories panel lists hubs and coming-soon categories; Escape closes it", async ({
    page,
    isMobile,
  }) => {
    test.skip(isMobile, "Desktop header");
    await page.goto("/percentage-calculator");
    const button = page.getByRole("button", { name: "Categories" });
    await button.click();
    await expect(button).toHaveAttribute("aria-expanded", "true");
    const panel = page.getByRole("navigation", { name: "Categories", exact: true });
    await expect(panel.getByRole("link", { name: "Math & Everyday" })).toHaveAttribute(
      "href",
      "/math",
    );
    await expect(panel.getByText("Coming soon", { exact: true })).toHaveCount(0);
    await page.keyboard.press("Escape");
    await expect(panel).toBeHidden();
    await expect(button).toBeFocused();
    await button.click();
    await panel.getByRole("link", { name: "Math & Everyday" }).click();
    await expect(page).toHaveURL(/\/math$/);
    await expect(panel).toBeHidden();
  });

  test("desktop: keyboard order runs skip link → brand → All tools → Categories → Search", async ({
    page,
    isMobile,
  }) => {
    test.skip(isMobile, "Desktop header");
    await page.goto("/");
    const order = ["Skip to content", "CalcEase home", "All tools", "Categories", "Search tools"];
    for (const name of order) {
      await page.keyboard.press("Tab");
      await expect(page.locator(":focus")).toHaveAccessibleName(name);
    }
  });

  test("mobile: menu opens and closes repeatedly, traps focus, locks scrolling and returns focus", async ({
    page,
    isMobile,
  }) => {
    test.skip(!isMobile, "Mobile menu");
    await page.goto("/percentage-calculator");
    const menuButton = page.getByRole("button", { name: "Menu", exact: true });
    const dialog = page.getByRole("dialog", { name: "Menu" });

    for (let round = 0; round < 3; round++) {
      await menuButton.click();
      await expect(dialog).toBeVisible();
      await expect(menuButton).toHaveAttribute("aria-expanded", "true");
      await expect(dialog.getByRole("button", { name: "Close menu" })).toBeFocused();
      expect(await htmlOverflow(page)).toBe("hidden");
      if (round === 0) await page.keyboard.press("Escape");
      else if (round === 1) await dialog.getByRole("button", { name: "Close menu" }).click();
      else await page.keyboard.press("Escape");
      await expect(dialog).toBeHidden();
      await expect(menuButton).toHaveAttribute("aria-expanded", "false");
      await expect(menuButton).toBeFocused();
      expect(await htmlOverflow(page)).not.toBe("hidden");
    }
  });

  test("mobile: Tab stays inside the open menu", async ({ page, isMobile }) => {
    test.skip(!isMobile, "Mobile menu");
    await page.goto("/");
    await page.getByRole("button", { name: "Menu", exact: true }).click();
    const dialog = page.getByRole("dialog", { name: "Menu" });
    for (let i = 0; i < 12; i++) {
      await page.keyboard.press("Tab");
      const inside = await page.evaluate(() => Boolean(document.activeElement?.closest("dialog")));
      // Focus may briefly sit on the browser chrome between cycles; it must never land on the page.
      const onPage = await page.evaluate(
        () =>
          document.activeElement !== document.body && !document.activeElement?.closest("dialog"),
      );
      expect(inside || !onPage).toBe(true);
    }
    await expect(dialog).toBeVisible();
  });

  test("mobile: choosing a menu link navigates and closes the menu", async ({ page, isMobile }) => {
    test.skip(!isMobile, "Mobile menu");
    await page.goto("/");
    await page.getByRole("button", { name: "Menu", exact: true }).click();
    const dialog = page.getByRole("dialog", { name: "Menu" });
    await dialog.getByRole("link", { name: "Percentage Calculator" }).click();
    await expect(page).toHaveURL(/\/percentage-calculator$/);
    await expect(dialog).toBeHidden();
    expect(await htmlOverflow(page)).not.toBe("hidden");
  });
});

test.describe("Breadcrumbs", () => {
  test("homepage has none; category hub shows Home > category", async ({ page }) => {
    await page.goto("/");
    await expect(page.getByRole("navigation", { name: "Breadcrumb" })).toHaveCount(0);
    await page.goto("/math");
    const crumbs = page.getByRole("navigation", { name: "Breadcrumb" });
    await expect(crumbs.getByRole("listitem")).toHaveText(["Home", /Math & Everyday$/]);
    await expect(crumbs.locator('[aria-current="page"]')).toHaveText("Math & Everyday");
  });
});

test.describe("Links and indexing", () => {
  test("every internal link reachable from the homepage resolves (no broken links)", async ({
    page,
    request,
  }) => {
    const seen = new Set<string>();
    const queue = ["/"];
    while (queue.length > 0) {
      const path = queue.shift()!;
      if (seen.has(path)) continue;
      seen.add(path);
      const response = await request.get(path);
      expect(response.status(), path).toBe(200);
      await page.goto(path);
      // Include links inside the (closed) menus, which are server-rendered for crawlers too.
      const hrefs = await page.$$eval("a[href^='/']", (links) =>
        links.map((a) => a.getAttribute("href")!),
      );
      for (const href of hrefs) {
        const clean = href.split("#")[0]!;
        if (clean && !seen.has(clean)) queue.push(clean);
      }
    }
    expect(seen.has("/percentage-calculator")).toBe(true);
    expect(seen.has("/math")).toBe(true);
    expect(seen.has("/tools")).toBe(true);
  });

  test("planned tools and categories without tools have no pages", async ({ request }) => {
    for (const path of ["/ctc-to-in-hand-salary-calculator", "/no-such-calculator"]) {
      expect((await request.get(path)).status(), path).toBe(404);
    }
  });

  test("draft pages are noindex and left out of the sitemap; methodology is indexable", async ({
    page,
    request,
  }) => {
    for (const path of ["/about", "/contact", "/privacy", "/terms", "/disclaimer"]) {
      await page.goto(path);
      await expect(page.locator('meta[name="robots"]')).toHaveAttribute("content", /noindex/);
      await expect(page.getByText("Draft: this page is not final")).toBeVisible();
    }
    await page.goto("/methodology");
    await expect(page.locator('meta[name="robots"]')).toHaveAttribute("content", "index, follow");
    const sitemap = await (await request.get("/sitemap.xml")).text();
    const locs = [...sitemap.matchAll(/<loc>[^<]*?(\/[^<]*)<\/loc>/g)].map(
      (m) => new URL(m[0].slice(5, -6)).pathname,
    );
    expect(locs.sort()).toEqual(
      [
        "/",
        "/age-calculator",
        "/calculator",
        "/compound-interest-calculator",
        "/date-add-subtract-calculator",
        "/date-difference-calculator",
        "/date-time",
        "/discount-calculator",
        "/emi-calculator",
        "/experience-calculator",
        "/fd-calculator",
        "/finance",
        "/gst-calculator",
        "/lumpsum-calculator",
        "/notice-period-calculator",
        "/math",
        "/methodology",
        "/percentage-calculator",
        "/percentage-hike-calculator",
        "/rd-calculator",
        "/salary",
        "/salary-budget-planner",
        "/sip-calculator",
        "/tools",
      ].sort(),
    );
  });

  test("each page has a unique title, a description, a canonical URL and an Open Graph image", async ({
    page,
  }) => {
    const titles = new Set<string>();
    for (const path of ["/", "/math", "/tools", "/percentage-calculator", "/methodology"]) {
      await page.goto(path);
      const title = await page.title();
      expect(titles.has(title), `${path}: ${title}`).toBe(false);
      titles.add(title);
      await expect(page.locator('meta[name="description"]')).toHaveAttribute("content", /.{50,}/);
      const canonical = await page.locator('link[rel="canonical"]').getAttribute("href");
      expect(new URL(canonical!).pathname, path).toBe(path);
      await expect(page.locator('meta[property="og:image"]')).toHaveAttribute(
        "content",
        /\/og-image\.png$/,
      );
      await expect(page.locator("h1")).toHaveCount(1);
    }
  });

  test("the Open Graph image is served as a PNG", async ({ request }) => {
    const response = await request.get("/og-image.png");
    expect(response.status()).toBe(200);
    expect(response.headers()["content-type"]).toBe("image/png");
  });
});

test("the homepage hero leaves room: the first highlighted tool is on the first screen at 360 × 800", async ({
  page,
  isMobile,
}) => {
  test.skip(!isMobile, "Phone layout");
  await page.setViewportSize({ width: 360, height: 800 });
  await page.goto("/");
  await expect(page.locator("#available").getByRole("link").first()).toBeInViewport({ ratio: 1 });
});
