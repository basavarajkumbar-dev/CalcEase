import { expect, test } from "@playwright/test";
import { chooseMode, expectNoAxeViolations, horizontalOverflow, typeInto } from "./helpers";

const PATH = "/gst-calculator";

test.describe("GST Calculator", () => {
  test("adds 18% GST by default and splits it into CGST + SGST", async ({ page }) => {
    await page.goto(PATH);
    await expect(page.getByTestId("result-value")).toHaveText("₹1,180");
    const panel = page.getByTestId("result-panel");
    await expect(panel).toContainText("CGST (9%)");
    await expect(panel).toContainText("SGST or UTGST (9%)");
    await expect(page.getByTestId("result-sentence")).toHaveText(
      "18% GST on ₹1,000 is ₹180, so the price including GST is ₹1,180.",
    );
  });

  test("removes GST from an inclusive price, with IGST between states", async ({ page }) => {
    await page.goto(PATH);
    await chooseMode(page, "Remove GST from a price");
    await typeInto(page, "Price including GST", "1000");
    await page.getByLabel("GST rate", { exact: true }).selectOption({ label: "5%" });
    await page
      .getByLabel("Where are the buyer and seller?")
      .selectOption({ label: "Different states (IGST)" });
    await expect(page.getByTestId("result-value")).toHaveText("₹952.38");
    const panel = page.getByTestId("result-panel");
    await expect(panel).toContainText("IGST (5%)");
    await expect(panel).toContainText("₹47.62");
    await expect(panel).not.toContainText("CGST");
  });

  test("other rate: accepts a custom rate and rejects one above 100%", async ({ page }) => {
    await page.goto(PATH);
    await page.getByLabel("GST rate", { exact: true }).selectOption({ label: "Other rate" });
    await typeInto(page, "Other rate", "0.25");
    await typeInto(page, "Price before GST", "100");
    await expect(page.getByTestId("result-value")).toHaveText("₹100.25");
    await typeInto(page, "Other rate", "150");
    await expect(page.getByText("Enter a rate between 0% and 100%.")).toBeVisible();
  });

  test("a zero amount shows the allowed range", async ({ page }) => {
    await page.goto(PATH);
    await typeInto(page, "Price before GST", "0");
    await expect(page.getByText(/Enter an amount more than ₹0/)).toBeVisible();
  });

  test("a shared link restores mode, rate and supply type", async ({ page }) => {
    await page.goto(`${PATH}#mode=inclusive&amount=1050&rate=5&supply=inter`);
    await expect(page.getByTestId("result-value")).toHaveText("₹1,000");
    await expect(page.getByTestId("result-panel")).toContainText("IGST (5%)");
  });

  test("an unknown rate in a link falls back to the default", async ({ page }) => {
    await page.goto(`${PATH}#rate=12&amount=1000`);
    await expect(page.getByLabel("GST rate", { exact: true })).toHaveValue("18");
    await expect(page.getByTestId("result-value")).toHaveText("₹1,180");
  });

  test("shows the rates' effective date and official sources", async ({ page }) => {
    await page.goto(PATH);
    const rates = page.locator("#rates");
    await expect(rates).toContainText("22 September 2025");
    await expect(rates.getByRole("link", { name: /Press Information Bureau/ })).toHaveAttribute(
      "href",
      /pib\.gov\.in/,
    );
  });

  test("has no detectable accessibility violations, including with Other rate open", async ({
    page,
  }) => {
    await page.goto(PATH);
    await expectNoAxeViolations(page);
    await page.getByLabel("GST rate", { exact: true }).selectOption({ label: "Other rate" });
    await typeInto(page, "Other rate", "abc");
    await page.getByLabel("Price before GST").focus();
    await expectNoAxeViolations(page);
  });

  test("no horizontal scrolling at 360px", async ({ page }) => {
    await page.setViewportSize({ width: 360, height: 800 });
    await page.goto(PATH);
    await page.getByLabel("GST rate", { exact: true }).selectOption({ label: "Other rate" });
    expect(await horizontalOverflow(page)).toBeLessThanOrEqual(0);
  });
});
