import { expect, test } from "@playwright/test";
import { chooseMode, expectNoAxeViolations, horizontalOverflow, typeInto } from "./helpers";

test.describe("Discount Calculator", () => {
  const PATH = "/discount-calculator";

  test("price after a discount: 15% off ₹1,299", async ({ page }) => {
    await page.goto(PATH);
    await expect(page.getByTestId("result-value")).toHaveText("₹1,104.15");
    await typeInto(page, "Original price", "1000");
    await typeInto(page, "Discount", "10");
    await expect(page.getByTestId("result-value")).toHaveText("₹900");
    await expect(page.getByTestId("result-sentence")).toHaveText(
      "10% off ₹1,000 saves you ₹100, so you pay ₹900.",
    );
  });

  test("discount from a sale price, and the error when the sale price is higher", async ({
    page,
  }) => {
    await page.goto(PATH);
    await chooseMode(page, "Discount from a sale price");
    await typeInto(page, "Original price", "2000");
    await typeInto(page, "Sale price", "1500");
    await expect(page.getByTestId("result-value")).toHaveText("25%");
    await typeInto(page, "Sale price", "2500");
    await expect(page.getByTestId("result-message")).toHaveText(
      "The sale price is higher than the original price, so there is no discount.",
    );
  });

  test("stacked discounts explain that 20% + 10% is 28%", async ({ page }) => {
    await page.goto(PATH);
    await chooseMode(page, "Discount + extra discount");
    await typeInto(page, "Original price", "1000");
    await typeInto(page, "First discount", "20");
    await typeInto(page, "Extra discount", "10");
    await expect(page.getByTestId("result-value")).toHaveText("₹720");
    await expect(page.getByTestId("result-sentence")).toContainText(
      "a total discount of 28%, not 30%",
    );
  });

  test("a discount above 100% shows the allowed range on the field", async ({ page }) => {
    await page.goto(PATH);
    await typeInto(page, "Discount", "120");
    await expect(page.getByText("Enter a discount between 0% and 100%.")).toBeVisible();
    await expect(page.getByLabel("Discount", { exact: true })).toHaveAttribute(
      "aria-invalid",
      "true",
    );
  });

  test("has no detectable accessibility violations, including in an error state", async ({
    page,
  }) => {
    await page.goto(PATH);
    await expectNoAxeViolations(page);
    await typeInto(page, "Discount", "abc");
    await page.getByLabel("Original price").focus();
    await expectNoAxeViolations(page);
  });
});

test.describe("Percentage Hike Calculator", () => {
  const PATH = "/percentage-hike-calculator";

  test("new salary after a hike, with the yearly figure and LPA", async ({ page }) => {
    await page.goto(PATH);
    await typeInto(page, "Current salary (a month)", "70000");
    await typeInto(page, "Hike", "10");
    await expect(page.getByTestId("result-value")).toHaveText("₹77,000");
    await expect(page.getByTestId("result-panel")).toContainText("₹9,24,000 (9.24 LPA)");
  });

  test("hike between two salaries, including a pay cut", async ({ page }) => {
    await page.goto(PATH);
    await chooseMode(page, "Hike between two salaries");
    await typeInto(page, "Current salary (a month)", "45000");
    await typeInto(page, "New salary (a month)", "52650");
    await expect(page.getByTestId("result-value")).toHaveText("17%");
    await expect(page.getByTestId("result-panel")).toContainText("Your hike");
    await typeInto(page, "New salary (a month)", "40500");
    await expect(page.getByTestId("result-value")).toHaveText("10%");
    await expect(page.getByTestId("result-panel")).toContainText("Your pay cut");
  });

  test("switching to yearly relabels the fields", async ({ page }) => {
    await page.goto(PATH);
    await page.getByLabel("Salary is").selectOption({ label: "Per year" });
    await expect(page.getByLabel("Current salary (a year)", { exact: true })).toBeVisible();
  });

  test("has no detectable accessibility violations", async ({ page }) => {
    await page.goto(PATH);
    await expectNoAxeViolations(page);
  });
});

test.describe("Shareable results (query parameters)", () => {
  test("a shared link opens with the same inputs and result", async ({ page }) => {
    await page.goto("/percentage-calculator?mode=percentChange&a=600&b=500");
    await expect(page.getByTestId("result-value")).toHaveText("16.67%");
    await page.goto("/discount-calculator?mode=stacked&price=3999&off=50&extra=20");
    await expect(page.getByTestId("result-value")).toHaveText("₹1,599.60");
    await page.goto(
      "/percentage-hike-calculator?mode=betweenSalaries&per=year&salary=600000&new=720000",
    );
    await expect(page.getByTestId("result-value")).toHaveText("20%");
  });

  test("typing never changes the address bar or sends the inputs anywhere", async ({ page }) => {
    // Regression (wave 1): rewriting the URL made the browser re-request the site icon with
    // a Referer header containing the inputs. Inputs now live only in the page and in the
    // fragment of shared links, which browsers never send.
    await page.goto("/discount-calculator");
    await page.waitForLoadState("networkidle");
    const sent: string[] = [];
    page.on("request", (r) => sent.push(`${r.url()} ${r.headers()["referer"] ?? ""}`));
    await typeInto(page, "Original price", "48213");
    await typeInto(page, "Discount", "37");
    await expect(page.getByTestId("result-value")).toHaveText("₹30,374.19");
    await page.waitForTimeout(1000);
    expect(new URL(page.url()).search + new URL(page.url()).hash).toBe("");
    expect(sent.filter((line) => line.includes("48213") || line.includes("off=37"))).toEqual([]);
    const canonical = await page.locator('link[rel="canonical"]').getAttribute("href");
    expect(new URL(canonical!).search + new URL(canonical!).hash).toBe("");
  });

  test("opening a shared link does not send the inputs to the server", async ({ page }) => {
    const sent: string[] = [];
    page.on("request", (r) => sent.push(`${r.url()} ${r.headers()["referer"] ?? ""}`));
    await page.goto("/discount-calculator#mode=percentOff&price=48213&off=37");
    await expect(page.getByTestId("result-value")).toHaveText("₹30,374.19");
    await page.waitForLoadState("networkidle");
    expect(sent.filter((line) => line.includes("48213"))).toEqual([]);
  });

  test("malicious or malformed parameters are ignored and nothing breaks", async ({ page }) => {
    const errors: string[] = [];
    page.on("pageerror", (e) => errors.push(e.message));
    page.on("dialog", (d) => {
      errors.push(`dialog: ${d.message()}`);
      void d.dismiss();
    });
    await page.goto(
      `/discount-calculator#mode=%3Cscript%3Ealert(1)%3C%2Fscript%3E&price=%3Cimg%20src%3Dx%20onerror%3Dalert(1)%3E&off=${"9".repeat(40)}&extra=abc`,
    );
    // Unknown mode and non-numeric values fall back to the defaults.
    await expect(page.getByTestId("result-value")).toHaveText("₹1,104.15");
    expect(await page.locator("img[src=x]").count()).toBe(0);
    expect(errors).toEqual([]);
  });

  test("an out-of-range value from a link shows a field error rather than a wrong answer", async ({
    page,
  }) => {
    await page.goto("/discount-calculator#mode=percentOff&price=1000&off=150");
    await expect(page.getByText("Enter a discount between 0% and 100%.")).toBeVisible();
    await expect(page.getByTestId("result-value")).toHaveCount(0);
  });

  test("Share copies a link that reproduces the result", async ({ page, context, browserName }) => {
    test.skip(browserName !== "chromium", "Clipboard permissions are Chromium-only in Playwright");
    await context.grantPermissions(["clipboard-read", "clipboard-write"]);
    await page.goto("/percentage-hike-calculator");
    const hasNativeShare = await page.evaluate(() => typeof navigator.share === "function");
    test.skip(hasNativeShare, "Native share sheet instead of clipboard");
    await typeInto(page, "Hike", "12");
    await page.getByRole("button", { name: "Share result" }).click();
    const copied = await page.evaluate(() => navigator.clipboard.readText());
    const link = copied.split("\n").at(-1)!;
    expect(link).toMatch(
      /\/percentage-hike-calculator#mode=byPercent&per=month&salary=50000&hike=12&new=57500$/,
    );
    await page.goto(new URL(link).pathname + new URL(link).hash);
    await expect(page.getByTestId("result-value")).toHaveText("₹56,000");
  });
});

test.describe("Wave 1 layout", () => {
  for (const path of ["/discount-calculator", "/percentage-hike-calculator", "/salary"]) {
    test(`${path} has no horizontal scrolling at 360px`, async ({ page, isMobile }) => {
      test.skip(isMobile, "Explicit viewport");
      await page.setViewportSize({ width: 360, height: 800 });
      await page.goto(path);
      expect(await horizontalOverflow(page)).toBeLessThanOrEqual(0);
    });
  }
});
