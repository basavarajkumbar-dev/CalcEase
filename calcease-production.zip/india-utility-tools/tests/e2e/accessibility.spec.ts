import AxeBuilder from "@axe-core/playwright";
import { expect, test } from "@playwright/test";
import { CALCULATOR_PATH, chooseMode, typeInto } from "./helpers";

const WCAG_TAGS = ["wcag2a", "wcag2aa", "wcag21a", "wcag21aa", "wcag22aa"];

async function axe(page: import("@playwright/test").Page) {
  const results = await new AxeBuilder({ page }).withTags(WCAG_TAGS).analyze();
  return results.violations.map((v) => `${v.id}: ${v.help} (${v.nodes.length} element(s))`);
}

test.describe("Accessibility (axe-core, WCAG 2.2 AA rules)", () => {
  test("homepage has no detectable violations", async ({ page }) => {
    await page.goto("/");
    expect(await axe(page)).toEqual([]);
  });

  test("calculator has no detectable violations in its default state", async ({ page }) => {
    await page.goto(CALCULATOR_PATH);
    expect(await axe(page)).toEqual([]);
  });

  test("calculator has no detectable violations while showing errors", async ({ page }) => {
    await page.goto(CALCULATOR_PATH);
    await typeInto(page, "Percentage", "abc");
    await expect(page.getByLabel("Percentage", { exact: true })).toHaveAttribute(
      "aria-invalid",
      "true",
    );
    expect(await axe(page)).toEqual([]);

    await chooseMode(page, "A number is what % of another?");
    await typeInto(page, "Of the total (whole)", "0");
    await expect(page.getByTestId("result-message")).toBeVisible();
    expect(await axe(page)).toEqual([]);
  });

  test("result is announced to screen readers after typing pauses", async ({ page }) => {
    await page.goto(CALCULATOR_PATH);
    await typeInto(page, "Percentage", "25");
    await typeInto(page, "Of the number", "80");
    const liveRegion = page.locator('[aria-live="polite"]');
    await expect(liveRegion).toHaveText("25% of 80 is 20.");
  });

  test("interactive controls meet the 44 × 44 px touch target size", async ({ page }) => {
    await page.goto(CALCULATOR_PATH);
    const controls = page.locator(
      // Inline links inside sentences are exempt (WCAG 2.5.8); the site footer's links are not.
      "header button:visible, main select, main input, main button, main summary, body > footer a",
    );
    expect(await controls.count()).toBeGreaterThan(5);
    for (const control of await controls.all()) {
      const box = await control.boundingBox();
      const name = await control.evaluate((el) => el.outerHTML.slice(0, 80));
      expect(box?.height ?? 0, name).toBeGreaterThanOrEqual(44);
      expect(box?.width ?? 0, name).toBeGreaterThanOrEqual(44);
    }
  });

  test("open menu and search panels have no detectable violations", async ({ page, isMobile }) => {
    await page.goto(CALCULATOR_PATH);
    if (isMobile) {
      await page.getByRole("button", { name: "Menu", exact: true }).click();
      await expect(page.getByRole("dialog", { name: "Menu" })).toBeVisible();
      expect(await axe(page)).toEqual([]);
      await page.keyboard.press("Escape");
    } else {
      await page.getByRole("button", { name: "Categories" }).click();
      await expect(page.getByRole("navigation", { name: "Categories", exact: true })).toBeVisible();
      expect(await axe(page)).toEqual([]);
      await page.keyboard.press("Escape");
    }
    await page.getByRole("button", { name: "Search tools" }).click();
    await page.getByRole("searchbox", { name: "Search tools" }).fill("percent");
    await expect(page.getByText("3 tools found.")).toBeVisible();
    expect(await axe(page)).toEqual([]);
  });

  for (const path of ["/math", "/tools", "/methodology", "/about", "/privacy"]) {
    test(`${path} has no detectable violations`, async ({ page }) => {
      await page.goto(path);
      expect(await axe(page)).toEqual([]);
    });
  }

  test("search with coming-soon results and no-result suggestions has no violations", async ({
    page,
  }) => {
    await page.goto("/");
    const search = page.getByRole("main").getByRole("searchbox", { name: "Search tools" });
    await search.fill("ctc");
    await expect(page.getByRole("main").getByText("Coming soon").first()).toBeVisible();
    expect(await axe(page)).toEqual([]);
    await search.fill("qqqq");
    await expect(page.getByRole("main").getByText("Try searching for:")).toBeVisible();
    expect(await axe(page)).toEqual([]);
  });

  test("404 page has no detectable violations", async ({ page }) => {
    await page.goto("/no-such-tool");
    expect(await axe(page)).toEqual([]);
  });

  test("there is exactly one h1 and a skip link", async ({ page }) => {
    await page.goto(CALCULATOR_PATH);
    await expect(page.locator("h1")).toHaveCount(1);
    await expect(page.getByRole("link", { name: "Skip to content" })).toHaveAttribute(
      "href",
      "#main",
    );
  });
});
