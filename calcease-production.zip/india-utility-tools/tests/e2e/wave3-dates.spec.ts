import { expect, test, type Page } from "@playwright/test";
import { chooseMode, expectNoAxeViolations, horizontalOverflow, typeInto } from "./helpers";

/** Fix the device clock: 7 October 2026, mid-morning local time. */
async function fixToday(page: Page, iso = "2026-10-07T10:00:00") {
  await page.clock.setFixedTime(new Date(iso));
}

async function setDate(page: Page, label: string, iso: string) {
  await page.getByLabel(label, { exact: true }).fill(iso);
}

const value = (page: Page) => page.getByTestId("result-value");
const panel = (page: Page) => page.getByTestId("result-panel");

test.describe("Age Calculator", () => {
  const PATH = "/age-calculator";

  test("uses today's date by default and shows the exact age", async ({ page }) => {
    await fixToday(page);
    await page.goto(PATH);
    await expect(page.getByLabel("Age on", { exact: true })).toHaveValue("2026-10-07");
    await expect(value(page)).toHaveText("26 years");
    await setDate(page, "Date of birth", "1990-08-15");
    await expect(value(page)).toHaveText("36 years");
    await expect(page.getByTestId("result-sentence")).toHaveText(
      "You are 36 years, 1 month and 22 days old today.",
    );
    await expect(panel(page)).toContainText("Sunday, 15 August 2027, in 312 days (turning 37)");
    await expect(panel(page)).toContainText("13,202 days");
  });

  test("leap-day birthday is counted on 28 February and says so", async ({ page }) => {
    await fixToday(page);
    await page.goto(`${PATH}#dob=2000-02-29&on=2023-02-28`);
    await expect(value(page)).toHaveText("23 years");
    await expect(panel(page)).toContainText("Happy birthday!");
    await expect(panel(page)).toContainText("the birthday is counted on 28 February");
  });

  test("a date of birth after the date is explained", async ({ page }) => {
    await fixToday(page);
    await page.goto(PATH);
    await setDate(page, "Date of birth", "2026-10-08");
    await expect(page.getByTestId("result-message")).toHaveText(
      "The date of birth is after the date you are calculating the age on.",
    );
  });

  test("an impossible date in a link is flagged, not guessed", async ({ page }) => {
    await fixToday(page);
    await page.goto(`${PATH}#dob=2023-02-30`);
    await expect(page.getByText("Enter a real date, for example 15/08/1990.")).toBeVisible();
    await expect(page.getByTestId("result-message")).toHaveText(
      "Fix the highlighted value to see your result.",
    );
  });

  test("'today' follows the device's own time zone", async ({ browser }) => {
    // 12:00 UTC on 7 October is already 8 October on Kiritimati (UTC+14).
    const context = await browser.newContext({ timezoneId: "Pacific/Kiritimati" });
    const page = await context.newPage();
    await page.clock.setFixedTime(new Date("2026-10-07T12:00:00Z"));
    await page.goto(PATH);
    await expect(page.getByLabel("Age on", { exact: true })).toHaveValue("2026-10-08");
    await context.close();
  });

  test("has no detectable accessibility violations", async ({ page }) => {
    await fixToday(page);
    await page.goto(PATH);
    await expect(value(page)).toBeVisible();
    await expectNoAxeViolations(page);
  });
});

test.describe("Date Difference Calculator", () => {
  const PATH = "/date-difference-calculator";

  test("defaults to today until 31 December", async ({ page }) => {
    await fixToday(page);
    await page.goto(PATH);
    await expect(value(page)).toHaveText("85 days");
  });

  test("counts a leap year, with and without the end date", async ({ page }) => {
    await fixToday(page);
    await page.goto(PATH);
    await setDate(page, "Start date", "2024-01-01");
    await setDate(page, "End date", "2024-12-31");
    await expect(value(page)).toHaveText("365 days");
    await expect(panel(page)).toContainText("261 days");
    await page.getByLabel("Include the end date").check();
    await expect(value(page)).toHaveText("366 days");
    await expect(page.getByTestId("result-sentence")).toContainText("is 1 year (366 days)");
  });

  test("swaps reversed dates and says so", async ({ page }) => {
    await fixToday(page);
    await page.goto(`${PATH}#from=2026-10-07&to=2000-02-29`);
    await expect(value(page)).toHaveText("9,717 days");
    await expect(panel(page)).toContainText("the dates were swapped");
  });

  test("is not thrown off by daylight saving time on the device", async ({ browser }) => {
    // US clocks went forward on 8 March 2026: a Date-based count could give 13.96 days.
    const context = await browser.newContext({ timezoneId: "America/New_York" });
    const page = await context.newPage();
    await page.clock.setFixedTime(new Date("2026-10-07T10:00:00Z"));
    await page.goto(`${PATH}#from=2026-03-01&to=2026-03-15`);
    await expect(value(page)).toHaveText("14 days");
    await context.close();
  });

  test("has no detectable accessibility violations", async ({ page }) => {
    await fixToday(page);
    await page.goto(PATH);
    await expect(value(page)).toBeVisible();
    await expectNoAxeViolations(page);
  });
});

test.describe("Date Add / Subtract Calculator", () => {
  const PATH = "/date-add-subtract-calculator";

  test("adds 30 days to today by default", async ({ page }) => {
    await fixToday(page);
    await page.goto(PATH);
    await expect(value(page)).toHaveText("6 November 2026");
  });

  test("month-end dates are clamped and explained", async ({ page }) => {
    await fixToday(page);
    await page.goto(PATH);
    await setDate(page, "Start date", "2026-01-31");
    await page.getByLabel("Days", { exact: true }).fill("");
    await typeInto(page, "Months", "1");
    await expect(value(page)).toHaveText("28 February 2026");
    await expect(panel(page)).toContainText("February 2026 has no day 31");
  });

  test("subtracts days", async ({ page }) => {
    await fixToday(page);
    await page.goto(PATH);
    await chooseMode(page, "Subtract from the date", "Add or subtract?");
    await typeInto(page, "Days", "45");
    await expect(value(page)).toHaveText("23 August 2026");
  });

  test("whole numbers only, and results must stay in range", async ({ page }) => {
    await fixToday(page);
    await page.goto(PATH);
    await typeInto(page, "Months", "1.5");
    await expect(page.getByText("Enter a whole number, without decimals.")).toBeVisible();
    await typeInto(page, "Months", "0");
    await typeInto(page, "Years", "300");
    await expect(page.getByTestId("result-message")).toContainText(
      "outside the dates this calculator supports",
    );
  });

  test("has no detectable accessibility violations", async ({ page }) => {
    await fixToday(page);
    await page.goto(PATH);
    await expect(value(page)).toBeVisible();
    await expectNoAxeViolations(page);
  });
});

test.describe("Wave 3 layout", () => {
  for (const path of [
    "/age-calculator",
    "/date-difference-calculator",
    "/date-add-subtract-calculator",
    "/date-time",
  ]) {
    test(`${path} has no horizontal scrolling at 360px`, async ({ page, isMobile }) => {
      test.skip(isMobile, "Explicit viewport");
      await fixToday(page);
      await page.setViewportSize({ width: 360, height: 800 });
      await page.goto(path);
      expect(await horizontalOverflow(page)).toBeLessThanOrEqual(0);
    });
  }
});
