import { expect, test, type Page } from "@playwright/test";
import { expectNoAxeViolations, horizontalOverflow, typeInto } from "./helpers";

const value = (page: Page) => page.getByTestId("result-value");
const panel = (page: Page) => page.getByTestId("result-panel");

async function fixToday(page: Page) {
  await page.clock.setFixedTime(new Date("2026-10-07T10:00:00"));
}

test.describe("Compound Interest Calculator", () => {
  const PATH = "/compound-interest-calculator";

  test("quarterly compounding, effective rate and simple-interest comparison", async ({ page }) => {
    await page.goto(PATH);
    await typeInto(page, "Principal", "100000");
    await typeInto(page, "Interest rate (a year)", "8");
    await typeInto(page, "Years", "3");
    await expect(value(page)).toHaveText("₹1,26,824.18");
    await expect(panel(page)).toContainText("8.24%");
    await expect(panel(page)).toContainText("₹24,000");
  });

  test("year-by-year table opens and ends at the total", async ({ page }) => {
    await page.goto(`${PATH}#p=100000&rate=10&years=2&freq=yearly`);
    await expect(value(page)).toHaveText("₹1,21,000");
    await page.getByText("Year-by-year growth").click();
    const table = page.getByRole("table", { name: /balance at the end of each year/ });
    await expect(table.getByRole("row")).toHaveCount(3);
    await expect(table).toContainText("₹1,10,000");
    await expect(table).toContainText("₹1,21,000");
  });

  test("a time of zero is explained", async ({ page }) => {
    await page.goto(PATH);
    await typeInto(page, "Years", "0");
    await expect(page.getByTestId("result-message")).toHaveText(
      "Enter a time of more than 0 and up to 100 years.",
    );
  });

  test("has no detectable accessibility violations, including the open table", async ({ page }) => {
    await page.goto(PATH);
    await page.getByText("Year-by-year growth").click();
    await expectNoAxeViolations(page);
  });
});

test.describe("FD Calculator", () => {
  const PATH = "/fd-calculator";

  test("matches ICICI Bank's published example to the rupee", async ({ page }) => {
    await fixToday(page);
    await page.goto(`${PATH}#amount=100000&rate=6.6&years=3&date=2026-01-01`);
    await expect(value(page)).toHaveText("₹1,21,699.44");
    await expect(panel(page)).toContainText("12 quarters compounded");
  });

  test("part quarters are simple interest for the exact days, with the maturity date", async ({
    page,
  }) => {
    await fixToday(page);
    await page.goto(PATH);
    await typeInto(page, "Months", "2");
    await typeInto(page, "Days", "10");
    await expect(value(page)).toHaveText("₹1,08,645.39");
    await expect(panel(page)).toContainText("Friday, 17 December 2027");
    await expect(panel(page)).toContainText(
      "4 quarters compounded, then simple interest for 71 days",
    );
  });

  test("the short-deposit rule appears under a year and changes the answer", async ({ page }) => {
    await fixToday(page);
    await page.goto(`${PATH}#amount=50000&rate=6&years=0&months=6`);
    const rule = page.getByLabel("Your bank pays simple interest on deposits");
    await expect(value(page)).toHaveText("₹51,511.25");
    await rule.selectOption({ label: "Shorter than 12 months" });
    await expect(value(page)).toHaveText("₹51,495.89");
    await typeInto(page, "Years", "1");
    await expect(rule).toHaveCount(0);
  });

  test("quarterly payout shows the interest each quarter", async ({ page }) => {
    await fixToday(page);
    await page.goto(`${PATH}#amount=200000&rate=7.25&years=2&payout=quarterly`);
    await expect(value(page)).toHaveText("₹3,625");
    await expect(panel(page)).toContainText("₹29,000");
  });

  test("tenures under 7 days are explained", async ({ page }) => {
    await fixToday(page);
    await page.goto(`${PATH}#years=0&days=5`);
    await expect(page.getByTestId("result-message")).toHaveText(
      "A fixed deposit must be for at least 7 days.",
    );
  });

  test("shows its method sources and has no accessibility violations", async ({ page }) => {
    await fixToday(page);
    await page.goto(PATH);
    await expect(
      page.locator("#sources").getByRole("link", { name: /Reserve Bank of India/ }),
    ).toHaveAttribute("href", /rbi\.org\.in/);
    await expect(value(page)).toBeVisible();
    await expectNoAxeViolations(page);
  });
});

test.describe("RD Calculator", () => {
  const PATH = "/rd-calculator";

  test("matches ICICI Bank's published example", async ({ page }) => {
    await page.goto(PATH);
    await typeInto(page, "Monthly instalment", "5000");
    await typeInto(page, "Interest rate (a year)", "8");
    await typeInto(page, "Tenure (months)", "12");
    await expect(value(page)).toHaveText("₹62,646.63");
  });

  test("tenures must be whole quarters", async ({ page }) => {
    await page.goto(PATH);
    await typeInto(page, "Tenure (months)", "13");
    await expect(page.getByTestId("result-message")).toContainText(
      "Enter a tenure in whole quarters",
    );
  });

  test("has no detectable accessibility violations", async ({ page }) => {
    await page.goto(PATH);
    await expectNoAxeViolations(page);
  });
});

test.describe("Wave 4 layout", () => {
  for (const path of [
    "/compound-interest-calculator",
    "/fd-calculator",
    "/rd-calculator",
    "/finance",
  ]) {
    test(`${path} has no horizontal scrolling at 360px`, async ({ page, isMobile }) => {
      test.skip(isMobile, "Explicit viewport");
      await fixToday(page);
      await page.setViewportSize({ width: 360, height: 800 });
      await page.goto(path);
      expect(await horizontalOverflow(page)).toBeLessThanOrEqual(0);
    });
  }
});
