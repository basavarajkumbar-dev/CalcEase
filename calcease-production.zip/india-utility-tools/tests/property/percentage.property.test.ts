/**
 * Property-based tests: each property is a mathematical invariant that must hold
 * for every valid input, checked against thousands of random inputs by fast-check.
 * They catch classes of bugs that hand-picked examples miss (sign errors, swapped
 * arguments, precision loss in one mode but not another).
 *
 * Why fast-check: it is the standard, well-maintained property-testing library for
 * TypeScript, is a dev-only dependency (zero bytes shipped to users), and shrinks a
 * failing input to the smallest counter-example, which makes failures easy to debug.
 */
import fc from "fast-check";
import { describe, it } from "vitest";
import {
  calculateDecreaseBy,
  calculateIncreaseBy,
  calculatePercentChange,
  calculatePercentOf,
  calculateWhatPercent,
  MAX_ABS_INPUT,
  type CalcResult,
} from "@/lib/calc/percentage";
import { parseNumberInput } from "@/lib/validation/parse-number";

/** Realistic amounts: up to ±10 lakh with two decimal places (paise). */
const amount = fc.integer({ min: -100_000_000, max: 100_000_000 }).map((n) => n / 100);
const nonZeroAmount = amount.filter((n) => n !== 0);
/** Realistic percentages: −1000% to 1000% with two decimal places. */
const percent = fc.integer({ min: -100_000, max: 100_000 }).map((n) => n / 100);
/** Any finite double inside the accepted range, including awkward ones (subnormals, -0). */
const anyValidNumber = fc.double({
  min: -MAX_ABS_INPUT,
  max: MAX_ABS_INPUT,
  noNaN: true,
  noDefaultInfinity: true,
});

function value(result: CalcResult): number {
  if (!result.ok) throw new Error(`Unexpected error ${result.error}`);
  return result.value;
}

/** Relative tolerance for chains of two operations. */
function approx(actual: number, expected: number, relative = 1e-9): boolean {
  const diff = Math.abs(actual - expected);
  return diff <= 1e-9 || diff <= relative * Math.abs(expected);
}

const RUNS = { numRuns: 2000 };

describe("percentage invariants", () => {
  it("100% of x is x", () => {
    // The definition of "per cent": a hundred hundredths is the whole.
    fc.assert(
      fc.property(amount, (x) => approx(value(calculatePercentOf(100, x)), x)),
      RUNS,
    );
  });

  it("modes A and B are inverses: (p% of x) is p% of x", () => {
    // If the two modes disagreed, one of them has a bug (e.g. swapped arguments).
    fc.assert(
      fc.property(percent, nonZeroAmount, (p, x) => {
        const part = value(calculatePercentOf(p, x));
        return approx(value(calculateWhatPercent(part, x)), p);
      }),
      RUNS,
    );
  });

  it("modes C and E agree: increasing x by p% is a change of p% (sign follows x)", () => {
    // With the |start| convention, a positive start rises by p%; for a negative start the
    // same multiplication moves it further below zero, which is a fall of p%.
    fc.assert(
      fc.property(nonZeroAmount, percent, (x, p) => {
        const increased = value(calculateIncreaseBy(x, p));
        if (increased === x) return true; // p rounds away entirely for tiny x
        const change = value(calculatePercentChange(x, increased));
        return approx(change, Math.sign(x) * p, 1e-6);
      }),
      RUNS,
    );
  });

  it("increase and decrease by the same p% are symmetric around x", () => {
    // x(1 + p) + x(1 − p) = 2x: catches a sign error in either function.
    fc.assert(
      fc.property(amount, percent, (x, p) => {
        const sum = value(calculateIncreaseBy(x, p)) + value(calculateDecreaseBy(x, p));
        return approx(sum, 2 * x);
      }),
      RUNS,
    );
  });

  it("decreasing by the reverse percentage undoes an increase", () => {
    // The common user confusion (spec, edge case 1): +p% is undone by −p/(1+p/100)%,
    // not by −p%. Restricted to p > −90% so 1 + p/100 stays well away from zero.
    const p = fc.integer({ min: -9_000, max: 100_000 }).map((n) => n / 100);
    fc.assert(
      fc.property(amount, p, (x, pct) => {
        const increased = value(calculateIncreaseBy(x, pct));
        const reverse = pct / (1 + pct / 100);
        return approx(value(calculateDecreaseBy(increased, reverse)), x, 1e-8);
      }),
      RUNS,
    );
  });

  it("p% of x grows with p when x is positive", () => {
    fc.assert(
      fc.property(nonZeroAmount.map(Math.abs), percent, percent, (x, p1, p2) => {
        const [lo, hi] = p1 <= p2 ? [p1, p2] : [p2, p1];
        return value(calculatePercentOf(lo, x)) <= value(calculatePercentOf(hi, x));
      }),
      RUNS,
    );
  });

  it("every function returns a finite number or a typed error for any in-range input, never -0", () => {
    // Robustness: NaN, Infinity or -0 must never reach the UI, whatever the inputs.
    const fns = [
      calculatePercentOf,
      calculateWhatPercent,
      calculatePercentChange,
      calculateIncreaseBy,
      calculateDecreaseBy,
    ];
    fc.assert(
      fc.property(anyValidNumber, anyValidNumber, (a, b) => {
        for (const fn of fns) {
          const result = fn(a, b);
          if (result.ok) {
            if (!Number.isFinite(result.value) || Object.is(result.value, -0)) return false;
          } else if (result.error !== "DIVISION_BY_ZERO" && result.error !== "RESULT_TOO_LARGE") {
            return false;
          }
        }
        return true;
      }),
      { numRuns: 5000 },
    );
  });
});

describe("parser invariants", () => {
  it("parses any in-range integer written with Indian grouping back to itself", () => {
    const grouped = new Intl.NumberFormat("en-IN", { useGrouping: true, maximumFractionDigits: 0 });
    fc.assert(
      fc.property(fc.integer({ min: -MAX_ABS_INPUT, max: MAX_ABS_INPUT }), (n) => {
        const parsed = parseNumberInput(grouped.format(n));
        return parsed.ok && parsed.value === (n === 0 ? 0 : n);
      }),
      RUNS,
    );
  });

  it("never throws, whatever text is typed", () => {
    fc.assert(
      fc.property(fc.string(), (text) => {
        const result = parseNumberInput(text);
        return result.ok ? Number.isFinite(result.value) : typeof result.error === "string";
      }),
      { numRuns: 5000 },
    );
  });
});
