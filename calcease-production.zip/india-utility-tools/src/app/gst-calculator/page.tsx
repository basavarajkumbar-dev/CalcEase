import type { Metadata } from "next";
import { GstCalculator } from "@/components/calculator/gst-calculator";
import type { FaqItem } from "@/components/content/faq-list";
import { SourceList } from "@/components/content/source-list";
import { ToolPage, type ToolSection } from "@/components/tool/tool-page";
import { Callout } from "@/components/ui/callout";
import { DataTable } from "@/components/ui/data-table";
import { CURRENT_GST_RULES } from "@/lib/rules/gst/rates";
import { getActiveTool } from "@/lib/tools/registry";
import { pageMetadata } from "@/seo/page-metadata";

const tool = getActiveTool("gst-calculator");
const rules = CURRENT_GST_RULES;

export const metadata: Metadata = pageMetadata({
  title: tool.title,
  description: tool.metaDescription,
  path: `/${tool.slug}`,
});

const longDate = (iso: string) =>
  new Intl.DateTimeFormat("en-IN", { dateStyle: "long", timeZone: "UTC" }).format(new Date(iso));

interface Example {
  situation: string;
  working: string;
  answer: string;
}

// Values match tests/fixtures/gst.json (verified with exact arithmetic).
const EXAMPLES: readonly Example[] = [
  { situation: "₹1,000 + 18% GST", working: "1,000 × 18 ÷ 100 = 180", answer: "₹1,180" },
  {
    situation: "₹1,180 including 18% GST",
    working: "1,180 × 100 ÷ 118",
    answer: "₹1,000 + ₹180 GST",
  },
  {
    situation: "₹1,050 including 5% GST",
    working: "1,050 × 100 ÷ 105",
    answer: "₹1,000 + ₹50 GST",
  },
  {
    situation: "₹1,000 including 5% GST",
    working: "1,000 × 100 ÷ 105",
    answer: "₹952.38 + ₹47.62 GST",
  },
];

interface RateRow {
  rate: string;
  name: string;
}

const RATE_ROWS: readonly RateRow[] = rules.presets.map((p) => ({
  rate: `${p.rate}%`,
  name: p.name,
}));

const sections: readonly ToolSection[] = [
  {
    id: "how-it-works",
    title: "How it is calculated",
    content: (
      <>
        <h3 className="text-h3">Adding GST to a price</h3>
        <p>
          Multiply the price before GST by the rate and divide by 100 to get the GST, then add it.{" "}
          <code>1,000 × 18 ÷ 100 = 180</code>, so the price including GST is ₹1,180.
        </p>
        <h3 className="text-h3">Removing GST from a price that includes it</h3>
        <p>
          Multiply the price by 100 and divide by 100 plus the rate. The difference is the GST.{" "}
          <code>1,180 × 100 ÷ 118 = 1,000</code>, so the GST is ₹180.
        </p>
        <p>
          Taking 18% off ₹1,180 does not work: that gives ₹967.60, because the GST was worked out on
          ₹1,000, not on ₹1,180.
        </p>
        <h3 className="text-h3">CGST, SGST and IGST</h3>
        <p>
          When the seller and the place of supply are in the same state or union territory, the GST
          is split equally into Central GST (CGST) and State GST (SGST), or Union Territory GST
          (UTGST). At 18%, that is 9% + 9%. Between states, the whole amount is Integrated GST
          (IGST). The total is the same either way. In practice the place-of-supply rules decide
          which applies; the calculator lets you choose.
        </p>
      </>
    ),
  },
  {
    id: "examples",
    title: "Worked examples",
    content: (
      <DataTable
        caption="GST added to and removed from prices"
        columns={[
          { key: "situation", header: "Situation", cell: (row: Example) => row.situation },
          {
            key: "working",
            header: "Working",
            hideOnMobile: true,
            cell: (row: Example) => <span className="numeric">{row.working}</span>,
          },
          { key: "answer", header: "Result", numeric: true, cell: (row: Example) => row.answer },
        ]}
        rows={EXAMPLES}
        rowKey={(row) => row.situation}
      />
    ),
  },
  {
    id: "rates",
    title: "GST rates and sources",
    content: (
      <>
        <p>
          The rate options follow the structure recommended by the 56th GST Council meeting, in
          force from <time dateTime={rules.effectiveFrom}>{longDate(rules.effectiveFrom)}</time>.
        </p>
        <DataTable
          caption="GST rate options in this calculator"
          columns={[
            { key: "rate", header: "Rate", cell: (row: RateRow) => row.rate },
            { key: "name", header: "Official name", cell: (row: RateRow) => row.name },
          ]}
          rows={RATE_ROWS}
          rowKey={(row) => row.rate}
        />
        <ul>
          {rules.notes.map((note) => (
            <li key={note}>{note}</li>
          ))}
        </ul>
        <p>Sources:</p>
        <SourceList sources={rules.sources} />
        <p>
          Rates last checked against these sources on{" "}
          <time dateTime={rules.reviewedOn}>{longDate(rules.reviewedOn)}</time>.
        </p>
      </>
    ),
  },
  {
    id: "limits",
    title: "What this calculator does not cover",
    content: (
      <Callout tone="warning" title="An estimate, not a tax assessment">
        <p>
          The GST on a real transaction depends on how the goods or services are classified (HSN or
          SAC code), the place of supply and the applicable notifications. This calculator does not
          handle compensation cess, reverse charge, the composition scheme, TCS or input tax credit.
          Check the invoice or ask a tax professional for anything you will file or pay.
        </p>
      </Callout>
    ),
  },
];

const faqs: readonly FaqItem[] = [
  {
    question: "Which GST rate applies to my product or service?",
    answer: (
      <p>
        It depends on its HSN or SAC classification. Most goods and services are at 5% or 18%, a
        select few at 40%, and some are nil-rated or exempt. The calculator does not look up rates
        by product; check the invoice or the official rate notifications.
      </p>
    ),
  },
  {
    question: "What about 12% or 28% GST?",
    answer: (
      <p>
        Those slabs were part of the structure before {longDate(rules.effectiveFrom)}. To check an
        older invoice, choose &ldquo;Other rate&rdquo; and type the rate.
      </p>
    ),
  },
  {
    question: "Why are CGST and SGST sometimes a paisa apart from half the GST?",
    answer: (
      <p>
        The calculator shows each half exactly, rounded to the paisa for display. When the GST has
        an odd number of paise, the two halves cannot both be exact, and invoicing software rounds
        each component its own way.
      </p>
    ),
  },
  {
    question: "Is MRP inclusive of GST?",
    answer: (
      <p>
        Yes. The{" "}
        <a
          href="https://legalmetrology.nagaland.gov.in/documents/11/9_The_Legal_Metrology_Package_Commodities_Rules_2011.pdf"
          rel="noopener noreferrer"
        >
          Legal Metrology (Packaged Commodities) Rules, 2011
        </a>{" "}
        define the maximum retail price on a package as inclusive of all taxes. Use &ldquo;Remove
        GST from a price&rdquo; to see how much of it is GST.
      </p>
    ),
  },
];

export default function GstCalculatorPage() {
  return (
    <ToolPage
      tool={tool}
      intro={
        <p>
          Add GST to a price, or find the GST inside a price that already includes it, with the CGST
          + SGST or IGST split.
        </p>
      }
      calculator={<GstCalculator />}
      sections={sections}
      faqs={faqs}
    />
  );
}
