import type { Metadata } from "next";
import { CompoundInterestCalculator } from "@/components/calculator/compound-interest-calculator";
import type { FaqItem } from "@/components/content/faq-list";
import { ToolPage, type ToolSection } from "@/components/tool/tool-page";
import { Callout } from "@/components/ui/callout";
import { DataTable } from "@/components/ui/data-table";
import { getActiveTool } from "@/lib/tools/registry";
import { pageMetadata } from "@/seo/page-metadata";

const tool = getActiveTool("compound-interest-calculator");

export const metadata: Metadata = pageMetadata({
  title: tool.title,
  description: tool.metaDescription,
  path: `/${tool.slug}`,
});

interface Example {
  investment: string;
  working: string;
  amount: string;
}

// Values match tests/fixtures/deposits.json (independently verified).
const EXAMPLES: readonly Example[] = [
  {
    investment: "₹1,00,000 at 10% for 2 years, yearly",
    working: "1,00,000 × 1.1²",
    amount: "₹1,21,000",
  },
  {
    investment: "₹1,00,000 at 8% for 3 years, quarterly",
    working: "1,00,000 × 1.02¹²",
    amount: "₹1,26,824.18",
  },
  {
    investment: "₹50,000 at 12% for 1½ years, half-yearly",
    working: "50,000 × 1.06³",
    amount: "₹59,550.80",
  },
  {
    investment: "₹10,000 at 5% for 10 years, monthly",
    working: "10,000 × (1 + 0.05/12)¹²⁰",
    amount: "₹16,470.09",
  },
];

const sections: readonly ToolSection[] = [
  {
    id: "how-it-works",
    title: "How it is calculated",
    content: (
      <>
        <p>
          With compound interest, the interest for each period is added to the balance, and the next
          period&rsquo;s interest is worked out on the larger balance.
        </p>
        <p>
          <code>A = P × (1 + r ÷ 100n)^(n × t)</code>, where P is the principal, r the yearly rate
          in percent, n the number of times interest is added each year and t the time in years. The
          interest is A − P.
        </p>
        <p>
          The effective annual rate shows what the compounding is worth: 8% compounded quarterly is
          the same as about 8.24% added once a year.
        </p>
      </>
    ),
  },
  {
    id: "examples",
    title: "Worked examples",
    content: (
      <DataTable
        caption="Compound interest examples"
        columns={[
          { key: "investment", header: "Investment", cell: (r: Example) => r.investment },
          {
            key: "working",
            header: "Working",
            hideOnMobile: true,
            cell: (r: Example) => <span className="numeric">{r.working}</span>,
          },
          { key: "amount", header: "Amount", numeric: true, cell: (r: Example) => r.amount },
        ]}
        rows={EXAMPLES}
        rowKey={(r) => r.investment}
      />
    ),
  },
  {
    id: "edge-cases",
    title: "Good to know",
    content: (
      <>
        <Callout tone="info" title="Part periods">
          <p>
            If the time is not a whole number of periods (1½ years compounded yearly), the formula
            is used with a fractional power, as in textbooks. Banks often pay simple interest for a
            part period instead; the FD Calculator follows the bank method.
          </p>
        </Callout>
        <Callout tone="warning" title="Before tax and inflation">
          <p>
            Results are before income tax on the interest and do not allow for inflation. Rates on
            real investments can change.
          </p>
        </Callout>
      </>
    ),
  },
];

const faqs: readonly FaqItem[] = [
  {
    question: "What is the difference between simple and compound interest?",
    answer: (
      <p>
        Simple interest is worked out on the original amount only. Compound interest is also worked
        out on interest already added, so it grows faster over time. The calculator shows both.
      </p>
    ),
  },
  {
    question: "Does more frequent compounding make much difference?",
    answer: (
      <p>
        A little. ₹1,00,000 at 8% for 3 years is ₹1,25,971.20 compounded yearly and ₹1,26,824.18
        compounded quarterly.
      </p>
    ),
  },
  {
    question: "Can I use it for a fixed deposit?",
    answer: (
      <p>
        For whole quarters, yes, with quarterly compounding. For exact bank figures with a maturity
        date and part quarters, use the FD Calculator.
      </p>
    ),
  },
];

export default function CompoundInterestCalculatorPage() {
  return (
    <ToolPage
      tool={tool}
      intro={
        <p>
          How a lump sum grows with interest compounded yearly, half-yearly, quarterly or monthly,
          year by year.
        </p>
      }
      calculator={<CompoundInterestCalculator />}
      sections={sections}
      faqs={faqs}
    />
  );
}
