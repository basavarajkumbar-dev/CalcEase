/**
 * UNDER REVIEW. This page exists only in review builds (ENABLE_UNDER_REVIEW_TOOLS=1).
 * In production builds it is a 404: not published, not in the sitemap, never linked.
 * Publishing requires the chartered-accountant review in docs/reviews/ctc-to-in-hand.md.
 */
import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { CtcCalculator } from "@/components/calculator/ctc-calculator";
import type { FaqItem } from "@/components/content/faq-list";
import { SourceList } from "@/components/content/source-list";
import { ToolPage, type ToolSection } from "@/components/tool/tool-page";
import { Callout } from "@/components/ui/callout";
import { UNDER_REVIEW_TOOLS_ENABLED } from "@/config/review";
import { CURRENT_EPF_RULES } from "@/lib/rules/epf/rates";
import { GRATUITY_SOURCE } from "@/lib/rules/gratuity";
import { CURRENT_INCOME_TAX_RULES as TAX } from "@/lib/rules/income-tax/rates";
import { CTC_REVIEW_TOOL as tool } from "@/lib/tools/review-tools";
import { pageMetadata } from "@/seo/page-metadata";

export const metadata: Metadata = pageMetadata({
  title: tool.title,
  description: tool.metaDescription,
  path: `/${tool.slug}`,
  // Never indexed while under review, even in review builds.
  noindex: true,
});

const rupees = (n: number) => `₹${new Intl.NumberFormat("en-IN").format(n)}`;

const sections: readonly ToolSection[] = [
  {
    id: "how-it-works",
    title: "How it is calculated",
    content: (
      <>
        <ol>
          <li>Basic salary = CTC × basic %.</li>
          <li>
            PF = 12% of basic (or of basic up to the wage ceiling) for you, and the same from your
            employer.
          </li>
          <li>Gross salary = CTC − employer&rsquo;s PF − other employer costs.</li>
          <li>
            Taxable income = gross − standard deduction ({rupees(TAX.newRegime.standardDeduction)}{" "}
            new regime, {rupees(TAX.oldRegime.standardDeduction)} old regime) − professional tax
            (old regime) − your deductions (old regime).
          </li>
          <li>Income tax from the slabs, less the rebate, plus 4% cess.</li>
          <li>In-hand = gross − your PF − professional tax − income tax.</li>
        </ol>
      </>
    ),
  },
  {
    id: "sources",
    title: "Rules and sources",
    content: (
      <>
        <p>Income tax, tax year {TAX.taxYear}:</p>
        <SourceList sources={TAX.sources} />
        <p>
          Provident Fund (wage ceiling {rupees(CURRENT_EPF_RULES.wageCeiling)} a month from 17
          September 2026):
        </p>
        <SourceList sources={CURRENT_EPF_RULES.sources} />
        <p>
          Gratuity (optional), professional tax (enter your state&rsquo;s amount from your payslip):
        </p>
        <SourceList sources={[GRATUITY_SOURCE]} />
        <ul>
          {[...TAX.notes, ...CURRENT_EPF_RULES.notes].map((n) => (
            <li key={n}>{n}</li>
          ))}
        </ul>
      </>
    ),
  },
  {
    id: "limits",
    title: "Not covered",
    content: (
      <Callout tone="warning" title="Under review">
        <p>
          Surcharge (taxable income above ₹50 lakh), HRA exemption worked out from rent, employer
          NPS contributions, perquisites, bonuses, arrears and the rounding rules for tax are not
          calculated.
        </p>
      </Callout>
    ),
  },
];

const faqs: readonly FaqItem[] = [];

export default function CtcToInHandPage() {
  if (!UNDER_REVIEW_TOOLS_ENABLED) notFound();
  return (
    <ToolPage
      tool={tool}
      intro={
        <p>
          Estimated monthly take-home pay from your CTC, after PF, professional tax and income tax.
        </p>
      }
      calculator={<CtcCalculator />}
      sections={sections}
      faqs={faqs}
    />
  );
}
