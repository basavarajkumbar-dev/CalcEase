"use client";

import { Container } from "@/components/layout/container";
import { Button, ButtonLink } from "@/components/ui/button";

/** Generic error state for an unexpected failure while rendering a page. */
export default function ErrorPage({
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <Container className="py-8 md:py-12">
      <div className="max-w-prose">
        <h1 className="text-h1 text-ink">Something went wrong on this page</h1>
        <p className="mt-3 text-muted">
          Your numbers were not sent anywhere. Try loading the page again; if it keeps happening, go
          back to the list of tools.
        </p>
        <div className="mt-6 flex flex-wrap gap-3">
          <Button onClick={reset}>Try again</Button>
          <ButtonLink href="/" variant="secondary">
            Go to all tools
          </ButtonLink>
        </div>
      </div>
    </Container>
  );
}
