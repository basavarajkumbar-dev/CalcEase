import { InfoPage } from "@/components/content/info-page";
import { getSitePage } from "@/config/site";
import { sitePageMetadata } from "@/seo/site-page-metadata";

export const metadata = sitePageMetadata("privacy");

export default function PrivacyPage() {
  return (
    <InfoPage page={getSitePage("privacy")}>
      <p>
        This page describes what the site does today. It will be updated, and reviewed for
        compliance with India&apos;s Digital Personal Data Protection Act, 2023, before analytics or
        advertising are added.
      </p>
      <h2 className="text-h2">The numbers you enter</h2>
      <p>
        Calculations run entirely in your browser. The values you type into a calculator are not
        sent to our server or to anyone else, and they are not stored. Sharing a result only happens
        if you press Share, and then only to the app you choose.
      </p>
      <h2 className="text-h2">Accounts, cookies and tracking</h2>
      <p>
        There are no accounts. The site currently sets no cookies and uses no analytics or
        advertising services.
      </p>
      <h2 className="text-h2">Hosting</h2>
      <p>
        Like any website, the server that delivers the pages receives technical information such as
        your IP address and browser type in order to send you the page, and may keep it briefly in
        logs for security and reliability.
      </p>
      <h2 className="text-h2">Still to be completed</h2>
      <p>
        <strong>Before launch:</strong> the name and contact details of the data fiduciary, the
        hosting provider and its log retention period, and how to raise a privacy request.
      </p>
    </InfoPage>
  );
}
