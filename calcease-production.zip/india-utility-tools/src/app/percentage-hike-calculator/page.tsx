import type { Metadata } from "next";
import { HikeCalculator } from "@/components/calculator/hike-calculator";
import type { FaqItem } from "@/components/content/faq-list";
import { ToolPage, type ToolSection } from "@/components/tool/tool-page";
import { Callout } from "@/components/ui/callout";
import { DataTable } from "@/components/ui/data-table";
import { getActiveTool } from "@/lib/tools/registry";
import { pageMetadata } from "@/seo/page-metadata";

const tool = getActiveTool("percentage-hike-calculator");

export const metadata: Metadata = pageMetadata({
  title: tool.title,
  description: tool.metaDescription,
  path: `/${tool.slug}`,
});

interface Example {
  situation: string;
  working: string;
  answer: string;
}

const EXAMPLES: readonly Example[] = [
  {
    situation: "10% hike on ₹50,000 a month",
    working: "50,000 + 5,000",
    answer: "₹55,000 a month",
  },
  {
    situation: "12.5% hike on ₹8,40,000 a year",
    working: "8,40,000 + 1,05,000",
    answer: "₹9,45,000 (9.45 LPA)",
  },
  { situation: "₹45,000 to ₹52,650 a month", working: "7,650 × 100 ÷ 45,000", answer: "17% hike" },
  {
    situation: "₹60,000 to ₹54,000 a month",
    working: "−6,000 × 100 ÷ 60,000",
    answer: "10% pay cut",
  },
];

const sections: readonly ToolSection[] = [
  {
    id: "how-it-works",
    title: "How it is calculated",
    content: (
      <>
        <h3 className="text-h3">New salary after a hike</h3>
        <p>
          The increase is the current salary × hike ÷ 100; add it to the current salary.{" "}
          <code>50,000 + (50,000 × 10 ÷ 100) = 55,000</code>
        </p>
        <h3 className="text-h3">Hike between two salaries</h3>
        <p>
          Subtract the current salary from the new one, multiply by 100 and divide by the current
          salary. <code>(52,650 − 45,000) × 100 ÷ 45,000 = 17%</code>
        </p>
        <p>
          The percentage is the same whether you enter monthly or yearly salaries; the calculator
          shows both, with yearly amounts also in LPA (lakh per annum).
        </p>
      </>
    ),
  },
  {
    id: "examples",
    title: "Worked examples",
    content: (
      <DataTable
        caption="Salary hike examples"
        columns={[
          { key: "situation", header: "Situation", cell: (row: Example) => row.situation },
          {
            key: "working",
            header: "Working",
            hideOnMobile: true,
            cell: (row: Example) => <span className="numeric">{row.working}</span>,
          },
          { key: "answer", header: "Answer", numeric: true, cell: (row: Example) => row.answer },
        ]}
        rows={EXAMPLES}
        rowKey={(row) => row.situation}
      />
    ),
  },
  {
    id: "assumptions",
    title: "Good to know",
    content: (
      <>
        <Callout tone="warning" title="A hike in CTC is not a hike in take-home pay">
          <p>
            Offers and appraisals usually quote CTC (cost to company). Your in-hand pay changes by a
            different amount, because income tax, provident fund and other deductions also change.
            This calculator works on whichever figure you enter.
          </p>
        </Callout>
        <Callout tone="info" title="Percentage and rupee increase are different things">
          <p>
            A 10% hike on ₹30,000 is ₹3,000; on ₹1,00,000 it is ₹10,000. The result always shows
            both.
          </p>
        </Callout>
      </>
    ),
  },
];

const faqs: readonly FaqItem[] = [
  {
    question: "Can I calculate a pay cut?",
    answer: (
      <p>Yes. Enter a negative hike such as −10, or a new salary lower than the current one.</p>
    ),
  },
  {
    question: "What does LPA mean?",
    answer: <p>Lakh per annum: a yearly amount in lakhs of rupees. ₹8,40,000 a year is 8.4 LPA.</p>,
  },
  {
    question: "Is a 10% hike followed by a 10% cut back to the same salary?",
    answer: (
      <p>
        No. ₹50,000 + 10% is ₹55,000, and 10% off ₹55,000 is ₹49,500. The second percentage is taken
        from a different amount.
      </p>
    ),
  },
];

export default function PercentageHikeCalculatorPage() {
  return (
    <ToolPage
      tool={tool}
      intro={
        <p>Your new salary after a hike, or the hike between two salaries, monthly or yearly.</p>
      }
      calculator={<HikeCalculator />}
      sections={sections}
      faqs={faqs}
    />
  );
}
