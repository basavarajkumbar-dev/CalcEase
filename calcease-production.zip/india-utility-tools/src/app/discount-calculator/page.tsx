import type { Metadata } from "next";
import { DiscountCalculator } from "@/components/calculator/discount-calculator";
import type { FaqItem } from "@/components/content/faq-list";
import { ToolPage, type ToolSection } from "@/components/tool/tool-page";
import { Callout } from "@/components/ui/callout";
import { DataTable } from "@/components/ui/data-table";
import { getActiveTool } from "@/lib/tools/registry";
import { pageMetadata } from "@/seo/page-metadata";

const tool = getActiveTool("discount-calculator");

export const metadata: Metadata = pageMetadata({
  title: tool.title,
  description: tool.metaDescription,
  path: `/${tool.slug}`,
});

interface Example {
  offer: string;
  working: string;
  pay: string;
}

const EXAMPLES: readonly Example[] = [
  { offer: "15% off a ₹1,299 shirt", working: "1,299 − 194.85", pay: "₹1,104.15" },
  { offer: "₹2,000 shoes on sale at ₹1,500", working: "500 × 100 ÷ 2,000", pay: "25% off" },
  { offer: "50% + extra 20% off ₹3,999", working: "3,999 × 0.5 × 0.8", pay: "₹1,599.60" },
  { offer: "20% + extra 10% off ₹1,000", working: "1,000 × 0.8 × 0.9", pay: "₹720 (28% off)" },
];

const sections: readonly ToolSection[] = [
  {
    id: "how-it-works",
    title: "How it is calculated",
    content: (
      <>
        <h3 className="text-h3">Price after a discount</h3>
        <p>
          Work out the discount (price × discount ÷ 100), then subtract it from the price.{" "}
          <code>1,000 − (1,000 × 10 ÷ 100) = 900</code>
        </p>
        <h3 className="text-h3">Discount from a sale price</h3>
        <p>
          Subtract the sale price from the original price, multiply by 100 and divide by the
          original price. <code>(2,000 − 1,500) × 100 ÷ 2,000 = 25%</code>
        </p>
        <h3 className="text-h3">Two discounts</h3>
        <p>
          The extra discount is taken off the price that is already reduced, so multiply the
          remaining fractions. <code>1,000 × (1 − 0.20) × (1 − 0.10) = 720</code>, a total of 28%
          off.
        </p>
      </>
    ),
  },
  {
    id: "examples",
    title: "Worked examples",
    content: (
      <DataTable
        caption="Common shopping discounts"
        columns={[
          { key: "offer", header: "Offer", cell: (row: Example) => row.offer },
          {
            key: "working",
            header: "Working",
            hideOnMobile: true,
            cell: (row: Example) => <span className="numeric">{row.working}</span>,
          },
          { key: "pay", header: "Result", numeric: true, cell: (row: Example) => row.pay },
        ]}
        rows={EXAMPLES}
        rowKey={(row) => row.offer}
      />
    ),
  },
  {
    id: "assumptions",
    title: "Good to know",
    content: (
      <>
        <Callout tone="warning" title="“20% + extra 10%” is 28%, not 30%">
          <p>
            The extra discount applies to the reduced price, not the original one. Two discounts of
            a% and b% always come to a + b − (a × b ÷ 100) percent.
          </p>
        </Callout>
        <Callout tone="info" title="Prices and GST">
          <p>
            In India the price on a tag (MRP) normally already includes GST, so the discount comes
            off the full price. Bills that add GST after a discount are calculated differently; use
            the GST calculator for that step.
          </p>
        </Callout>
      </>
    ),
  },
];

const faqs: readonly FaqItem[] = [
  {
    question: "Can a discount be more than 100%?",
    answer: (
      <p>No. 100% off means the item is free; the calculator accepts discounts from 0% to 100%.</p>
    ),
  },
  {
    question: "What if the sale price is higher than the original price?",
    answer: (
      <p>
        Then there is no discount, and the calculator says so. To measure a price rise, use the
        percentage increase option of the Percentage Calculator.
      </p>
    ),
  },
  {
    question: "How are paise handled?",
    answer: (
      <p>
        Calculations keep full precision. Amounts are shown to the nearest paisa, and the calculator
        tells you when it has rounded. In shops, the final bill is usually rounded to the nearest
        rupee.
      </p>
    ),
  },
];

export default function DiscountCalculatorPage() {
  return (
    <ToolPage
      tool={tool}
      intro={
        <p>
          Price after a discount, the real discount on a sale price, and offers like 20% + extra 10%
          off.
        </p>
      }
      calculator={<DiscountCalculator />}
      sections={sections}
      faqs={faqs}
    />
  );
}
