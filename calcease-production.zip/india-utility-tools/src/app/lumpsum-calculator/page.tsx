import type { Metadata } from "next";
import { LumpsumCalculator } from "@/components/calculator/lumpsum-calculator";
import type { FaqItem } from "@/components/content/faq-list";
import { SourceList } from "@/components/content/source-list";
import { ToolPage, type ToolSection } from "@/components/tool/tool-page";
import { Callout } from "@/components/ui/callout";
import { DataTable } from "@/components/ui/data-table";
import { getActiveTool } from "@/lib/tools/registry";
import { pageMetadata } from "@/seo/page-metadata";

const tool = getActiveTool("lumpsum-calculator");

export const metadata: Metadata = pageMetadata({
  title: tool.title,
  description: tool.metaDescription,
  path: `/${tool.slug}`,
});

interface Example {
  investment: string;
  value: string;
}

// Values match tests/fixtures/lumpsum.json (independently verified).
const EXAMPLES: readonly Example[] = [
  { investment: "₹1,00,000 for 10 years at 12%", value: "₹3,10,584.82" },
  { investment: "₹50,000 for 5 years at 8%", value: "₹73,466.40" },
  { investment: "₹15,00,000 for 5 years at 12%", value: "₹26,43,512.52" },
];

const sections: readonly ToolSection[] = [
  {
    id: "how-it-works",
    title: "How it is calculated",
    content: (
      <>
        <p>
          <code>Value = P × (1 + r ÷ 100)^n</code>, where P is the amount invested once, r the
          expected yearly return in percent and n the number of years. The return is compounded once
          a year: each year&rsquo;s growth earns returns in the following years.
        </p>
        <p>
          Estimated returns = value − amount invested. ₹1,00,000 at 12% for 10 years: 1,00,000 ×
          1.12<sup>10</sup> = ₹3,10,584.82, so ₹2,10,584.82 of estimated returns.
        </p>
      </>
    ),
  },
  {
    id: "examples",
    title: "Worked examples",
    content: (
      <DataTable
        caption="Lumpsum examples"
        columns={[
          { key: "investment", header: "Investment", cell: (r: Example) => r.investment },
          { key: "value", header: "Estimated value", numeric: true, cell: (r: Example) => r.value },
        ]}
        rows={EXAMPLES}
        rowKey={(r) => r.investment}
      />
    ),
  },
  {
    id: "sources",
    title: "Sources",
    content: (
      <>
        <p>
          Groww&rsquo;s lumpsum example (₹15,00,000 at 12% for 5 years, about ₹26,43,513) matches
          this calculator, which compounds once a year.
        </p>
        <SourceList
          sources={[
            {
              name: "Groww: Lumpsum calculator (formula and example)",
              url: "https://groww.in/calculators/lumpsum-calculator",
              retrieved: "2026-10-07",
            },
          ]}
        />
      </>
    ),
  },
  {
    id: "limits",
    title: "Important",
    content: (
      <Callout tone="warning" title="Returns are estimates, not guaranteed">
        <p>
          Market-linked investments go up and down. This calculator assumes the same return every
          year, so it is an illustration, not a forecast or a recommendation. It does not deduct
          tax, expense ratios or exit loads.
        </p>
      </Callout>
    ),
  },
];

const faqs: readonly FaqItem[] = [
  {
    question: "What is the difference between lumpsum and SIP?",
    answer: (
      <p>
        A lumpsum is invested once, at the start. A SIP invests a fixed amount every month. Use the
        SIP Calculator for monthly investments.
      </p>
    ),
  },
  {
    question: "What return should I enter?",
    answer: (
      <p>
        Nobody can know future returns. Try a few rates to see a range of outcomes; past returns are
        not a promise.
      </p>
    ),
  },
];

export default function LumpsumCalculatorPage() {
  return (
    <ToolPage
      tool={tool}
      intro={
        <p>
          Estimated value of a one-time investment at an expected yearly return, with the returns
          shown year by year.
        </p>
      }
      calculator={<LumpsumCalculator />}
      sections={sections}
      faqs={faqs}
    />
  );
}
