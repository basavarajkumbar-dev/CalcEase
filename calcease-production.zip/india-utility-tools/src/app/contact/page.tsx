import { InfoPage } from "@/components/content/info-page";
import { getSitePage } from "@/config/site";
import { sitePageMetadata } from "@/seo/site-page-metadata";

export const metadata = sitePageMetadata("contact");

export default function ContactPage() {
  return (
    <InfoPage page={getSitePage("contact")}>
      <p>
        If a result looks wrong, please include the tool, the numbers you entered and the answer you
        expected. Every reported mistake is checked and, if confirmed, fixed and turned into a
        permanent test.
      </p>
      <h2 className="text-h2">How to reach us</h2>
      <p>
        <strong>To be completed before launch:</strong> a contact email address.
      </p>
    </InfoPage>
  );
}
