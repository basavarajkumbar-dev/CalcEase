import type { Metadata } from "next";
import { NoticePeriodCalculator } from "@/components/calculator/notice-period-calculator";
import type { FaqItem } from "@/components/content/faq-list";
import { ToolPage, type ToolSection } from "@/components/tool/tool-page";
import { Callout } from "@/components/ui/callout";
import { DataTable } from "@/components/ui/data-table";
import { getActiveTool } from "@/lib/tools/registry";
import { pageMetadata } from "@/seo/page-metadata";

const tool = getActiveTool("notice-period-calculator");

export const metadata: Metadata = pageMetadata({
  title: tool.title,
  description: tool.metaDescription,
  path: `/${tool.slug}`,
});

interface Example {
  resignation: string;
  notice: string;
  lwd: string;
}

// Values match tests/fixtures/career.json (independently verified).
const EXAMPLES: readonly Example[] = [
  { resignation: "8 Oct 2026", notice: "30 days", lwd: "7 Nov 2026" },
  { resignation: "8 Oct 2026 (counted as day 1)", notice: "30 days", lwd: "6 Nov 2026" },
  { resignation: "31 Jan 2026", notice: "90 days", lwd: "1 May 2026" },
  { resignation: "15 Dec 2026", notice: "30 days", lwd: "14 Jan 2027" },
];

const sections: readonly ToolSection[] = [
  {
    id: "how-it-works",
    title: "How it is calculated",
    content: (
      <>
        <p>
          The notice period is counted in calendar days, including weekends and holidays. By default
          it starts the day after you resign, so the last working day is the resignation date plus
          the number of notice days: resigning on 8 October with 30 days&rsquo; notice ends on 7
          November.
        </p>
        <p>
          Some employers count the resignation date itself as day 1. Tick that option and the last
          working day moves one day earlier (6 November in the same example).
        </p>
      </>
    ),
  },
  {
    id: "examples",
    title: "Worked examples",
    content: (
      <DataTable
        caption="Last working day examples"
        columns={[
          { key: "resignation", header: "Resigned", cell: (r: Example) => r.resignation },
          { key: "notice", header: "Notice", cell: (r: Example) => r.notice },
          { key: "lwd", header: "Last day", numeric: true, cell: (r: Example) => r.lwd },
        ]}
        rows={EXAMPLES}
        rowKey={(r) => r.resignation}
      />
    ),
  },
  {
    id: "limits",
    title: "Good to know",
    content: (
      <Callout tone="warning" title="Your contract decides">
        <p>
          Notice periods stated in months, working-day rules, leave adjustment, early release and
          notice buyout all depend on your employment contract and HR policy. Use this as an
          estimate and confirm the date with HR.
        </p>
      </Callout>
    ),
  },
];

const faqs: readonly FaqItem[] = [
  {
    question: "My notice period is 2 months. What do I enter?",
    answer: (
      <p>
        Enter the number of days your employer uses, for example 60. If it is counted in calendar
        months, the Date Add / Subtract Calculator can add months to the resignation date.
      </p>
    ),
  },
  {
    question: "Are weekends and holidays counted?",
    answer: <p>Yes. The calculator counts calendar days, as most notice clauses do.</p>,
  },
];

export default function NoticePeriodCalculatorPage() {
  return (
    <ToolPage
      tool={tool}
      intro={<p>Your expected last working day from the resignation date and notice period.</p>}
      calculator={<NoticePeriodCalculator />}
      sections={sections}
      faqs={faqs}
    />
  );
}
