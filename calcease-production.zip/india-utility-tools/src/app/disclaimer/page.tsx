import { Link } from "@/components/ui/link";
import { InfoPage } from "@/components/content/info-page";
import { getSitePage } from "@/config/site";
import { sitePageMetadata } from "@/seo/site-page-metadata";

export const metadata = sitePageMetadata("disclaimer");

export default function DisclaimerPage() {
  return (
    <InfoPage page={getSitePage("disclaimer")}>
      <p>
        The calculators on this site give estimates for general information. They are not financial,
        tax, legal or investment advice, and they don&apos;t take your personal circumstances into
        account.
      </p>
      <p>
        Formulas are checked carefully (<Link href="/methodology">how we calculate</Link>), but
        banks, employers, fund houses and tax authorities may round differently or apply rules a
        calculator doesn&apos;t include. Before making a decision, confirm figures with the
        organisation concerned or a qualified professional.
      </p>
      <h2 className="text-h2">Still to be completed</h2>
      <p>
        <strong>Before launch, with legal review:</strong> final wording, and any disclosures
        required once advertising or affiliate links are added.
      </p>
    </InfoPage>
  );
}
