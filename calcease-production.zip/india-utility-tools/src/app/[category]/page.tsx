import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { CategoryHub, categoryHubMetadata } from "@/components/discovery/category-hub";
import {
  categoriesWithHubs,
  categoryBySlug,
  hasHub,
  type CategoryDefinition,
} from "@/lib/tools/registry";

/**
 * Category hubs, generated from the registry. A hub is built only for categories with
 * at least one active tool; every other path here is a 404, so empty or "coming soon"
 * category pages can never be crawled or indexed. Activating a category's first tool
 * publishes its hub automatically.
 */
export const dynamicParams = false;

export function generateStaticParams() {
  return categoriesWithHubs().map((category) => ({ category: category.slug }));
}

type Params = Promise<{ category: string }>;

function resolve(slug: string): CategoryDefinition {
  const category = categoryBySlug(slug);
  if (!category || !hasHub(category.id)) notFound();
  return category;
}

export async function generateMetadata({ params }: { params: Params }): Promise<Metadata> {
  return categoryHubMetadata(resolve((await params).category).id);
}

export default async function CategoryPage({ params }: { params: Params }) {
  return <CategoryHub id={resolve((await params).category).id} />;
}
