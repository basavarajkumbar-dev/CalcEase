import { Link } from "@/components/ui/link";
import { InfoPage } from "@/components/content/info-page";
import { getSitePage } from "@/config/site";
import { sitePageMetadata } from "@/seo/site-page-metadata";

export const metadata = sitePageMetadata("terms");

export default function TermsPage() {
  return (
    <InfoPage page={getSitePage("terms")}>
      <p>
        You may use the calculators on this site free of charge for personal or business purposes.
        Results are estimates for general information; see the{" "}
        <Link href="/disclaimer">disclaimer</Link>.
      </p>
      <p>
        Please don&apos;t attempt to disrupt the site, copy it wholesale, or present its content as
        your own.
      </p>
      <h2 className="text-h2">Still to be completed</h2>
      <p>
        <strong>Before launch, with legal review:</strong> the operator&apos;s identity, governing
        law and jurisdiction, limitation of liability, and how these terms change.
      </p>
    </InfoPage>
  );
}
