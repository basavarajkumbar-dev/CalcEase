import type { Metadata } from "next";
import { RdCalculator } from "@/components/calculator/rd-calculator";
import type { FaqItem } from "@/components/content/faq-list";
import { SourceList } from "@/components/content/source-list";
import { ToolPage, type ToolSection } from "@/components/tool/tool-page";
import { Callout } from "@/components/ui/callout";
import { DataTable } from "@/components/ui/data-table";
import { RD_METHOD_SOURCES } from "@/lib/rules/deposits/sources";
import { getActiveTool } from "@/lib/tools/registry";
import { pageMetadata } from "@/seo/page-metadata";

const tool = getActiveTool("rd-calculator");

export const metadata: Metadata = pageMetadata({
  title: tool.title,
  description: tool.metaDescription,
  path: `/${tool.slug}`,
});

interface Example {
  rd: string;
  deposited: string;
  maturity: string;
}

// Values match tests/fixtures/deposits.json (independently verified).
const EXAMPLES: readonly Example[] = [
  { rd: "₹5,000 a month at 8% for 12 months", deposited: "₹60,000", maturity: "₹62,646.63" },
  { rd: "₹2,000 a month at 7% for 36 months", deposited: "₹72,000", maturity: "₹80,274.60" },
  { rd: "₹5,000 a month at 7% for 60 months", deposited: "₹3,00,000", maturity: "₹3,59,663.95" },
  {
    rd: "₹10,000 a month at 7.5% for 120 months",
    deposited: "₹12,00,000",
    maturity: "₹17,85,760.32",
  },
];

const sections: readonly ToolSection[] = [
  {
    id: "how-it-works",
    title: "How it is calculated",
    content: (
      <>
        <p>Banks compound RD interest quarterly and publish this formula:</p>
        <p>
          <code>M = R × [(1 + i)^n − 1] ÷ [1 − (1 + i)^(−1/3)]</code>
        </p>
        <p>
          R is the monthly instalment, i is the yearly rate ÷ 400 (the rate for one quarter) and n
          is the number of quarters. It is the same as adding up each instalment&rsquo;s growth: the
          first instalment earns interest for the whole tenure, the last for one month.
        </p>
      </>
    ),
  },
  {
    id: "examples",
    title: "Worked examples",
    content: (
      <DataTable
        caption="Recurring deposit examples"
        columns={[
          { key: "rd", header: "Recurring deposit", cell: (r: Example) => r.rd },
          {
            key: "deposited",
            header: "Deposited",
            numeric: true,
            hideOnMobile: true,
            cell: (r: Example) => r.deposited,
          },
          { key: "maturity", header: "Maturity", numeric: true, cell: (r: Example) => r.maturity },
        ]}
        rows={EXAMPLES}
        rowKey={(r) => r.rd}
      />
    ),
  },
  {
    id: "sources",
    title: "Method and sources",
    content: (
      <>
        <p>
          The formula is the one banks publish for completed quarters, which is why the tenure must
          be a whole number of quarters. Banks treat leftover months differently, so the calculator
          does not estimate them. ICICI Bank&rsquo;s example (₹5,000 a month at 8% for a year gives
          ₹62,647) matches this calculator.
        </p>
        <SourceList sources={RD_METHOD_SOURCES} />
      </>
    ),
  },
  {
    id: "limits",
    title: "What this calculator does not cover",
    content: (
      <Callout tone="warning" title="An estimate: your bank's figure decides">
        <p>
          It assumes every instalment is paid on time. It does not include penalties for missed
          instalments, early closure, TDS or tax on the interest. Banks round interest in their own
          way.
        </p>
      </Callout>
    ),
  },
];

const faqs: readonly FaqItem[] = [
  {
    question: "Why can't I enter 13 months?",
    answer: (
      <p>
        The published bank formula covers whole quarters. For part quarters banks use different
        methods, and a figure we cannot attribute to a published method could mislead you.
      </p>
    ),
  },
  {
    question: "Is RD interest taxable?",
    answer: (
      <p>
        Yes, at your slab rate, and banks may deduct TDS. The calculator shows interest before tax.
      </p>
    ),
  },
];

export default function RdCalculatorPage() {
  return (
    <ToolPage
      tool={tool}
      intro={<p>Maturity amount and interest on a bank recurring deposit, compounded quarterly.</p>}
      calculator={<RdCalculator />}
      sections={sections}
      faqs={faqs}
    />
  );
}
