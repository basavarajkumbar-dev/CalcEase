import type { Metadata } from "next";
import { ExperienceCalculator } from "@/components/calculator/experience-calculator";
import type { FaqItem } from "@/components/content/faq-list";
import { ToolPage, type ToolSection } from "@/components/tool/tool-page";
import { Callout } from "@/components/ui/callout";
import { DataTable } from "@/components/ui/data-table";
import { getActiveTool } from "@/lib/tools/registry";
import { pageMetadata } from "@/seo/page-metadata";

const tool = getActiveTool("experience-calculator");

export const metadata: Metadata = pageMetadata({
  title: tool.title,
  description: tool.metaDescription,
  path: `/${tool.slug}`,
});

interface Example {
  dates: string;
  experience: string;
}

// Values match tests/fixtures/career.json (independently verified).
const EXAMPLES: readonly Example[] = [
  { dates: "1 Jan 2020 to 31 Dec 2024", experience: "5 years" },
  { dates: "16 Jul 2018 to 8 Oct 2026", experience: "8 years, 2 months, 23 days" },
  { dates: "31 Jan 2023 to 28 Feb 2023", experience: "1 month, 1 day" },
  { dates: "Joined and left on the same day", experience: "1 day" },
];

const sections: readonly ToolSection[] = [
  {
    id: "how-it-works",
    title: "How it is calculated",
    content: (
      <>
        <p>
          Experience is counted on the calendar: whole years and months from the joining date, then
          the days left over. By default both the joining date and the last working day count as
          days worked, so 1 January 2020 to 31 December 2024 is exactly 5 years. Untick the option
          to leave the last day out.
        </p>
        <p>
          Leap years and month-end dates are handled: one month from 31 January ends on the last day
          of February. Dates are calendar days, so time zones cannot shift the answer.
        </p>
      </>
    ),
  },
  {
    id: "examples",
    title: "Worked examples",
    content: (
      <DataTable
        caption="Experience examples (counting the last day)"
        columns={[
          { key: "dates", header: "Dates", cell: (r: Example) => r.dates },
          {
            key: "experience",
            header: "Experience",
            numeric: true,
            cell: (r: Example) => r.experience,
          },
        ]}
        rows={EXAMPLES}
        rowKey={(r) => r.dates}
      />
    ),
  },
  {
    id: "limits",
    title: "Good to know",
    content: (
      <Callout tone="info" title="Different employers count differently">
        <p>
          Some forms ask for completed years only, or round to the nearest month. Gaps between jobs
          are not included: add each job separately. For gratuity or legal purposes, check the rule
          that applies.
        </p>
      </Callout>
    ),
  },
];

const faqs: readonly FaqItem[] = [
  {
    question: "Can the end date be in the future?",
    answer: <p>Yes. The result is then projected experience, and the calculator says so.</p>,
  },
  {
    question: "How do I add up several jobs?",
    answer: (
      <p>
        Calculate each job separately and add the years, months and days, carrying 12 months into a
        year.
      </p>
    ),
  },
];

export default function ExperienceCalculatorPage() {
  return (
    <ToolPage
      tool={tool}
      intro={<p>Total work experience in years, months and days between two dates.</p>}
      calculator={<ExperienceCalculator />}
      sections={sections}
      faqs={faqs}
    />
  );
}
