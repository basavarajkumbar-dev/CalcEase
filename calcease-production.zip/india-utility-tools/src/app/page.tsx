import type { Metadata } from "next";
import { Link } from "@/components/ui/link";
import { CategoryCard } from "@/components/discovery/category-card";
import { ToolTile } from "@/components/discovery/tool-tile";
import { Container } from "@/components/layout/container";
import { Section } from "@/components/layout/section";
import { SearchBox } from "@/components/search/search-box";
import { Calculator, ListChecks, Lock } from "@/components/ui/icons";
import { SITE_NAME, SITE_TAGLINE } from "@/config/site";
import { CATEGORIES, categoryHref, featuredTools } from "@/lib/tools/registry";
import { JsonLd, websiteJsonLd } from "@/seo/json-ld";
import { pageMetadata } from "@/seo/page-metadata";

export const metadata: Metadata = pageMetadata({
  title: `${SITE_NAME}: ${SITE_TAGLINE} Free Calculators for India`,
  description:
    "Free calculators for India that show their working: EMI, SIP, lumpsum, FD, GST, percentage, age and date tools, and a simple calculator. No sign-up.",
  path: "/",
  absoluteTitle: true,
});

const TRUST_POINTS = [
  {
    Icon: ListChecks,
    title: "Formulas checked before release",
    text: "Each calculator is written up as a specification and tested against examples worked out independently by hand.",
  },
  {
    Icon: Calculator,
    title: "The working is shown",
    text: "Every result comes with the formula and your numbers, so you can check it yourself.",
  },
  {
    Icon: Lock,
    title: "No sign-up, nothing sent",
    text: "Calculations run in your browser. The numbers you type are not sent to a server or stored.",
  },
] as const;

/** Homepage highlights, in this order (all must be featured in the registry). */
const HIGHLIGHT_ORDER = [
  "emi-calculator",
  "sip-calculator",
  "lumpsum-calculator",
  "gst-calculator",
  "percentage-calculator",
  "calculator",
];

export default function HomePage() {
  const featured = featuredTools().sort((a, b) => rank(a.slug) - rank(b.slug));

  return (
    <>
      <JsonLd data={websiteJsonLd()} />
      <div className="border-b border-line bg-surface">
        <Container className="py-8 md:py-14">
          <div className="max-w-prose">
            <p className="text-label font-semibold text-primary">{SITE_NAME}</p>
            <h1 className="text-h1 mt-1 text-ink">{SITE_TAGLINE}</h1>
            <p className="mt-3 text-lg text-muted">
              Useful calculators for everyday money, work and dates. Every answer shows its working.
              No sign-up.
            </p>
            <nav aria-label="Calculator categories" className="mt-4">
              <ul className="flex flex-wrap gap-2">
                {CATEGORIES.map((category) => {
                  const href = categoryHref(category.id);
                  return href ? (
                    <li key={category.id}>
                      <Link
                        href={href}
                        className="inline-flex min-h-11 items-center rounded-full border border-line bg-canvas px-4 text-small font-semibold text-ink no-underline hover:border-primary hover:text-primary"
                      >
                        {category.name}
                      </Link>
                    </li>
                  ) : null;
                })}
              </ul>
            </nav>
            <div className="mt-6">
              <SearchBox size="lg" />
            </div>
          </div>
        </Container>
      </div>

      <Container className="space-y-10 py-8 md:space-y-14 md:py-12">
        {featured.length > 0 && (
          <Section id="available" title="Start here">
            <ul className="grid gap-3 md:grid-cols-2 md:gap-4 lg:grid-cols-3">
              {featured.map((tool) => (
                <li key={tool.id}>
                  <ToolTile tool={tool} />
                </li>
              ))}
            </ul>
          </Section>
        )}

        <Section id="categories" title="Browse by category">
          <ul className="grid gap-4 md:grid-cols-2">
            {CATEGORIES.map((category) => (
              <li key={category.id}>
                <CategoryCard category={category} />
              </li>
            ))}
          </ul>
          <p className="mt-4">
            <Link href="/tools">See every tool</Link>
          </p>
        </Section>

        <Section id="accuracy" title="Why you can trust the answers">
          <ul className="grid gap-4 md:grid-cols-3">
            {TRUST_POINTS.map(({ Icon, title, text }) => (
              <li
                key={title}
                className="flex gap-3 rounded-lg border border-line bg-surface p-4 md:p-5"
              >
                <Icon aria-hidden="true" className="mt-0.5 size-6 shrink-0 text-primary" />
                <span>
                  <span className="block font-semibold text-ink">{title}</span>
                  <span className="text-small mt-1 block text-muted">{text}</span>
                </span>
              </li>
            ))}
          </ul>
          <p className="mt-6">
            <Link href="/methodology">Read how we calculate and check results</Link>
          </p>
        </Section>
      </Container>
    </>
  );
}

function rank(slug: string): number {
  const i = HIGHLIGHT_ORDER.indexOf(slug);
  return i === -1 ? HIGHLIGHT_ORDER.length : i;
}
