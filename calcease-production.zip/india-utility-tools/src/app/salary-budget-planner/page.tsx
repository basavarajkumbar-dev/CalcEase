import type { Metadata } from "next";
import { SalaryBudgetPlanner } from "@/components/calculator/salary-budget-planner";
import type { FaqItem } from "@/components/content/faq-list";
import { ToolPage, type ToolSection } from "@/components/tool/tool-page";
import { Callout } from "@/components/ui/callout";
import { getActiveTool } from "@/lib/tools/registry";
import { pageMetadata } from "@/seo/page-metadata";

const tool = getActiveTool("salary-budget-planner");

export const metadata: Metadata = pageMetadata({
  title: tool.title,
  description: tool.metaDescription,
  path: `/${tool.slug}`,
});

const sections: readonly ToolSection[] = [
  {
    id: "methodology",
    title: "How the planner works",
    content: (
      <>
        <p>
          <code>Monthly income − essentials − EMIs − wants = available surplus.</code> The surplus
          is what you can save or invest. The planner then:
        </p>
        <ul>
          <li>
            Sets an emergency-fund target of a number of months of essentials plus EMIs (6 by
            default; 3 to 6 is a common reference) and shows how many months your savings cover.
          </li>
          <li>
            Suggests sending part of the surplus (50% by default) to the emergency fund until it
            reaches the target, and the rest to investments.
          </li>
          <li>
            Shows a <strong>Balanced reference</strong>: it keeps your essentials and EMIs as they
            are, then splits what is left between wants (60% by default) and saving. High rent or
            high EMIs therefore shrink the reference for wants and saving automatically, instead of
            applying one fixed percentage to everyone.
          </li>
        </ul>
        <p>
          With the defaults and your essentials and EMIs at half your pay, the reference comes to
          the familiar 50/30/20 split. It is a starting point to adjust, not a rule.
        </p>
        <h3 className="text-h3">Example: ₹50,000 take-home</h3>
        <p>
          With ₹22,000 essentials, ₹5,000 EMI, ₹8,000 wants, ₹60,000 saved and ₹5,000 invested: the
          surplus is ₹15,000 (30%); the emergency target is 6 × ₹27,000 = ₹1,62,000, so ₹60,000
          covers about 2.2 months; the suggestion is ₹7,500 a month to the emergency fund and ₹7,500
          to investments.
        </p>
      </>
    ),
  },
  {
    id: "disclaimer",
    title: "Important",
    content: (
      <Callout tone="warning" title="A planning aid, not financial advice">
        <p>
          The planner only organises the numbers you enter. Suggested and reference amounts are not
          recommendations for your situation, investment amounts are plans and do not include
          returns, and no product is recommended. Consider a qualified adviser for personal advice.
        </p>
      </Callout>
    ),
  },
];

const faqs: readonly FaqItem[] = [
  {
    question: "Is 50/30/20 the right budget for me?",
    answer: (
      <p>
        Not necessarily. It is one reference. If rent or EMIs take more of your pay, less is left
        for wants and saving; the reference here adapts to that, and you can change its shares.
      </p>
    ),
  },
  {
    question: "Should I build the emergency fund before investing?",
    answer: (
      <p>
        Many people do, but it depends on your situation. The planner shows both and lets you choose
        how much of your savings goes to the emergency fund.
      </p>
    ),
  },
  {
    question: "Is anything I enter saved?",
    answer: <p>No. Everything is calculated in your browser and nothing is sent or stored.</p>,
  },
];

export default function SalaryBudgetPlannerPage() {
  return (
    <ToolPage
      tool={tool}
      intro={
        <p>
          See where your monthly take-home pay goes, how much is left to save or invest, and how far
          your emergency fund will stretch.
        </p>
      }
      calculator={<SalaryBudgetPlanner />}
      sections={sections}
      faqs={faqs}
    />
  );
}
