import type { Metadata } from "next";
import { AgeCalculator } from "@/components/calculator/age-calculator";
import type { FaqItem } from "@/components/content/faq-list";
import { ToolPage, type ToolSection } from "@/components/tool/tool-page";
import { Callout } from "@/components/ui/callout";
import { DataTable } from "@/components/ui/data-table";
import { getActiveTool } from "@/lib/tools/registry";
import { pageMetadata } from "@/seo/page-metadata";

const tool = getActiveTool("age-calculator");

export const metadata: Metadata = pageMetadata({
  title: tool.title,
  description: tool.metaDescription,
  path: `/${tool.slug}`,
});

interface Example {
  born: string;
  on: string;
  age: string;
}

// Values match tests/fixtures/dates.json (independently verified).
const EXAMPLES: readonly Example[] = [
  { born: "15 Aug 1990", on: "7 Oct 2026", age: "36 years, 1 month, 22 days" },
  { born: "8 Oct 1985", on: "7 Oct 2026", age: "40 years, 11 months, 29 days" },
  { born: "31 Jan 1995", on: "28 Feb 2026", age: "31 years, 1 month" },
  { born: "29 Feb 2000", on: "28 Feb 2023", age: "23 years" },
];

const sections: readonly ToolSection[] = [
  {
    id: "how-it-works",
    title: "How it is calculated",
    content: (
      <>
        <p>
          The calculator counts the whole years and months from the date of birth that fit before
          the chosen date, then the days left over. Born on 15 August 1990, on 7 October 2026 you
          have completed 36 years (15 August 2026) and 1 more month (15 September 2026), plus 22
          days.
        </p>
        <p>
          Dates are handled as calendar days, not as times, so the answer does not change with your
          device&rsquo;s time zone. &ldquo;Today&rdquo; is your device&rsquo;s date.
        </p>
      </>
    ),
  },
  {
    id: "examples",
    title: "Worked examples",
    content: (
      <DataTable
        caption="Ages on a given date"
        columns={[
          { key: "born", header: "Born", cell: (row: Example) => row.born },
          { key: "on", header: "On", cell: (row: Example) => row.on },
          { key: "age", header: "Age", numeric: true, cell: (row: Example) => row.age },
        ]}
        rows={EXAMPLES}
        rowKey={(row) => `${row.born}-${row.on}`}
      />
    ),
  },
  {
    id: "edge-cases",
    title: "Good to know",
    content: (
      <>
        <Callout tone="info" title="Born on 29 February">
          <p>
            In years without a 29 February, this calculator counts the birthday on 28 February. Some
            laws and organisations use 1 March instead, so check the rule that applies to you.
          </p>
        </Callout>
        <Callout tone="info" title="Ages for official purposes">
          <p>
            School admission, exam eligibility, retirement and similar rules set their own
            &ldquo;age as on&rdquo; date and counting method. Enter that date in &ldquo;Age
            on&rdquo;, and check the notification for how the age is counted.
          </p>
        </Callout>
      </>
    ),
  },
];

const faqs: readonly FaqItem[] = [
  {
    question: "How do I find my age on a particular date?",
    answer: <p>Change &ldquo;Age on&rdquo; to that date. It starts as today&rsquo;s date.</p>,
  },
  {
    question: "Why can the number of days in a month differ in the answer?",
    answer: (
      <p>
        Months have 28 to 31 days, so &ldquo;1 month&rdquo; is counted on the calendar: from the
        15th of one month to the 15th of the next. If you were born on the 31st, a month is complete
        on the last day of a shorter month.
      </p>
    ),
  },
  {
    question: "Is my date of birth sent or stored anywhere?",
    answer: (
      <p>
        No. The calculation runs in your browser. If you share a result, the link carries the dates
        after a &ldquo;#&rdquo;, which browsers never send to a website.
      </p>
    ),
  },
];

export default function AgeCalculatorPage() {
  return (
    <ToolPage
      tool={tool}
      intro={
        <p>
          Exact age in years, months and days from a date of birth, with the next birthday and age
          in days, weeks and months.
        </p>
      }
      calculator={<AgeCalculator />}
      sections={sections}
      faqs={faqs}
    />
  );
}
