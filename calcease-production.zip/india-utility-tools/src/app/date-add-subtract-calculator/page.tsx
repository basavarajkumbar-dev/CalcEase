import type { Metadata } from "next";
import { DateAddSubtractCalculator } from "@/components/calculator/date-add-subtract-calculator";
import type { FaqItem } from "@/components/content/faq-list";
import { ToolPage, type ToolSection } from "@/components/tool/tool-page";
import { Callout } from "@/components/ui/callout";
import { DataTable } from "@/components/ui/data-table";
import { getActiveTool } from "@/lib/tools/registry";
import { pageMetadata } from "@/seo/page-metadata";

const tool = getActiveTool("date-add-subtract-calculator");

export const metadata: Metadata = pageMetadata({
  title: tool.title,
  description: tool.metaDescription,
  path: `/${tool.slug}`,
});

interface Example {
  start: string;
  change: string;
  result: string;
}

// Values match tests/fixtures/dates.json (independently verified).
const EXAMPLES: readonly Example[] = [
  { start: "7 Oct 2026", change: "+ 90 days", result: "5 Jan 2027" },
  { start: "7 Oct 2026", change: "− 45 days", result: "23 Aug 2026" },
  { start: "31 Jan 2026", change: "+ 1 month", result: "28 Feb 2026" },
  { start: "29 Feb 2024", change: "+ 1 year", result: "28 Feb 2025" },
  { start: "7 Oct 2026", change: "+ 1 year, 2 months, 3 weeks, 4 days", result: "1 Jan 2028" },
];

const sections: readonly ToolSection[] = [
  {
    id: "how-it-works",
    title: "How it is calculated",
    content: (
      <>
        <p>
          Years and months are added first, as calendar months: 7 October + 2 months is 7 December.
          Then weeks (7 days each) and days are added. Subtracting works the same way backwards.
        </p>
        <p>
          If the day does not exist in the new month, the date moves to that month&rsquo;s last day:
          31 January + 1 month is 28 February (29 February in a leap year). The result tells you
          when this happens.
        </p>
      </>
    ),
  },
  {
    id: "examples",
    title: "Worked examples",
    content: (
      <DataTable
        caption="Dates after adding or subtracting"
        columns={[
          { key: "start", header: "Start", cell: (row: Example) => row.start },
          { key: "change", header: "Change", cell: (row: Example) => row.change },
          { key: "result", header: "Result", numeric: true, cell: (row: Example) => row.result },
        ]}
        rows={EXAMPLES}
        rowKey={(row) => `${row.start}${row.change}`}
      />
    ),
  },
  {
    id: "edge-cases",
    title: "Good to know",
    content: (
      <Callout tone="warning" title="Working days and legal deadlines">
        <p>
          This adds calendar days. It does not skip weekends or holidays, and legal or statutory
          deadlines have their own counting rules (for example, whether the first day counts). Check
          the rule that applies.
        </p>
      </Callout>
    ),
  },
];

const faqs: readonly FaqItem[] = [
  {
    question: "Is adding 1 month the same as adding 30 days?",
    answer: (
      <p>
        No. A month is a calendar month, from 28 to 31 days. 7 October + 1 month is 7 November (31
        days), while + 30 days is 6 November.
      </p>
    ),
  },
  {
    question: "Can I leave some fields empty?",
    answer: <p>Yes. Empty years, months, weeks or days count as 0.</p>,
  },
  {
    question: "Which dates are supported?",
    answer: <p>Start dates and results from 1 January 1900 to 31 December 2199.</p>,
  },
];

export default function DateAddSubtractCalculatorPage() {
  return (
    <ToolPage
      tool={tool}
      intro={
        <p>The date a number of years, months, weeks and days after or before another date.</p>
      }
      calculator={<DateAddSubtractCalculator />}
      sections={sections}
      faqs={faqs}
    />
  );
}
