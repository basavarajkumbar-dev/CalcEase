import type { Metadata } from "next";
import { DateDifferenceCalculator } from "@/components/calculator/date-difference-calculator";
import type { FaqItem } from "@/components/content/faq-list";
import { ToolPage, type ToolSection } from "@/components/tool/tool-page";
import { Callout } from "@/components/ui/callout";
import { DataTable } from "@/components/ui/data-table";
import { getActiveTool } from "@/lib/tools/registry";
import { pageMetadata } from "@/seo/page-metadata";

const tool = getActiveTool("date-difference-calculator");

export const metadata: Metadata = pageMetadata({
  title: tool.title,
  description: tool.metaDescription,
  path: `/${tool.slug}`,
});

interface Example {
  dates: string;
  result: string;
}

// Values match tests/fixtures/dates.json (independently verified).
const EXAMPLES: readonly Example[] = [
  { dates: "1 Jan 2024 to 31 Dec 2024", result: "365 days (11 months, 30 days)" },
  { dates: "Same, including the end date", result: "366 days (1 year)" },
  { dates: "31 Jan 2023 to 1 Mar 2023", result: "29 days (1 month, 1 day)" },
  { dates: "25 Dec 2025 to 1 Jan 2026", result: "7 days (5 weekdays)" },
];

const sections: readonly ToolSection[] = [
  {
    id: "how-it-works",
    title: "How it is calculated",
    content: (
      <>
        <p>
          The total is the number of days from the start date to the end date. By default the end
          date is not counted, the way you count nights or the days until an event: 1 to 2 January
          is 1 day.
        </p>
        <p>
          Tick &ldquo;Include the end date&rdquo; when both days count, such as days of leave or the
          length of a course: 1 to 2 January is then 2 days.
        </p>
        <p>
          Years, months and days are counted on the calendar: whole months from the start date
          first, then the days left over. Weekdays are Monday to Friday.
        </p>
      </>
    ),
  },
  {
    id: "examples",
    title: "Worked examples",
    content: (
      <DataTable
        caption="Days between dates"
        columns={[
          { key: "dates", header: "Dates", cell: (row: Example) => row.dates },
          { key: "result", header: "Result", numeric: true, cell: (row: Example) => row.result },
        ]}
        rows={EXAMPLES}
        rowKey={(row) => row.dates}
      />
    ),
  },
  {
    id: "edge-cases",
    title: "Good to know",
    content: (
      <>
        <Callout tone="warning" title="Holidays are not removed">
          <p>
            The weekday count is Monday to Friday only. Public and bank holidays differ by state and
            employer, so subtract them yourself for working-day deadlines.
          </p>
        </Callout>
        <Callout tone="info" title="Month-end dates">
          <p>
            From 31 January to 1 March 2023 is 1 month and 1 day: one month from 31 January ends on
            28 February, the last day of that month.
          </p>
        </Callout>
      </>
    ),
  },
];

const faqs: readonly FaqItem[] = [
  {
    question: "What if the end date is before the start date?",
    answer: <p>The calculator swaps them, gives the same answer, and tells you it did.</p>,
  },
  {
    question: "Does it handle leap years?",
    answer: (
      <p>
        Yes. 29 February is counted in leap years: 1 January to 31 December 2024 is 365 days, and
        366 days counting both dates.
      </p>
    ),
  },
  {
    question: "Which dates can I use?",
    answer: <p>Any date from 1 January 1900 to 31 December 2199.</p>,
  },
];

export default function DateDifferenceCalculatorPage() {
  return (
    <ToolPage
      tool={tool}
      intro={
        <p>
          Days, weeks, months and years between two dates, with weekdays and an option to count the
          end date.
        </p>
      }
      calculator={<DateDifferenceCalculator />}
      sections={sections}
      faqs={faqs}
    />
  );
}
