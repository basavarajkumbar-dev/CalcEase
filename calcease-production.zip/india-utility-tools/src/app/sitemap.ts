import type { MetadataRoute } from "next";
import { SITE_PAGES, SITE_URL } from "@/config/site";
import { activeTools, categoriesWithHubs, toolHref } from "@/lib/tools/registry";

/**
 * Generated from the registry and site-page list. Contains only indexable pages:
 * no coming-soon tools, no categories without tools, no draft pages, no search URLs.
 */
export default function sitemap(): MetadataRoute.Sitemap {
  const tools = activeTools();
  const newest = tools
    .map((t) => t.lastReviewed)
    .sort()
    .at(-1);
  const lastModified = newest ? { lastModified: newest } : {};
  return [
    { url: `${SITE_URL}/`, ...lastModified },
    { url: `${SITE_URL}/tools`, ...lastModified },
    ...categoriesWithHubs().map((category) => ({
      url: `${SITE_URL}/${category.slug}`,
      ...lastModified,
    })),
    ...tools.map((tool) => ({
      url: `${SITE_URL}${toolHref(tool)}`,
      lastModified: tool.lastReviewed,
    })),
    ...SITE_PAGES.filter((page) => page.status === "published").map((page) => ({
      url: `${SITE_URL}${page.href}`,
    })),
  ];
}
