import type { Metadata } from "next";
import { Link } from "@/components/ui/link";
import { CategoryIcon } from "@/components/discovery/category-icon";
import { Breadcrumb } from "@/components/layout/breadcrumb";
import { Container } from "@/components/layout/container";
import { Badge } from "@/components/ui/badge";
import {
  activeTools,
  activeToolsInCategory,
  CATEGORIES,
  categoryHref,
  isActive,
  plannedTools,
  TOOLS,
  toolHref,
} from "@/lib/tools/registry";
import { pageMetadata } from "@/seo/page-metadata";

export const metadata: Metadata = pageMetadata({
  title: "All Tools",
  description:
    "Every calculator on the site, grouped by category, with the tools that are coming next.",
  path: "/tools",
});

/** The complete A–Z list, grouped by category: one crawlable page that links every active tool. */
export default function ToolsPage() {
  const active = activeTools().length;
  const planned = plannedTools().length;

  return (
    <Container className="pt-4 pb-8">
      <Breadcrumb items={[{ name: "Home", href: "/" }, { name: "All tools" }]} />
      <header className="mt-4 max-w-prose">
        <h1 className="text-h1 text-ink">All tools</h1>
        <p className="mt-2 text-lg text-muted">
          {active} {active === 1 ? "calculator" : "calculators"} available now, {planned} coming
          soon. Tools marked &ldquo;Coming soon&rdquo; are being built and tested and can&apos;t be
          opened yet.
        </p>
      </header>

      <div className="mt-8 grid gap-8 md:grid-cols-2">
        {/* Categories with tools you can open come first, so they are never buried. */}
        {[...CATEGORIES]
          .sort((a, b) => activeToolsInCategory(b.id).length - activeToolsInCategory(a.id).length)
          .map((category) => {
            const href = categoryHref(category.id);
            const tools = TOOLS.filter((tool) => tool.category === category.id).sort(
              (a, b) => Number(isActive(b)) - Number(isActive(a)) || a.name.localeCompare(b.name),
            );
            return (
              <section key={category.id} aria-labelledby={`cat-${category.id}`}>
                <h2 id={`cat-${category.id}`} className="text-h2 flex items-center gap-2 text-ink">
                  <CategoryIcon category={category.id} />
                  {href ? (
                    <Link href={href} className="text-ink">
                      {category.name}
                    </Link>
                  ) : (
                    category.name
                  )}
                </h2>
                <ul className="mt-3 divide-y divide-line border-y border-line">
                  {tools.map((tool) => (
                    <li
                      key={tool.id}
                      className="flex min-h-12 flex-wrap items-center justify-between gap-x-4 gap-y-1 py-2"
                    >
                      {isActive(tool) ? (
                        <Link href={toolHref(tool)} className="font-semibold">
                          {tool.name}
                        </Link>
                      ) : (
                        <>
                          <span className="text-muted">{tool.name}</span>
                          <Badge>Coming soon</Badge>
                        </>
                      )}
                    </li>
                  ))}
                </ul>
              </section>
            );
          })}
      </div>
    </Container>
  );
}
