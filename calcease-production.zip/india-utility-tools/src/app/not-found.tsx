import { Link } from "@/components/ui/link";
import type { Metadata } from "next";
import { ToolCard } from "@/components/discovery/tool-card";
import { Container } from "@/components/layout/container";
import { SearchBox } from "@/components/search/search-box";
import { featuredTools } from "@/lib/tools/registry";

export const metadata: Metadata = {
  title: "Page not found",
  robots: { index: false, follow: true },
};

/**
 * Also the "tool not available" state: coming-soon tools and categories without tools
 * have no pages, so their URLs land here with a way forward.
 */
export default function NotFound() {
  return (
    <Container className="py-8 md:py-12">
      <div className="max-w-prose">
        <h1 className="text-h1 text-ink">This page isn&apos;t here</h1>
        <p className="mt-3 text-muted">
          The link may be wrong, or the tool may not be available yet. Search for what you need, or
          go to <Link href="/tools">all tools</Link>.
        </p>
        <div className="mt-6">
          <SearchBox />
        </div>
        <h2 className="text-h3 mt-8 text-ink">Available now</h2>
        <ul className="mt-3 grid gap-4">
          {featuredTools().map((tool) => (
            <li key={tool.id}>
              <ToolCard tool={tool} />
            </li>
          ))}
        </ul>
      </div>
    </Container>
  );
}
