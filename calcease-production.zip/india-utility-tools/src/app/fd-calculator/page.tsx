import type { Metadata } from "next";
import { FdCalculator } from "@/components/calculator/fd-calculator";
import type { FaqItem } from "@/components/content/faq-list";
import { SourceList } from "@/components/content/source-list";
import { ToolPage, type ToolSection } from "@/components/tool/tool-page";
import { Callout } from "@/components/ui/callout";
import { DataTable } from "@/components/ui/data-table";
import { FD_METHOD_SOURCES } from "@/lib/rules/deposits/sources";
import { getActiveTool } from "@/lib/tools/registry";
import { pageMetadata } from "@/seo/page-metadata";

const tool = getActiveTool("fd-calculator");

export const metadata: Metadata = pageMetadata({
  title: tool.title,
  description: tool.metaDescription,
  path: `/${tool.slug}`,
});

interface Example {
  deposit: string;
  result: string;
}

// Values match tests/fixtures/deposits.json (independently verified).
const EXAMPLES: readonly Example[] = [
  { deposit: "₹1,00,000 at 6.6% for 3 years", result: "₹1,21,699.44" },
  {
    deposit: "₹1,00,000 at 7% for 1 year, 2 months, 10 days (from 7 Oct 2026)",
    result: "₹1,08,645.39",
  },
  { deposit: "₹50,000 at 6% for 90 days", result: "₹739.73 interest (simple)" },
  { deposit: "₹2,00,000 at 7.25% for 2 years, interest every quarter", result: "₹3,625 a quarter" },
];

const sections: readonly ToolSection[] = [
  {
    id: "how-it-works",
    title: "How banks calculate FD interest",
    content: (
      <>
        <p>
          Banks add interest to a cumulative FD every completed quarter, counted from the deposit
          date: <code>P × (1 + r ÷ 400)^quarters</code>. For the days after the last full quarter
          they pay simple interest on the accumulated amount: <code>× (1 + r × days ÷ 36,500)</code>
          .
        </p>
        <p>
          Short deposits earn simple interest for the actual number of days. Where
          &ldquo;short&rdquo; ends depends on the bank: under 3, 6 or 12 months. The calculator asks
          when it matters.
        </p>
        <p>
          With interest paid every quarter, each payment is <code>P × r ÷ 400</code> and the deposit
          is repaid at maturity.
        </p>
      </>
    ),
  },
  {
    id: "examples",
    title: "Worked examples",
    content: (
      <DataTable
        caption="Fixed deposit examples"
        columns={[
          { key: "deposit", header: "Deposit", cell: (r: Example) => r.deposit },
          { key: "result", header: "Result", numeric: true, cell: (r: Example) => r.result },
        ]}
        rows={EXAMPLES}
        rowKey={(r) => r.deposit}
      />
    ),
  },
  {
    id: "sources",
    title: "Method and sources",
    content: (
      <>
        <p>
          There is no single rule for the arithmetic that every bank must follow. Banks publish
          their own method, and the calculator follows what these published methods have in common.
          They differ on the limit for simple interest (you can choose it) and on leap years: this
          calculator counts 365 days a year, as most do, while some banks use 366 in leap years.
        </p>
        <SourceList sources={FD_METHOD_SOURCES} />
      </>
    ),
  },
  {
    id: "limits",
    title: "What this calculator does not cover",
    content: (
      <Callout tone="warning" title="An estimate: your bank's figure decides">
        <p>
          Enter the rate your bank offers for your amount, tenure and age (senior citizens often get
          more). The calculator does not deduct TDS or tax, apply penalties for early withdrawal, or
          calculate monthly-payout deposits (paid at a discounted rate). Banks round interest in
          their own way, so their figure may differ by a few rupees.
        </p>
      </Callout>
    ),
  },
];

const faqs: readonly FaqItem[] = [
  {
    question: "Why does the deposit date change the result?",
    answer: (
      <p>
        Quarters are counted from the deposit date, and the days left over are counted exactly. A
        deposit for 1 year and 1 month has 30 or 31 extra days depending on the month.
      </p>
    ),
  },
  {
    question: "Is FD interest taxable?",
    answer: (
      <p>
        Interest is added to your income and taxed at your slab rate, and banks may deduct TDS. The
        calculator shows interest before tax.
      </p>
    ),
  },
  {
    question: "What is the difference between cumulative and payout FDs?",
    answer: (
      <p>
        A cumulative FD adds the interest to the deposit, so it earns interest too, and pays
        everything at maturity. A payout FD pays the interest out every quarter, so it earns less in
        total but gives regular income.
      </p>
    ),
  },
];

export default function FdCalculatorPage() {
  return (
    <ToolPage
      tool={tool}
      intro={
        <p>
          Maturity amount, interest and maturity date for a bank fixed deposit, using the method
          banks publish.
        </p>
      }
      calculator={<FdCalculator />}
      sections={sections}
      faqs={faqs}
    />
  );
}
