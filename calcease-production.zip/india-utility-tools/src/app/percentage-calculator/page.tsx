import type { Metadata } from "next";
import { PercentageCalculator } from "@/components/calculator/percentage-calculator";
import { ToolPage, type ToolSection } from "@/components/tool/tool-page";
import type { FaqItem } from "@/components/content/faq-list";
import { Callout } from "@/components/ui/callout";
import { DataTable } from "@/components/ui/data-table";
import { pageMetadata } from "@/seo/page-metadata";
import { getActiveTool } from "@/lib/tools/registry";

const SLUG = "percentage-calculator";
const tool = getActiveTool(SLUG);

export const metadata: Metadata = pageMetadata({
  title: tool.title,
  description: tool.metaDescription,
  path: `/${tool.slug}`,
});

interface Example {
  situation: string;
  working: string;
  answer: string;
}

const EXAMPLES: readonly Example[] = [
  {
    situation: "15% off a ₹1,299 shirt",
    working: "1,299 − (1,299 × 15 ÷ 100)",
    answer: "₹1,104.15",
  },
  {
    situation: "Salary from ₹45,000 to ₹52,650",
    working: "(52,650 − 45,000) × 100 ÷ 45,000",
    answer: "17% hike",
  },
  { situation: "432 marks out of 600", working: "432 × 100 ÷ 600", answer: "72%" },
  { situation: "18% of ₹1,25,000", working: "18 × 1,25,000 ÷ 100", answer: "₹22,500" },
];

const sections: readonly ToolSection[] = [
  {
    id: "how-it-works",
    title: "How it is calculated",
    content: (
      <>
        <p>
          A percentage means &ldquo;per hundred&rdquo;, so 20% is 20 out of every 100. Each option
          in the calculator uses one formula:
        </p>
        <h3 className="text-h3">What is X% of a number?</h3>
        <p>
          Multiply the percentage by the number, then divide by 100.{" "}
          <code>20 × 500 ÷ 100 = 100</code>
        </p>
        <h3 className="text-h3">A number is what % of another?</h3>
        <p>
          Multiply the part by 100, then divide by the whole. <code>100 × 100 ÷ 500 = 20%</code>
        </p>
        <h3 className="text-h3">Percentage increase or decrease</h3>
        <p>
          Subtract the original value from the new value, multiply by 100 and divide by the original
          value. A positive answer is an increase; a negative one is a decrease.
        </p>
        <ul>
          <li>
            <code>(600 − 500) × 100 ÷ 500 = 20%</code>, an increase
          </li>
          <li>
            <code>(500 − 600) × 100 ÷ 600 = −16.67%</code>, a decrease of 16.67%
          </li>
        </ul>
        <h3 className="text-h3">Increase or decrease a number by X%</h3>
        <p>
          Work out X% of the number, then add or subtract it.{" "}
          <code>500 + 20% = 500 + 100 = 600</code>
        </p>
      </>
    ),
  },
  {
    id: "examples",
    title: "Worked examples",
    content: (
      <DataTable
        caption="Everyday percentage calculations"
        columns={[
          { key: "situation", header: "Situation", cell: (row: Example) => row.situation },
          {
            key: "working",
            header: "Working",
            hideOnMobile: true,
            cell: (row: Example) => <span className="numeric">{row.working}</span>,
          },
          { key: "answer", header: "Answer", numeric: true, cell: (row: Example) => row.answer },
        ]}
        rows={EXAMPLES}
        rowKey={(row) => row.situation}
      />
    ),
  },
  {
    id: "edge-cases",
    title: "Things that often catch people out",
    content: (
      <>
        <Callout tone="warning" title="Adding 10% and then removing 10% does not get you back">
          <p>
            500 + 10% = 550, but 10% of 550 is 55, so 550 − 10% = 495. To undo an increase of P%,
            decrease by P ÷ (1 + P/100)%. For 10%, that is about 9.09%.
          </p>
        </Callout>
        <Callout tone="info" title="A change from 0 has no percentage">
          <p>
            Going from 0 to 100 is an increase of 100, but it cannot be expressed as a percentage of
            0, so the calculator explains this instead of showing a number.
          </p>
        </Callout>
      </>
    ),
  },
];

const faqs: readonly FaqItem[] = [
  {
    question: "Can I use negative numbers or decimals?",
    answer: (
      <p>
        Yes. Every field accepts decimals and negative numbers. For a percentage change from a
        negative starting value, the change is divided by the size of the starting value, so going
        from −100 to −50 shows as an increase of 50%, because the value went up. Decreasing a number
        by more than 100% takes it below zero (500 − 150% = −250).
      </p>
    ),
  },
  {
    question: "How are results rounded?",
    answer: (
      <p>
        Calculations keep full precision. Only the displayed result is rounded, to at most 2 decimal
        places (16.67%), and the calculator tells you when it has rounded and shows the exact value.
        Very small results are shown to 2 significant digits, so a tiny value is never shown as 0.
      </p>
    ),
  },
  {
    question: "Can I type numbers with commas?",
    answer: <p>Yes. Both Indian (1,25,000) and international (125,000) grouping work.</p>,
  },
  {
    question: "What range of numbers can I enter?",
    answer: <p>Any number between −1,00,00,00,00,000 and 1,00,00,00,00,000 (one lakh crore).</p>,
  },
];

export default function PercentageCalculatorPage() {
  return (
    <ToolPage
      tool={tool}
      intro={<p>Percentage of a number, percentage change, and adding or removing a percentage.</p>}
      calculator={<PercentageCalculator />}
      sections={sections}
      faqs={faqs}
    />
  );
}
