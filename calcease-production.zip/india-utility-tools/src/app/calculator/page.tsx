import type { Metadata } from "next";
import { BasicCalculator } from "@/components/calculator/basic-calculator";
import type { FaqItem } from "@/components/content/faq-list";
import { ToolPage, type ToolSection } from "@/components/tool/tool-page";
import { DataTable } from "@/components/ui/data-table";
import { getActiveTool } from "@/lib/tools/registry";
import { pageMetadata } from "@/seo/page-metadata";

const tool = getActiveTool("calculator");

export const metadata: Metadata = pageMetadata({
  title: tool.title,
  description: tool.metaDescription,
  path: `/${tool.slug}`,
});

interface Example {
  calculation: string;
  answer: string;
}

// Values match tests/fixtures/calculator.json (independently verified).
const EXAMPLES: readonly Example[] = [
  { calculation: "2 + 3 × 4", answer: "14" },
  { calculation: "(100 + 50) × 2", answer: "300" },
  { calculation: "200 × 10%", answer: "20" },
  { calculation: "100 + 10%", answer: "110" },
  { calculation: "500 − 20%", answer: "400" },
  { calculation: "−5 + 2", answer: "−3" },
];

const sections: readonly ToolSection[] = [
  {
    id: "how-it-works",
    title: "How it works",
    content: (
      <>
        <p>
          Calculations follow the usual order: brackets first, then × and ÷, then + and −, each from
          left to right. 2 + 3 × 4 is 14, not 20.
        </p>
        <h3 className="text-h3">Percent</h3>
        <p>
          10% means 10 ÷ 100, so 200 × 10% is 20. After + or −, a percentage is a percentage of the
          number before it, as on a handheld calculator: 100 + 10% is 110 and 500 − 20% is 400.
        </p>
        <h3 className="text-h3">Precision</h3>
        <p>
          Results are shown to 15 significant digits, so 0.1 + 0.2 shows as 0.3. Numbers up to
          1,00,00,00,00,00,000 (10<sup>15</sup>) are supported.
        </p>
      </>
    ),
  },
  {
    id: "examples",
    title: "Examples",
    content: (
      <DataTable
        caption="Example calculations"
        columns={[
          {
            key: "calculation",
            header: "Calculation",
            cell: (r: Example) => <span className="numeric">{r.calculation}</span>,
          },
          { key: "answer", header: "Answer", numeric: true, cell: (r: Example) => r.answer },
        ]}
        rows={EXAMPLES}
        rowKey={(r) => r.calculation}
      />
    ),
  },
];

const faqs: readonly FaqItem[] = [
  {
    question: "Can I use my keyboard?",
    answer: (
      <p>
        Yes. Type numbers and + − * / % ( ), press Enter for the answer, Backspace to delete and Esc
        to clear.
      </p>
    ),
  },
  {
    question: "Is my history saved?",
    answer: (
      <p>
        Only on this page while it is open. It is not stored or sent anywhere, and it disappears
        when you leave or reload.
      </p>
    ),
  },
];

export default function CalculatorPage() {
  return (
    <ToolPage
      tool={tool}
      intro={
        <p>A simple calculator with brackets, percent and history. Works with touch or keyboard.</p>
      }
      calculator={<BasicCalculator />}
      sections={sections}
      faqs={faqs}
    />
  );
}
