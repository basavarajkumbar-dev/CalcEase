import type { MetadataRoute } from "next";
import { SITE_URL } from "@/config/site";

/**
 * Allows crawling everywhere. Vercel preview deployments are kept out of search
 * results by Vercel's own noindex header on preview URLs; production indexing is
 * reviewed again in Phase 10 before launch.
 */
export default function robots(): MetadataRoute.Robots {
  return {
    rules: { userAgent: "*", allow: "/" },
    sitemap: `${SITE_URL}/sitemap.xml`,
  };
}
