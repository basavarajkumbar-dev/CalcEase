import { Link } from "@/components/ui/link";
import { InfoPage } from "@/components/content/info-page";
import { getSitePage } from "@/config/site";
import { sitePageMetadata } from "@/seo/site-page-metadata";

export const metadata = sitePageMetadata("methodology");

export default function MethodologyPage() {
  return (
    <InfoPage page={getSitePage("methodology")}>
      <p>
        Every calculator on this site goes through the same steps before it is published. The aim is
        simple: the number you see should be the number a careful person would get by hand.
      </p>
      <h2 className="text-h2">1. The calculation is written down first</h2>
      <p>
        Before any code is written, each tool gets a specification: the formula, every input and its
        allowed range, how zero and negative values behave, how results are rounded, which
        situations are errors, and worked examples. Where a convention has to be chosen (for
        example, how percentage change is measured from a negative number), the choice and the
        reason are written down and explained on the tool&apos;s page.
      </p>
      <h2 className="text-h2">2. Expected answers are worked out independently</h2>
      <p>
        Test answers are worked out by hand as exact decimals or fractions, never by running the
        calculator itself. A separate script then recalculates every expected answer using exact
        arithmetic (no rounding at all) and fails if any of them is wrong. This step has already
        caught a mistake in a test value before release.
      </p>
      <h2 className="text-h2">3. The calculator is tested automatically</h2>
      <ul>
        <li>Every worked example is checked on every change to the code.</li>
        <li>
          Boundary cases are tested: zero, negative numbers, decimals, very large and very small
          values.
        </li>
        <li>
          Mathematical rules are checked against thousands of random inputs (for example, that 100%
          of any number is that number).
        </li>
        <li>Any mistake that is found becomes a permanent test, so it cannot come back.</li>
      </ul>
      <h2 className="text-h2">4. Rounding happens once, at the end</h2>
      <p>
        Calculations keep full precision. Only the number you see is rounded, normally to two
        decimal places, and the calculator tells you when it has rounded and shows the exact value.
        Very small results are shown to two significant digits so they never appear as zero. Numbers
        use the Indian digit grouping (12,50,000).
      </p>
      <h2 className="text-h2">5. The working is always shown</h2>
      <p>
        Each result comes with the formula filled in with your numbers, so you can check it yourself
        or with a spreadsheet. Each tool page explains the formula, gives worked examples and lists
        the cases that often catch people out.
      </p>
      <h2 className="text-h2">What the calculators don&apos;t do</h2>
      <p>
        Results are estimates for general information. Banks, employers and tax authorities may use
        their own rounding or rules, and their figures are the ones that count. Tools that depend on
        tax or other rules will state which rules and which year they use.
      </p>
      <p>
        Found a result that looks wrong? Please <Link href="/contact">tell us</Link>, with the
        numbers you entered.
      </p>
    </InfoPage>
  );
}
