import type { Metadata } from "next";
import { EmiCalculator } from "@/components/calculator/emi-calculator";
import type { FaqItem } from "@/components/content/faq-list";
import { SourceList } from "@/components/content/source-list";
import { ToolPage, type ToolSection } from "@/components/tool/tool-page";
import { Callout } from "@/components/ui/callout";
import { DataTable } from "@/components/ui/data-table";
import { getActiveTool } from "@/lib/tools/registry";
import { pageMetadata } from "@/seo/page-metadata";

const tool = getActiveTool("emi-calculator");

export const metadata: Metadata = pageMetadata({
  title: tool.title,
  description: tool.metaDescription,
  path: `/${tool.slug}`,
});

interface Example {
  loan: string;
  emi: string;
  interest: string;
}

// Values match tests/fixtures/emi-sip.json (independently verified).
const EXAMPLES: readonly Example[] = [
  { loan: "₹10,00,000 at 7.25% for 10 years", emi: "₹11,740.10", interest: "₹4,08,812.49" },
  { loan: "₹50,00,000 at 8.5% for 20 years", emi: "₹43,391.16", interest: "₹54,13,878.80" },
  { loan: "₹2,00,000 at 12% for 2 years", emi: "₹9,414.69", interest: "₹25,952.67" },
];

const sections: readonly ToolSection[] = [
  {
    id: "how-it-works",
    title: "How EMI is calculated",
    content: (
      <>
        <p>
          <code>EMI = P × r × (1 + r)^n ÷ ((1 + r)^n − 1)</code>, where P is the loan amount, r the
          monthly rate (yearly rate ÷ 12 ÷ 100) and n the number of months.
        </p>
        <p>
          Each EMI first pays the month&rsquo;s interest on the balance still owed; the rest repays
          the loan. Early EMIs are mostly interest, and later ones mostly principal, which the
          year-by-year table shows.
        </p>
        <h3 className="text-h3">Part-prepayment</h3>
        <p>
          A one-time prepayment is taken off the balance right after the EMI you choose. The EMI
          stays the same and the loan ends sooner, so you pay less interest. Some lenders reduce the
          EMI instead; ask yours which they do.
        </p>
      </>
    ),
  },
  {
    id: "examples",
    title: "Worked examples",
    content: (
      <DataTable
        caption="EMI examples"
        columns={[
          { key: "loan", header: "Loan", cell: (r: Example) => r.loan },
          { key: "emi", header: "EMI", numeric: true, cell: (r: Example) => r.emi },
          {
            key: "interest",
            header: "Total interest",
            numeric: true,
            hideOnMobile: true,
            cell: (r: Example) => r.interest,
          },
        ]}
        rows={EXAMPLES}
        rowKey={(r) => r.loan}
      />
    ),
  },
  {
    id: "sources",
    title: "Sources",
    content: (
      <>
        <p>
          The formula is the standard reducing-balance EMI formula that lenders publish. ICICI
          Bank&rsquo;s example (₹10,00,000 at 7.25% for 120 months, EMI about ₹11,740) matches this
          calculator.
        </p>
        <SourceList
          sources={[
            {
              name: "ICICI Bank: Home loan EMI calculator (formula and example)",
              url: "https://www.icici.bank.in/calculator/home-loan-emi-calculator",
              retrieved: "2026-10-07",
            },
          ]}
        />
      </>
    ),
  },
  {
    id: "limits",
    title: "What this calculator does not cover",
    content: (
      <Callout tone="warning" title="An estimate: your loan agreement decides">
        <p>
          It assumes a fixed rate for the whole loan. It does not include processing fees,
          insurance, prepayment charges, rate changes on floating-rate loans or pre-EMI interest.
          Lenders usually round the EMI to the rupee and adjust the last instalment, so their
          figures may differ by a few rupees. Check the Key Facts Statement your lender gives you.
        </p>
      </Callout>
    ),
  },
];

const faqs: readonly FaqItem[] = [
  {
    question: "Does a longer tenure save money?",
    answer: (
      <p>
        It lowers the EMI but raises the total interest. ₹50,00,000 at 8.5% costs ₹54,13,878.80 in
        interest over 20 years; try a shorter tenure to compare.
      </p>
    ),
  },
  {
    question: "Why is most of my early EMI interest?",
    answer: (
      <p>
        Interest is charged on the balance still owed, which is largest at the start. As the balance
        falls, more of each EMI goes to repaying the loan.
      </p>
    ),
  },
  {
    question: "Can I see every month?",
    answer: <p>Yes. Open &ldquo;Month-by-month schedule&rdquo; under the calculator.</p>,
  },
];

export default function EmiCalculatorPage() {
  return (
    <ToolPage
      tool={tool}
      intro={
        <p>
          Monthly EMI, total interest and the full repayment schedule for a home, car or personal
          loan, with an optional part-prepayment.
        </p>
      }
      calculator={<EmiCalculator />}
      sections={sections}
      faqs={faqs}
    />
  );
}
