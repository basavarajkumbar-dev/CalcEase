import type { Metadata } from "next";
import { SipCalculator } from "@/components/calculator/sip-calculator";
import type { FaqItem } from "@/components/content/faq-list";
import { SourceList } from "@/components/content/source-list";
import { ToolPage, type ToolSection } from "@/components/tool/tool-page";
import { Callout } from "@/components/ui/callout";
import { DataTable } from "@/components/ui/data-table";
import { getActiveTool } from "@/lib/tools/registry";
import { pageMetadata } from "@/seo/page-metadata";

const tool = getActiveTool("sip-calculator");

export const metadata: Metadata = pageMetadata({
  title: tool.title,
  description: tool.metaDescription,
  path: `/${tool.slug}`,
});

interface Example {
  sip: string;
  divide: string;
  equivalent: string;
}

// Values match tests/fixtures/emi-sip.json (independently verified).
const EXAMPLES: readonly Example[] = [
  { sip: "₹1,000 a month for 1 year at 12%", divide: "₹12,809.33", equivalent: "₹12,766.50" },
  {
    sip: "₹10,000 a month for 20 years at 12%",
    divide: "₹99,91,479.19",
    equivalent: "₹91,98,573.56",
  },
];

const sections: readonly ToolSection[] = [
  {
    id: "how-it-works",
    title: "How it is calculated",
    content: (
      <>
        <p>
          <code>M = P × ((1 + i)^n − 1) ÷ i × (1 + i)</code>, where P is the monthly investment, n
          the number of months and i the monthly rate. Each investment is assumed to be made at the
          start of the month, so it earns a full month&rsquo;s return straight away.
        </p>
        <h3 className="text-h3">Turning a yearly return into a monthly rate</h3>
        <p>Calculators do this in one of two ways, and you can choose:</p>
        <ul>
          <li>
            <strong>Yearly return ÷ 12</strong>: 12% a year becomes 1% a month. Simple, and widely
            used, but 1% a month compounds to about 12.68% a year.
          </li>
          <li>
            <strong>Monthly equivalent</strong>: the monthly rate that compounds to exactly the
            yearly return, about 0.95% for 12%. HDFC Mutual Fund and Groww use this.
          </li>
        </ul>
        <h3 className="text-h3">Step-up</h3>
        <p>
          With a yearly step-up, the monthly amount rises by that percentage after every 12
          instalments: ₹5,000 with a 10% step-up becomes ₹5,500 in the second year.
        </p>
      </>
    ),
  },
  {
    id: "examples",
    title: "Worked examples",
    content: (
      <DataTable
        caption="SIP values with each monthly-rate method"
        columns={[
          { key: "sip", header: "SIP", cell: (r: Example) => r.sip },
          { key: "divide", header: "÷ 12", numeric: true, cell: (r: Example) => r.divide },
          {
            key: "equivalent",
            header: "Monthly equivalent",
            numeric: true,
            cell: (r: Example) => r.equivalent,
          },
        ]}
        rows={EXAMPLES}
        rowKey={(r) => r.sip}
      />
    ),
  },
  {
    id: "sources",
    title: "Sources",
    content: (
      <SourceList
        sources={[
          {
            name: "HDFC Mutual Fund: SIP calculator (formula, start-of-month timing, monthly rate)",
            url: "https://www.hdfcfund.com/calculators/sip-calculator",
            retrieved: "2026-10-07",
          },
          {
            name: "Groww: SIP calculator (formula and example: ₹1,000 a month at 12% ≈ ₹12,766)",
            url: "https://groww.in/calculators/sip-calculator",
            retrieved: "2026-10-07",
          },
        ]}
      />
    ),
  },
  {
    id: "limits",
    title: "Important",
    content: (
      <Callout tone="warning" title="Returns are not guaranteed">
        <p>
          Mutual fund investments are subject to market risks. Real returns go up and down from year
          to year; this calculator assumes the same return every month, so it is an illustration,
          not a forecast. It does not deduct tax or exit loads. This is not investment advice.
        </p>
      </Callout>
    ),
  },
];

const faqs: readonly FaqItem[] = [
  {
    question: "Which monthly-rate method should I use?",
    answer: (
      <p>
        If your expected return is a yearly compounded figure (like a fund&rsquo;s CAGR), the
        monthly equivalent matches it exactly. ÷ 12 is common and gives a slightly higher figure.
        The difference grows with time and rate.
      </p>
    ),
  },
  {
    question: "What return should I expect?",
    answer: (
      <p>
        Nobody can know. Past returns of a fund or index are a guide, not a promise. Try a few rates
        to see a range.
      </p>
    ),
  },
];

export default function SipCalculatorPage() {
  return (
    <ToolPage
      tool={tool}
      intro={
        <p>
          Estimated value of a monthly SIP at an expected return, with an optional yearly step-up
          and a year-by-year table.
        </p>
      }
      calculator={<SipCalculator />}
      sections={sections}
      faqs={faqs}
    />
  );
}
