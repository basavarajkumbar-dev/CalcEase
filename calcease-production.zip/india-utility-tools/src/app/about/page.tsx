import { Link } from "@/components/ui/link";
import { InfoPage } from "@/components/content/info-page";
import { getSitePage } from "@/config/site";
import { sitePageMetadata } from "@/seo/site-page-metadata";

export const metadata = sitePageMetadata("about");

export default function AboutPage() {
  return (
    <InfoPage page={getSitePage("about")}>
      <p>
        This site offers free, fast calculators for everyday numbers, built for people in India:
        percentages today, and loans, savings, salary and date tools as each one is finished and
        tested.
      </p>
      <p>
        The principles are simple: the answer comes first, the working is always shown, the formulas
        are checked before release (<Link href="/methodology">how we calculate</Link>), and there is
        no sign-up. Calculations run in your browser, so the numbers you type are not sent anywhere.
      </p>
      <h2 className="text-h2">Who runs this site</h2>
      <p>
        <strong>To be completed before launch:</strong> the name of the person or organisation
        responsible for the site, and who reviews finance and salary calculators.
      </p>
    </InfoPage>
  );
}
