import type { Metadata } from "next";
import { getSitePage, type SitePage } from "@/config/site";
import { pageMetadata } from "./page-metadata";

/** Metadata for a trust/legal page; drafts are noindex. */
export function sitePageMetadata(id: SitePage["id"]): Metadata {
  const page = getSitePage(id);
  return pageMetadata({
    title: page.title,
    description: page.description,
    path: page.href,
    noindex: page.status === "draft",
  });
}
