import { SITE_NAME, SITE_TAGLINE, SITE_URL } from "@/config/site";

/**
 * Structured data (schema.org JSON-LD). The data is built on the server from the tool
 * registry and site config only, never from user input, and "<" is escaped so the text
 * can never close the script element. This is the one place dangerouslySetInnerHTML is
 * used: React would otherwise HTML-escape the JSON.
 */
export function JsonLd({ data }: { data: Record<string, unknown> }) {
  const json = JSON.stringify({ "@context": "https://schema.org", ...data }).replace(
    /</g,
    "\\u003c",
  );
  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: json }} />;
}

export function websiteJsonLd(): Record<string, unknown> {
  return { "@type": "WebSite", name: SITE_NAME, url: `${SITE_URL}/`, description: SITE_TAGLINE };
}

/** BreadcrumbList for a page; the last item is the page itself. */
export function breadcrumbJsonLd(items: { name: string; path: string }[]): Record<string, unknown> {
  return {
    "@type": "BreadcrumbList",
    itemListElement: items.map((item, i) => ({
      "@type": "ListItem",
      position: i + 1,
      name: item.name,
      item: `${SITE_URL}${item.path}`,
    })),
  };
}
