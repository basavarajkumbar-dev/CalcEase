/**
 * One way to build page metadata, so every page has a unique title and description,
 * a canonical URL, consistent Open Graph tags and the right indexing rule.
 *
 * The Open Graph image is public/og-image.png (one brand image for the whole site for
 * now; its source is scripts/og-image-source.tsx).
 */
import type { Metadata } from "next";
import { SITE_NAME, SITE_TAGLINE } from "@/config/site";

export interface PageMetadataInput {
  /** Page title without the site name (the root layout appends it). */
  title: string;
  description: string;
  /** Path of the canonical URL, e.g. "/math". Never includes query strings. */
  path: string;
  /** Keep the page out of search results (draft pages). Links are still followed. */
  noindex?: boolean;
  /** Use the title as-is, without the " | Site name" suffix (homepage). */
  absoluteTitle?: boolean;
}

const OG_IMAGE = {
  url: "/og-image.png",
  width: 1200,
  height: 630,
  alt: `${SITE_NAME}: ${SITE_TAGLINE}`,
};

export function pageMetadata({
  title,
  description,
  path,
  noindex = false,
  absoluteTitle = false,
}: PageMetadataInput): Metadata {
  const fullTitle = absoluteTitle ? title : `${title} | ${SITE_NAME}`;
  return {
    title: absoluteTitle ? { absolute: title } : title,
    description,
    alternates: { canonical: path },
    openGraph: {
      title: fullTitle,
      description,
      url: path,
      siteName: SITE_NAME,
      locale: "en_IN",
      type: "website",
      images: [OG_IMAGE],
    },
    twitter: { card: "summary_large_image", title: fullTitle, description, images: [OG_IMAGE.url] },
    ...(noindex ? { robots: { index: false, follow: true } } : {}),
  };
}
