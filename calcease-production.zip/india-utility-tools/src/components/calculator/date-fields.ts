/** Shared pieces for calculators with date inputs. */
import { DATE_RANGE, formatIsoDate } from "@/lib/calc/date/plain-date";
import { validateDateField, type DateFieldError } from "@/lib/validation/date-field";

export const DATE_MIN = formatIsoDate(DATE_RANGE.min);
export const DATE_MAX = formatIsoDate(DATE_RANGE.max);
/** Accepted shape for dates in shared links (full validation happens afterwards). */
export const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;

/**
 * Validates a date field. A missing date is only flagged after the user leaves the field;
 * an impossible or out-of-range date (e.g. from a link) is flagged at once.
 */
export function readDate(text: string, touched: boolean) {
  const result = validateDateField(text);
  const visible: DateFieldError | undefined =
    !result.ok && (result.error.code !== "REQUIRED" || touched) ? result.error : undefined;
  return { result, visible };
}
