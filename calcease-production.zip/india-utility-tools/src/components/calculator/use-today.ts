"use client";

import { useSyncExternalStore } from "react";

/**
 * Today's date on the user's device, in its own time zone, as ISO yyyy-mm-dd; undefined
 * during server rendering and hydration (static HTML cannot know the visitor's date).
 * Re-read when the tab becomes visible again and every minute, so a page left open past
 * midnight moves on to the new day.
 */
function subscribe(onChange: () => void): () => void {
  const timer = window.setInterval(onChange, 60_000);
  document.addEventListener("visibilitychange", onChange);
  return () => {
    window.clearInterval(timer);
    document.removeEventListener("visibilitychange", onChange);
  };
}

function localIsoDate(): string {
  const now = new Date();
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;
}

export function useToday(): string | undefined {
  return useSyncExternalStore(subscribe, localIsoDate, () => undefined);
}
