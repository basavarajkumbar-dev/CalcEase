"use client";

/**
 * Shared state for every calculator: the text in each field, which fields the user has
 * left (for error timing), validation against each field's rule, and shareable URLs.
 *
 * Shareable results (Phase 1 §2): the Share button builds a link with the inputs in the
 * URL *fragment*, e.g. /emi-calculator#amount=2500000&rate=8.5&years=20. Browsers never
 * send the part after "#" to any server, so opening a shared link does not reveal the
 * amounts to the website's host or its logs, keeping the promise that nothing you type
 * is sent anywhere. Links that use a query string (?amount=…) are also read, as a
 * fallback, but the site never creates them.
 *
 * The address bar is deliberately not rewritten while typing: in Next.js, changing the
 * URL makes the router refetch link data, and those requests would carry the URL (and so
 * the inputs) to the server. Measured and fixed in Phase 5, wave 1.
 *
 * Values from a link are untrusted text: each must pass its field's pattern or option
 * list, or it is ignored (the field keeps its default). They are only ever rendered as
 * text, never as HTML. The canonical URL never includes them.
 */
import { useCallback, useMemo, useState, useSyncExternalStore } from "react";
import {
  shouldShowFieldError,
  validateNumberField,
  type NumberFieldError,
  type NumberFieldResult,
  type NumberFieldRule,
} from "@/lib/validation/number-field";

export type FieldSpec =
  | {
      kind: "number";
      /** Link parameter name, short and readable: "amount", "rate", "years". */
      param: string;
      rule: NumberFieldRule;
      /** Default text, optionally per scope (see `scopeField`). */
      initial: string | ((scope: string) => string);
    }
  | { kind: "choice"; param: string; options: readonly string[]; initial: string }
  | {
      kind: "text";
      param: string;
      /** Accepted shape for values from the URL, e.g. an ISO date. */
      pattern: RegExp;
      initial: string;
    };

export type CalculatorSpec<K extends string> = Record<K, FieldSpec>;

export interface CalculatorStateOptions<K extends string> {
  /**
   * A choice field whose value scopes the other fields' text: each scope (e.g. each
   * calculation mode) remembers its own values, so switching modes and back keeps them.
   */
  scopeField?: K;
  /**
   * Defaults known only on the client (e.g. today's date), used when the user has not
   * edited a field and the link does not set it. Fields fall back to `initial` until then.
   */
  defaults?: Partial<Record<K, string>>;
}

/** Longest text accepted from a URL parameter. */
const MAX_PARAM_LENGTH = 32;
/** Characters a typed number may contain (see parse-number.ts). */
const NUMBER_TEXT = /^[0-9.,+\-− ]*$/;

function subscribe(onChange: () => void): () => void {
  window.addEventListener("hashchange", onChange);
  return () => window.removeEventListener("hashchange", onChange);
}
/** The link's parameters: the fragment if it has any, otherwise the query string. */
const clientParams = () => window.location.hash.slice(1) || window.location.search.slice(1);
const serverParams = () => "";

/** Reads allowed values from link parameters; anything malformed is dropped. */
export function readParams<K extends string>(
  search: string,
  spec: CalculatorSpec<K>,
): Partial<Record<K, string>> {
  const params = new URLSearchParams(search);
  const out: Partial<Record<K, string>> = {};
  for (const name of Object.keys(spec) as K[]) {
    const field = spec[name];
    const raw = params.get(field.param);
    if (raw === null || raw.length > MAX_PARAM_LENGTH) continue;
    if (field.kind === "choice" && field.options.includes(raw)) out[name] = raw;
    else if (field.kind === "number" && NUMBER_TEXT.test(raw)) out[name] = raw;
    else if (field.kind === "text" && field.pattern.test(raw)) out[name] = raw;
  }
  return out;
}

/** Builds deterministic link parameters: every field, in the order the spec declares them. */
export function buildQuery<K extends string>(
  values: Record<K, string>,
  spec: CalculatorSpec<K>,
): string {
  const params = new URLSearchParams();
  for (const name of Object.keys(spec) as K[]) {
    const value = values[name].trim();
    if (value !== "") params.set(spec[name].param, value);
  }
  return params.toString();
}

export function useCalculatorState<K extends string>(
  spec: CalculatorSpec<K>,
  options: CalculatorStateOptions<NoInfer<K>> = {},
) {
  const { scopeField, defaults } = options;
  // The link's parameters, read without a hydration mismatch: "" on the server and during
  // hydration, then the real value on the client (and again if the fragment changes).
  const search = useSyncExternalStore(subscribe, clientParams, serverParams);
  const fromUrl = useMemo(() => readParams(search, spec), [search, spec]);

  /** What the user has typed or chosen, keyed by field (and scope for scoped fields). */
  const [edits, setEdits] = useState<Record<string, string>>({});
  const [touchedFields, setTouched] = useState<Record<string, boolean>>({});

  const scope = scopeField
    ? (edits[scopeField] ?? fromUrl[scopeField] ?? String(spec[scopeField].initial))
    : "";
  const urlScope = scopeField ? (fromUrl[scopeField] ?? String(spec[scopeField].initial)) : "";

  const keyFor = useCallback(
    (name: K) => (scopeField && name !== scopeField ? `${name}@${scope}` : name),
    [scopeField, scope],
  );

  const value = useCallback(
    (name: K): string => {
      const edited = edits[keyFor(name)];
      if (edited !== undefined) return edited;
      const field = spec[name];
      // URL values belong to the scope named in the URL.
      if (!(scopeField && name !== scopeField && scope !== urlScope)) {
        const fromQuery = fromUrl[name];
        if (fromQuery !== undefined) return fromQuery;
      }
      const clientDefault = defaults?.[name];
      if (clientDefault !== undefined) return clientDefault;
      return typeof field.initial === "function" ? field.initial(scope) : field.initial;
    },
    [edits, keyFor, spec, fromUrl, scopeField, scope, urlScope, defaults],
  );

  const set = useCallback(
    (name: K, text: string) => {
      if (name === scopeField) {
        setEdits((previous) => ({ ...previous, [name]: text }));
        setTouched({});
        return;
      }
      setEdits((previous) => ({ ...previous, [keyFor(name)]: text }));
    },
    [keyFor, scopeField],
  );

  const touch = useCallback(
    (name: K) => setTouched((t) => ({ ...t, [keyFor(name)]: true })),
    [keyFor],
  );

  const parsed = useCallback(
    (name: K): NumberFieldResult => {
      const field = spec[name];
      if (field.kind !== "number") throw new Error(`Field ${name} is not numeric`);
      return validateNumberField(value(name), field.rule);
    },
    [spec, value],
  );

  /** The error to show under a field right now, if any (respects error timing). */
  const visibleError = useCallback(
    (name: K): NumberFieldError | undefined => {
      const result = parsed(name);
      if (result.ok) return undefined;
      return shouldShowFieldError(value(name), result, Boolean(touchedFields[keyFor(name)]))
        ? result.error
        : undefined;
    },
    [parsed, value, touchedFields, keyFor],
  );

  /** Whether the user has left the field (for error timing in custom fields). */
  const touched = useCallback(
    (name: K): boolean => Boolean(touchedFields[keyFor(name)]),
    [touchedFields, keyFor],
  );

  const values = useMemo(() => {
    const out = {} as Record<K, string>;
    for (const name of Object.keys(spec) as K[]) out[name] = value(name);
    return out;
  }, [spec, value]);

  const query = buildQuery(values, spec);

  /** Absolute link to the current result (for the Share button), inputs in the fragment. */
  const shareUrl = useCallback(
    () => `${window.location.origin}${window.location.pathname}${query ? `#${query}` : ""}`,
    [query],
  );

  return { value, values, set, touch, touched, parsed, visibleError, shareUrl, scope };
}
