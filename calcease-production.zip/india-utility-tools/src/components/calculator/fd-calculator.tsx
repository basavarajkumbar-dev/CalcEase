"use client";

import { useId, useMemo, type ReactNode } from "react";
import { shiftDate } from "@/lib/calc/date/add";
import type { PlainDate } from "@/lib/calc/date/plain-date";
import {
  FD_LIMITS,
  fixedDeposit,
  type FdError,
  type FdPayout,
  type SimpleInterestBelow,
} from "@/lib/calc/deposit/fd";
import { formatDateWithWeekday, formatDuration, plural } from "@/lib/format/date";
import type { NumberFieldResult } from "@/lib/validation/number-field";
import { DateInput } from "@/components/ui/date-input";
import { NumberInput } from "@/components/ui/number-input";
import { SelectInput } from "@/components/ui/select-input";
import { ShareButton } from "@/components/ui/share-button";
import { CalculatorFrame } from "./calculator-frame";
import { DATE_MAX, DATE_MIN, ISO_DATE, readDate } from "./date-fields";
import { Display } from "./display";
import { dateFieldMessage, numberFieldMessage } from "./field-messages";
import { incompleteMessage } from "./incomplete-message";
import { LiveAnnouncer } from "./live-announcer";
import { ResultPanel } from "./result-panel";
import { useCalculatorState, type CalculatorSpec } from "./use-calculator-state";
import { useToday } from "./use-today";

const PAYOUTS = [
  { value: "cumulative", label: "At maturity (cumulative)" },
  { value: "quarterly", label: "Every quarter" },
] as const;

const SHORT_LIMITS = [
  { value: "3", label: "Shorter than 3 months" },
  { value: "6", label: "Shorter than 6 months" },
  { value: "12", label: "Shorter than 12 months" },
] as const;

const AMOUNT = { min: 0, minExclusive: true, max: 1e12 };
const RATE = { min: 0, minExclusive: true, max: FD_LIMITS.rateMax };
const TENURE = {
  years: { min: 0, max: 10, integer: true },
  months: { min: 0, max: 11, integer: true },
  days: { min: 0, max: 365, integer: true },
} as const;
const TENURE_PARTS = ["years", "months", "days"] as const;

const SPEC: CalculatorSpec<
  "amount" | "rate" | "years" | "months" | "days" | "date" | "payout" | "short"
> = {
  amount: { kind: "number", param: "amount", rule: AMOUNT, initial: "100000" },
  rate: { kind: "number", param: "rate", rule: RATE, initial: "7" },
  years: { kind: "number", param: "years", rule: TENURE.years, initial: "1" },
  months: { kind: "number", param: "months", rule: TENURE.months, initial: "" },
  days: { kind: "number", param: "days", rule: TENURE.days, initial: "" },
  date: { kind: "text", param: "date", pattern: ISO_DATE, initial: "" },
  payout: {
    kind: "choice",
    param: "payout",
    options: PAYOUTS.map((p) => p.value),
    initial: "cumulative",
  },
  short: { kind: "choice", param: "short", options: ["3", "6", "12"], initial: "3" },
};

const zeroIfEmpty = (r: NumberFieldResult): NumberFieldResult =>
  !r.ok && r.error.code === "REQUIRED" ? { ok: true, value: 0 } : r;

function errorMessage(error: FdError): string {
  switch (error) {
    case "TENURE_TOO_SHORT":
      return "A fixed deposit must be for at least 7 days.";
    case "TENURE_TOO_LONG":
      return "Enter a tenure of up to 10 years.";
    case "MATURITY_OUT_OF_RANGE":
      return "The maturity date is outside the dates this calculator supports (up to 31 December 2199).";
    default:
      return "Check the values you entered.";
  }
}

export function FdCalculator() {
  const baseId = useId();
  const today = useToday();
  const defaults = useMemo(() => (today ? { date: today } : {}), [today]);
  const state = useCalculatorState(SPEC, { defaults });
  const payout = state.value("payout") as FdPayout;
  const start = readDate(state.value("date"), state.touched("date"));

  const amount = state.parsed("amount");
  const rate = state.parsed("rate");
  const tenure = TENURE_PARTS.map((n) => zeroIfEmpty(state.parsed(n)));
  const tenureErrors = TENURE_PARTS.map((n) => {
    const e = state.visibleError(n);
    return e?.code === "REQUIRED" ? undefined : e;
  });
  const [years, months] = tenure.map((t) => (t.ok ? t.value : 0));
  // The short-deposit choice only changes the answer for deposits under a year.
  const showShortLimit = (years ?? 0) * 12 + (months ?? 0) < 12;

  let result: ReactNode;
  let announcement: string;
  const fieldResults = [amount, rate, ...tenure, start.result];
  const fieldErrors = [
    state.visibleError("amount"),
    state.visibleError("rate"),
    ...tenureErrors,
    start.visible,
  ];

  if (fieldResults.some((r) => !r.ok)) {
    const waitingForToday = !today && state.value("date") === "";
    const incomplete = incompleteMessage(fieldResults, fieldErrors);
    const message = waitingForToday ? "Reading today's date…" : incomplete.message;
    result = (
      <ResultPanel status={incomplete.status} message={message} reserveSpace={waitingForToday} />
    );
    announcement = message;
  } else {
    const [y, m, dd] = tenure.map((t) => (t as { value: number }).value) as [
      number,
      number,
      number,
    ];
    const from = (start.result as { value: PlainDate }).value;
    const shifted = shiftDate(from, { years: y, months: m, weeks: 0, days: dd }, "add");
    const outcome = shifted.ok
      ? fixedDeposit({
          principal: (amount as { value: number }).value,
          rate: (rate as { value: number }).value,
          start: from,
          maturity: shifted.value.date,
          payout,
          simpleBelowMonths: Number(state.value("short")) as SimpleInterestBelow,
        })
      : ({ ok: false, error: "MATURITY_OUT_OF_RANGE" } as const);
    // (When the maturity date cannot be worked out, outcome is already that error.)
    if (!outcome.ok || !shifted.ok) {
      const message = errorMessage(outcome.ok ? "MATURITY_OUT_OF_RANGE" : outcome.error);
      result = <ResultPanel status="error" message={message} />;
      announcement = message;
    } else {
      const d = new Display();
      const v = outcome.value;
      const P = (amount as { value: number }).value;
      const r = (rate as { value: number }).value;
      const maturityDate = formatDateWithWeekday(shifted.value.date);
      const term = formatDuration({ years: y, months: m, days: dd });
      const method = v.simple
        ? `Simple interest for ${plural(v.totalDays, "day")}`
        : `${plural(v.quarters, "quarter")} compounded${v.brokenDays ? `, then simple interest for ${plural(v.brokenDays, "day")}` : ""}`;
      let label: string;
      let value: string;
      let sentence: string;
      let rows;
      if (payout === "cumulative") {
        label = "Maturity amount";
        value = d.rupees(v.maturityAmount);
        sentence = `${d.rupees(P)} at ${d.percent(r)} for ${term} grows to ${d.rupees(v.maturityAmount)} on ${maturityDate}: ${d.rupees(v.interest)} of interest.`;
        rows = [
          { label: "Deposit", value: d.rupees(P) },
          { label: "Interest", value: d.rupees(v.interest) },
          { label: "Maturity amount", value: d.rupees(v.maturityAmount), strong: true },
          { label: "Maturity date", value: maturityDate },
          { label: "How it was worked out", value: method },
        ];
      } else {
        const quarterly = v.quarterlyPayout ?? 0;
        label = v.quarters > 0 ? "Interest every quarter" : "Interest at maturity";
        value = d.rupees(v.quarters > 0 ? quarterly : v.interest);
        sentence =
          v.quarters > 0
            ? `${d.rupees(P)} at ${d.percent(r)} pays ${d.rupees(quarterly)} every quarter (${plural(v.quarters, "payment")})${v.finalPayout ? ` and ${d.rupees(v.finalPayout)} at maturity` : ""}: ${d.rupees(v.interest)} in all.`
            : `${d.rupees(P)} at ${d.percent(r)} for ${term} earns ${d.rupees(v.interest)}, paid at maturity with the deposit.`;
        rows = [
          { label: "Deposit", value: d.rupees(P) },
          ...(v.quarters > 0 ? [{ label: "Each quarter", value: d.rupees(quarterly) }] : []),
          ...(v.finalPayout
            ? [{ label: "Interest for the last part-quarter", value: d.rupees(v.finalPayout) }]
            : []),
          { label: "Total interest", value: d.rupees(v.interest), strong: true },
          { label: "Repaid on " + maturityDate, value: d.rupees(P) },
        ];
      }
      const note = d.roundingNote();
      result = (
        <ResultPanel
          status="result"
          label={label}
          value={value}
          sentence={sentence}
          rows={rows}
          {...(note ? { note } : {})}
          actions={
            <ShareButton data={{ title: "FD Calculator", text: sentence, url: state.shareUrl }} />
          }
        />
      );
      announcement = sentence;
    }
  }

  const amountError = state.visibleError("amount");
  const rateError = state.visibleError("rate");

  const inputs = (
    <form className="space-y-4 md:space-y-5" onSubmit={(e) => e.preventDefault()} noValidate>
      <div className="grid gap-4 md:grid-cols-2 md:gap-5 lg:grid-cols-1">
        <NumberInput
          id={`${baseId}-amount`}
          label="Deposit amount"
          value={state.value("amount")}
          example="100000"
          prefix="₹"
          error={
            amountError
              ? numberFieldMessage(amountError, AMOUNT, { noun: "an amount", prefix: "₹" })
              : undefined
          }
          onChange={(text) => state.set("amount", text)}
          onBlur={() => state.touch("amount")}
        />
        <NumberInput
          id={`${baseId}-rate`}
          label="Interest rate (a year)"
          value={state.value("rate")}
          example="7"
          suffix="%"
          error={
            rateError
              ? numberFieldMessage(rateError, RATE, { noun: "a rate", suffix: "%" })
              : undefined
          }
          onChange={(text) => state.set("rate", text)}
          onBlur={() => state.touch("rate")}
        />
      </div>
      <fieldset>
        <legend className="text-label text-ink">Tenure</legend>
        <div className="mt-2 grid grid-cols-3 gap-3 md:gap-5">
          {TENURE_PARTS.map((name, i) => {
            const error = tenureErrors[i];
            return (
              <NumberInput
                key={name}
                id={`${baseId}-${name}`}
                label={name[0]!.toUpperCase() + name.slice(1)}
                value={state.value(name)}
                example="0"
                error={
                  error
                    ? numberFieldMessage(error, TENURE[name], { noun: `whole ${name}` })
                    : undefined
                }
                onChange={(text) => state.set(name, text)}
                onBlur={() => state.touch(name)}
              />
            );
          })}
        </div>
      </fieldset>
      <div className="grid gap-4 md:grid-cols-2 md:gap-5 lg:grid-cols-1">
        <DateInput
          id={`${baseId}-date`}
          label="Deposit date"
          helperText="Sets the maturity date and the exact days in a part quarter."
          value={state.value("date")}
          min={DATE_MIN}
          max={DATE_MAX}
          error={start.visible ? dateFieldMessage(start.visible, "a deposit date") : undefined}
          onChange={(text) => state.set("date", text)}
          onBlur={() => state.touch("date")}
        />
        <SelectInput
          id={`${baseId}-payout`}
          label="Interest paid"
          value={payout}
          options={PAYOUTS}
          onChange={(next) => state.set("payout", next)}
        />
      </div>
      {showShortLimit && (
        <SelectInput
          id={`${baseId}-short`}
          label="Your bank pays simple interest on deposits"
          helperText="Banks differ. Check your bank's method of interest calculation."
          value={state.value("short")}
          options={SHORT_LIMITS}
          onChange={(next) => state.set("short", next)}
        />
      )}
    </form>
  );

  return (
    <>
      <CalculatorFrame title="FD calculator" inputs={inputs} result={result} />
      <LiveAnnouncer message={announcement} />
    </>
  );
}
