"use client";

import { useId, type ReactNode } from "react";
import { RD_LIMITS, recurringDeposit, type RdError } from "@/lib/calc/deposit/rd";
import { formatExact } from "@/lib/format/number";
import { NumberInput } from "@/components/ui/number-input";
import { ShareButton } from "@/components/ui/share-button";
import { CalculatorFrame } from "./calculator-frame";
import { Display } from "./display";
import { numberFieldMessage } from "./field-messages";
import { incompleteMessage } from "./incomplete-message";
import { LiveAnnouncer } from "./live-announcer";
import { ResultPanel } from "./result-panel";
import { useCalculatorState, type CalculatorSpec } from "./use-calculator-state";

const INSTALMENT = { min: 0, minExclusive: true, max: 1e12 };
const RATE = { min: 0, minExclusive: true, max: RD_LIMITS.rateMax };
const MONTHS = { min: RD_LIMITS.minMonths, max: RD_LIMITS.maxMonths, integer: true };

const SPEC: CalculatorSpec<"instalment" | "rate" | "months"> = {
  instalment: { kind: "number", param: "monthly", rule: INSTALMENT, initial: "5000" },
  rate: { kind: "number", param: "rate", rule: RATE, initial: "7" },
  months: { kind: "number", param: "months", rule: MONTHS, initial: "12" },
};

const FIELDS = {
  instalment: { label: "Monthly instalment", noun: "an amount", prefix: "₹", rule: INSTALMENT },
  rate: { label: "Interest rate (a year)", noun: "a rate", suffix: "%", rule: RATE },
  months: { label: "Tenure (months)", noun: "a number of months", rule: MONTHS },
} as const;
const NAMES = ["instalment", "rate", "months"] as const;

function errorMessage(error: RdError): string {
  if (error === "TENURE_NOT_WHOLE_QUARTERS")
    return "Enter a tenure in whole quarters: 3, 6, 9, 12 … 120 months. Banks treat part quarters differently, so this calculator does not estimate them.";
  return "Check the values you entered.";
}

export function RdCalculator() {
  const baseId = useId();
  const state = useCalculatorState(SPEC);
  const parsed = NAMES.map((n) => state.parsed(n));
  const visible = NAMES.map((n) => state.visibleError(n));

  let result: ReactNode;
  let announcement: string;

  if (parsed.some((p) => !p.ok)) {
    const incomplete = incompleteMessage(parsed, visible);
    result = <ResultPanel status={incomplete.status} message={incomplete.message} />;
    announcement = incomplete.message;
  } else {
    const [R, rate, months] = parsed.map((p) => (p as { value: number }).value) as [
      number,
      number,
      number,
    ];
    const outcome = recurringDeposit(R, rate, months);
    if (!outcome.ok) {
      const message = errorMessage(outcome.error);
      result = <ResultPanel status="error" message={message} />;
      announcement = message;
    } else {
      const d = new Display();
      const v = outcome.value;
      const sentence = `${d.rupees(R)} a month for ${months} months at ${d.percent(rate)} grows to ${d.rupees(v.maturity)}: ${d.rupees(v.deposited)} deposited and ${d.rupees(v.interest)} of interest.`;
      const working = `${formatExact(R)} × [(1 + ${formatExact(rate)}/400)^${formatExact(months / 3)} − 1] ÷ [1 − (1 + ${formatExact(rate)}/400)^(−1/3)] = ${formatExact(v.maturity)}`;
      const note = d.roundingNote();
      result = (
        <ResultPanel
          status="result"
          label="Maturity amount"
          value={d.rupees(v.maturity)}
          sentence={sentence}
          rows={[
            { label: "Total deposited", value: d.rupees(v.deposited) },
            { label: "Interest", value: d.rupees(v.interest) },
            { label: "Maturity amount", value: d.rupees(v.maturity), strong: true },
          ]}
          working={working}
          {...(note ? { note } : {})}
          actions={
            <ShareButton data={{ title: "RD Calculator", text: sentence, url: state.shareUrl }} />
          }
        />
      );
      announcement = sentence;
    }
  }

  const inputs = (
    <form className="space-y-4 md:space-y-5" onSubmit={(e) => e.preventDefault()} noValidate>
      <div className="grid gap-4 md:grid-cols-2 md:gap-5 lg:grid-cols-1">
        {NAMES.map((name, i) => {
          const f = FIELDS[name];
          const error = visible[i];
          return (
            <NumberInput
              key={name}
              id={`${baseId}-${name}`}
              label={f.label}
              value={state.value(name)}
              example={String(SPEC[name].initial)}
              prefix={"prefix" in f ? f.prefix : undefined}
              suffix={"suffix" in f ? f.suffix : undefined}
              helperText={name === "months" ? "Whole quarters: 3, 6, 9 … 120." : undefined}
              error={error ? numberFieldMessage(error, f.rule, f) : undefined}
              onChange={(text) => state.set(name, text)}
              onBlur={() => state.touch(name)}
            />
          );
        })}
      </div>
    </form>
  );

  return (
    <>
      <CalculatorFrame title="RD calculator" inputs={inputs} result={result} />
      <LiveAnnouncer message={announcement} />
    </>
  );
}
