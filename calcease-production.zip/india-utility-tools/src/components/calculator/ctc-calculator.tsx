"use client";

/**
 * CTC to In-Hand. UNDER REVIEW: rendered only in review builds (see src/config/review.ts).
 */
import { useId, type ReactNode } from "react";
import { ctcToInHand, type CtcError, type PfMode, type Regime } from "@/lib/calc/salary/ctc";
import { CURRENT_EPF_RULES } from "@/lib/rules/epf/rates";
import { CURRENT_INCOME_TAX_RULES } from "@/lib/rules/income-tax/rates";
import type { NumberFieldResult, NumberFieldRule } from "@/lib/validation/number-field";
import { Checkbox } from "@/components/ui/checkbox";
import { NumberInput } from "@/components/ui/number-input";
import { SelectInput } from "@/components/ui/select-input";
import { CalculatorFrame } from "./calculator-frame";
import { Display } from "./display";
import { numberFieldMessage } from "./field-messages";
import { incompleteMessage } from "./incomplete-message";
import { LiveAnnouncer } from "./live-announcer";
import { ResultPanel } from "./result-panel";
import { useCalculatorState, type CalculatorSpec } from "./use-calculator-state";

const CEILING = new Intl.NumberFormat("en-IN").format(CURRENT_EPF_RULES.wageCeiling);
const PF_MODES = [
  { value: "full", label: "12% of basic salary" },
  { value: "capped", label: `12% of basic, up to ₹${CEILING} a month` },
  { value: "none", label: "No PF" },
] as const;
const REGIMES = [
  { value: "new", label: "New regime (default)" },
  { value: "old", label: "Old regime" },
] as const;

const CTC = { min: 0, minExclusive: true, max: 1e9 };
const PERCENT = { min: 0, minExclusive: true, max: 100 };
const AMOUNT = { min: 0, max: 1e9 };

type Field = "ctc" | "basic" | "other" | "pt" | "deductions";
const OPTIONAL: readonly Field[] = ["other", "pt", "deductions"];

const SPEC: CalculatorSpec<Field | "pf" | "employerPf" | "gratuity" | "regime"> = {
  ctc: { kind: "number", param: "ctc", rule: CTC, initial: "1200000" },
  basic: { kind: "number", param: "basic", rule: PERCENT, initial: "50" },
  pf: { kind: "choice", param: "pf", options: PF_MODES.map((p) => p.value), initial: "full" },
  employerPf: { kind: "choice", param: "employerPf", options: ["yes", "no"], initial: "yes" },
  gratuity: { kind: "choice", param: "gratuity", options: ["yes", "no"], initial: "no" },
  other: { kind: "number", param: "other", rule: AMOUNT, initial: "" },
  pt: { kind: "number", param: "pt", rule: AMOUNT, initial: "" },
  regime: { kind: "choice", param: "regime", options: ["new", "old"], initial: "new" },
  deductions: { kind: "number", param: "deductions", rule: AMOUNT, initial: "" },
};

const FIELDS: Record<
  Field,
  {
    label: string;
    noun: string;
    prefix?: string;
    suffix?: string;
    rule: NumberFieldRule;
    helper?: string;
  }
> = {
  ctc: { label: "CTC (a year)", noun: "an amount", prefix: "₹", rule: CTC },
  basic: {
    label: "Basic salary (% of CTC)",
    noun: "a percentage",
    suffix: "%",
    rule: PERCENT,
    helper: "From your offer letter or payslip.",
  },
  other: {
    label: "Other employer costs in CTC (a year)",
    noun: "an amount",
    prefix: "₹",
    rule: AMOUNT,
    helper: "Insurance and similar. Leave empty if none.",
  },
  pt: {
    label: "Professional tax (a month)",
    noun: "an amount",
    prefix: "₹",
    rule: AMOUNT,
    helper: "Depends on your state: see your payslip. Leave empty if none.",
  },
  deductions: {
    label: "Deductions you claim (a year)",
    noun: "an amount",
    prefix: "₹",
    rule: AMOUNT,
    helper: "80C (including your PF), 80D, HRA exemption and others.",
  },
};

function errorMessage(error: CtcError): string {
  switch (error) {
    case "ABOVE_SURCHARGE_THRESHOLD":
      return "This calculator covers taxable income up to ₹50 lakh (no surcharge).";
    case "COSTS_TOO_HIGH":
      return "The deductions are more than the salary. Check the values.";
    default:
      return "Check the values you entered.";
  }
}

const zeroIfEmpty = (r: NumberFieldResult): NumberFieldResult =>
  !r.ok && r.error.code === "REQUIRED" ? { ok: true, value: 0 } : r;

export function CtcCalculator() {
  const baseId = useId();
  const state = useCalculatorState(SPEC);
  const regime = state.value("regime") as Regime;
  const names: readonly Field[] =
    regime === "old"
      ? ["ctc", "basic", "other", "pt", "deductions"]
      : ["ctc", "basic", "other", "pt"];
  const parsed = names.map((n) =>
    OPTIONAL.includes(n) ? zeroIfEmpty(state.parsed(n)) : state.parsed(n),
  );
  const visible = names.map((n) => {
    const e = state.visibleError(n);
    return OPTIONAL.includes(n) && e?.code === "REQUIRED" ? undefined : e;
  });

  let result: ReactNode;
  let announcement: string;

  if (parsed.some((p) => !p.ok)) {
    const incomplete = incompleteMessage(parsed, visible);
    result = <ResultPanel status={incomplete.status} message={incomplete.message} />;
    announcement = incomplete.message;
  } else {
    const v = Object.fromEntries(
      names.map((n, i) => [n, (parsed[i] as { value: number }).value]),
    ) as Record<Field, number>;
    const outcome = ctcToInHand(
      {
        ctc: v.ctc,
        basicPercent: v.basic,
        employerPfInCtc: state.value("employerPf") === "yes",
        gratuityInCtc: state.value("gratuity") === "yes",
        pfMode: state.value("pf") as PfMode,
        otherEmployerCosts: v.other,
        professionalTaxMonthly: v.pt,
        regime,
        oldRegimeDeductions: v.deductions ?? 0,
      },
      CURRENT_INCOME_TAX_RULES,
      CURRENT_EPF_RULES,
    );
    if (!outcome.ok) {
      const message = errorMessage(outcome.error);
      result = <ResultPanel status="error" message={message} />;
      announcement = message;
    } else {
      const d = new Display();
      const r = outcome.value;
      const m = (n: number) => d.rupees(n / 12);
      const sentence = `On a CTC of ${d.rupees(v.ctc)}, your estimated take-home pay is ${m(r.inHandYearly)} a month under the ${regime} regime (tax year ${CURRENT_INCOME_TAX_RULES.taxYear}).`;
      result = (
        <ResultPanel
          status="result"
          label="In-hand salary a month"
          value={m(r.inHandYearly)}
          sentence={sentence}
          rows={[
            { label: "Gross salary a month", value: m(r.gross) },
            { label: "Your PF a month", value: `−${m(r.employeePf)}` },
            { label: "Professional tax a month", value: `−${m(r.professionalTax)}` },
            { label: "Income tax a month", value: `−${m(r.totalTax)}` },
            { label: "In-hand a month", value: m(r.inHandYearly), strong: true },
            { label: "Taxable income (a year)", value: d.rupees(r.taxableIncome) },
            { label: "Tax before rebate", value: d.rupees(r.slabTax) },
            { label: "Rebate", value: d.rupees(r.rebate) },
            { label: "Cess (4%)", value: d.rupees(r.cess) },
            { label: "Income tax (a year)", value: d.rupees(r.totalTax) },
            { label: "Employer's PF (in CTC)", value: d.rupees(r.employerPf) },
            ...(r.gratuity > 0
              ? [{ label: "Gratuity (in CTC)", value: d.rupees(r.gratuity) }]
              : []),
          ]}
          note="Estimate for review only. Not checked by a chartered accountant."
        />
      );
      announcement = sentence;
    }
  }

  const field = (name: Field) => {
    const f = FIELDS[name];
    const i = names.indexOf(name);
    const error = i >= 0 ? visible[i] : undefined;
    return (
      <NumberInput
        key={name}
        id={`${baseId}-${name}`}
        label={f.label}
        value={state.value(name)}
        example={name === "ctc" ? "1200000" : name === "basic" ? "50" : "0"}
        prefix={f.prefix}
        suffix={f.suffix}
        helperText={f.helper}
        error={error ? numberFieldMessage(error, f.rule, f) : undefined}
        onChange={(text) => state.set(name, text)}
        onBlur={() => state.touch(name)}
      />
    );
  };

  const inputs = (
    <form className="space-y-4 md:space-y-5" onSubmit={(e) => e.preventDefault()} noValidate>
      {field("ctc")}
      {field("basic")}
      <SelectInput
        id={`${baseId}-pf`}
        label="Provident Fund (PF)"
        value={state.value("pf")}
        options={PF_MODES}
        onChange={(next) => state.set("pf", next)}
      />
      <Checkbox
        id={`${baseId}-employerPf`}
        label="Employer's PF is part of my CTC"
        checked={state.value("employerPf") === "yes"}
        onChange={(checked) => state.set("employerPf", checked ? "yes" : "no")}
      />
      <Checkbox
        id={`${baseId}-gratuity`}
        label="Gratuity is part of my CTC"
        helperText="Counted at 15 days' basic a year (basic ÷ 26 × 15), about 4.81% of basic."
        checked={state.value("gratuity") === "yes"}
        onChange={(checked) => state.set("gratuity", checked ? "yes" : "no")}
      />
      {field("other")}
      {field("pt")}
      <SelectInput
        id={`${baseId}-regime`}
        label="Tax regime"
        value={regime}
        options={REGIMES}
        onChange={(next) => state.set("regime", next)}
      />
      {regime === "old" && field("deductions")}
    </form>
  );

  return (
    <>
      <CalculatorFrame title="CTC to in-hand salary calculator" inputs={inputs} result={result} />
      <LiveAnnouncer message={announcement} />
    </>
  );
}
