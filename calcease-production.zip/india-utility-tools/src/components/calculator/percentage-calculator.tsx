"use client";

import { useId, type ReactNode } from "react";
import { ArrowDown, ArrowUp } from "@/components/ui/icons";
import {
  getMode,
  MAX_ABS_INPUT,
  PERCENTAGE_MODES,
  type PercentageMode,
} from "@/lib/calc/percentage";
import { NumberInput } from "@/components/ui/number-input";
import { SelectInput } from "@/components/ui/select-input";
import { ShareButton } from "@/components/ui/share-button";
import { CalculatorFrame } from "./calculator-frame";
import { numberFieldMessage } from "./field-messages";
import { LiveAnnouncer } from "./live-announcer";
import { ResultPanel } from "./result-panel";
import { calculationErrorMessage, describeResult } from "./percentage-copy";
import { useCalculatorState, type CalculatorSpec } from "./use-calculator-state";
import { incompleteMessage } from "./incomplete-message";

const RULE = { min: -MAX_ABS_INPUT, max: MAX_ABS_INPUT };
const FIELD = { noun: "a number" };

/** Each mode starts with its own worked example, so a result is visible immediately. */
const SPEC: CalculatorSpec<"mode" | "a" | "b"> = {
  mode: {
    kind: "choice",
    param: "mode",
    options: PERCENTAGE_MODES.map((m) => m.id),
    initial: "percentOf",
  },
  a: {
    kind: "number",
    param: "a",
    rule: RULE,
    initial: (mode) => getMode(mode as PercentageMode).inputs[0].example,
  },
  b: {
    kind: "number",
    param: "b",
    rule: RULE,
    initial: (mode) => getMode(mode as PercentageMode).inputs[1].example,
  },
};

export function PercentageCalculator() {
  const baseId = useId();
  const state = useCalculatorState(SPEC, { scopeField: "mode" });
  const modeId = state.value("mode") as PercentageMode;
  const mode = getMode(modeId);
  const a = state.parsed("a");
  const b = state.parsed("b");

  let result: ReactNode;
  let announcement: string;

  if (!a.ok || !b.ok) {
    const incomplete = incompleteMessage(
      [a, b],
      [state.visibleError("a"), state.visibleError("b")],
    );
    result = <ResultPanel status={incomplete.status} message={incomplete.message} />;
    announcement = incomplete.message;
  } else {
    const outcome = mode.calculate(a.value, b.value);
    if (!outcome.ok) {
      const message = calculationErrorMessage(modeId, outcome.error);
      result = <ResultPanel status="error" message={message} />;
      announcement = message;
    } else {
      const copy = describeResult(modeId, a.value, b.value, outcome.value);
      const arrow =
        copy.direction === "increase" ? (
          <ArrowUp
            aria-hidden="true"
            className="mr-1 inline size-9 align-[-0.1em] lg:size-10"
            strokeWidth={2.5}
          />
        ) : copy.direction === "decrease" ? (
          <ArrowDown
            aria-hidden="true"
            className="mr-1 inline size-9 align-[-0.1em] lg:size-10"
            strokeWidth={2.5}
          />
        ) : null;
      result = (
        <ResultPanel
          status="result"
          label={copy.label}
          value={copy.value}
          valuePrefix={arrow}
          sentence={copy.sentence}
          working={copy.working}
          {...(copy.rows ? { rows: copy.rows } : {})}
          {...(copy.exact
            ? { note: `Rounded to 2 decimal places. Exact value: ${copy.exact}` }
            : {})}
          actions={
            <ShareButton
              data={{ title: "Percentage Calculator", text: copy.sentence, url: state.shareUrl }}
            />
          }
        />
      );
      announcement = copy.sentence;
    }
  }

  const inputs = (
    <form
      className="space-y-4 md:space-y-5"
      onSubmit={(event) => event.preventDefault()}
      noValidate
    >
      <SelectInput
        id={`${baseId}-mode`}
        label="What do you want to calculate?"
        value={modeId}
        options={PERCENTAGE_MODES.map((m) => ({ value: m.id, label: m.question }))}
        onChange={(next) => state.set("mode", next)}
      />
      <div className="grid gap-4 md:grid-cols-2 md:gap-5 lg:grid-cols-1">
        {(["a", "b"] as const).map((name, index) => {
          const input = mode.inputs[index === 0 ? 0 : 1];
          const error = state.visibleError(name);
          return (
            <NumberInput
              key={`${modeId}-${name}`}
              id={`${baseId}-${modeId}-${name}`}
              label={input.label}
              value={state.value(name)}
              example={input.example}
              suffix={input.suffix}
              error={error ? numberFieldMessage(error, RULE, FIELD) : undefined}
              onChange={(text) => state.set(name, text)}
              onBlur={() => state.touch(name)}
            />
          );
        })}
      </div>
    </form>
  );

  return (
    <>
      <CalculatorFrame title="Percentage calculator" inputs={inputs} result={result} />
      <LiveAnnouncer message={announcement} />
    </>
  );
}
