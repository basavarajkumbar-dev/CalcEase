"use client";

import { useId, type ReactNode } from "react";
import { LUMPSUM_LIMITS, lumpsumValue, type LumpsumYear } from "@/lib/calc/invest/lumpsum";
import { plural } from "@/lib/format/date";
import { formatExact } from "@/lib/format/number";
import type { NumberFieldRule } from "@/lib/validation/number-field";
import { DataTable } from "@/components/ui/data-table";
import { NumberInput } from "@/components/ui/number-input";
import { ShareButton } from "@/components/ui/share-button";
import { CalculatorFrame } from "./calculator-frame";
import { DisclosureTable } from "./disclosure-table";
import { Display } from "./display";
import { numberFieldMessage } from "./field-messages";
import { incompleteMessage } from "./incomplete-message";
import { LiveAnnouncer } from "./live-announcer";
import { ProportionBar } from "./proportion-bar";
import { ResultPanel } from "./result-panel";
import { useCalculatorState, type CalculatorSpec } from "./use-calculator-state";

const AMOUNT = { min: 0, minExclusive: true, max: 1e12 };
const RETURN = { min: 0, max: LUMPSUM_LIMITS.returnMax };
const YEARS = { min: 1, max: LUMPSUM_LIMITS.yearsMax, integer: true };

type Field = "amount" | "rate" | "years";
const NAMES: readonly Field[] = ["amount", "rate", "years"];

const SPEC: CalculatorSpec<Field> = {
  amount: { kind: "number", param: "amount", rule: AMOUNT, initial: "100000" },
  rate: { kind: "number", param: "return", rule: RETURN, initial: "12" },
  years: { kind: "number", param: "years", rule: YEARS, initial: "10" },
};

const FIELDS: Record<
  Field,
  { label: string; noun: string; prefix?: string; suffix?: string; rule: NumberFieldRule }
> = {
  amount: { label: "Initial investment", noun: "an amount", prefix: "₹", rule: AMOUNT },
  rate: { label: "Expected return (a year)", noun: "a return", suffix: "%", rule: RETURN },
  years: { label: "Investment period (years)", noun: "a whole number of years", rule: YEARS },
};

export function LumpsumCalculator() {
  const baseId = useId();
  const state = useCalculatorState(SPEC);
  const parsed = NAMES.map((n) => state.parsed(n));
  const visible = NAMES.map((n) => state.visibleError(n));

  let result: ReactNode;
  let table: ReactNode = null;
  let announcement: string;

  if (parsed.some((p) => !p.ok)) {
    const incomplete = incompleteMessage(parsed, visible);
    result = <ResultPanel status={incomplete.status} message={incomplete.message} />;
    announcement = incomplete.message;
  } else {
    const [amount, rate, years] = parsed.map((p) => (p as { value: number }).value) as [
      number,
      number,
      number,
    ];
    const outcome = lumpsumValue(amount, rate, years);
    if (!outcome.ok) {
      const message =
        outcome.error === "RESULT_TOO_LARGE"
          ? "The result is too large to show. Check the values."
          : "Check the values you entered.";
      result = <ResultPanel status="error" message={message} />;
      announcement = message;
    } else {
      const d = new Display();
      const v = outcome.value;
      const sentence = `${d.rupees(amount)} invested once for ${plural(years, "year")} at ${d.percent(rate)} a year could grow to about ${d.rupees(v.value)}: ${d.rupees(v.gains)} of estimated returns.`;
      const chart = new Display();
      const note = [
        "Estimate at a constant yearly return, compounded once a year. Returns are not guaranteed.",
        d.roundingNote(),
      ]
        .filter(Boolean)
        .join(" ");
      result = (
        <ResultPanel
          status="result"
          label="Estimated maturity value"
          value={d.rupees(v.value)}
          sentence={sentence}
          rows={[
            { label: "Invested amount", value: d.rupees(v.invested) },
            { label: "Estimated returns", value: d.rupees(v.gains) },
            { label: "Estimated maturity value", value: d.rupees(v.value), strong: true },
          ]}
          chart={
            <ProportionBar
              caption="What makes up the value"
              parts={[
                {
                  label: "Invested",
                  value: v.invested,
                  display: chart.rupees(v.invested),
                  tone: "primary",
                },
                {
                  label: "Returns",
                  value: v.gains,
                  display: chart.rupees(v.gains),
                  tone: "accent",
                },
              ]}
            />
          }
          working={`${formatExact(amount)} × (1 + ${formatExact(rate)} ÷ 100)^${years} = ${formatExact(v.value)}`}
          note={note}
          actions={
            <ShareButton
              data={{ title: "Lumpsum Calculator", text: sentence, url: state.shareUrl }}
            />
          }
        />
      );
      const t = new Display();
      table = (
        <DisclosureTable summary="Year-by-year growth">
          <DataTable
            caption="Estimated value at the end of each year"
            columns={[
              { key: "year", header: "Year", cell: (row: LumpsumYear) => row.year },
              {
                key: "value",
                header: "Value",
                numeric: true,
                cell: (row: LumpsumYear) => t.rupees(row.value),
              },
            ]}
            rows={v.years}
            rowKey={(row) => String(row.year)}
          />
        </DisclosureTable>
      );
      announcement = sentence;
    }
  }

  const inputs = (
    <form className="space-y-4 md:space-y-5" onSubmit={(e) => e.preventDefault()} noValidate>
      <div className="grid gap-4 md:grid-cols-2 md:gap-5 lg:grid-cols-1">
        {NAMES.map((name, i) => {
          const f = FIELDS[name];
          const error = visible[i];
          return (
            <NumberInput
              key={name}
              id={`${baseId}-${name}`}
              label={f.label}
              value={state.value(name)}
              example={String(SPEC[name].initial)}
              prefix={f.prefix}
              suffix={f.suffix}
              error={error ? numberFieldMessage(error, f.rule, f) : undefined}
              onChange={(text) => state.set(name, text)}
              onBlur={() => state.touch(name)}
            />
          );
        })}
      </div>
    </form>
  );

  return (
    <>
      <CalculatorFrame title="Lumpsum calculator" inputs={inputs} result={result} />
      {table}
      <LiveAnnouncer message={announcement} />
    </>
  );
}
