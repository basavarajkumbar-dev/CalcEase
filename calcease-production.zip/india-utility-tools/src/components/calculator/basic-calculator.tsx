"use client";

import { useId, useRef, useState, type KeyboardEvent } from "react";
import { evaluateExpression, plainNumber, type ExpressionError } from "@/lib/calc/expression";
import { formatExact } from "@/lib/format/number";
import { LiveAnnouncer } from "./live-announcer";

/** Characters the field accepts; anything else typed or pasted is dropped. */
const ALLOWED = /[0-9.+\-−*×/÷%() ,xX]/g;
const DISPLAY: Record<string, string> = { "*": "×", x: "×", X: "×", "/": "÷", "-": "−" };
const OPERATORS = new Set(["+", "−", "×", "÷", "%"]);

function clean(text: string): string {
  return (text.match(ALLOWED) ?? []).map((c) => DISPLAY[c] ?? c).join("");
}

const MESSAGES: Record<ExpressionError, string> = {
  EMPTY: "Enter a calculation.",
  INVALID: "That calculation is incomplete or has a mistake. Check it and try again.",
  UNBALANCED_PARENTHESES: "Check the brackets: each ( needs a matching ).",
  DIVIDE_BY_ZERO: "You can't divide by zero.",
  TOO_LARGE: "The result is too large to show.",
  TOO_LONG: "That calculation is too long.",
};

interface Key {
  label: string;
  /** Accessible name when the label is a symbol. */
  name?: string;
  insert?: string;
  action?: "clear" | "back" | "equals";
  tone?: "digit" | "op" | "fn" | "equals";
  wide?: boolean;
}

const KEYS: readonly Key[] = [
  { label: "C", name: "Clear", action: "clear", tone: "fn" },
  { label: "(", name: "Open bracket", insert: "(", tone: "fn" },
  { label: ")", name: "Close bracket", insert: ")", tone: "fn" },
  { label: "⌫", name: "Backspace", action: "back", tone: "fn" },
  { label: "7", insert: "7" },
  { label: "8", insert: "8" },
  { label: "9", insert: "9" },
  { label: "÷", name: "Divide", insert: "÷", tone: "op" },
  { label: "4", insert: "4" },
  { label: "5", insert: "5" },
  { label: "6", insert: "6" },
  { label: "×", name: "Multiply", insert: "×", tone: "op" },
  { label: "1", insert: "1" },
  { label: "2", insert: "2" },
  { label: "3", insert: "3" },
  { label: "−", name: "Minus", insert: "−", tone: "op" },
  { label: "0", insert: "0" },
  { label: ".", name: "Decimal point", insert: "." },
  { label: "%", name: "Percent", insert: "%", tone: "op" },
  { label: "+", name: "Plus", insert: "+", tone: "op" },
  { label: "=", name: "Equals", action: "equals", tone: "equals", wide: true },
];

const TONES: Record<NonNullable<Key["tone"]>, string> = {
  digit: "border border-line bg-surface text-ink hover:bg-canvas",
  op: "border border-line bg-primary-soft text-primary hover:border-primary",
  fn: "border border-line bg-canvas text-ink hover:border-line-strong",
  equals: "bg-primary text-white hover:bg-primary-hover",
};

interface HistoryEntry {
  id: number;
  expression: string;
  result: string;
}

export function BasicCalculator() {
  const baseId = useId();
  const inputRef = useRef<HTMLInputElement>(null);
  const [expression, setExpression] = useState("");
  const [shown, setShown] = useState<
    | { kind: "result"; expression: string; value: number }
    | { kind: "error"; message: string }
    | null
  >(null);
  const [justEvaluated, setJustEvaluated] = useState(false);
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [announcement, setAnnouncement] = useState("");

  const preview = expression && !justEvaluated ? evaluateExpression(expression) : undefined;

  function update(next: string) {
    setExpression(next);
    setShown(null);
    setJustEvaluated(false);
  }

  function insert(text: string) {
    // After "=", a digit starts a new calculation; an operator continues from the result.
    const continuing = !justEvaluated || OPERATORS.has(text);
    update((continuing ? expression : "") + text);
  }

  function equals() {
    const result = evaluateExpression(expression);
    if (!result.ok) {
      const message = MESSAGES[result.error];
      setShown({ kind: "error", message });
      setAnnouncement(message);
      return;
    }
    const text = plainNumber(result.value);
    setShown({ kind: "result", expression, value: result.value });
    setHistory((h) => [{ id: Date.now() + h.length, expression, result: text }, ...h].slice(0, 20));
    setExpression(text);
    setJustEvaluated(true);
    setAnnouncement(`${expression} equals ${formatExact(result.value)}`);
  }

  function press(key: Key) {
    if (key.action === "clear") {
      update("");
      setAnnouncement("Cleared");
    } else if (key.action === "back") update(expression.slice(0, -1));
    else if (key.action === "equals") equals();
    else if (key.insert) insert(key.insert);
  }

  function onKeyDown(event: KeyboardEvent<HTMLInputElement>) {
    if (event.key === "Enter" || event.key === "=") {
      event.preventDefault();
      equals();
    } else if (event.key === "Escape") {
      event.preventDefault();
      update("");
    }
  }

  return (
    <section
      aria-label="Calculator"
      className="grid gap-4 overflow-hidden rounded-lg border border-line bg-surface p-4 md:p-6 lg:grid-cols-[minmax(0,34rem)_minmax(0,1fr)] lg:gap-8"
    >
      <div className="mx-auto w-full max-w-md lg:max-w-none">
        <div className="rounded-md border-t-4 border-primary bg-primary-soft p-4">
          <label htmlFor={`${baseId}-expr`} className="text-label text-primary">
            Calculation
          </label>
          <input
            ref={inputRef}
            id={`${baseId}-expr`}
            type="text"
            inputMode="none"
            autoComplete="off"
            spellCheck={false}
            enterKeyHint="go"
            value={expression}
            placeholder="0"
            onChange={(event) => update(clean(event.target.value))}
            onKeyDown={onKeyDown}
            aria-describedby={`${baseId}-out`}
            className="numeric mt-1 block w-full min-w-0 border-0 bg-transparent p-0 text-right text-3xl font-semibold text-ink placeholder:text-muted focus:outline-none md:text-4xl"
          />
          <p
            id={`${baseId}-out`}
            data-testid="calculator-output"
            className={`numeric mt-2 min-h-7 text-right text-lg [overflow-wrap:anywhere] ${
              shown?.kind === "error" ? "font-medium text-error" : "text-muted"
            }`}
          >
            {shown?.kind === "error"
              ? shown.message
              : shown?.kind === "result"
                ? `${shown.expression} =`
                : preview?.ok && /[+−×÷%]/.test(expression.replace(/^−/, ""))
                  ? `= ${formatExact(preview.value)}`
                  : ""}
          </p>
        </div>

        <div className="mt-4 grid grid-cols-4 gap-2" role="group" aria-label="Keypad">
          {KEYS.map((key) => (
            <button
              key={key.label}
              type="button"
              aria-label={key.name}
              onClick={() => press(key)}
              className={`numeric min-h-14 rounded-md text-xl font-semibold transition-colors duration-100 select-none ${
                TONES[key.tone ?? "digit"]
              } ${key.wide ? "col-span-4" : ""}`}
            >
              {key.label}
            </button>
          ))}
        </div>
        <p className="text-helper mt-3">
          Type with your keyboard too: Enter for =, Esc to clear. 200 × 10% = 20; 100 + 10% = 110.
        </p>
      </div>

      <section aria-labelledby={`${baseId}-history`} className="lg:border-l lg:border-line lg:pl-8">
        <div className="flex items-center justify-between gap-2">
          <h2 id={`${baseId}-history`} className="text-h3 text-ink">
            History
          </h2>
          {history.length > 0 && (
            <button
              type="button"
              onClick={() => setHistory([])}
              className="min-h-11 rounded-md px-3 text-small font-semibold text-primary hover:bg-primary-soft"
            >
              Clear history
            </button>
          )}
        </div>
        {history.length === 0 ? (
          <p className="text-small mt-2 text-muted">
            Your calculations appear here until you leave the page. Nothing is saved or sent.
          </p>
        ) : (
          <ol className="mt-2 space-y-1">
            {history.map((entry) => (
              <li key={entry.id}>
                <button
                  type="button"
                  onClick={() => {
                    update(entry.expression);
                    inputRef.current?.focus();
                  }}
                  aria-label={`Use again: ${entry.expression} = ${entry.result}`}
                  className="numeric block min-h-11 w-full rounded-md px-2 py-1 text-right hover:bg-canvas [overflow-wrap:anywhere]"
                >
                  <span className="text-small block text-muted">{entry.expression} =</span>
                  <span className="block font-semibold text-ink">
                    {formatExact(Number(entry.result))}
                  </span>
                </button>
              </li>
            ))}
          </ol>
        )}
      </section>
      <LiveAnnouncer message={announcement} delayMs={50} />
    </section>
  );
}
