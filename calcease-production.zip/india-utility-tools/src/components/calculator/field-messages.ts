/**
 * User-facing wording for field validation errors, built from each field's rule so a
 * message always states the real allowed range ("Enter a rate between 0% and 100%.").
 */
import { formatExact } from "@/lib/format/number";
import type { NumberFieldError, NumberFieldRule } from "@/lib/validation/number-field";

export interface FieldUnit {
  /** Shown before numbers, e.g. "₹". */
  prefix?: string | undefined;
  /** Shown after numbers, e.g. "%" or " years". */
  suffix?: string | undefined;
}

export interface FieldDescription extends FieldUnit {
  /** Noun used in messages: "an amount", "a rate", "a number of years". */
  noun: string;
}

function show(value: number, unit: FieldUnit): string {
  const text = formatExact(Math.abs(value));
  const sign = value < 0 ? "−" : "";
  return `${sign}${unit.prefix ?? ""}${text}${unit.suffix ?? ""}`;
}

export function rangeMessage(rule: NumberFieldRule, field: FieldDescription): string {
  const { min, max, minExclusive } = rule;
  if (min !== undefined && max !== undefined && !minExclusive) {
    return `Enter ${field.noun} between ${show(min, field)} and ${show(max, field)}.`;
  }
  if (min !== undefined && max !== undefined) {
    return `Enter ${field.noun} more than ${show(min, field)} and up to ${show(max, field)}.`;
  }
  if (min !== undefined)
    return `Enter ${field.noun} of ${minExclusive ? "more than" : "at least"} ${show(min, field)}.`;
  if (max !== undefined) return `Enter ${field.noun} of at most ${show(max, field)}.`;
  return "Enter a smaller number.";
}

export function numberFieldMessage(
  error: NumberFieldError,
  rule: NumberFieldRule,
  field: FieldDescription,
): string {
  switch (error.code) {
    case "REQUIRED":
      return `Enter ${field.noun}.`;
    case "NOT_A_NUMBER":
      return rule.integer
        ? "Enter a whole number, for example 12."
        : "Enter a number, for example 250 or 12.5.";
    case "NOT_INTEGER":
      return "Enter a whole number, without decimals.";
    case "OUT_OF_RANGE":
      return rangeMessage(rule, field);
  }
}

/** Wording for date field errors; the range is the date engine's (spec §2). */
export function dateFieldMessage(
  error: { code: "REQUIRED" | "INVALID_DATE" | "OUT_OF_RANGE" },
  noun: string,
): string {
  switch (error.code) {
    case "REQUIRED":
      return `Enter ${noun}.`;
    case "INVALID_DATE":
      return "Enter a real date, for example 15/08/1990.";
    case "OUT_OF_RANGE":
      return "Enter a date between 1 January 1900 and 31 December 2199.";
  }
}
