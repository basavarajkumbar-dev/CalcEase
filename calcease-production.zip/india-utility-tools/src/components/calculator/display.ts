/**
 * Small display helpers shared by calculator components: rupees, signed rupees,
 * percentages and LPA. Formatting only (src/lib/format does the work); a list of
 * rounding flags lets each result say once whether anything shown was rounded.
 */
import { compactIndian, formatCurrency, type PaiseMode } from "@/lib/format/currency";
import { formatPercent } from "@/lib/format/number";

export class Display {
  private roundedMoney = false;
  private roundedPercent = false;

  rupees(value: number, paise: PaiseMode = "auto"): string {
    const f = formatCurrency(value, paise);
    if (f.isRounded && paise !== "never") this.roundedMoney = true;
    return f.text;
  }

  /** "+₹5,000" / "−₹6,000" / "₹0". */
  signedRupees(value: number): string {
    const text = this.rupees(Math.abs(value));
    if (value > 0) return `+${text}`;
    if (value < 0) return `−${text}`;
    return text;
  }

  percent(value: number): string {
    const f = formatPercent(value);
    if (f.isRounded) this.roundedPercent = true;
    return f.text.replace(/^-/, "−");
  }

  /** "8.4 LPA" for yearly amounts of at least ₹1 lakh (lakh per annum). */
  static lpa(yearly: number): string | undefined {
    if (Math.abs(yearly) < 1e5) return undefined;
    return compactIndian(yearly).replace(" lakh", " LPA").replace(" crore", " crore a year");
  }

  /** One sentence about rounding, or undefined when nothing shown was rounded. */
  roundingNote(): string | undefined {
    if (this.roundedMoney && this.roundedPercent)
      return "Amounts are rounded to the nearest paisa and percentages to 2 decimal places.";
    if (this.roundedMoney) return "Amounts are rounded to the nearest paisa.";
    if (this.roundedPercent) return "Percentages are rounded to 2 decimal places.";
    return undefined;
  }
}
