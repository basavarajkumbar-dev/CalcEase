"use client";

import { useId, useMemo, type ReactNode } from "react";
import { NOTICE_LIMITS, noticePeriod } from "@/lib/calc/career/career";
import { parseIsoDate } from "@/lib/calc/date/plain-date";
import { formatDateWithWeekday, formatLongDate, plural } from "@/lib/format/date";
import { Checkbox } from "@/components/ui/checkbox";
import { DateInput } from "@/components/ui/date-input";
import { NumberInput } from "@/components/ui/number-input";
import { ShareButton } from "@/components/ui/share-button";
import { CalculatorFrame } from "./calculator-frame";
import { DATE_MAX, DATE_MIN, ISO_DATE, readDate } from "./date-fields";
import { dateFieldMessage, numberFieldMessage } from "./field-messages";
import { incompleteMessage } from "./incomplete-message";
import { LiveAnnouncer } from "./live-announcer";
import { ResultPanel } from "./result-panel";
import { useCalculatorState, type CalculatorSpec } from "./use-calculator-state";
import { useToday } from "./use-today";

const DAYS = { min: NOTICE_LIMITS.minDays, max: NOTICE_LIMITS.maxDays, integer: true };

const SPEC: CalculatorSpec<"resigned" | "days" | "dayOne"> = {
  // Defaults to today once the page knows it (see useToday).
  resigned: { kind: "text", param: "resigned", pattern: ISO_DATE, initial: "" },
  days: { kind: "number", param: "days", rule: DAYS, initial: "30" },
  dayOne: { kind: "choice", param: "dayOne", options: ["yes", "no"], initial: "no" },
};

export function NoticePeriodCalculator() {
  const baseId = useId();
  const today = useToday();
  const defaults = useMemo(() => (today ? { resigned: today } : {}), [today]);
  const state = useCalculatorState(SPEC, { defaults });
  const resigned = readDate(state.value("resigned"), state.touched("resigned"));
  const days = state.parsed("days");
  const daysError = state.visibleError("days");
  const dayOne = state.value("dayOne") === "yes";

  let result: ReactNode;
  let announcement: string;

  if (!resigned.result.ok || !days.ok) {
    const waiting = !today && state.value("resigned") === "";
    const incomplete = incompleteMessage([resigned.result, days], [resigned.visible, daysError]);
    const message = waiting ? "Reading today's date…" : incomplete.message;
    result = <ResultPanel status={incomplete.status} message={message} reserveSpace={waiting} />;
    announcement = message;
  } else {
    const todayDate = today ? parseIsoDate(today) : undefined;
    const outcome = noticePeriod(resigned.result.value, days.value, dayOne, todayDate);
    if (!outcome.ok) {
      const message = "The last working day falls outside the supported dates (up to 2199).";
      result = <ResultPanel status="error" message={message} />;
      announcement = message;
    } else {
      const v = outcome.value;
      const lwd = formatDateWithWeekday(v.lastWorkingDay);
      const sentence = `Resigning on ${formatDateWithWeekday(resigned.result.value)} with ${plural(days.value, "day")} of notice, your last working day is ${lwd}.`;
      const until = v.daysUntilLastDay;
      const remaining =
        until === undefined
          ? undefined
          : until > 0
            ? `${plural(until, "day")} from today`
            : until === 0
              ? "Today is the last working day"
              : `Passed ${plural(-until, "day")} ago`;
      result = (
        <ResultPanel
          status="result"
          label="Last working day"
          value={formatLongDate(v.lastWorkingDay)}
          sentence={sentence}
          rows={[
            { label: "Notice starts", value: formatDateWithWeekday(v.firstNoticeDay) },
            { label: "Last working day", value: lwd, strong: true },
            ...(remaining ? [{ label: "Time left", value: remaining }] : []),
            ...(v.daysServed !== undefined
              ? [{ label: "Notice served so far", value: `${v.daysServed} of ${days.value} days` }]
              : []),
          ]}
          note="Calendar days, including weekends and holidays. Your employment contract or HR policy decides the actual date."
          actions={
            <ShareButton
              data={{ title: "Notice Period Calculator", text: sentence, url: state.shareUrl }}
            />
          }
        />
      );
      announcement = sentence;
    }
  }

  const inputs = (
    <form className="space-y-4 md:space-y-5" onSubmit={(e) => e.preventDefault()} noValidate>
      <div className="grid gap-4 md:grid-cols-2 md:gap-5 lg:grid-cols-1">
        <DateInput
          id={`${baseId}-resigned`}
          label="Resignation date"
          value={state.value("resigned")}
          min={DATE_MIN}
          max={DATE_MAX}
          error={
            resigned.visible ? dateFieldMessage(resigned.visible, "a resignation date") : undefined
          }
          onChange={(text) => state.set("resigned", text)}
          onBlur={() => state.touch("resigned")}
        />
        <NumberInput
          id={`${baseId}-days`}
          label="Notice period (days)"
          value={state.value("days")}
          example="30"
          suffix="days"
          error={
            daysError
              ? numberFieldMessage(daysError, DAYS, { noun: "a number of days", suffix: " days" })
              : undefined
          }
          onChange={(text) => state.set("days", text)}
          onBlur={() => state.touch("days")}
        />
      </div>
      <Checkbox
        id={`${baseId}-dayOne`}
        label="Count the resignation date as day 1"
        helperText="Off by default: the notice starts the day after you resign."
        checked={dayOne}
        onChange={(checked) => state.set("dayOne", checked ? "yes" : "no")}
      />
    </form>
  );

  return (
    <>
      <CalculatorFrame title="Notice period calculator" inputs={inputs} result={result} />
      <LiveAnnouncer message={announcement} />
    </>
  );
}
