"use client";

import { useId, type ReactNode } from "react";
import {
  CI_LIMITS,
  compoundInterest,
  type Compounding,
  type CompoundError,
  type YearRow,
} from "@/lib/calc/deposit/compound";
import { formatDuration } from "@/lib/format/date";
import { formatExact } from "@/lib/format/number";
import { DataTable } from "@/components/ui/data-table";
import { NumberInput } from "@/components/ui/number-input";
import { SelectInput } from "@/components/ui/select-input";
import { ShareButton } from "@/components/ui/share-button";
import { CalculatorFrame } from "./calculator-frame";
import { DisclosureTable } from "./disclosure-table";
import { Display } from "./display";
import { numberFieldMessage } from "./field-messages";
import { incompleteMessage } from "./incomplete-message";
import { LiveAnnouncer } from "./live-announcer";
import { ResultPanel } from "./result-panel";
import { useCalculatorState, type CalculatorSpec } from "./use-calculator-state";

const FREQUENCIES = [
  { value: "yearly", label: "Yearly" },
  { value: "halfYearly", label: "Half-yearly" },
  { value: "quarterly", label: "Quarterly" },
  { value: "monthly", label: "Monthly" },
] as const;

const PRINCIPAL = { min: 0, minExclusive: true, max: 1e12 };
const RATE = { min: 0, max: CI_LIMITS.rateMax };
const YEARS = { min: 0, max: CI_LIMITS.yearsMax, integer: true };
const MONTHS = { min: 0, max: 11, integer: true };

const SPEC: CalculatorSpec<"principal" | "rate" | "years" | "months" | "freq"> = {
  principal: { kind: "number", param: "p", rule: PRINCIPAL, initial: "100000" },
  rate: { kind: "number", param: "rate", rule: RATE, initial: "8" },
  years: { kind: "number", param: "years", rule: YEARS, initial: "5" },
  months: { kind: "number", param: "months", rule: MONTHS, initial: "" },
  freq: {
    kind: "choice",
    param: "freq",
    options: FREQUENCIES.map((f) => f.value),
    initial: "quarterly",
  },
};

const FIELDS = {
  principal: { label: "Principal", noun: "an amount", prefix: "₹", rule: PRINCIPAL },
  rate: { label: "Interest rate (a year)", noun: "a rate", suffix: "%", rule: RATE },
  years: { label: "Years", noun: "a whole number of years", rule: YEARS },
  months: { label: "Months", noun: "a whole number of months", rule: MONTHS },
} as const;

function errorMessage(error: CompoundError): string {
  if (error === "TIME_OUT_OF_RANGE") return "Enter a time of more than 0 and up to 100 years.";
  if (error === "RESULT_TOO_LARGE") return "The result is too large to show. Check the values.";
  return "Check the values you entered.";
}

export function CompoundInterestCalculator() {
  const baseId = useId();
  const state = useCalculatorState(SPEC);
  const freq = state.value("freq") as Compounding;
  const names = ["principal", "rate", "years", "months"] as const;
  // Empty years or months count as 0 (the total must still be more than 0).
  const parsed = names.map((n) => {
    const r = state.parsed(n);
    return (n === "years" || n === "months") && !r.ok && r.error.code === "REQUIRED"
      ? ({ ok: true, value: 0 } as const)
      : r;
  });
  const visible = names.map((n) => {
    const e = state.visibleError(n);
    return (n === "years" || n === "months") && e?.code === "REQUIRED" ? undefined : e;
  });

  let result: ReactNode;
  let table: ReactNode = null;
  let announcement: string;

  if (parsed.some((p) => !p.ok)) {
    const incomplete = incompleteMessage(parsed, visible);
    result = <ResultPanel status={incomplete.status} message={incomplete.message} />;
    announcement = incomplete.message;
  } else {
    const [principal, rate, years, months] = parsed.map((p) => (p as { value: number }).value) as [
      number,
      number,
      number,
      number,
    ];
    const t = years + months / 12;
    const outcome = compoundInterest(principal, rate, t, freq);
    if (!outcome.ok) {
      const message = errorMessage(outcome.error);
      result = <ResultPanel status="error" message={message} />;
      announcement = message;
    } else {
      const d = new Display();
      const v = outcome.value;
      const time = formatDuration({ years, months });
      const how = FREQUENCIES.find((f) => f.value === freq)!.label.toLowerCase();
      const sentence = `${d.rupees(principal)} at ${d.percent(rate)} a year, compounded ${how}, grows to ${d.rupees(v.amount)} in ${time}: ${d.rupees(v.interest)} of interest.`;
      const rows = [
        { label: "Principal", value: d.rupees(principal) },
        { label: "Interest earned", value: d.rupees(v.interest) },
        { label: "Total amount", value: d.rupees(v.amount), strong: true },
        { label: "Effective annual rate", value: d.percent(v.effectiveRate) },
        { label: "Simple interest, for comparison", value: d.rupees(v.simpleInterest) },
      ];
      const n = { yearly: 1, halfYearly: 2, quarterly: 4, monthly: 12 }[freq];
      const working = `${formatExact(principal)} × (1 + ${formatExact(rate)} ÷ ${100 * n})^(${n} × ${formatExact(Math.round(t * 1e6) / 1e6)}) = ${formatExact(v.amount)}`;
      const note = d.roundingNote();
      result = (
        <ResultPanel
          status="result"
          label="Total amount"
          value={d.rupees(v.amount)}
          sentence={sentence}
          rows={rows}
          working={working}
          {...(note ? { note } : {})}
          actions={
            <ShareButton
              data={{ title: "Compound Interest Calculator", text: sentence, url: state.shareUrl }}
            />
          }
        />
      );
      const t2 = new Display();
      table = (
        <DisclosureTable summary="Year-by-year growth">
          <DataTable
            caption="Interest earned and balance at the end of each year"
            columns={[
              {
                key: "year",
                header: "Year",
                cell: (row: YearRow) =>
                  Number.isInteger(row.year)
                    ? row.year
                    : formatExact(Math.round(row.year * 100) / 100),
              },
              {
                key: "interest",
                header: "Interest",
                numeric: true,
                cell: (row: YearRow) => t2.rupees(row.interest),
              },
              {
                key: "balance",
                header: "Balance",
                numeric: true,
                cell: (row: YearRow) => t2.rupees(row.balance),
              },
            ]}
            rows={v.years}
            rowKey={(row) => String(row.year)}
          />
        </DisclosureTable>
      );
      announcement = sentence;
    }
  }

  const inputs = (
    <form className="space-y-4 md:space-y-5" onSubmit={(e) => e.preventDefault()} noValidate>
      <div className="grid gap-4 md:grid-cols-2 md:gap-5 lg:grid-cols-1">
        {(["principal", "rate"] as const).map((name) => {
          const f = FIELDS[name];
          const error = visible[names.indexOf(name)];
          return (
            <NumberInput
              key={name}
              id={`${baseId}-${name}`}
              label={f.label}
              value={state.value(name)}
              example={String(SPEC[name].initial)}
              prefix={"prefix" in f ? f.prefix : undefined}
              suffix={"suffix" in f ? f.suffix : undefined}
              error={error ? numberFieldMessage(error, f.rule, f) : undefined}
              onChange={(text) => state.set(name, text)}
              onBlur={() => state.touch(name)}
            />
          );
        })}
      </div>
      <fieldset>
        <legend className="text-label text-ink">Time</legend>
        <div className="mt-2 grid grid-cols-2 gap-4 md:gap-5">
          {(["years", "months"] as const).map((name) => {
            const f = FIELDS[name];
            const error = visible[names.indexOf(name)];
            return (
              <NumberInput
                key={name}
                id={`${baseId}-${name}`}
                label={f.label}
                value={state.value(name)}
                example="0"
                error={error ? numberFieldMessage(error, f.rule, f) : undefined}
                onChange={(text) => state.set(name, text)}
                onBlur={() => state.touch(name)}
              />
            );
          })}
        </div>
      </fieldset>
      <SelectInput
        id={`${baseId}-freq`}
        label="Compounded"
        value={freq}
        options={FREQUENCIES}
        onChange={(next) => state.set("freq", next)}
      />
    </form>
  );

  return (
    <>
      <CalculatorFrame title="Compound interest calculator" inputs={inputs} result={result} />
      {table}
      <LiveAnnouncer message={announcement} />
    </>
  );
}
