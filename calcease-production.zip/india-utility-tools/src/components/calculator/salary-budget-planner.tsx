"use client";

import { useId, type ReactNode } from "react";
import {
  BUDGET_DEFAULTS,
  BUDGET_LIMITS,
  salaryBudget,
  type Allocation,
  type BudgetError,
} from "@/lib/calc/budget/budget";
import { plural } from "@/lib/format/date";
import { formatExact } from "@/lib/format/number";
import type { NumberFieldResult, NumberFieldRule } from "@/lib/validation/number-field";
import { Checkbox } from "@/components/ui/checkbox";
import { NumberInput } from "@/components/ui/number-input";
import { ShareButton } from "@/components/ui/share-button";
import { CalculatorFrame } from "./calculator-frame";
import { Display } from "./display";
import { numberFieldMessage } from "./field-messages";
import { incompleteMessage } from "./incomplete-message";
import { LiveAnnouncer } from "./live-announcer";
import { ResultPanel } from "./result-panel";
import { useCalculatorState, type CalculatorSpec } from "./use-calculator-state";

const INCOME = { min: 0, minExclusive: true, max: BUDGET_LIMITS.maxAmount };
const AMOUNT = { min: 0, max: BUDGET_LIMITS.maxAmount };
const MONTHS = { min: BUDGET_LIMITS.minMonths, max: BUDGET_LIMITS.maxMonths, integer: true };
const SHARE = { min: 0, max: 100 };

const ITEMS = ["housing", "food", "transport", "utilities", "insurance", "other"] as const;
type Item = (typeof ITEMS)[number];
const SETTINGS = ["months", "wantsShare", "emergencyShare", "goal"] as const;
type Field =
  | "income"
  | "essentials"
  | "emi"
  | "wants"
  | "savings"
  | "investments"
  | Item
  | (typeof SETTINGS)[number];

const n = (param: string, rule: NumberFieldRule, initial: string) =>
  ({ kind: "number", param, rule, initial }) as const;

const SPEC: CalculatorSpec<Field | "itemize"> = {
  income: n("income", INCOME, "50000"),
  essentials: n("essentials", AMOUNT, "22000"),
  emi: n("emi", AMOUNT, "5000"),
  wants: n("wants", AMOUNT, "8000"),
  savings: n("saved", AMOUNT, "60000"),
  investments: n("invest", AMOUNT, "5000"),
  itemize: { kind: "choice", param: "itemize", options: ["yes", "no"], initial: "no" },
  housing: n("housing", AMOUNT, ""),
  food: n("food", AMOUNT, ""),
  transport: n("transport", AMOUNT, ""),
  utilities: n("utilities", AMOUNT, ""),
  insurance: n("insurance", AMOUNT, ""),
  other: n("other", AMOUNT, ""),
  months: n("months", MONTHS, String(BUDGET_DEFAULTS.emergencyMonths)),
  wantsShare: n("wantsShare", SHARE, String(BUDGET_DEFAULTS.wantsShare)),
  emergencyShare: n("emergencyShare", SHARE, String(BUDGET_DEFAULTS.emergencyShare)),
  goal: n("goal", AMOUNT, ""),
};

const LABELS: Record<Field, { label: string; helper?: string; suffix?: string; rupee?: boolean }> =
  {
    income: { label: "Monthly take-home salary", rupee: true },
    essentials: {
      label: "Essential expenses (a month)",
      helper: "Rent, food, transport, bills, insurance.",
      rupee: true,
    },
    emi: { label: "EMIs and debt payments (a month)", rupee: true },
    wants: {
      label: "Wants and lifestyle (a month)",
      helper: "Eating out, shopping, trips.",
      rupee: true,
    },
    savings: { label: "Emergency savings you have now", rupee: true },
    investments: { label: "Amount you invest (a month)", rupee: true },
    housing: { label: "Housing / rent", rupee: true },
    food: { label: "Food and groceries", rupee: true },
    transport: { label: "Transport", rupee: true },
    utilities: { label: "Bills and utilities", rupee: true },
    insurance: { label: "Insurance and health", rupee: true },
    other: { label: "Other essentials", rupee: true },
    months: {
      label: "Emergency fund target",
      helper: "Months of essentials + EMIs. 3 to 6 is a common reference.",
      suffix: "months",
    },
    wantsShare: {
      label: "Reference: share of what's left for wants",
      helper: "After essentials and EMIs. The rest is for saving and investing.",
      suffix: "%",
    },
    emergencyShare: {
      label: "Share of savings for the emergency fund",
      helper: "Until the target is reached.",
      suffix: "%",
    },
    goal: { label: "Savings goal (optional)", rupee: true },
  };

const OPTIONAL = new Set<Field>([...ITEMS, "goal", "emi", "wants", "savings", "investments"]);

const zero = (r: NumberFieldResult): NumberFieldResult =>
  !r.ok && r.error.code === "REQUIRED" ? { ok: true, value: 0 } : r;

function errorMessage(error: BudgetError): string {
  return error === "OUT_OF_RANGE"
    ? "Enter amounts up to ₹10,00,00,00,000."
    : "Check the values you entered.";
}

const ROWS: { key: keyof Allocation; label: string }[] = [
  { key: "needs", label: "Needs (essentials)" },
  { key: "debt", label: "Debt / EMIs" },
  { key: "wants", label: "Wants" },
  { key: "savings", label: "Emergency fund / savings" },
  { key: "investments", label: "Investments" },
];

function Bar({ share }: { share: number }) {
  return (
    <span
      aria-hidden="true"
      className="mt-1 block h-1.5 w-full overflow-hidden rounded-full bg-line"
    >
      <span
        className="block h-full rounded-full bg-primary"
        style={{ width: `${Math.min(100, Math.max(0, share))}%` }}
      />
    </span>
  );
}

export function SalaryBudgetPlanner() {
  const baseId = useId();
  const state = useCalculatorState(SPEC);
  const itemize = state.value("itemize") === "yes";
  const fields: readonly Field[] = [
    "income",
    ...(itemize ? ITEMS : (["essentials"] as const)),
    "emi",
    "wants",
    "savings",
    "investments",
    ...SETTINGS,
  ];
  const parsed = fields.map((f) => (OPTIONAL.has(f) ? zero(state.parsed(f)) : state.parsed(f)));
  const visible = fields.map((f) => {
    const e = state.visibleError(f);
    return OPTIONAL.has(f) && e?.code === "REQUIRED" ? undefined : e;
  });

  let result: ReactNode;
  let details: ReactNode = null;
  let announcement: string;

  if (parsed.some((p) => !p.ok)) {
    const incomplete = incompleteMessage(parsed, visible);
    result = <ResultPanel status={incomplete.status} message={incomplete.message} />;
    announcement = incomplete.message;
  } else {
    const v = Object.fromEntries(
      fields.map((f, i) => [f, (parsed[i] as { value: number }).value]),
    ) as Record<Field, number>;
    const essentials = itemize ? ITEMS.reduce((s, k) => s + v[k], 0) : v.essentials;
    const outcome = salaryBudget({
      income: v.income,
      essentials,
      emi: v.emi,
      wants: v.wants,
      emergencySavings: v.savings,
      investments: v.investments,
      emergencyMonths: v.months,
      wantsShare: v.wantsShare,
      emergencyShare: v.emergencyShare,
      goal: v.goal,
    });
    if (!outcome.ok) {
      const message = errorMessage(outcome.error);
      result = <ResultPanel status="error" message={message} />;
      announcement = message;
    } else {
      const d = new Display();
      const r = outcome.value;
      const e = r.emergency;
      const over = r.surplus < 0;
      const sentence = over
        ? `Your expenses are ${d.rupees(-r.surplus)} a month more than your take-home pay of ${d.rupees(r.income)}.`
        : `After expenses, ${d.rupees(r.surplus)} of your ${d.rupees(r.income)} take-home pay is left each month (${d.percent(r.savingsInvestPercent)}).`;
      const coverage =
        e.coverageMonths === null
          ? "No essentials or EMIs entered"
          : `${formatExact(Math.floor(e.coverageMonths * 10) / 10)} months`;
      result = (
        <ResultPanel
          status="result"
          label={over ? "Monthly shortfall" : "Available surplus"}
          value={d.rupees(Math.abs(r.surplus))}
          sentence={sentence}
          rows={[
            { label: "Monthly income", value: d.rupees(r.income) },
            {
              label: `Monthly expenses (${d.percent(r.expensePercent)})`,
              value: d.rupees(r.totalExpenses),
            },
            {
              label: over ? "Shortfall" : "Available surplus",
              value: d.rupees(r.surplus),
              strong: true,
            },
            {
              label: "You invest now",
              value: `${d.rupees(v.investments)} (${d.percent(r.investPercent)})`,
            },
            {
              label: "Suggested savings / investment",
              value: over
                ? "Nothing to allocate"
                : `${d.rupees(r.suggested.toEmergency)} emergency + ${d.rupees(r.suggested.toInvestments)} invest`,
            },
            { label: "Emergency fund target", value: d.rupees(e.target) },
          ]}
          working={`${formatExact(r.income)} − ${formatExact(essentials)} essentials − ${formatExact(v.emi)} EMIs − ${formatExact(v.wants)} wants = ${formatExact(r.surplus)}`}
          note="A planning aid using your numbers, not financial advice. Investment amounts are plans, not guaranteed returns."
          actions={
            <ShareButton
              data={{ title: "Salary Budget Planner", text: sentence, url: state.shareUrl }}
            />
          }
        />
      );

      const t = new Display();
      const pct = (x: number) => (x * 100) / r.income;
      details = (
        <div className="mt-4 grid gap-4 lg:grid-cols-[minmax(0,3fr)_minmax(0,2fr)]">
          <section
            aria-labelledby={`${baseId}-alloc`}
            className="rounded-lg border border-line bg-surface p-4 md:p-6"
          >
            <h2 id={`${baseId}-alloc`} className="text-h3 text-ink">
              Allocation breakdown
            </h2>
            <p className="text-small mt-1 text-muted">
              Your plan next to a <strong>Balanced reference</strong>: it keeps your essentials and
              EMIs as they are, then shares what is left between wants ({formatExact(v.wantsShare)}
              %) and saving, emergency fund first. Adjust it in the settings. It is a reference, not
              a rule.
            </p>
            <table className="mt-3 w-full border-collapse text-left">
              <caption className="sr-only">Monthly allocation: your plan and the reference</caption>
              <thead>
                <tr className="text-small border-b border-line text-muted">
                  <th scope="col" className="py-2 pr-2 font-semibold">
                    Income {t.rupees(r.income)}
                  </th>
                  <th scope="col" className="py-2 pr-2 text-right font-semibold">
                    Your plan
                  </th>
                  <th scope="col" className="py-2 text-right font-semibold">
                    Reference
                  </th>
                </tr>
              </thead>
              <tbody>
                {ROWS.map(({ key, label }) => (
                  <tr key={key} className="border-b border-line align-top">
                    <th scope="row" className="py-2 pr-2 font-normal text-ink">
                      {label}
                    </th>
                    <td className="numeric py-2 pr-2 text-right">
                      {t.rupees(r.plan[key])}
                      <span className="text-small block text-muted">
                        {t.percent(pct(r.plan[key]))}
                      </span>
                      <Bar share={pct(r.plan[key])} />
                    </td>
                    <td className="numeric py-2 text-right">
                      {t.rupees(r.reference[key])}
                      <span className="text-small block text-muted">
                        {t.percent(pct(r.reference[key]))}
                      </span>
                      <Bar share={pct(r.reference[key])} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {r.unallocated < 0 && !over && (
              <p className="text-small mt-3 font-medium text-warning">
                Your investments are {t.rupees(-r.unallocated)} more than the surplus.
              </p>
            )}
          </section>

          <section
            aria-labelledby={`${baseId}-ef`}
            className="rounded-lg border border-line bg-surface p-4 md:p-6"
          >
            <h2 id={`${baseId}-ef`} className="text-h3 text-ink">
              Emergency fund
            </h2>
            <dl className="mt-3 divide-y divide-line">
              {[
                ["Current savings", t.rupees(e.current)],
                [`Target (${plural(v.months, "month")})`, t.rupees(e.target)],
                ["Shortfall", t.rupees(e.shortfall)],
                ["Months covered now", coverage],
                [
                  "Time to reach the target",
                  r.monthsToEmergencyTarget === 0
                    ? "Target reached"
                    : r.monthsToEmergencyTarget === null
                      ? "Not possible at the current surplus"
                      : `About ${plural(r.monthsToEmergencyTarget, "month")}`,
                ],
                ["Extra available to save or invest", t.rupees(r.additionalAvailable)],
                ...(v.goal > 0
                  ? [
                      [
                        `Goal of ${t.rupees(v.goal)}`,
                        r.monthsToGoal === null
                          ? "Not reachable from the surplus"
                          : `About ${plural(r.monthsToGoal, "month")} at the full surplus`,
                      ],
                    ]
                  : []),
              ].map(([k, val]) => (
                <div key={k} className="flex justify-between gap-3 py-2">
                  <dt className="text-muted">{k}</dt>
                  <dd className="numeric text-right font-semibold text-ink">{val}</dd>
                </div>
              ))}
            </dl>
            <p className="text-small mt-3 text-muted">
              The target is based on essentials plus EMIs, because loan payments continue in an
              emergency. Months to target and goal assume no interest or returns.
            </p>
          </section>
        </div>
      );
      announcement = sentence;
    }
  }

  const field = (name: Field) => {
    const i = fields.indexOf(name);
    const error = i >= 0 ? visible[i] : undefined;
    const f = LABELS[name];
    const rule = (SPEC[name] as { rule: NumberFieldRule }).rule;
    return (
      <NumberInput
        key={name}
        id={`${baseId}-${name}`}
        label={f.label}
        helperText={f.helper}
        value={state.value(name)}
        example={name === "income" ? "50000" : "0"}
        prefix={f.rupee ? "₹" : undefined}
        suffix={f.suffix}
        error={
          error
            ? numberFieldMessage(error, rule, {
                noun: f.rupee ? "an amount" : "a value",
                prefix: f.rupee ? "₹" : undefined,
                suffix: f.suffix === "%" ? "%" : f.suffix ? ` ${f.suffix}` : undefined,
              })
            : undefined
        }
        onChange={(text) => state.set(name, text)}
        onBlur={() => state.touch(name)}
      />
    );
  };

  const inputs = (
    <form className="space-y-4 md:space-y-5" onSubmit={(e) => e.preventDefault()} noValidate>
      {field("income")}
      <Checkbox
        id={`${baseId}-itemize`}
        label="Break down my essential expenses"
        checked={itemize}
        onChange={(checked) => state.set("itemize", checked ? "yes" : "no")}
      />
      {itemize ? (
        <fieldset>
          <legend className="text-label text-ink">Essential expenses (a month)</legend>
          <div className="mt-2 grid grid-cols-1 gap-4 md:grid-cols-2">{ITEMS.map(field)}</div>
        </fieldset>
      ) : (
        field("essentials")
      )}
      <div className="grid gap-4 md:grid-cols-2 md:gap-5 lg:grid-cols-1">
        {field("emi")}
        {field("wants")}
        {field("savings")}
        {field("investments")}
      </div>
      <details className="group rounded-md border border-line">
        <summary className="flex min-h-11 cursor-pointer items-center px-3 font-semibold text-ink">
          Reference settings and goal
        </summary>
        <div className="space-y-4 border-t border-line p-3">{SETTINGS.map(field)}</div>
      </details>
    </form>
  );

  return (
    <>
      <CalculatorFrame title="Salary budget planner" inputs={inputs} result={result} />
      {details}
      <LiveAnnouncer message={announcement} />
    </>
  );
}
