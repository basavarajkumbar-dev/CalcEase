"use client";

import { useId, useMemo, type ReactNode } from "react";
import { dateDifference } from "@/lib/calc/date/difference";
import { formatDateWithWeekday, formatYmd, plural } from "@/lib/format/date";
import { Checkbox } from "@/components/ui/checkbox";
import { DateInput } from "@/components/ui/date-input";
import { ShareButton } from "@/components/ui/share-button";
import { CalculatorFrame } from "./calculator-frame";
import { DATE_MAX, DATE_MIN, ISO_DATE, readDate } from "./date-fields";
import { dateFieldMessage } from "./field-messages";
import { incompleteMessage } from "./incomplete-message";
import { LiveAnnouncer } from "./live-announcer";
import { ResultPanel } from "./result-panel";
import { useCalculatorState, type CalculatorSpec } from "./use-calculator-state";
import { useToday } from "./use-today";

const SPEC: CalculatorSpec<"from" | "to" | "inclusive"> = {
  // Both filled from today's date once the page knows it (see useToday).
  from: { kind: "text", param: "from", pattern: ISO_DATE, initial: "" },
  to: { kind: "text", param: "to", pattern: ISO_DATE, initial: "" },
  inclusive: { kind: "choice", param: "inclusive", options: ["no", "yes"], initial: "no" },
};

export function DateDifferenceCalculator() {
  const baseId = useId();
  const today = useToday();
  const defaults = useMemo(
    () => (today ? { from: today, to: `${today.slice(0, 4)}-12-31` } : {}),
    [today],
  );
  const state = useCalculatorState(SPEC, { defaults });
  const from = readDate(state.value("from"), state.touched("from"));
  const to = readDate(state.value("to"), state.touched("to"));
  const includeEnd = state.value("inclusive") === "yes";

  let result: ReactNode;
  let announcement: string;

  if (!from.result.ok || !to.result.ok) {
    const waitingForToday = !today && state.value("from") === "" && state.value("to") === "";
    const incomplete = incompleteMessage([from.result, to.result], [from.visible, to.visible]);
    const message = waitingForToday ? "Reading today's date…" : incomplete.message;
    result = (
      <ResultPanel status={incomplete.status} message={message} reserveSpace={waitingForToday} />
    );
    announcement = message;
  } else {
    const diff = dateDifference(from.result.value, to.result.value, includeEnd);
    const [first, last] = diff.reversed
      ? [to.result.value, from.result.value]
      : [from.result.value, to.result.value];
    const total = plural(diff.totalDays, "day");
    const sentence = `From ${formatDateWithWeekday(first)} to ${formatDateWithWeekday(last)} is ${formatYmd(diff)} (${total})${includeEnd ? ", counting both dates" : ""}.`;
    const rows = [
      { label: "Years, months and days", value: formatYmd(diff) },
      { label: "Total days", value: total, strong: true },
      {
        label: "Weeks",
        value: `${plural(diff.weeks, "week")}${diff.weekRemainderDays ? ` and ${plural(diff.weekRemainderDays, "day")}` : ""}`,
      },
      { label: "Whole months", value: plural(diff.totalMonths, "month") },
      { label: "Weekdays (Mon–Fri)", value: plural(diff.weekdays, "day") },
    ];
    const notes = [
      diff.reversed ? "The end date is before the start date, so the dates were swapped." : "",
      "Weekdays do not remove public holidays.",
    ].filter(Boolean);
    result = (
      <ResultPanel
        status="result"
        label="Time between the dates"
        value={total}
        sentence={sentence}
        rows={rows}
        note={notes.join(" ")}
        actions={
          <ShareButton
            data={{ title: "Date Difference Calculator", text: sentence, url: state.shareUrl }}
          />
        }
      />
    );
    announcement = sentence;
  }

  const inputs = (
    <form
      className="space-y-4 md:space-y-5"
      onSubmit={(event) => event.preventDefault()}
      noValidate
    >
      <div className="grid gap-4 md:grid-cols-2 md:gap-5 lg:grid-cols-1">
        <DateInput
          id={`${baseId}-from`}
          label="Start date"
          value={state.value("from")}
          min={DATE_MIN}
          max={DATE_MAX}
          error={from.visible ? dateFieldMessage(from.visible, "a start date") : undefined}
          onChange={(text) => state.set("from", text)}
          onBlur={() => state.touch("from")}
        />
        <DateInput
          id={`${baseId}-to`}
          label="End date"
          value={state.value("to")}
          min={DATE_MIN}
          max={DATE_MAX}
          error={to.visible ? dateFieldMessage(to.visible, "an end date") : undefined}
          onChange={(text) => state.set("to", text)}
          onBlur={() => state.touch("to")}
        />
      </div>
      <Checkbox
        id={`${baseId}-inclusive`}
        label="Include the end date"
        helperText="Counts both dates: 1 to 2 January becomes 2 days."
        checked={includeEnd}
        onChange={(checked) => state.set("inclusive", checked ? "yes" : "no")}
      />
    </form>
  );

  return (
    <>
      <CalculatorFrame title="Date difference calculator" inputs={inputs} result={result} />
      <LiveAnnouncer message={announcement} />
    </>
  );
}
