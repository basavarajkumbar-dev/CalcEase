"use client";

import { useEffect, useState } from "react";

/**
 * Announces a message to screen readers after the user pauses typing, rather than
 * on every keystroke (Phase 1, accessibility). Visually hidden.
 */
export function LiveAnnouncer({ message, delayMs = 750 }: { message: string; delayMs?: number }) {
  const [announced, setAnnounced] = useState("");

  useEffect(() => {
    const timer = setTimeout(() => setAnnounced(message), delayMs);
    return () => clearTimeout(timer);
  }, [message, delayMs]);

  return (
    <div className="sr-only" aria-live="polite" aria-atomic="true">
      {announced}
    </div>
  );
}
