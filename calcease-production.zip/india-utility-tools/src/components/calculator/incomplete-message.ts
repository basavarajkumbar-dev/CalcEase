/** Any field validation result (number or date fields). */
type FieldResult = { ok: true } | { ok: false; error: { code: string } };

/**
 * What the result panel says while inputs are incomplete or invalid. Shared so every
 * calculator words these states the same way (design system §9).
 */
export function incompleteMessage(
  results: readonly FieldResult[],
  visibleErrors: readonly ({ code: string } | undefined)[],
): { status: "empty" | "invalid"; message: string } {
  if (visibleErrors.some(Boolean)) {
    return { status: "invalid", message: "Fix the highlighted value to see your result." };
  }
  const missing = results.some((r) => !r.ok && r.error.code === "REQUIRED");
  if (missing) {
    return {
      status: "empty",
      message:
        results.length === 1
          ? "Enter a value to see your result."
          : results.length === 2
            ? "Enter both values to see your result."
            : "Enter all values to see your result.",
    };
  }
  return { status: "empty", message: "Finish typing to see your result." };
}
