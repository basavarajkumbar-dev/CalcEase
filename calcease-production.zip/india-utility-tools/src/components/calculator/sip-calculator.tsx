"use client";

import { useId, type ReactNode } from "react";
import {
  SIP_LIMITS,
  sipValue,
  type MonthlyRateMethod,
  type SipError,
  type SipYear,
} from "@/lib/calc/invest/sip";
import { plural } from "@/lib/format/date";
import type { NumberFieldRule } from "@/lib/validation/number-field";
import { DataTable } from "@/components/ui/data-table";
import { NumberInput } from "@/components/ui/number-input";
import { SelectInput } from "@/components/ui/select-input";
import { ShareButton } from "@/components/ui/share-button";
import { CalculatorFrame } from "./calculator-frame";
import { DisclosureTable } from "./disclosure-table";
import { Display } from "./display";
import { numberFieldMessage } from "./field-messages";
import { incompleteMessage } from "./incomplete-message";
import { LiveAnnouncer } from "./live-announcer";
import { ProportionBar } from "./proportion-bar";
import { ResultPanel } from "./result-panel";
import { useCalculatorState, type CalculatorSpec } from "./use-calculator-state";

const METHODS = [
  { value: "divide12", label: "Yearly return ÷ 12" },
  { value: "equivalent", label: "Monthly equivalent (compounded)" },
] as const;

const AMOUNT = { min: 0, minExclusive: true, max: 1e12 };
const RETURN = { min: 0, max: SIP_LIMITS.returnMax };
const YEARS = { min: 1, max: SIP_LIMITS.yearsMax, integer: true };
const STEP = { min: 0, max: SIP_LIMITS.stepUpMax };

type Field = "amount" | "rate" | "years" | "step";
const NAMES: readonly Field[] = ["amount", "rate", "years", "step"];

const SPEC: CalculatorSpec<Field | "method"> = {
  amount: { kind: "number", param: "monthly", rule: AMOUNT, initial: "10000" },
  rate: { kind: "number", param: "return", rule: RETURN, initial: "12" },
  years: { kind: "number", param: "years", rule: YEARS, initial: "10" },
  step: { kind: "number", param: "stepup", rule: STEP, initial: "" },
  method: {
    kind: "choice",
    param: "method",
    options: METHODS.map((m) => m.value),
    initial: "divide12",
  },
};

const FIELDS: Record<
  Field,
  {
    label: string;
    noun: string;
    prefix?: string;
    suffix?: string;
    rule: NumberFieldRule;
    helper?: string;
  }
> = {
  amount: { label: "Monthly investment", noun: "an amount", prefix: "₹", rule: AMOUNT },
  rate: { label: "Expected return (a year)", noun: "a return", suffix: "%", rule: RETURN },
  years: { label: "Years", noun: "a whole number of years", rule: YEARS },
  step: {
    label: "Yearly step-up (optional)",
    noun: "a step-up",
    suffix: "%",
    rule: STEP,
    helper: "Raise the monthly amount by this much every year.",
  },
};

function errorMessage(error: SipError): string {
  return error === "RESULT_TOO_LARGE"
    ? "The result is too large to show. Check the values."
    : "Check the values you entered.";
}

export function SipCalculator() {
  const baseId = useId();
  const state = useCalculatorState(SPEC);
  const method = state.value("method") as MonthlyRateMethod;
  const parsed = NAMES.map((n) => {
    const r = state.parsed(n);
    return n === "step" && !r.ok && r.error.code === "REQUIRED"
      ? ({ ok: true, value: 0 } as const)
      : r;
  });
  const visible = NAMES.map((n) => {
    const e = state.visibleError(n);
    return n === "step" && e?.code === "REQUIRED" ? undefined : e;
  });

  let result: ReactNode;
  let table: ReactNode = null;
  let announcement: string;

  if (parsed.some((p) => !p.ok)) {
    const incomplete = incompleteMessage(parsed, visible);
    result = <ResultPanel status={incomplete.status} message={incomplete.message} />;
    announcement = incomplete.message;
  } else {
    const [amount, rate, years, step] = parsed.map((p) => (p as { value: number }).value) as [
      number,
      number,
      number,
      number,
    ];
    const outcome = sipValue(amount, rate, years, step, method);
    if (!outcome.ok) {
      const message = errorMessage(outcome.error);
      result = <ResultPanel status="error" message={message} />;
      announcement = message;
    } else {
      const d = new Display();
      const v = outcome.value;
      const sentence = `${d.rupees(amount)} a month${step ? `, raised ${d.percent(step)} every year,` : ""} for ${plural(years, "year")} at ${d.percent(rate)} a year could grow to about ${d.rupees(v.value)}: ${d.rupees(v.invested)} invested and ${d.rupees(v.gains)} of estimated gains.`;
      const chart = new Display();
      const note = [
        `Monthly rate used: ${d.percent(v.monthlyRate)} (${method === "divide12" ? "yearly return ÷ 12" : "the monthly rate that compounds to the yearly return"}). Investments at the start of each month.`,
        d.roundingNote(),
      ]
        .filter(Boolean)
        .join(" ");
      result = (
        <ResultPanel
          status="result"
          label="Estimated value"
          value={d.rupees(v.value)}
          sentence={sentence}
          rows={[
            { label: "Amount invested", value: d.rupees(v.invested) },
            { label: "Estimated gains", value: d.rupees(v.gains) },
            { label: "Estimated value", value: d.rupees(v.value), strong: true },
          ]}
          chart={
            <ProportionBar
              caption="What makes up the value"
              parts={[
                {
                  label: "Invested",
                  value: v.invested,
                  display: chart.rupees(v.invested),
                  tone: "primary",
                },
                {
                  label: "Gains",
                  value: Math.max(0, v.gains),
                  display: chart.rupees(v.gains),
                  tone: "accent",
                },
              ]}
            />
          }
          note={note}
          actions={
            <ShareButton data={{ title: "SIP Calculator", text: sentence, url: state.shareUrl }} />
          }
        />
      );
      const t = new Display();
      table = (
        <DisclosureTable summary="Year-by-year growth">
          <DataTable
            caption="Monthly amount, total invested and estimated value at the end of each year"
            {...(step ? { minWidth: "28rem" } : {})}
            columns={[
              { key: "year", header: "Year", cell: (row: SipYear) => row.year },
              {
                key: "instalment",
                header: "Monthly",
                numeric: true,
                hideOnMobile: !step,
                cell: (row: SipYear) => t.rupees(row.instalment),
              },
              {
                key: "invested",
                header: "Invested",
                numeric: true,
                cell: (row: SipYear) => t.rupees(row.invested),
              },
              {
                key: "value",
                header: "Value",
                numeric: true,
                cell: (row: SipYear) => t.rupees(row.value),
              },
            ]}
            rows={v.years}
            rowKey={(row) => String(row.year)}
          />
        </DisclosureTable>
      );
      announcement = sentence;
    }
  }

  const inputs = (
    <form className="space-y-4 md:space-y-5" onSubmit={(e) => e.preventDefault()} noValidate>
      <div className="grid gap-4 md:grid-cols-2 md:gap-5 lg:grid-cols-1">
        {NAMES.map((name, i) => {
          const f = FIELDS[name];
          const error = visible[i];
          return (
            <NumberInput
              key={name}
              id={`${baseId}-${name}`}
              label={f.label}
              value={state.value(name)}
              example={name === "step" ? "10" : String(SPEC[name].initial)}
              prefix={f.prefix}
              suffix={f.suffix}
              helperText={f.helper}
              error={error ? numberFieldMessage(error, f.rule, f) : undefined}
              onChange={(text) => state.set(name, text)}
              onBlur={() => state.touch(name)}
            />
          );
        })}
      </div>
      <SelectInput
        id={`${baseId}-method`}
        label="Monthly rate"
        helperText="Fund houses differ. ÷ 12 gives a slightly higher estimate."
        value={method}
        options={METHODS}
        onChange={(next) => state.set("method", next)}
      />
    </form>
  );

  return (
    <>
      <CalculatorFrame title="SIP calculator" inputs={inputs} result={result} />
      {table}
      <LiveAnnouncer message={announcement} />
    </>
  );
}
