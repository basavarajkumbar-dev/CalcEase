"use client";

import { useId, useMemo, type ReactNode } from "react";
import { ageOn } from "@/lib/calc/date/age";
import { formatDateWithWeekday, formatYmd, plural, weekdayName } from "@/lib/format/date";
import { DateInput } from "@/components/ui/date-input";
import { ShareButton } from "@/components/ui/share-button";
import { CalculatorFrame } from "./calculator-frame";
import { DATE_MAX, DATE_MIN, ISO_DATE, readDate } from "./date-fields";
import { dateFieldMessage } from "./field-messages";
import { incompleteMessage } from "./incomplete-message";
import { LiveAnnouncer } from "./live-announcer";
import { ResultPanel } from "./result-panel";
import { useCalculatorState, type CalculatorSpec } from "./use-calculator-state";
import { useToday } from "./use-today";

const SPEC: CalculatorSpec<"dob" | "on"> = {
  dob: { kind: "text", param: "dob", pattern: ISO_DATE, initial: "2000-01-01" },
  // Filled with today's date once the page knows it (see useToday).
  on: { kind: "text", param: "on", pattern: ISO_DATE, initial: "" },
};

export function AgeCalculator() {
  const baseId = useId();
  const today = useToday();
  const defaults = useMemo(() => (today ? { on: today } : {}), [today]);
  const state = useCalculatorState(SPEC, { defaults });
  const dob = readDate(state.value("dob"), state.touched("dob"));
  const on = readDate(state.value("on"), state.touched("on"));
  const isToday = state.value("on") === today;

  let result: ReactNode;
  let announcement: string;

  if (!dob.result.ok || !on.result.ok) {
    const waitingForToday = !today && state.value("on") === "";
    const incomplete = incompleteMessage([dob.result, on.result], [dob.visible, on.visible]);
    const message = waitingForToday ? "Reading today's date…" : incomplete.message;
    result = (
      <ResultPanel status={incomplete.status} message={message} reserveSpace={waitingForToday} />
    );
    announcement = message;
  } else {
    const birth = dob.result.value;
    const date = on.result.value;
    const outcome = ageOn(birth, date);
    if (!outcome.ok) {
      const message = "The date of birth is after the date you are calculating the age on.";
      result = <ResultPanel status="error" message={message} />;
      announcement = message;
    } else {
      const a = outcome.value;
      const exact = formatYmd(a);
      const onDate = formatDateWithWeekday(date);
      const sentence =
        a.totalDays === 0
          ? `Born ${isToday ? "today" : `on ${onDate}`}: 0 days old.`
          : isToday
            ? `You are ${exact} old today.`
            : `On ${onDate}, the age is ${exact}.`;
      const birthday =
        a.daysToNextBirthday === 0
          ? a.nextAge === 0
            ? "Today (date of birth)"
            : `Today: ${plural(a.nextAge, "year")} old. Happy birthday!`
          : `${formatDateWithWeekday(a.nextBirthday)}, in ${plural(a.daysToNextBirthday, "day")} (turning ${a.nextAge})`;
      const rows = [
        { label: "Age", value: exact, strong: true },
        { label: "In months", value: plural(a.totalMonths, "month") },
        {
          label: "In weeks",
          value: `${plural(a.totalWeeks, "week")}${a.weekRemainderDays ? ` and ${plural(a.weekRemainderDays, "day")}` : ""}`,
        },
        { label: "In days", value: plural(a.totalDays, "day") },
        { label: "Next birthday", value: birthday },
        { label: "Born on a", value: weekdayName(a.bornWeekday) },
      ];
      const note = a.leapDayBirthday
        ? "Born on 29 February: in years without a 29 February, the birthday is counted on 28 February."
        : undefined;
      result = (
        <ResultPanel
          status="result"
          label={isToday ? "Your age today" : "Age"}
          value={a.years === 0 && a.months === 0 ? plural(a.days, "day") : plural(a.years, "year")}
          sentence={sentence}
          rows={rows}
          {...(note ? { note } : {})}
          actions={
            <ShareButton data={{ title: "Age Calculator", text: sentence, url: state.shareUrl }} />
          }
        />
      );
      announcement = sentence;
    }
  }

  const inputs = (
    <form
      className="space-y-4 md:space-y-5"
      onSubmit={(event) => event.preventDefault()}
      noValidate
    >
      <div className="grid gap-4 md:grid-cols-2 md:gap-5 lg:grid-cols-1">
        <DateInput
          id={`${baseId}-dob`}
          label="Date of birth"
          value={state.value("dob")}
          min={DATE_MIN}
          max={DATE_MAX}
          error={dob.visible ? dateFieldMessage(dob.visible, "a date of birth") : undefined}
          onChange={(text) => state.set("dob", text)}
          onBlur={() => state.touch("dob")}
        />
        <DateInput
          id={`${baseId}-on`}
          label="Age on"
          helperText="Today's date, or change it to find an age on another day."
          value={state.value("on")}
          min={DATE_MIN}
          max={DATE_MAX}
          error={on.visible ? dateFieldMessage(on.visible, "a date") : undefined}
          onChange={(text) => state.set("on", text)}
          onBlur={() => state.touch("on")}
        />
      </div>
    </form>
  );

  return (
    <>
      <CalculatorFrame title="Age calculator" inputs={inputs} result={result} />
      <LiveAnnouncer message={announcement} />
    </>
  );
}
