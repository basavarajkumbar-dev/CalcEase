"use client";

import { useId, type ReactNode } from "react";
import { EMI_LIMITS, loanEmi, type EmiError, type ScheduleRow } from "@/lib/calc/loan/emi";
import { formatDuration, plural } from "@/lib/format/date";
import { formatExact } from "@/lib/format/number";
import type { NumberFieldRule } from "@/lib/validation/number-field";
import { Checkbox } from "@/components/ui/checkbox";
import { DataTable } from "@/components/ui/data-table";
import { NumberInput } from "@/components/ui/number-input";
import { ShareButton } from "@/components/ui/share-button";
import { CalculatorFrame } from "./calculator-frame";
import { DisclosureTable } from "./disclosure-table";
import { Display } from "./display";
import { numberFieldMessage } from "./field-messages";
import { incompleteMessage } from "./incomplete-message";
import { LiveAnnouncer } from "./live-announcer";
import { ProportionBar } from "./proportion-bar";
import { ResultPanel } from "./result-panel";
import { useCalculatorState, type CalculatorSpec } from "./use-calculator-state";

const AMOUNT = { min: 0, minExclusive: true, max: 1e12 };
const RATE = { min: 0, max: EMI_LIMITS.rateMax };
const YEARS = { min: 0, max: 40, integer: true };
const MONTHS = { min: 0, max: 11, integer: true };
const PREPAY = { min: 0, minExclusive: true, max: 1e12 };
const AFTER = { min: 1, max: EMI_LIMITS.monthsMax - 1, integer: true };

type Field = "amount" | "rate" | "years" | "months" | "prepay" | "after";

const SPEC: CalculatorSpec<Field | "prepayOn"> = {
  amount: { kind: "number", param: "amount", rule: AMOUNT, initial: "2500000" },
  rate: { kind: "number", param: "rate", rule: RATE, initial: "8.5" },
  years: { kind: "number", param: "years", rule: YEARS, initial: "20" },
  months: { kind: "number", param: "months", rule: MONTHS, initial: "" },
  prepayOn: { kind: "choice", param: "prepay", options: ["no", "yes"], initial: "no" },
  prepay: { kind: "number", param: "prepayAmount", rule: PREPAY, initial: "200000" },
  after: { kind: "number", param: "after", rule: AFTER, initial: "12" },
};

const FIELDS: Record<
  Field,
  { label: string; noun: string; prefix?: string; suffix?: string; rule: NumberFieldRule }
> = {
  amount: { label: "Loan amount", noun: "an amount", prefix: "₹", rule: AMOUNT },
  rate: { label: "Interest rate (a year)", noun: "a rate", suffix: "%", rule: RATE },
  years: { label: "Years", noun: "a whole number of years", rule: YEARS },
  months: { label: "Months", noun: "a whole number of months", rule: MONTHS },
  prepay: { label: "Prepayment amount", noun: "an amount", prefix: "₹", rule: PREPAY },
  after: { label: "Made after EMI number", noun: "an EMI number", rule: AFTER },
};

function errorMessage(error: EmiError, months: number): string {
  switch (error) {
    case "TENURE_OUT_OF_RANGE":
      return "Enter a tenure from 1 month to 40 years.";
    case "PREPAYMENT_MONTH_OUT_OF_RANGE":
      return `The prepayment must come after one of EMIs 1 to ${months - 1}.`;
    case "PREPAYMENT_TOO_LARGE":
      return "The prepayment is as much as or more than the loan left at that point, so it would close the loan. Enter a smaller amount.";
    default:
      return "Check the values you entered.";
  }
}

interface YearSummary {
  year: number;
  interest: number;
  principal: number;
  balance: number;
}

function byYear(rows: readonly ScheduleRow[]): YearSummary[] {
  const out: YearSummary[] = [];
  for (const row of rows) {
    const year = Math.ceil(row.month / 12);
    const last = out[out.length - 1];
    if (!last || last.year !== year) out.push({ year, interest: 0, principal: 0, balance: 0 });
    const current = out[out.length - 1]!;
    current.interest += row.interest;
    current.principal += row.principal + row.prepayment;
    current.balance = row.balance;
  }
  return out;
}

export function EmiCalculator() {
  const baseId = useId();
  const state = useCalculatorState(SPEC);
  const prepayOn = state.value("prepayOn") === "yes";
  const names: readonly Field[] = prepayOn
    ? ["amount", "rate", "years", "months", "prepay", "after"]
    : ["amount", "rate", "years", "months"];
  const parsed = names.map((n) => {
    const r = state.parsed(n);
    return (n === "years" || n === "months") && !r.ok && r.error.code === "REQUIRED"
      ? ({ ok: true, value: 0 } as const)
      : r;
  });
  const visible = names.map((n) => {
    const e = state.visibleError(n);
    return (n === "years" || n === "months") && e?.code === "REQUIRED" ? undefined : e;
  });

  let result: ReactNode;
  let tables: ReactNode = null;
  let announcement: string;

  if (parsed.some((p) => !p.ok)) {
    const incomplete = incompleteMessage(parsed, visible);
    result = <ResultPanel status={incomplete.status} message={incomplete.message} />;
    announcement = incomplete.message;
  } else {
    const v = Object.fromEntries(
      names.map((n, i) => [n, (parsed[i] as { value: number }).value]),
    ) as Record<Field, number>;
    const months = v.years * 12 + v.months;
    const prepayment = prepayOn ? { afterMonth: v.after, amount: v.prepay } : undefined;
    const outcome = loanEmi(v.amount, v.rate, months, prepayment);
    const base = prepayOn ? loanEmi(v.amount, v.rate, months) : outcome;
    if (!outcome.ok || !base.ok) {
      const message = errorMessage(outcome.ok ? "NOT_A_NUMBER" : outcome.error, months);
      result = <ResultPanel status="error" message={message} />;
      announcement = message;
    } else {
      const d = new Display();
      const r = outcome.value;
      const tenure = formatDuration({ years: v.years, months: v.months });
      let sentence = `A loan of ${d.rupees(v.amount)} at ${d.percent(v.rate)} for ${tenure} has an EMI of ${d.rupees(r.emi)}, with ${d.rupees(r.totalInterest)} of interest in all.`;
      const rows = [
        { label: "Monthly EMI", value: d.rupees(r.emi), strong: true },
        { label: "Total interest", value: d.rupees(r.totalInterest) },
        { label: "Total paid", value: d.rupees(r.totalPaid) },
      ];
      if (prepayOn) {
        const savedInterest = base.value.totalInterest - r.totalInterest;
        const savedMonths = months - r.months;
        sentence = `Prepaying ${d.rupees(v.prepay)} after EMI ${v.after} cuts the loan to ${plural(r.months, "EMI")} (${plural(savedMonths, "month")} sooner) and saves ${d.rupees(savedInterest)} of interest. The EMI stays ${d.rupees(r.emi)}.`;
        rows.push(
          {
            label: "EMIs after prepaying",
            value: `${formatExact(r.months)} instead of ${formatExact(months)}`,
          },
          { label: "Interest saved", value: d.rupees(savedInterest) },
        );
      }
      const note = [
        d.roundingNote(),
        "Banks usually round the EMI to the rupee and adjust the last one.",
      ]
        .filter(Boolean)
        .join(" ");
      const chartDisplay = new Display();
      result = (
        <ResultPanel
          status="result"
          label="Monthly EMI"
          value={d.rupees(r.emi)}
          sentence={sentence}
          rows={rows}
          chart={
            <ProportionBar
              caption="What you repay"
              parts={[
                {
                  label: "Principal",
                  value: v.amount,
                  display: chartDisplay.rupees(v.amount),
                  tone: "primary",
                },
                {
                  label: "Interest",
                  value: r.totalInterest,
                  display: chartDisplay.rupees(r.totalInterest),
                  tone: "accent",
                },
              ]}
            />
          }
          working={`EMI = ${formatExact(v.amount)} × r × (1 + r)^${months} ÷ ((1 + r)^${months} − 1), r = ${formatExact(v.rate)} ÷ 1,200`}
          note={note}
          actions={
            <ShareButton data={{ title: "EMI Calculator", text: sentence, url: state.shareUrl }} />
          }
        />
      );
      const t = new Display();
      tables = (
        <>
          <DisclosureTable summary="Year-by-year repayment">
            <DataTable
              caption="Interest and principal paid each year, and the balance at its end"
              minWidth="30rem"
              columns={[
                { key: "year", header: "Year", cell: (row: YearSummary) => row.year },
                {
                  key: "principal",
                  header: "Principal",
                  numeric: true,
                  cell: (row: YearSummary) => t.rupees(row.principal),
                },
                {
                  key: "interest",
                  header: "Interest",
                  numeric: true,
                  cell: (row: YearSummary) => t.rupees(row.interest),
                },
                {
                  key: "balance",
                  header: "Balance",
                  numeric: true,
                  cell: (row: YearSummary) => t.rupees(row.balance),
                },
              ]}
              rows={byYear(r.schedule)}
              rowKey={(row) => String(row.year)}
            />
          </DisclosureTable>
          <DisclosureTable summary="Month-by-month schedule">
            <DataTable
              caption="Repayment schedule by month"
              minWidth="36rem"
              columns={[
                { key: "month", header: "EMI", cell: (row: ScheduleRow) => row.month },
                {
                  key: "payment",
                  header: "Payment",
                  numeric: true,
                  cell: (row: ScheduleRow) => t.rupees(row.payment + row.prepayment),
                },
                {
                  key: "interest",
                  header: "Interest",
                  numeric: true,
                  cell: (row: ScheduleRow) => t.rupees(row.interest),
                },
                {
                  key: "principal",
                  header: "Principal",
                  numeric: true,
                  cell: (row: ScheduleRow) => t.rupees(row.principal + row.prepayment),
                },
                {
                  key: "balance",
                  header: "Balance",
                  numeric: true,
                  cell: (row: ScheduleRow) => t.rupees(row.balance),
                },
              ]}
              rows={r.schedule}
              rowKey={(row) => String(row.month)}
            />
          </DisclosureTable>
        </>
      );
      announcement = sentence;
    }
  }

  const field = (name: Field, example: string) => {
    const f = FIELDS[name];
    const i = names.indexOf(name);
    const error = i >= 0 ? visible[i] : undefined;
    return (
      <NumberInput
        key={name}
        id={`${baseId}-${name}`}
        label={f.label}
        value={state.value(name)}
        example={example}
        prefix={f.prefix}
        suffix={f.suffix}
        error={error ? numberFieldMessage(error, f.rule, f) : undefined}
        onChange={(text) => state.set(name, text)}
        onBlur={() => state.touch(name)}
      />
    );
  };

  const inputs = (
    <form className="space-y-4 md:space-y-5" onSubmit={(e) => e.preventDefault()} noValidate>
      <div className="grid gap-4 md:grid-cols-2 md:gap-5 lg:grid-cols-1">
        {field("amount", "2500000")}
        {field("rate", "8.5")}
      </div>
      <fieldset>
        <legend className="text-label text-ink">Tenure</legend>
        <div className="mt-2 grid grid-cols-2 gap-4 md:gap-5">
          {field("years", "0")}
          {field("months", "0")}
        </div>
      </fieldset>
      <Checkbox
        id={`${baseId}-prepayOn`}
        label="Add a one-time part-prepayment"
        checked={prepayOn}
        onChange={(checked) => state.set("prepayOn", checked ? "yes" : "no")}
      />
      {prepayOn && (
        <div className="grid gap-4 md:grid-cols-2 md:gap-5 lg:grid-cols-1">
          {field("prepay", "200000")}
          {field("after", "12")}
        </div>
      )}
    </form>
  );

  return (
    <>
      <CalculatorFrame title="EMI calculator" inputs={inputs} result={result} />
      {tables}
      <LiveAnnouncer message={announcement} />
    </>
  );
}
