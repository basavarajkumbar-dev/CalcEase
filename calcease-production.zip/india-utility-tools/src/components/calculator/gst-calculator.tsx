"use client";

import { useId, type ReactNode } from "react";
import { GST_RATE_RANGE, gstExclusive, gstInclusive, type GstError } from "@/lib/calc/gst";
import { formatExact } from "@/lib/format/number";
import { CURRENT_GST_RULES } from "@/lib/rules/gst/rates";
import { NumberInput } from "@/components/ui/number-input";
import { SelectInput } from "@/components/ui/select-input";
import { ShareButton } from "@/components/ui/share-button";
import { CalculatorFrame } from "./calculator-frame";
import { Display } from "./display";
import { numberFieldMessage } from "./field-messages";
import { incompleteMessage } from "./incomplete-message";
import { LiveAnnouncer } from "./live-announcer";
import { ResultPanel } from "./result-panel";
import { useCalculatorState, type CalculatorSpec } from "./use-calculator-state";

const MODES = [
  { value: "exclusive", label: "Add GST to a price" },
  { value: "inclusive", label: "Remove GST from a price" },
] as const;
type Mode = (typeof MODES)[number]["value"];

const SUPPLY = [
  { value: "intra", label: "Same state (CGST + SGST)" },
  { value: "inter", label: "Different states (IGST)" },
] as const;

const OTHER = "other";
const RATE_OPTIONS = [
  ...CURRENT_GST_RULES.presets.map((p) => ({ value: String(p.rate), label: `${p.rate}%` })),
  { value: OTHER, label: "Other rate" },
];

const AMOUNT = { min: 0, minExclusive: true, max: 1e12 };
const RATE = { min: GST_RATE_RANGE.min, max: GST_RATE_RANGE.max };
const AMOUNT_FIELD = { noun: "an amount", prefix: "₹" };
const RATE_FIELD = { noun: "a rate", suffix: "%" };

const SPEC: CalculatorSpec<"mode" | "amount" | "rate" | "other" | "supply"> = {
  mode: { kind: "choice", param: "mode", options: MODES.map((m) => m.value), initial: "exclusive" },
  amount: { kind: "number", param: "amount", rule: AMOUNT, initial: "1000" },
  rate: { kind: "choice", param: "rate", options: RATE_OPTIONS.map((o) => o.value), initial: "18" },
  other: { kind: "number", param: "other", rule: RATE, initial: "3" },
  supply: {
    kind: "choice",
    param: "supply",
    options: SUPPLY.map((s) => s.value),
    initial: "intra",
  },
};

const EFFECTIVE = new Intl.DateTimeFormat("en-IN", { dateStyle: "long", timeZone: "UTC" }).format(
  new Date(CURRENT_GST_RULES.effectiveFrom),
);

function errorMessage(error: GstError): string {
  return error === "RESULT_TOO_LARGE"
    ? "The result is too large to show. Check the values you entered."
    : "Check the values you entered.";
}

export function GstCalculator() {
  const baseId = useId();
  const state = useCalculatorState(SPEC);
  const mode = state.value("mode") as Mode;
  const isOther = state.value("rate") === OTHER;
  const intra = state.value("supply") === "intra";
  const amountLabel = mode === "exclusive" ? "Price before GST" : "Price including GST";

  const names = isOther ? (["amount", "other"] as const) : (["amount"] as const);
  const parsed = names.map((n) => state.parsed(n));
  const visible = names.map((n) => state.visibleError(n));

  let result: ReactNode;
  let announcement: string;

  if (parsed.some((p) => !p.ok)) {
    const incomplete = incompleteMessage(parsed, visible);
    result = <ResultPanel status={incomplete.status} message={incomplete.message} />;
    announcement = incomplete.message;
  } else {
    const [amount, customRate] = parsed.map((p) => (p as { value: number }).value) as [
      number,
      number | undefined,
    ];
    const rate = customRate ?? Number(state.value("rate"));
    const outcome = mode === "exclusive" ? gstExclusive(amount, rate) : gstInclusive(amount, rate);
    if (!outcome.ok) {
      const message = errorMessage(outcome.error);
      result = <ResultPanel status="error" message={message} />;
      announcement = message;
    } else {
      const d = new Display();
      const { base, gst, total, half } = outcome.value;
      const r = d.percent(rate);
      const halfRate = d.percent(rate / 2);
      const split = intra
        ? [
            { label: `CGST (${halfRate})`, value: d.rupees(half) },
            { label: `SGST or UTGST (${halfRate})`, value: d.rupees(half) },
          ]
        : [{ label: `IGST (${r})`, value: d.rupees(gst) }];
      const rows = [
        { label: "Price before GST", value: d.rupees(base), strong: mode === "inclusive" },
        ...split,
        { label: `Total GST (${r})`, value: d.rupees(gst) },
        { label: "Price including GST", value: d.rupees(total), strong: mode === "exclusive" },
      ];
      const sentence =
        rate === 0
          ? `At 0% no GST applies, so the price is ${d.rupees(total)} either way.`
          : mode === "exclusive"
            ? `${r} GST on ${d.rupees(base)} is ${d.rupees(gst)}, so the price including GST is ${d.rupees(total)}.`
            : `${d.rupees(total)} including ${r} GST is ${d.rupees(base)} before GST plus ${d.rupees(gst)} GST.`;
      const working =
        mode === "exclusive"
          ? `GST = ${formatExact(amount)} × ${formatExact(rate)} ÷ 100 = ${formatExact(gst)}`
          : `Price before GST = ${formatExact(amount)} × 100 ÷ (100 + ${formatExact(rate)}) = ${formatExact(base)}`;
      // Odd number of paise: the two halves cannot both be exact to the paisa.
      const oddPaise = intra && Math.round(gst * 100) % 2 !== 0;
      const notes = [
        d.roundingNote(),
        oddPaise
          ? "CGST and SGST are each exactly half the GST; on an invoice, the billing system rounds each one."
          : undefined,
      ].filter(Boolean);
      result = (
        <ResultPanel
          status="result"
          label={mode === "exclusive" ? "Price including GST" : "Price before GST"}
          value={mode === "exclusive" ? d.rupees(total) : d.rupees(base)}
          sentence={sentence}
          rows={rows}
          working={working}
          {...(notes.length > 0 ? { note: notes.join(" ") } : {})}
          actions={
            <ShareButton data={{ title: "GST Calculator", text: sentence, url: state.shareUrl }} />
          }
        />
      );
      announcement = sentence;
    }
  }

  const amountError = state.visibleError("amount");
  const otherError = state.visibleError("other");

  const inputs = (
    <form
      className="space-y-4 md:space-y-5"
      onSubmit={(event) => event.preventDefault()}
      noValidate
    >
      <SelectInput
        id={`${baseId}-mode`}
        label="What do you want to calculate?"
        value={mode}
        options={MODES}
        onChange={(next) => state.set("mode", next)}
      />
      <NumberInput
        id={`${baseId}-amount`}
        label={amountLabel}
        value={state.value("amount")}
        example="1000"
        prefix="₹"
        error={amountError ? numberFieldMessage(amountError, AMOUNT, AMOUNT_FIELD) : undefined}
        onChange={(text) => state.set("amount", text)}
        onBlur={() => state.touch("amount")}
      />
      <div className="grid gap-4 md:grid-cols-2 md:gap-5 lg:grid-cols-1">
        <SelectInput
          id={`${baseId}-rate`}
          label="GST rate"
          value={state.value("rate")}
          options={RATE_OPTIONS}
          helperText={`Rates in force from ${EFFECTIVE}.`}
          onChange={(next) => state.set("rate", next)}
        />
        {isOther ? (
          <NumberInput
            id={`${baseId}-other`}
            label="Other rate"
            value={state.value("other")}
            example="3"
            suffix="%"
            error={otherError ? numberFieldMessage(otherError, RATE, RATE_FIELD) : undefined}
            onChange={(text) => state.set("other", text)}
            onBlur={() => state.touch("other")}
          />
        ) : null}
        <SelectInput
          id={`${baseId}-supply`}
          label="Where are the buyer and seller?"
          value={state.value("supply")}
          options={SUPPLY}
          onChange={(next) => state.set("supply", next)}
        />
      </div>
    </form>
  );

  return (
    <>
      <CalculatorFrame title="GST calculator" inputs={inputs} result={result} />
      <LiveAnnouncer message={announcement} />
    </>
  );
}
