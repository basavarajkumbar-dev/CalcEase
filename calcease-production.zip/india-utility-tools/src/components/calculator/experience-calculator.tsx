"use client";

import { useId, useMemo, type ReactNode } from "react";
import { workExperience } from "@/lib/calc/career/career";
import { compareDates, parseIsoDate } from "@/lib/calc/date/plain-date";
import { formatDateWithWeekday, formatYmd, plural } from "@/lib/format/date";
import { Checkbox } from "@/components/ui/checkbox";
import { DateInput } from "@/components/ui/date-input";
import { ShareButton } from "@/components/ui/share-button";
import { CalculatorFrame } from "./calculator-frame";
import { DATE_MAX, DATE_MIN, ISO_DATE, readDate } from "./date-fields";
import { dateFieldMessage } from "./field-messages";
import { incompleteMessage } from "./incomplete-message";
import { LiveAnnouncer } from "./live-announcer";
import { ResultPanel } from "./result-panel";
import { useCalculatorState, type CalculatorSpec } from "./use-calculator-state";
import { useToday } from "./use-today";

const SPEC: CalculatorSpec<"from" | "to" | "inclusive"> = {
  from: { kind: "text", param: "joined", pattern: ISO_DATE, initial: "2020-01-01" },
  // The end date defaults to today once the page knows it (see useToday).
  to: { kind: "text", param: "until", pattern: ISO_DATE, initial: "" },
  inclusive: { kind: "choice", param: "inclusive", options: ["yes", "no"], initial: "yes" },
};

export function ExperienceCalculator() {
  const baseId = useId();
  const today = useToday();
  const defaults = useMemo(() => (today ? { to: today } : {}), [today]);
  const state = useCalculatorState(SPEC, { defaults });
  const from = readDate(state.value("from"), state.touched("from"));
  const to = readDate(state.value("to"), state.touched("to"));
  const includeEnd = state.value("inclusive") === "yes";

  let result: ReactNode;
  let announcement: string;

  if (!from.result.ok || !to.result.ok) {
    const waiting = !today && state.value("to") === "";
    const incomplete = incompleteMessage([from.result, to.result], [from.visible, to.visible]);
    const message = waiting ? "Reading today's date…" : incomplete.message;
    result = <ResultPanel status={incomplete.status} message={message} reserveSpace={waiting} />;
    announcement = message;
  } else {
    const outcome = workExperience(from.result.value, to.result.value, includeEnd);
    if (!outcome.ok) {
      const message =
        outcome.error === "END_BEFORE_JOINING"
          ? "The end date is before the joining date. Check the dates."
          : "Enter dates between 1 January 1900 and 31 December 2199.";
      result = <ResultPanel status="error" message={message} />;
      announcement = message;
    } else {
      const v = outcome.value;
      const todayDate = today ? parseIsoDate(today) : undefined;
      const future = todayDate ? compareDates(to.result.value, todayDate) > 0 : false;
      const exact = formatYmd(v);
      const sentence = `From ${formatDateWithWeekday(from.result.value)} to ${formatDateWithWeekday(to.result.value)} is ${exact} of experience${includeEnd ? ", counting both dates" : ""}.`;
      const decimalYears = Math.floor((v.years + v.months / 12) * 10) / 10;
      const notes = [
        future ? "The end date is in the future, so this is projected experience." : "",
        "Employers and forms may count experience differently, for example in completed years only.",
      ].filter(Boolean);
      result = (
        <ResultPanel
          status="result"
          label="Total experience"
          value={exact}
          sentence={sentence}
          rows={[
            { label: "Years", value: String(v.years), strong: true },
            { label: "Months", value: String(v.months) },
            { label: "Days", value: String(v.days) },
            { label: "In years (one decimal, rounded down)", value: `${decimalYears}` },
            { label: "Total months", value: plural(v.totalMonths, "month") },
            { label: "Total days", value: plural(v.totalDays, "day") },
          ]}
          note={notes.join(" ")}
          actions={
            <ShareButton
              data={{ title: "Experience Calculator", text: sentence, url: state.shareUrl }}
            />
          }
        />
      );
      announcement = sentence;
    }
  }

  const inputs = (
    <form className="space-y-4 md:space-y-5" onSubmit={(e) => e.preventDefault()} noValidate>
      <div className="grid gap-4 md:grid-cols-2 md:gap-5 lg:grid-cols-1">
        <DateInput
          id={`${baseId}-from`}
          label="Joining date"
          value={state.value("from")}
          min={DATE_MIN}
          max={DATE_MAX}
          error={from.visible ? dateFieldMessage(from.visible, "a joining date") : undefined}
          onChange={(text) => state.set("from", text)}
          onBlur={() => state.touch("from")}
        />
        <DateInput
          id={`${baseId}-to`}
          label="Last working day"
          helperText="Today's date, or your relieving date."
          value={state.value("to")}
          min={DATE_MIN}
          max={DATE_MAX}
          error={to.visible ? dateFieldMessage(to.visible, "an end date") : undefined}
          onChange={(text) => state.set("to", text)}
          onBlur={() => state.touch("to")}
        />
      </div>
      <Checkbox
        id={`${baseId}-inclusive`}
        label="Count the last working day"
        helperText="On by default: joining 1 Jan 2020 and leaving 31 Dec 2024 is 5 years."
        checked={includeEnd}
        onChange={(checked) => state.set("inclusive", checked ? "yes" : "no")}
      />
    </form>
  );

  return (
    <>
      <CalculatorFrame title="Experience calculator" inputs={inputs} result={result} />
      <LiveAnnouncer message={announcement} />
    </>
  );
}
