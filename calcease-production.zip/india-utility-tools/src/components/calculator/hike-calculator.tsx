"use client";

import { useId, type ReactNode } from "react";
import { ArrowDown, ArrowUp } from "@/components/ui/icons";
import {
  convertPeriod,
  HIKE_RANGE,
  hikeBetweenSalaries,
  salaryAfterHike,
  type PayPeriod,
} from "@/lib/calc/hike";
import { formatExact } from "@/lib/format/number";
import { NumberInput } from "@/components/ui/number-input";
import { SelectInput } from "@/components/ui/select-input";
import { ShareButton } from "@/components/ui/share-button";
import { CalculatorFrame } from "./calculator-frame";
import { Display } from "./display";
import { numberFieldMessage, type FieldDescription } from "./field-messages";
import type { NumberFieldRule } from "@/lib/validation/number-field";
import { incompleteMessage } from "./incomplete-message";
import { LiveAnnouncer } from "./live-announcer";
import { ResultPanel } from "./result-panel";
import { useCalculatorState, type CalculatorSpec } from "./use-calculator-state";

const MODES = [
  { value: "byPercent", label: "New salary after a hike" },
  { value: "betweenSalaries", label: "Hike between two salaries" },
] as const;
type Mode = (typeof MODES)[number]["value"];

const PERIODS = [
  { value: "month", label: "Per month" },
  { value: "year", label: "Per year" },
] as const;

const SALARY = { min: 0, minExclusive: true, max: 1e12 };
const NEW_SALARY = { min: 0, max: 1e12 };
const HIKE = { min: HIKE_RANGE.min, max: HIKE_RANGE.max };

const FIELDS: Record<
  "salary" | "hike" | "next",
  FieldDescription & { label: string; rule: NumberFieldRule }
> = {
  salary: { noun: "a salary", prefix: "₹", label: "Current salary", rule: SALARY },
  hike: { noun: "a hike", suffix: "%", label: "Hike", rule: HIKE },
  next: { noun: "a salary", prefix: "₹", label: "New salary", rule: NEW_SALARY },
};

const SPEC: CalculatorSpec<"mode" | "per" | "salary" | "hike" | "next"> = {
  mode: { kind: "choice", param: "mode", options: MODES.map((m) => m.value), initial: "byPercent" },
  per: { kind: "choice", param: "per", options: PERIODS.map((p) => p.value), initial: "month" },
  salary: { kind: "number", param: "salary", rule: SALARY, initial: "50000" },
  hike: { kind: "number", param: "hike", rule: HIKE, initial: "10" },
  next: { kind: "number", param: "new", rule: NEW_SALARY, initial: "57500" },
};

export function HikeCalculator() {
  const baseId = useId();
  const state = useCalculatorState(SPEC);
  const mode = state.value("mode") as Mode;
  const period = state.value("per") as PayPeriod;
  const names =
    mode === "byPercent" ? (["salary", "hike"] as const) : (["salary", "next"] as const);
  const parsed = names.map((n) => state.parsed(n));
  const visible = names.map((n) => state.visibleError(n));
  const per = period === "month" ? "a month" : "a year";
  const otherPer = period === "month" ? "a year" : "a month";

  let result: ReactNode;
  let announcement: string;

  if (parsed.some((p) => !p.ok)) {
    const incomplete = incompleteMessage(parsed, visible);
    result = <ResultPanel status={incomplete.status} message={incomplete.message} />;
    announcement = incomplete.message;
  } else {
    const [first, second] = parsed.map((p) => (p as { value: number }).value) as [number, number];
    const outcome =
      mode === "byPercent" ? salaryAfterHike(first, second) : hikeBetweenSalaries(first, second);
    if (!outcome.ok) {
      const message = "Check the values you entered.";
      result = <ResultPanel status="error" message={message} />;
      announcement = message;
    } else {
      const d = new Display();
      const { change, result: next, percent, direction } = outcome.value;
      const current = d.rupees(first);
      const newSalary = d.rupees(next);
      const otherNew = convertPeriod(next, period);
      const lpa = Display.lpa(period === "year" ? next : otherNew);
      const what = direction === "decrease" ? "pay cut" : "hike";
      const changeWords =
        direction === "none"
          ? "no change"
          : `${direction === "increase" ? "an increase" : "a decrease"} of ${d.rupees(Math.abs(change))}`;
      const rows = [
        { label: `Current salary (${per})`, value: current },
        {
          label: `${direction === "decrease" ? "Decrease" : "Increase"} in rupees`,
          value: d.signedRupees(change),
        },
        {
          label: `${direction === "decrease" ? "Pay cut" : "Hike"} in percent`,
          value: d.percent(Math.abs(percent)),
        },
        { label: `New salary (${per})`, value: newSalary, strong: true },
        {
          label: `New salary (${otherPer})`,
          value: `${d.rupees(otherNew)}${lpa && period === "month" ? ` (${lpa})` : ""}`,
        },
      ];

      let label: string;
      let value: string;
      let sentence: string;
      let working: string;
      let arrow: ReactNode = null;
      if (mode === "byPercent") {
        label = "New salary";
        value = `${newSalary}`;
        sentence =
          direction === "none"
            ? `With no hike your salary stays at ${current} ${per}.`
            : `A ${d.percent(Math.abs(percent))} ${what} on ${current} ${per} is ${changeWords}, so your new salary is ${newSalary} ${per}.`;
        working = `${formatExact(first)} + (${formatExact(first)} × ${formatExact(second)} ÷ 100) = ${formatExact(next)}`;
      } else {
        label =
          direction === "decrease"
            ? "Your pay cut"
            : direction === "none"
              ? "No change"
              : "Your hike";
        value = d.percent(Math.abs(percent));
        arrow =
          direction === "increase" ? (
            <ArrowUp
              aria-hidden="true"
              className="mr-1 inline size-9 align-[-0.1em] lg:size-10"
              strokeWidth={2.5}
            />
          ) : direction === "decrease" ? (
            <ArrowDown
              aria-hidden="true"
              className="mr-1 inline size-9 align-[-0.1em] lg:size-10"
              strokeWidth={2.5}
            />
          ) : null;
        sentence =
          direction === "none"
            ? `There is no change from ${current} ${per}.`
            : `From ${current} to ${newSalary} ${per} is a ${what} of ${d.percent(Math.abs(percent))} (${changeWords}).`;
        working = `(${formatExact(second)} − ${formatExact(first)}) × 100 ÷ ${formatExact(first)} = ${formatExact(percent)}%`;
      }
      const note = d.roundingNote();
      result = (
        <ResultPanel
          status="result"
          label={label}
          value={value}
          valuePrefix={arrow}
          sentence={sentence}
          rows={rows}
          working={working}
          {...(note ? { note } : {})}
          actions={
            <ShareButton
              data={{ title: "Percentage Hike Calculator", text: sentence, url: state.shareUrl }}
            />
          }
        />
      );
      announcement = sentence;
    }
  }

  const inputs = (
    <form
      className="space-y-4 md:space-y-5"
      onSubmit={(event) => event.preventDefault()}
      noValidate
    >
      <div className="grid gap-4 md:grid-cols-2 md:gap-5 lg:grid-cols-1">
        <SelectInput
          id={`${baseId}-mode`}
          label="What do you want to calculate?"
          value={mode}
          options={MODES}
          onChange={(next) => state.set("mode", next)}
        />
        <SelectInput
          id={`${baseId}-per`}
          label="Salary is"
          value={period}
          options={PERIODS}
          onChange={(next) => state.set("per", next)}
        />
      </div>
      <div className="grid gap-4 md:grid-cols-2 md:gap-5 lg:grid-cols-1">
        {names.map((name) => {
          const field = FIELDS[name];
          const error = state.visibleError(name);
          return (
            <NumberInput
              key={name}
              id={`${baseId}-${name}`}
              label={name === "hike" ? field.label : `${field.label} (${per})`}
              value={state.value(name)}
              example={String(SPEC[name].initial)}
              prefix={field.prefix}
              suffix={field.suffix}
              {...(name === "hike"
                ? { helperText: "Use a minus sign for a pay cut, e.g. −10." }
                : {})}
              error={error ? numberFieldMessage(error, field.rule, field) : undefined}
              onChange={(text) => state.set(name, text)}
              onBlur={() => state.touch(name)}
            />
          );
        })}
      </div>
    </form>
  );

  return (
    <>
      <CalculatorFrame title="Percentage hike calculator" inputs={inputs} result={result} />
      <LiveAnnouncer message={announcement} />
    </>
  );
}
