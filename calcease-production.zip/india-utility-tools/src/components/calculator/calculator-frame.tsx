import type { ReactNode } from "react";

export interface CalculatorFrameProps {
  /** Accessible name for the calculator region. */
  title: string;
  /** The form: mode selector and inputs. */
  inputs: ReactNode;
  /** The ResultPanel. */
  result: ReactNode;
}

/**
 * The calculator card shared by every tool: inputs, then the result directly below on
 * phones (no scrolling past content to find the answer) and beside them from 1024px.
 */
export function CalculatorFrame({ title, inputs, result }: CalculatorFrameProps) {
  return (
    <section
      aria-label={title}
      className="grid overflow-hidden rounded-lg border border-line bg-surface lg:grid-cols-2"
    >
      <div className="p-4 md:p-6">{inputs}</div>
      <div className="lg:border-l lg:border-line">{result}</div>
    </section>
  );
}
