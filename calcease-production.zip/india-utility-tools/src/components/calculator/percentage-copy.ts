/**
 * Turns a successful percentage calculation into the words shown to the user.
 * Presentation only: all maths comes from src/lib/calc, all rounding from src/lib/format.
 */
import {
  calculatePercentOf,
  changeDirection,
  type ChangeDirection,
  type PercentageMode,
} from "@/lib/calc/percentage";
import type { SummaryRow } from "@/components/ui/summary-list";
import { formatExact, formatNumber, formatPercent } from "@/lib/format/number";

export interface ResultCopy {
  /** Label above the big number. */
  label: string;
  /** The big number, already formatted. */
  value: string;
  /** Plain-language sentence restating the question with the answer. */
  sentence: string;
  /** The formula with the user's numbers. */
  working: string;
  /** Secondary values, e.g. the amount added. */
  rows?: SummaryRow[];
  /** For percentage change: shown as an arrow next to the value. */
  direction?: ChangeDirection;
  /** Exact value text, present only when the big number is rounded. */
  exact?: string;
}

export function describeResult(
  mode: PercentageMode,
  a: number,
  b: number,
  result: number,
): ResultCopy {
  const A = formatExact(a);
  const B = formatExact(b);
  const plain = formatNumber(result);
  const percent = formatPercent(result);
  const exact = (rounded: boolean, suffix = "") =>
    rounded ? { exact: `${formatExact(result)}${suffix}` } : {};

  switch (mode) {
    case "percentOf":
      return {
        label: "Your result",
        value: plain.text,
        sentence: `${A}% of ${B} is ${plain.text}.`,
        working: `${A} × ${B} ÷ 100 = ${plain.text}`,
        ...exact(plain.isRounded),
      };
    case "whatPercent":
      return {
        label: "Your result",
        value: percent.text,
        sentence: `${A} is ${percent.text} of ${B}.`,
        working: `${A} × 100 ÷ ${B} = ${percent.text}`,
        ...exact(percent.isRounded, "%"),
      };
    case "percentChange": {
      const direction = changeDirection(result);
      const magnitude = formatPercent(Math.abs(result));
      const label =
        direction === "increase"
          ? "Your result: an increase"
          : direction === "decrease"
            ? "Your result: a decrease"
            : "Your result: no change";
      const sentence =
        direction === "none"
          ? `There is no change from ${A} to ${B}.`
          : `From ${A} to ${B} is ${direction === "increase" ? "an increase" : "a decrease"} of ${magnitude.text}.`;
      return {
        label,
        value: magnitude.text,
        direction,
        sentence,
        working: `(${B} − ${A}) × 100 ÷ ${formatExact(Math.abs(a))} = ${percent.text}`,
        ...exact(magnitude.isRounded, "%"),
      };
    }
    case "increaseBy":
    case "decreaseBy": {
      const isIncrease = mode === "increaseBy";
      const change = calculatePercentOf(b, a);
      const changeText = change.ok ? formatNumber(Math.abs(change.value)).text : "";
      const sign = isIncrease ? "+" : "−";
      return {
        label: "Your result",
        value: plain.text,
        sentence: `${A} ${isIncrease ? "increased" : "decreased"} by ${B}% is ${plain.text}.`,
        working: `${A} ${sign} (${A} × ${B} ÷ 100) = ${plain.text}`,
        rows: [{ label: `Amount ${isIncrease ? "added" : "removed"}`, value: changeText }],
        ...exact(plain.isRounded),
      };
    }
  }
}

/** User-facing messages for calculation errors (spec, section 4). */
export function calculationErrorMessage(mode: PercentageMode, error: string): string {
  if (error === "DIVISION_BY_ZERO") {
    return mode === "percentChange"
      ? "The starting value can't be 0. A change from 0 can't be expressed as a percentage."
      : "The whole can't be 0, because a percentage of nothing is undefined.";
  }
  if (error === "RESULT_TOO_LARGE")
    return "The result is too large to show. Check the values you entered.";
  if (error === "OUT_OF_RANGE") return OUT_OF_RANGE_MESSAGE;
  return NOT_A_NUMBER_MESSAGE;
}

export const NOT_A_NUMBER_MESSAGE = "Enter a number, for example 250 or 12.5.";
export const OUT_OF_RANGE_MESSAGE =
  "Enter a number between −1,00,00,00,00,000 and 1,00,00,00,00,000.";
