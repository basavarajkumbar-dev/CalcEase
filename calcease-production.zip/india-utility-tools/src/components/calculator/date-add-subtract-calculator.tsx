"use client";

import { useId, useMemo, type ReactNode } from "react";
import { shiftDate } from "@/lib/calc/date/add";
import { formatDateWithWeekday, formatDuration, formatLongDate } from "@/lib/format/date";
import type { NumberFieldResult } from "@/lib/validation/number-field";
import { DateInput } from "@/components/ui/date-input";
import { NumberInput } from "@/components/ui/number-input";
import { SelectInput } from "@/components/ui/select-input";
import { ShareButton } from "@/components/ui/share-button";
import { CalculatorFrame } from "./calculator-frame";
import { DATE_MAX, DATE_MIN, ISO_DATE, readDate } from "./date-fields";
import { dateFieldMessage, numberFieldMessage } from "./field-messages";
import { incompleteMessage } from "./incomplete-message";
import { LiveAnnouncer } from "./live-announcer";
import { ResultPanel } from "./result-panel";
import { useCalculatorState, type CalculatorSpec } from "./use-calculator-state";
import { useToday } from "./use-today";

const DIRECTIONS = [
  { value: "add", label: "Add to the date" },
  { value: "subtract", label: "Subtract from the date" },
] as const;

const AMOUNTS = ["years", "months", "weeks", "days"] as const;
type Amount = (typeof AMOUNTS)[number];

const RULES: Record<Amount, { min: number; max: number; integer: true }> = {
  years: { min: 0, max: 300, integer: true },
  months: { min: 0, max: 3600, integer: true },
  weeks: { min: 0, max: 15000, integer: true },
  days: { min: 0, max: 110000, integer: true },
};

const LABELS: Record<Amount, string> = {
  years: "Years",
  months: "Months",
  weeks: "Weeks",
  days: "Days",
};

const SPEC: CalculatorSpec<"date" | "op" | Amount> = {
  date: { kind: "text", param: "date", pattern: ISO_DATE, initial: "" },
  op: { kind: "choice", param: "op", options: DIRECTIONS.map((d) => d.value), initial: "add" },
  years: { kind: "number", param: "years", rule: RULES.years, initial: "" },
  months: { kind: "number", param: "months", rule: RULES.months, initial: "" },
  weeks: { kind: "number", param: "weeks", rule: RULES.weeks, initial: "" },
  days: { kind: "number", param: "days", rule: RULES.days, initial: "30" },
};

/** An empty amount counts as 0 (spec §2). */
function amountOf(result: NumberFieldResult): NumberFieldResult {
  return !result.ok && result.error.code === "REQUIRED" ? { ok: true, value: 0 } : result;
}

export function DateAddSubtractCalculator() {
  const baseId = useId();
  const today = useToday();
  const defaults = useMemo(() => (today ? { date: today } : {}), [today]);
  const state = useCalculatorState(SPEC, { defaults });
  const start = readDate(state.value("date"), state.touched("date"));
  const direction = state.value("op") as "add" | "subtract";
  const amounts = AMOUNTS.map((name) => amountOf(state.parsed(name)));
  const amountErrors = AMOUNTS.map((name) => {
    const error = state.visibleError(name);
    return error?.code === "REQUIRED" ? undefined : error;
  });

  let result: ReactNode;
  let announcement: string;

  if (!start.result.ok || amounts.some((a) => !a.ok)) {
    const waitingForToday = !today && state.value("date") === "";
    const incomplete = incompleteMessage(
      [start.result, ...amounts],
      [start.visible, ...amountErrors],
    );
    const message = waitingForToday ? "Reading today's date…" : incomplete.message;
    result = (
      <ResultPanel status={incomplete.status} message={message} reserveSpace={waitingForToday} />
    );
    announcement = message;
  } else {
    const [years, months, weeks, days] = amounts.map((a) => (a as { value: number }).value) as [
      number,
      number,
      number,
      number,
    ];
    const from = start.result.value;
    const outcome = shiftDate(from, { years, months, weeks, days }, direction);
    if (!outcome.ok) {
      const message =
        "The result is outside the dates this calculator supports (1 January 1900 to 31 December 2199).";
      result = <ResultPanel status="error" message={message} />;
      announcement = message;
    } else {
      const change = formatDuration({ years, months, weeks, days });
      const target = outcome.value.date;
      const sentence = `${change} ${direction === "add" ? "after" : "before"} ${formatDateWithWeekday(from)} is ${formatDateWithWeekday(target)}.`;
      const rows = [
        { label: "Start date", value: formatDateWithWeekday(from) },
        { label: direction === "add" ? "Added" : "Subtracted", value: change },
        { label: "Result", value: formatDateWithWeekday(target), strong: true },
      ];
      const note = outcome.value.clamped
        ? `${formatLongDate(outcome.value.afterMonths).replace(/^\d+ /, "")} has no day ${from.day}, so after moving by ${formatDuration({ years, months })} the date became ${formatLongDate(outcome.value.afterMonths)}, the last day of that month.`
        : undefined;
      result = (
        <ResultPanel
          status="result"
          label="Date"
          value={formatLongDate(target)}
          sentence={sentence}
          rows={rows}
          {...(note ? { note } : {})}
          actions={
            <ShareButton
              data={{
                title: "Date Add / Subtract Calculator",
                text: sentence,
                url: state.shareUrl,
              }}
            />
          }
        />
      );
      announcement = sentence;
    }
  }

  const inputs = (
    <form
      className="space-y-4 md:space-y-5"
      onSubmit={(event) => event.preventDefault()}
      noValidate
    >
      <div className="grid gap-4 md:grid-cols-2 md:gap-5 lg:grid-cols-1">
        <DateInput
          id={`${baseId}-date`}
          label="Start date"
          value={state.value("date")}
          min={DATE_MIN}
          max={DATE_MAX}
          error={start.visible ? dateFieldMessage(start.visible, "a start date") : undefined}
          onChange={(text) => state.set("date", text)}
          onBlur={() => state.touch("date")}
        />
        <SelectInput
          id={`${baseId}-op`}
          label="Add or subtract?"
          value={direction}
          options={DIRECTIONS}
          onChange={(next) => state.set("op", next)}
        />
      </div>
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4 md:gap-5 lg:grid-cols-2">
        {AMOUNTS.map((name, i) => {
          const error = amountErrors[i];
          return (
            <NumberInput
              key={name}
              id={`${baseId}-${name}`}
              label={LABELS[name]}
              value={state.value(name)}
              example="0"
              error={
                error
                  ? numberFieldMessage(error, RULES[name], {
                      noun: `a whole number of ${name}`,
                    })
                  : undefined
              }
              onChange={(text) => state.set(name, text)}
              onBlur={() => state.touch(name)}
            />
          );
        })}
      </div>
    </form>
  );

  return (
    <>
      <CalculatorFrame title="Date add or subtract calculator" inputs={inputs} result={result} />
      <LiveAnnouncer message={announcement} />
    </>
  );
}
