"use client";

import { useId, type ReactNode } from "react";
import {
  discountByPercent,
  discountFromSalePrice,
  stackedDiscount,
  type DiscountError,
} from "@/lib/calc/discount";
import { formatExact } from "@/lib/format/number";
import { NumberInput } from "@/components/ui/number-input";
import { SelectInput } from "@/components/ui/select-input";
import { ShareButton } from "@/components/ui/share-button";
import { CalculatorFrame } from "./calculator-frame";
import { Display } from "./display";
import { numberFieldMessage, type FieldDescription } from "./field-messages";
import { incompleteMessage } from "./incomplete-message";
import { LiveAnnouncer } from "./live-announcer";
import { ResultPanel } from "./result-panel";
import { useCalculatorState, type CalculatorSpec } from "./use-calculator-state";

const MODES = [
  { value: "percentOff", label: "Price after a discount" },
  { value: "fromSalePrice", label: "Discount from a sale price" },
  { value: "stacked", label: "Discount + extra discount" },
] as const;
type Mode = (typeof MODES)[number]["value"];

const PRICE = { min: 0, minExclusive: true, max: 1e12 };
const SALE = { min: 0, max: 1e12 };
const PERCENT = { min: 0, max: 100 };

const FIELDS: Record<
  "price" | "off" | "sale" | "extra",
  FieldDescription & { label: (m: Mode) => string }
> = {
  price: { noun: "a price", prefix: "₹", label: () => "Original price" },
  off: {
    noun: "a discount",
    suffix: "%",
    label: (m) => (m === "stacked" ? "First discount" : "Discount"),
  },
  sale: { noun: "a sale price", prefix: "₹", label: () => "Sale price" },
  extra: { noun: "a discount", suffix: "%", label: () => "Extra discount" },
};

const SPEC: CalculatorSpec<"mode" | "price" | "off" | "sale" | "extra"> = {
  mode: {
    kind: "choice",
    param: "mode",
    options: MODES.map((m) => m.value),
    initial: "percentOff",
  },
  price: { kind: "number", param: "price", rule: PRICE, initial: "1299" },
  off: { kind: "number", param: "off", rule: PERCENT, initial: "15" },
  sale: { kind: "number", param: "sale", rule: SALE, initial: "999" },
  extra: { kind: "number", param: "extra", rule: PERCENT, initial: "10" },
};

const RULES = { price: PRICE, off: PERCENT, sale: SALE, extra: PERCENT };

const INPUTS_BY_MODE: Record<Mode, readonly ("price" | "off" | "sale" | "extra")[]> = {
  percentOff: ["price", "off"],
  fromSalePrice: ["price", "sale"],
  stacked: ["price", "off", "extra"],
};

function errorMessage(error: DiscountError): string {
  switch (error) {
    case "SALE_ABOVE_PRICE":
      return "The sale price is higher than the original price, so there is no discount.";
    case "RESULT_TOO_LARGE":
      return "The result is too large to show. Check the values you entered.";
    default:
      return "Check the values you entered.";
  }
}

export function DiscountCalculator() {
  const baseId = useId();
  const state = useCalculatorState(SPEC);
  const mode = state.value("mode") as Mode;
  const names = INPUTS_BY_MODE[mode];
  const parsed = names.map((n) => state.parsed(n));
  const visible = names.map((n) => state.visibleError(n));

  let result: ReactNode;
  let announcement: string;

  if (parsed.some((p) => !p.ok)) {
    const incomplete = incompleteMessage(parsed, visible);
    result = <ResultPanel status={incomplete.status} message={incomplete.message} />;
    announcement = incomplete.message;
  } else {
    const v = Object.fromEntries(
      names.map((n, i) => [n, (parsed[i] as { value: number }).value]),
    ) as Record<string, number>;
    const price = v.price!;
    const outcome =
      mode === "percentOff"
        ? discountByPercent(price, v.off!)
        : mode === "fromSalePrice"
          ? discountFromSalePrice(price, v.sale!)
          : stackedDiscount(price, v.off!, v.extra!);
    if (!outcome.ok) {
      const message = errorMessage(outcome.error);
      result = <ResultPanel status="error" message={message} />;
      announcement = message;
    } else {
      const d = new Display();
      const { saving, final, percent } = outcome.value;
      const P = d.rupees(price);
      let label: string;
      let value: string;
      let sentence: string;
      let working: string;
      const rows = [
        { label: "Original price", value: P },
        { label: `You save (${d.percent(percent)})`, value: d.rupees(saving) },
        { label: "You pay", value: d.rupees(final), strong: true },
      ];
      if (mode === "percentOff") {
        label = "You pay";
        value = d.rupees(final);
        sentence =
          saving === 0
            ? `With no discount you pay the full ${P}.`
            : `${d.percent(v.off!)} off ${P} saves you ${d.rupees(saving)}, so you pay ${d.rupees(final)}.`;
        working = `${formatExact(price)} − (${formatExact(price)} × ${formatExact(v.off!)} ÷ 100) = ${formatExact(final)}`;
      } else if (mode === "fromSalePrice") {
        label = "Your discount";
        value = d.percent(percent);
        sentence =
          saving === 0
            ? `The sale price is the same as the original price: there is no discount.`
            : `${P} reduced to ${d.rupees(final)} is a ${d.percent(percent)} discount: you save ${d.rupees(saving)}.`;
        working = `(${formatExact(price)} − ${formatExact(final)}) × 100 ÷ ${formatExact(price)} = ${formatExact(percent)}%`;
      } else {
        label = "You pay";
        value = d.rupees(final);
        const naive = v.off! + v.extra!;
        const differs = Math.abs(naive - percent) > 1e-9;
        sentence = `${d.percent(v.off!)} off and then an extra ${d.percent(v.extra!)} off ${P} comes to ${d.rupees(final)}: a total discount of ${d.percent(percent)}${differs ? `, not ${d.percent(naive)}` : ""}.`;
        working = `${formatExact(price)} × (1 − ${formatExact(v.off!)}/100) × (1 − ${formatExact(v.extra!)}/100) = ${formatExact(final)}`;
      }
      const note = d.roundingNote();
      result = (
        <ResultPanel
          status="result"
          label={label}
          value={value}
          sentence={sentence}
          rows={rows}
          working={working}
          {...(note ? { note } : {})}
          actions={
            <ShareButton
              data={{ title: "Discount Calculator", text: sentence, url: state.shareUrl }}
            />
          }
        />
      );
      announcement = sentence;
    }
  }

  const inputs = (
    <form
      className="space-y-4 md:space-y-5"
      onSubmit={(event) => event.preventDefault()}
      noValidate
    >
      <SelectInput
        id={`${baseId}-mode`}
        label="What do you want to calculate?"
        value={mode}
        options={MODES}
        onChange={(next) => state.set("mode", next)}
      />
      <div className="grid gap-4 md:grid-cols-2 md:gap-5 lg:grid-cols-1">
        {names.map((name) => {
          const field = FIELDS[name];
          const error = state.visibleError(name);
          return (
            <NumberInput
              key={name}
              id={`${baseId}-${name}`}
              label={field.label(mode)}
              value={state.value(name)}
              example={String(SPEC[name].initial)}
              prefix={field.prefix}
              suffix={field.suffix}
              error={error ? numberFieldMessage(error, RULES[name], field) : undefined}
              onChange={(text) => state.set(name, text)}
              onBlur={() => state.touch(name)}
            />
          );
        })}
      </div>
    </form>
  );

  return (
    <>
      <CalculatorFrame title="Discount calculator" inputs={inputs} result={result} />
      <LiveAnnouncer message={announcement} />
    </>
  );
}
