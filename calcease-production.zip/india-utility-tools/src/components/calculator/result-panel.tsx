import type { ReactNode } from "react";
import { CircleAlert } from "@/components/ui/icons";
import { SummaryList, type SummaryRow } from "@/components/ui/summary-list";

interface ResultState {
  status: "result";
  /** Defaults to "Your result". */
  label?: string;
  /** The primary result, formatted, e.g. "16.67%" or "₹1,47,500". */
  value: string;
  /** Optional marker before the value, e.g. an arrow for a decrease. */
  valuePrefix?: ReactNode;
  /** Plain-language answer, e.g. "From 600 to 500 is a decrease of 16.67%." */
  sentence?: string;
  /** Amount in words for money results, e.g. "One lakh forty-seven thousand five hundred rupees". */
  inWords?: string;
  /** Secondary values or a breakdown. */
  rows?: readonly SummaryRow[];
  /** A small chart after the rows (it must have its own text equivalent). */
  chart?: ReactNode;
  /** The formula with the user's numbers. */
  working?: string;
  /** Small print, e.g. "Rounded to 2 decimal places". */
  note?: ReactNode;
  /** Actions such as a share button. */
  actions?: ReactNode;
}

interface MessageState {
  /**
   * empty: required values missing (neutral, not an error)
   * invalid: a field needs fixing (the field shows the details)
   * error: the inputs are valid but the calculation is impossible (e.g. dividing by 0)
   */
  status: "empty" | "invalid" | "error";
  label?: string;
  message: string;
  /**
   * Hold roughly the height of a full result. For results that can only appear after the
   * page loads (e.g. ones that need today's date), so the content below does not jump
   * down when the result arrives (layout shift).
   */
  reserveSpace?: boolean;
}

export type ResultPanelProps = ResultState | MessageState;

/**
 * The answer. The one emphasised element on a tool page: a large tabular number with
 * its sentence and working, on a tinted background with a primary top rule. Not a live
 * region; <LiveAnnouncer> announces results after typing pauses.
 */
export function ResultPanel(props: ResultPanelProps) {
  const label = props.label ?? "Your result";

  if (props.status !== "result") {
    const isError = props.status === "error";
    return (
      <div
        data-testid="result-panel"
        data-status={props.status}
        className={`h-full border-t-4 border-line-strong bg-canvas p-4 md:p-6 ${props.reserveSpace ? "min-h-[36rem] md:min-h-[28rem]" : ""}`}
      >
        <p className="text-label text-muted">{label}</p>
        <p
          data-testid="result-message"
          className={`mt-2 flex items-start gap-2 ${isError ? "font-semibold text-error" : "text-muted"}`}
        >
          {isError && <CircleAlert aria-hidden="true" className="mt-0.5 size-5 shrink-0" />}
          <span>{props.message}</span>
        </p>
      </div>
    );
  }

  return (
    <div
      data-testid="result-panel"
      data-status="result"
      className="h-full border-t-4 border-primary bg-primary-soft p-4 md:p-6"
    >
      <p className="text-label text-primary">{label}</p>
      <p data-testid="result-value" className="text-result mt-1 text-ink [overflow-wrap:anywhere]">
        {props.valuePrefix}
        {props.value}
      </p>
      {props.inWords && <p className="mt-1 text-muted">{props.inWords}</p>}
      {props.sentence && (
        <p data-testid="result-sentence" className="mt-3 text-lg font-medium text-ink">
          {props.sentence}
        </p>
      )}
      {props.rows && props.rows.length > 0 && (
        <div className="mt-3">
          <SummaryList rows={props.rows} />
        </div>
      )}
      {props.chart}
      {props.working && (
        <p className="numeric text-small mt-3 border-t border-line pt-3 text-muted [overflow-wrap:anywhere]">
          <span className="sr-only">Calculation: </span>
          {props.working}
        </p>
      )}
      {props.note && (
        <p className="text-small mt-1 text-muted [overflow-wrap:anywhere]">{props.note}</p>
      )}
      {props.actions && <div className="mt-4">{props.actions}</div>}
    </div>
  );
}
