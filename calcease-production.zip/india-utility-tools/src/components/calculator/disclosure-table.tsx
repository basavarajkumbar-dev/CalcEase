import type { ReactNode } from "react";
import { ChevronDown } from "@/components/ui/icons";

/**
 * A closed-by-default section under a calculator for long tables (year-by-year growth,
 * repayment schedules): the result stays near the top, and the details are one tap away.
 */
export function DisclosureTable({ summary, children }: { summary: string; children: ReactNode }) {
  return (
    <details className="group mt-4 rounded-lg border border-line bg-surface">
      <summary className="flex min-h-12 cursor-pointer list-none items-center justify-between gap-3 px-4 font-semibold text-ink [&::-webkit-details-marker]:hidden">
        {summary}
        <ChevronDown aria-hidden="true" className="size-5 text-muted group-open:rotate-180" />
      </summary>
      <div className="border-t border-line p-2 md:p-4">{children}</div>
    </details>
  );
}
