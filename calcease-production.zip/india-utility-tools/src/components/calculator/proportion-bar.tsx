export interface ProportionPart {
  label: string;
  value: number;
  /** Shown next to the label, already formatted (e.g. "₹4,08,812.49"). */
  display: string;
  tone: "primary" | "accent";
}

/**
 * A two-part horizontal bar (e.g. principal vs interest) with its legend. The legend
 * states every figure and its share in text, so the bar itself is decorative for screen
 * readers (the text equivalent is right next to it).
 */
export function ProportionBar({
  parts,
  caption,
}: {
  parts: readonly ProportionPart[];
  caption: string;
}) {
  const total = parts.reduce((sum, p) => sum + p.value, 0);
  const share = (v: number) => (total > 0 ? (v / total) * 100 : 0);
  const percent = (v: number) => `${Math.round(share(v))}%`;
  return (
    <figure className="mt-3">
      <figcaption className="text-small font-semibold text-ink">{caption}</figcaption>
      <div aria-hidden="true" className="mt-2 flex h-3 overflow-hidden rounded-full bg-line">
        {parts.map((p) => (
          <div
            key={p.label}
            className={p.tone === "primary" ? "bg-primary" : "bg-chart-accent"}
            style={{ width: `${share(p.value)}%` }}
          />
        ))}
      </div>
      <ul className="text-small mt-2 flex flex-wrap gap-x-5 gap-y-1 text-muted">
        {parts.map((p) => (
          <li key={p.label} className="flex items-center gap-2">
            <span
              aria-hidden="true"
              className={`inline-block size-3 rounded-sm ${p.tone === "primary" ? "bg-primary" : "bg-chart-accent"}`}
            />
            {p.label}: <span className="numeric text-ink">{p.display}</span> ({percent(p.value)})
          </li>
        ))}
      </ul>
    </figure>
  );
}
