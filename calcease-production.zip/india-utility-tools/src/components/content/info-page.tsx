import type { ReactNode } from "react";
import { Breadcrumb } from "@/components/layout/breadcrumb";
import { Container } from "@/components/layout/container";
import { Callout } from "@/components/ui/callout";
import type { SitePage } from "@/config/site";

/**
 * Layout for About, Methodology, Contact and the legal pages. Draft pages say so at the
 * top, in words, so nobody mistakes unfinished content for the final version.
 */
export function InfoPage({ page, children }: { page: SitePage; children: ReactNode }) {
  return (
    <Container className="pt-4 pb-8">
      <Breadcrumb items={[{ name: "Home", href: "/" }, { name: page.name }]} />
      <article className="mt-4 max-w-prose">
        <h1 className="text-h1 text-ink">{page.title}</h1>
        {page.status === "draft" && (
          <Callout tone="warning" title="Draft: this page is not final" className="mt-4">
            <p>
              Some details below still need to be completed or reviewed before the site launches.
              Until then this page is hidden from search engines.
            </p>
          </Callout>
        )}
        <div className="prose-tool mt-6">{children}</div>
      </article>
    </Container>
  );
}
