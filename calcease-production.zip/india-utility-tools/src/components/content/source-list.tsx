import type { RuleSource } from "@/lib/rules/types";

const longDate = (iso: string) =>
  new Intl.DateTimeFormat("en-IN", { dateStyle: "long", timeZone: "UTC" }).format(new Date(iso));

/** Official or published sources behind a calculator's rules, with the date each was read. */
export function SourceList({ sources }: { sources: readonly RuleSource[] }) {
  return (
    <ul>
      {sources.map((source) => (
        <li key={source.url}>
          <a href={source.url} rel="noopener noreferrer">
            {source.name}
          </a>{" "}
          (checked <time dateTime={source.retrieved}>{longDate(source.retrieved)}</time>)
        </li>
      ))}
    </ul>
  );
}
