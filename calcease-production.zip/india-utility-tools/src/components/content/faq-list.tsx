import type { ReactNode } from "react";
import { ChevronDown } from "@/components/ui/icons";

export interface FaqItem {
  question: string;
  answer: ReactNode;
}

/**
 * Questions and answers as native <details> disclosures: no JavaScript, keyboard and
 * screen-reader support built in, and the answers stay in the HTML for search engines.
 */
export function FaqList({ items }: { items: readonly FaqItem[] }) {
  return (
    <div className="divide-y divide-line rounded-lg border border-line bg-surface">
      {items.map((item) => (
        <details key={item.question} className="group">
          <summary className="flex min-h-12 cursor-pointer list-none items-center justify-between gap-3 px-4 py-3 font-semibold text-ink hover:bg-canvas [&::-webkit-details-marker]:hidden">
            <span className="text-h3">{item.question}</span>
            <ChevronDown
              aria-hidden="true"
              className="size-5 shrink-0 text-muted transition-transform duration-100 group-open:rotate-180"
            />
          </summary>
          <div className="prose-tool px-4 pb-4">{item.answer}</div>
        </details>
      ))}
    </div>
  );
}
