/**
 * Where a display ad may go (Phase 1 §8): after the result, never between inputs and
 * result, never sticky. No ad code exists yet.
 *
 * In production this renders nothing, so there is no empty gap on the page. With
 * NEXT_PUBLIC_SHOW_AD_PLACEHOLDERS=1 (development and layout testing) it renders a
 * clearly labelled box at the height a real unit will reserve, so layout shift can be
 * checked before ads exist.
 */
const SHOW_PLACEHOLDERS = process.env.NEXT_PUBLIC_SHOW_AD_PLACEHOLDERS === "1";

export function AdSlot({ id }: { id: string }) {
  if (!SHOW_PLACEHOLDERS) return null;
  return (
    <aside
      aria-label="Advertisement placeholder"
      data-ad-slot={id}
      className="flex min-h-[280px] items-center justify-center rounded-lg border border-dashed border-line-strong bg-canvas text-small text-muted lg:min-h-[250px]"
    >
      Ad space (development placeholder: {id})
    </aside>
  );
}
