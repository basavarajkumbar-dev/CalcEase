"use client";

import { Link } from "@/components/ui/link";
import {
  useDeferredValue,
  useId,
  useMemo,
  useRef,
  useState,
  type FormEvent,
  type KeyboardEvent,
} from "react";
import { useRouter } from "next/navigation";
import { Search } from "@/components/ui/icons";
import { Badge } from "@/components/ui/badge";
import { SEARCH_SUGGESTIONS, searchTools } from "@/lib/tools/search";
import { getCategory, isActive, TOOLS, toolHref } from "@/lib/tools/registry";

export interface SearchBoxProps {
  /** Focus the field on mount (when opened from the header). */
  autoFocus?: boolean;
  /** Called after the user opens a result (e.g. to close a panel). */
  onNavigate?: () => void;
  /** Larger field for the homepage. */
  size?: "md" | "lg";
}

/**
 * Searches the tool registry on the device: names, keywords, categories and
 * descriptions. Results are a plain list of links (not an ARIA combobox): simple and
 * robust with every screen reader. Keyboard: Enter opens the best active match; Down
 * arrow moves into the results, Up/Down move between them, Up from the first returns
 * to the field. Coming-soon tools are listed as text with a badge, never as links.
 * Nothing is written to the URL, so searches never create indexable pages.
 */
export function SearchBox({ autoFocus = false, onNavigate, size = "md" }: SearchBoxProps) {
  const id = useId();
  const router = useRouter();
  const input = useRef<HTMLInputElement>(null);
  const list = useRef<HTMLUListElement>(null);
  const [query, setQuery] = useState("");
  // The field updates immediately; the result list renders just after, without blocking
  // the keystroke (keeps typing responsive on slow phones; measured in the Phase 4 report).
  const deferredQuery = useDeferredValue(query);
  const results = useMemo(() => searchTools(deferredQuery, TOOLS), [deferredQuery]);
  const active = results.filter(isActive);
  const planned = results.length - active.length;
  const trimmed = deferredQuery.trim();

  function handleSubmit(event: FormEvent) {
    event.preventDefault();
    const best = searchTools(query, TOOLS).find(isActive);
    if (best) {
      onNavigate?.();
      router.push(toolHref(best));
    }
  }

  function resultLinks(): HTMLAnchorElement[] {
    return Array.from(list.current?.querySelectorAll("a") ?? []);
  }

  function onInputKey(event: KeyboardEvent<HTMLInputElement>) {
    if (event.key === "ArrowDown") {
      const first = resultLinks()[0];
      if (first) {
        event.preventDefault();
        first.focus();
      }
    }
  }

  function onListKey(event: KeyboardEvent<HTMLUListElement>) {
    if (event.key !== "ArrowDown" && event.key !== "ArrowUp") return;
    const links = resultLinks();
    const index = links.indexOf(document.activeElement as HTMLAnchorElement);
    if (index === -1) return;
    event.preventDefault();
    if (event.key === "ArrowDown") links.at(Math.min(index + 1, links.length - 1))?.focus();
    else if (index === 0) input.current?.focus();
    else links.at(index - 1)?.focus();
  }

  let status = "";
  if (trimmed) {
    if (results.length === 0) status = `No tools found for "${trimmed}".`;
    else {
      const parts = [];
      if (active.length > 0)
        parts.push(`${active.length} ${active.length === 1 ? "tool" : "tools"} found`);
      if (planned > 0) parts.push(`${planned} coming soon`);
      status = parts.join(", ") + ".";
    }
  }

  return (
    <search>
      <form onSubmit={handleSubmit}>
        <label htmlFor={id} className="text-label block text-ink">
          Search tools
        </label>
        <div className="relative mt-2">
          <Search
            aria-hidden="true"
            className="pointer-events-none absolute top-1/2 left-3 size-5 -translate-y-1/2 text-muted"
          />
          <input
            ref={input}
            id={id}
            type="search"
            enterKeyHint="search"
            autoComplete="off"
            spellCheck={false}
            autoFocus={autoFocus}
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            onKeyDown={onInputKey}
            placeholder="e.g. EMI, SIP, GST, age"
            aria-describedby={`${id}-status`}
            className={`block w-full rounded-md border border-line-strong bg-surface pr-3 pl-10 text-ink placeholder:text-muted hover:border-ink ${
              size === "lg" ? "min-h-13 text-lg" : "min-h-12 text-base"
            }`}
          />
        </div>
      </form>

      <p id={`${id}-status`} role="status" className="text-helper mt-2 empty:hidden">
        {status}
      </p>

      {trimmed && results.length === 0 && (
        <div className="mt-2">
          <p className="text-small text-muted">Try searching for:</p>
          <ul className="mt-1 flex flex-wrap gap-2">
            {SEARCH_SUGGESTIONS.map((suggestion) => (
              <li key={suggestion}>
                <button
                  type="button"
                  onClick={() => {
                    setQuery(suggestion);
                    input.current?.focus();
                  }}
                  className="text-small inline-flex min-h-11 items-center rounded-md border border-line-strong bg-surface px-3 font-medium text-ink hover:border-ink"
                >
                  {suggestion}
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}

      {results.length > 0 && (
        <ul
          ref={list}
          onKeyDown={onListKey}
          className="mt-2 divide-y divide-line rounded-md border border-line bg-surface"
        >
          {results.map((tool) => {
            const category = getCategory(tool.category).name;
            return (
              <li key={tool.id}>
                {isActive(tool) ? (
                  <Link
                    href={toolHref(tool)}
                    onClick={() => onNavigate?.()}
                    className="block min-h-11 px-4 py-3 no-underline hover:bg-canvas"
                  >
                    <span className="block font-semibold text-primary">{tool.name}</span>
                    <span className="text-small block text-muted">
                      {category}: {tool.shortDescription}
                    </span>
                  </Link>
                ) : (
                  <div className="px-4 py-3">
                    <span className="flex flex-wrap items-center gap-2">
                      <span className="font-semibold text-muted">{tool.name}</span>
                      <Badge>Coming soon</Badge>
                    </span>
                    <span className="text-small block text-muted">
                      {category}: {tool.shortDescription}
                    </span>
                  </div>
                )}
              </li>
            );
          })}
        </ul>
      )}
    </search>
  );
}
