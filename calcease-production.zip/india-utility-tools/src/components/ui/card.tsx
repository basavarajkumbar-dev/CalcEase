import type { ReactNode } from "react";

/** A bordered surface for a self-contained item (a tool in a list). Not for every section. */
export function Card({ children, className = "" }: { children: ReactNode; className?: string }) {
  return (
    <div className={`rounded-lg border border-line bg-surface p-4 md:p-6 ${className}`}>
      {children}
    </div>
  );
}
