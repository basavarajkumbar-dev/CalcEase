/**
 * Icons used by the site, drawn as plain inline SVG.
 *
 * Shapes are from Lucide (https://lucide.dev), ISC License,
 * Copyright (c) 2026 Lucide Icons and Contributors. Inlining them avoids shipping the
 * lucide-react runtime (React context and forwardRef wrappers) to every page through
 * the header (docs/design-system.md, "Icons"). To add an icon, copy its nodes from
 * lucide.dev and add an entry below.
 */
import type { SVGProps } from "react";

type IconNode = readonly (readonly ["path" | "circle" | "rect" | "line", Record<string, string>])[];

export type IconProps = Omit<SVGProps<SVGSVGElement>, "children"> & { strokeWidth?: number };

function icon(name: string, nodes: IconNode) {
  function Icon({ strokeWidth = 2, ...props }: IconProps) {
    return (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth={strokeWidth}
        strokeLinecap="round"
        strokeLinejoin="round"
        focusable="false"
        {...props}
      >
        {nodes.map(([Tag, attrs], index) => (
          <Tag key={index} {...attrs} />
        ))}
      </svg>
    );
  }
  Icon.displayName = name;
  return Icon;
}

export const Search = icon("Search", [
  ["path", { d: "m21 21-4.34-4.34" }],
  ["circle", { cx: "11", cy: "11", r: "8" }],
]);
export const Menu = icon("Menu", [
  ["path", { d: "M4 5h16" }],
  ["path", { d: "M4 12h16" }],
  ["path", { d: "M4 19h16" }],
]);
export const X = icon("X", [
  ["path", { d: "M18 6 6 18" }],
  ["path", { d: "m6 6 12 12" }],
]);
export const Share2 = icon("Share2", [
  ["circle", { cx: "18", cy: "5", r: "3" }],
  ["circle", { cx: "6", cy: "12", r: "3" }],
  ["circle", { cx: "18", cy: "19", r: "3" }],
  ["line", { x1: "8.59", x2: "15.42", y1: "13.51", y2: "17.49" }],
  ["line", { x1: "15.41", x2: "8.59", y1: "6.51", y2: "10.49" }],
]);
export const CircleAlert = icon("CircleAlert", [
  ["circle", { cx: "12", cy: "12", r: "10" }],
  ["line", { x1: "12", x2: "12", y1: "8", y2: "12" }],
  ["line", { x1: "12", x2: "12.01", y1: "16", y2: "16" }],
]);
export const TriangleAlert = icon("TriangleAlert", [
  ["path", { d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3" }],
  ["path", { d: "M12 9v4" }],
  ["path", { d: "M12 17h.01" }],
]);
export const Info = icon("Info", [
  ["circle", { cx: "12", cy: "12", r: "10" }],
  ["path", { d: "M12 16v-4" }],
  ["path", { d: "M12 8h.01" }],
]);
export const CircleCheck = icon("CircleCheck", [
  ["circle", { cx: "12", cy: "12", r: "10" }],
  ["path", { d: "m16 9-5.5 5.5L8 12" }],
]);
export const ChevronDown = icon("ChevronDown", [["path", { d: "m6 9 6 6 6-6" }]]);
export const ArrowUp = icon("ArrowUp", [
  ["path", { d: "m5 12 7-7 7 7" }],
  ["path", { d: "M12 19V5" }],
]);
export const ArrowDown = icon("ArrowDown", [
  ["path", { d: "M12 5v14" }],
  ["path", { d: "m19 12-7 7-7-7" }],
]);
export const ShieldCheck = icon("ShieldCheck", [
  [
    "path",
    {
      d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
    },
  ],
  ["path", { d: "m9 12 2 2 4-4" }],
]);
export const Lock = icon("Lock", [
  ["rect", { width: "18", height: "11", x: "3", y: "11", rx: "2", ry: "2" }],
  ["path", { d: "M7 11V7a5 5 0 0 1 10 0v4" }],
]);
export const Calculator = icon("Calculator", [
  ["rect", { width: "16", height: "20", x: "4", y: "2", rx: "2" }],
  ["line", { x1: "8", x2: "16", y1: "6", y2: "6" }],
  ["line", { x1: "16", x2: "16", y1: "14", y2: "18" }],
  ["path", { d: "M16 10h.01" }],
  ["path", { d: "M12 10h.01" }],
  ["path", { d: "M8 10h.01" }],
  ["path", { d: "M12 14h.01" }],
  ["path", { d: "M8 14h.01" }],
  ["path", { d: "M12 18h.01" }],
  ["path", { d: "M8 18h.01" }],
]);
export const Wallet = icon("Wallet", [
  [
    "path",
    {
      d: "M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1",
    },
  ],
  ["path", { d: "M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4" }],
]);
export const BriefcaseBusiness = icon("BriefcaseBusiness", [
  ["path", { d: "M12 12h.01" }],
  ["path", { d: "M16 6V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2" }],
  ["path", { d: "M22 13a18.15 18.15 0 0 1-20 0" }],
  ["rect", { width: "20", height: "14", x: "2", y: "6", rx: "2" }],
]);
export const CalendarDays = icon("CalendarDays", [
  ["path", { d: "M8 2v3" }],
  ["path", { d: "M16 2v3" }],
  ["rect", { x: "3", y: "3", width: "18", height: "18", rx: "2" }],
  ["path", { d: "M3 9h18" }],
  ["path", { d: "M8 13h.01" }],
  ["path", { d: "M12 13h.01" }],
  ["path", { d: "M16 13h.01" }],
  ["path", { d: "M8 17h.01" }],
  ["path", { d: "M12 17h.01" }],
  ["path", { d: "M16 17h.01" }],
]);
export const ListChecks = icon("ListChecks", [
  ["path", { d: "M13 5h8" }],
  ["path", { d: "M13 12h8" }],
  ["path", { d: "M13 19h8" }],
  ["path", { d: "m3 17 2 2 4-4" }],
  ["path", { d: "m3 7 2 2 4-4" }],
]);
