import type { ChangeEvent } from "react";
import { describedBy, FieldShell } from "./field-shell";

export interface DateInputProps {
  id: string;
  label: string;
  /** ISO yyyy-mm-dd, or "" when empty. */
  value: string;
  onChange: (value: string) => void;
  onBlur?: () => void;
  /** ISO bounds for the picker. */
  min: string;
  max: string;
  helperText?: string | undefined;
  error?: string | undefined;
}

/**
 * Native date picker: the phone's own calendar, keyboard-accessible, and shown in the
 * user's local date format while its value is always ISO yyyy-mm-dd.
 */
export function DateInput({
  id,
  label,
  value,
  onChange,
  onBlur,
  min,
  max,
  helperText,
  error,
}: DateInputProps) {
  return (
    <FieldShell id={id} label={label} helperText={helperText} error={error}>
      <input
        id={id}
        name={id}
        type="date"
        value={value}
        min={min}
        max={max}
        onChange={(event: ChangeEvent<HTMLInputElement>) => onChange(event.target.value)}
        onBlur={onBlur}
        aria-invalid={error ? true : undefined}
        aria-describedby={describedBy(id, helperText, error)}
        className={[
          "numeric block min-h-12 w-full min-w-0 rounded-md bg-surface px-3 text-lg text-ink",
          // iOS Safari renders date inputs centred and shrink-wrapped without these.
          "appearance-none text-left [&::-webkit-date-and-time-value]:text-left",
          error ? "border-2 border-error" : "border border-line-strong hover:border-ink",
        ].join(" ")}
      />
    </FieldShell>
  );
}
