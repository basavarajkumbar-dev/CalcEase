import { useId, type ReactNode } from "react";

export interface DataTableColumn<Row> {
  key: string;
  header: string;
  /** Right-align and use tabular figures (amounts, percentages). */
  numeric?: boolean;
  /** Render the cell; defaults to the row value at `key`. */
  cell: (row: Row) => ReactNode;
  /**
   * Supporting detail that can be dropped on phones (below 768px) to keep the essential
   * columns readable, e.g. the working behind an example. Never hide the answer.
   */
  hideOnMobile?: boolean;
}

export interface DataTableProps<Row> {
  /** Required: describes the table for everyone, including screen readers. */
  caption: string;
  columns: readonly DataTableColumn<Row>[];
  rows: readonly Row[];
  rowKey: (row: Row) => string;
  /**
   * Minimum width for tables that cannot fit a phone (e.g. a 6-column amortization
   * schedule). The table then scrolls inside its own labelled, focusable region and
   * says so; the page itself never scrolls sideways.
   */
  minWidth?: string;
}

export function DataTable<Row>({ caption, columns, rows, rowKey, minWidth }: DataTableProps<Row>) {
  const captionId = useId();
  const scrolls = Boolean(minWidth);
  return (
    <div className="rounded-lg border border-line bg-surface">
      {scrolls && (
        <p className="text-helper border-b border-line px-4 py-2">
          Scroll sideways to see all columns.
        </p>
      )}
      <div
        className="overflow-x-auto"
        {...(scrolls ? { role: "region", "aria-labelledby": captionId, tabIndex: 0 } : {})}
      >
        <table
          className="text-table w-full border-collapse"
          style={minWidth ? { minWidth } : undefined}
        >
          <caption
            id={captionId}
            className="text-small px-4 pt-3 pb-1 text-left font-semibold text-ink"
          >
            {caption}
          </caption>
          <thead>
            <tr className="border-b border-line">
              {columns.map((column) => (
                <th
                  key={column.key}
                  scope="col"
                  className={`px-4 py-2 align-bottom font-semibold text-muted ${column.numeric ? "text-right" : "text-left"} ${column.hideOnMobile ? "hidden md:table-cell" : ""}`}
                >
                  {column.header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr key={rowKey(row)} className="border-b border-line last:border-b-0">
                {columns.map((column, index) => {
                  const Cell = index === 0 ? "th" : "td";
                  return (
                    <Cell
                      key={column.key}
                      {...(index === 0 ? { scope: "row" } : {})}
                      className={`px-4 py-3 align-top ${index === 0 ? "font-medium" : ""} ${
                        column.numeric ? "numeric text-right whitespace-nowrap" : "text-left"
                      } ${column.hideOnMobile ? "hidden md:table-cell" : ""}`}
                    >
                      {column.cell(row)}
                    </Cell>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
