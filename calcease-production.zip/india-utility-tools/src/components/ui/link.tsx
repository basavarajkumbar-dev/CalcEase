import NextLink from "next/link";
import type { ComponentProps } from "react";

/**
 * The site's internal link. Same as next/link, except it does not prefetch pages
 * automatically when they scroll into view.
 *
 * Why: with many calculators, a page full of tool links (homepage, category hubs, /tools)
 * made Next.js download the code of every visible calculator in the background
 * (measured in Phase 5, wave 1: +14 KB on the homepage for two tools). Most visitors open
 * one tool, so on mobile data that is mostly waste. The page for a link now loads when it
 * is clicked; pages are static and small, so navigation stays quick.
 */
export function Link({ prefetch = false, ...props }: ComponentProps<typeof NextLink>) {
  return <NextLink prefetch={prefetch} {...props} />;
}
