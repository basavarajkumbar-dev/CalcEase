import type { ChangeEvent } from "react";
import { describedBy, FieldShell } from "./field-shell";

export interface NumberInputProps {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  onBlur?: () => void;
  /** Example value; shown as "e.g. 500". Never a substitute for the label. */
  example?: string | undefined;
  helperText?: string | undefined;
  /** Unit before the number, e.g. "₹". */
  prefix?: string | undefined;
  /** Unit after the number, e.g. "%" or "years". */
  suffix?: string | undefined;
  error?: string | undefined;
  disabled?: boolean;
}

/**
 * Numeric text input for every calculator (amounts, rates, percentages, years).
 * type="text" + inputMode="decimal" rather than type="number": number inputs reject
 * Indian grouping (1,25,000), change value on scroll, and silently drop invalid text.
 */
export function NumberInput({
  id,
  label,
  value,
  onChange,
  onBlur,
  example,
  helperText,
  prefix,
  suffix,
  error,
  disabled = false,
}: NumberInputProps) {
  return (
    <FieldShell id={id} label={label} helperText={helperText} error={error}>
      <div className="relative">
        {prefix && (
          <span
            aria-hidden="true"
            className="pointer-events-none absolute inset-y-0 left-3 flex items-center text-lg text-muted"
          >
            {prefix}
          </span>
        )}
        <input
          id={id}
          name={id}
          type="text"
          inputMode="decimal"
          autoComplete="off"
          enterKeyHint="done"
          spellCheck={false}
          value={value}
          disabled={disabled}
          placeholder={example ? `e.g. ${example}` : undefined}
          onChange={(event: ChangeEvent<HTMLInputElement>) => onChange(event.target.value)}
          onBlur={onBlur}
          aria-invalid={error ? true : undefined}
          aria-describedby={describedBy(id, helperText, error)}
          className={[
            "numeric block min-h-12 w-full rounded-md bg-surface text-lg text-ink transition-colors duration-100",
            "placeholder:text-muted disabled:cursor-not-allowed disabled:opacity-50",
            prefix ? "pl-8" : "pl-3",
            suffix ? "pr-14" : "pr-3",
            error ? "border-2 border-error" : "border border-line-strong hover:border-ink",
          ].join(" ")}
        />
        {suffix && (
          <span
            aria-hidden="true"
            className="pointer-events-none absolute inset-y-0 right-3 flex items-center text-lg text-muted"
          >
            {suffix}
          </span>
        )}
      </div>
    </FieldShell>
  );
}
