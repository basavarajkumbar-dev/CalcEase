import { Link } from "@/components/ui/link";
import type { ButtonHTMLAttributes, ReactNode } from "react";

export type ButtonVariant = "primary" | "secondary" | "ghost";
export type ButtonSize = "md" | "lg";

const BASE =
  "inline-flex items-center justify-center gap-2 rounded-md font-semibold no-underline transition-colors duration-100 select-none aria-disabled:cursor-not-allowed aria-disabled:opacity-50 disabled:cursor-not-allowed disabled:opacity-50";

const VARIANTS: Record<ButtonVariant, string> = {
  primary: "bg-primary text-white hover:bg-primary-hover hover:text-white active:bg-primary-active",
  secondary:
    "border border-line-strong bg-surface text-ink hover:border-ink hover:bg-canvas hover:text-ink active:bg-line",
  ghost: "text-primary hover:bg-primary-soft hover:text-primary-hover active:bg-primary-soft",
};

const SIZES: Record<ButtonSize, string> = {
  md: "min-h-11 min-w-11 px-4 text-base",
  lg: "min-h-12 min-w-12 px-5 text-base",
};

export function buttonClasses(
  variant: ButtonVariant = "primary",
  size: ButtonSize = "md",
  extra = "",
): string {
  return `${BASE} ${VARIANTS[variant]} ${SIZES[size]} ${extra}`.trim();
}

interface CommonProps {
  variant?: ButtonVariant;
  size?: ButtonSize;
  /** Icon shown before the text (decorative; give the button a text label). */
  icon?: ReactNode;
  className?: string;
  children: ReactNode;
}

export type ButtonProps = CommonProps &
  Omit<ButtonHTMLAttributes<HTMLButtonElement>, "className" | "children">;

/** A button. For navigation use ButtonLink, which renders a real link. */
export function Button({
  variant,
  size,
  icon,
  className = "",
  children,
  type = "button",
  ...rest
}: ButtonProps) {
  return (
    <button type={type} className={buttonClasses(variant, size, className)} {...rest}>
      {icon}
      {children}
    </button>
  );
}

export interface ButtonLinkProps extends CommonProps {
  href: string;
  /**
   * Fuller accessible name when the visible text is generic (e.g. "Open calculator" on a
   * card). Must start with the visible text (WCAG 2.5.3 Label in Name).
   */
  ariaLabel?: string;
}

/** A link styled as a button (e.g. "Open Percentage Calculator"). */
export function ButtonLink({
  href,
  variant,
  size,
  icon,
  className = "",
  ariaLabel,
  children,
}: ButtonLinkProps) {
  return (
    <Link href={href} aria-label={ariaLabel} className={buttonClasses(variant, size, className)}>
      {icon}
      {children}
    </Link>
  );
}
