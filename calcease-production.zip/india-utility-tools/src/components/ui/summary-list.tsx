export interface SummaryRow {
  label: string;
  value: string;
  /** Emphasise a total row. */
  strong?: boolean;
}

/** Label/value rows for secondary results and breakdowns (e.g. "Amount added: 100"). */
export function SummaryList({ rows }: { rows: readonly SummaryRow[] }) {
  return (
    <dl className="divide-y divide-line">
      {rows.map((row) => (
        <div key={row.label} className="flex items-baseline justify-between gap-4 py-2">
          <dt className="text-muted">{row.label}</dt>
          <dd
            className={`numeric text-right text-ink ${row.strong ? "font-bold" : "font-semibold"}`}
          >
            {row.value}
          </dd>
        </div>
      ))}
    </dl>
  );
}
