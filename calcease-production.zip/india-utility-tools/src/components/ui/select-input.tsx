import { ChevronDown } from "@/components/ui/icons";
import { describedBy, FieldShell } from "./field-shell";

export interface SelectOption {
  value: string;
  label: string;
}

export interface SelectInputProps {
  id: string;
  label: string;
  value: string;
  options: readonly SelectOption[];
  onChange: (value: string) => void;
  helperText?: string | undefined;
  disabled?: boolean;
}

/** Native select: accessible by default and opens the phone's own picker. */
export function SelectInput({
  id,
  label,
  value,
  options,
  onChange,
  helperText,
  disabled = false,
}: SelectInputProps) {
  return (
    <FieldShell id={id} label={label} helperText={helperText}>
      <div className="relative">
        <select
          id={id}
          name={id}
          value={value}
          disabled={disabled}
          onChange={(event) => onChange(event.target.value)}
          aria-describedby={describedBy(id, helperText)}
          className="block min-h-12 w-full appearance-none rounded-md border border-line-strong bg-surface py-2 pr-10 pl-3 text-base text-ink hover:border-ink disabled:cursor-not-allowed disabled:opacity-50"
        >
          {options.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
        <ChevronDown
          aria-hidden="true"
          className="pointer-events-none absolute top-1/2 right-3 size-5 -translate-y-1/2 text-muted"
        />
      </div>
    </FieldShell>
  );
}
