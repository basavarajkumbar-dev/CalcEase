"use client";

import { useEffect, useState } from "react";
import { Share2 } from "@/components/ui/icons";
import { shareOrCopy, type ShareData, type ShareOutcome } from "@/lib/share/share";
import { Button } from "./button";

export interface ShareButtonProps {
  /**
   * What to share. `url` defaults to the current page; pass a function to build the
   * link at the moment of sharing (e.g. with the calculator's current inputs).
   */
  data: Omit<ShareData, "url"> & { url?: string | (() => string) };
  label?: string;
}

const MESSAGES: Partial<Record<ShareOutcome, string>> = {
  copied: "Result and link copied",
  unavailable: "Couldn't share from this browser. Copy the result above instead.",
};

/**
 * Shares a result with the Web Share API (Android Chrome, iOS Safari), or copies it
 * to the clipboard where sharing is unavailable (most desktop browsers). The status
 * message is announced politely and cleared after a few seconds.
 */
export function ShareButton({ data, label = "Share result" }: ShareButtonProps) {
  const [status, setStatus] = useState<ShareOutcome | null>(null);

  useEffect(() => {
    if (!status) return;
    const timer = setTimeout(() => setStatus(null), 4000);
    return () => clearTimeout(timer);
  }, [status]);

  async function handleClick() {
    const url =
      typeof data.url === "function"
        ? data.url()
        : (data.url ?? window.location.href.split("#")[0]!);
    const full: ShareData = { title: data.title, text: data.text, url };
    const outcome = await shareOrCopy(full, {
      share: navigator.share ? (d) => navigator.share(d) : undefined,
      canShare: navigator.canShare ? (d) => navigator.canShare(d) : undefined,
      clipboard: navigator.clipboard,
    });
    setStatus(outcome);
  }

  const message = status ? MESSAGES[status] : undefined;

  return (
    <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
      <Button
        variant="secondary"
        onClick={handleClick}
        icon={<Share2 aria-hidden="true" className="size-5" />}
      >
        {label}
      </Button>
      <p
        role="status"
        className={`text-small ${status === "unavailable" ? "text-error" : "text-success"}`}
      >
        {message}
      </p>
    </div>
  );
}
