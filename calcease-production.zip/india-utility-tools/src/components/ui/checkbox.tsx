export interface CheckboxProps {
  id: string;
  label: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
  helperText?: string | undefined;
}

/** Native checkbox with the whole label row as a 44 px touch target. */
export function Checkbox({ id, label, checked, onChange, helperText }: CheckboxProps) {
  return (
    <div>
      <label htmlFor={id} className="flex min-h-11 cursor-pointer items-center gap-3 text-ink">
        <input
          id={id}
          name={id}
          type="checkbox"
          checked={checked}
          onChange={(event) => onChange(event.target.checked)}
          aria-describedby={helperText ? `${id}-helper` : undefined}
          className="size-5 shrink-0 accent-primary"
        />
        <span className="text-label">{label}</span>
      </label>
      {helperText && (
        <p id={`${id}-helper`} className="text-helper ml-8">
          {helperText}
        </p>
      )}
    </div>
  );
}
