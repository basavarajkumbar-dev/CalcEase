import type { ReactNode } from "react";

/** A small neutral status label, e.g. "Coming soon". Text, not colour, carries the meaning. */
export function Badge({ children }: { children: ReactNode }) {
  return (
    <span className="text-small inline-flex items-center rounded-sm border border-line bg-canvas px-2 py-0.5 font-medium whitespace-nowrap text-muted">
      {children}
    </span>
  );
}
