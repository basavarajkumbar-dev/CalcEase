import type { ReactNode } from "react";
import { CircleAlert, CircleCheck, Info, TriangleAlert } from "@/components/ui/icons";

export type CalloutTone = "info" | "warning" | "error" | "success";

const TONES: Record<
  CalloutTone,
  { box: string; icon: string; Icon: typeof Info; srLabel: string }
> = {
  info: { box: "border-info bg-info-soft", icon: "text-info", Icon: Info, srLabel: "Note" },
  warning: {
    box: "border-warning bg-warning-soft",
    icon: "text-warning",
    Icon: TriangleAlert,
    srLabel: "Warning",
  },
  error: {
    box: "border-error bg-error-soft",
    icon: "text-error",
    Icon: CircleAlert,
    srLabel: "Error",
  },
  success: {
    box: "border-success bg-success-soft",
    icon: "text-success",
    Icon: CircleCheck,
    srLabel: "Success",
  },
};

export interface CalloutProps {
  tone?: CalloutTone;
  title?: string;
  children: ReactNode;
  className?: string;
}

/**
 * A note set apart from the text: assumptions, limits, confirmations, problems.
 * Meaning is carried by the icon, the (screen-reader) tone label and the words,
 * not by colour alone.
 */
export function Callout({ tone = "info", title, children, className = "" }: CalloutProps) {
  const { box, icon, Icon, srLabel } = TONES[tone];
  return (
    <div className={`flex gap-3 rounded-md border-l-4 p-4 text-ink ${box} ${className}`}>
      <Icon aria-hidden="true" className={`mt-0.5 size-5 shrink-0 ${icon}`} />
      <div className="min-w-0">
        <span className="sr-only">{srLabel}: </span>
        {title && <p className="font-semibold">{title}</p>}
        <div className={title ? "mt-1" : ""}>{children}</div>
      </div>
    </div>
  );
}
