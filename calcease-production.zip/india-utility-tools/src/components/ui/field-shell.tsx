import type { ReactNode } from "react";
import { CircleAlert } from "@/components/ui/icons";

export interface FieldShellProps {
  /** id of the control; label, helper and error ids are derived from it. */
  id: string;
  label: string;
  helperText?: string | undefined;
  error?: string | undefined;
  children: ReactNode;
}

/** The ids a control must reference in aria-describedby. */
export function describedBy(id: string, helperText?: string, error?: string): string | undefined {
  const ids = [helperText ? `${id}-helper` : null, error ? `${id}-error` : null].filter(Boolean);
  return ids.length > 0 ? ids.join(" ") : undefined;
}

/**
 * Shared label → helper → control → error layout for every form field.
 * Not exported as separate Label/HelperText/ErrorMessage components because they
 * never appear outside a field (docs/design-system.md §7).
 */
export function FieldShell({ id, label, helperText, error, children }: FieldShellProps) {
  return (
    <div>
      <label htmlFor={id} className="text-label block text-ink">
        {label}
      </label>
      {helperText && (
        <p id={`${id}-helper`} className="text-helper mt-1">
          {helperText}
        </p>
      )}
      <div className="mt-2">{children}</div>
      {error && (
        <p
          id={`${id}-error`}
          className="text-small mt-2 flex items-start gap-1.5 font-medium text-error"
        >
          <CircleAlert aria-hidden="true" className="mt-0.5 size-4 shrink-0" />
          <span>{error}</span>
        </p>
      )}
    </div>
  );
}
