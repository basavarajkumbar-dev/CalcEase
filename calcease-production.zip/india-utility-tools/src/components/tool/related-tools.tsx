import { ToolCard } from "@/components/discovery/tool-card";
import { relatedActiveTools, type ActiveTool, type ReviewTool } from "@/lib/tools/registry";

/** Hand-picked related tools from the registry; only ones that can be opened today. */
export function RelatedTools({ tool }: { tool: ActiveTool | ReviewTool }) {
  const tools = relatedActiveTools(tool);
  if (tools.length === 0) return null;
  return (
    <ul className="grid gap-4 md:grid-cols-2">
      {tools.map((related) => (
        <li key={related.id}>
          <ToolCard tool={related} />
        </li>
      ))}
    </ul>
  );
}
