import type { ReactNode } from "react";
import { AdSlot } from "@/components/ads/ad-slot";
import { FaqList, type FaqItem } from "@/components/content/faq-list";
import { Breadcrumb } from "@/components/layout/breadcrumb";
import { Container } from "@/components/layout/container";
import { Section } from "@/components/layout/section";
import { Link } from "@/components/ui/link";
import {
  categoryHref,
  getCategory,
  relatedActiveTools,
  type ActiveTool,
  type ReviewTool,
} from "@/lib/tools/registry";
import { Callout } from "@/components/ui/callout";
import { breadcrumbJsonLd, JsonLd } from "@/seo/json-ld";
import { RelatedTools } from "./related-tools";

export interface ToolSection {
  id: string;
  title: string;
  content: ReactNode;
}

export interface ToolPageProps {
  tool: ActiveTool | ReviewTool;
  /** One or two sentences under the H1. */
  intro: ReactNode;
  /** The interactive calculator (a client component). */
  calculator: ReactNode;
  /** Explanation sections, in order: how it's calculated, worked examples, edge cases. */
  sections: readonly ToolSection[];
  faqs: readonly FaqItem[];
}

function formatReviewDate(iso: string): string {
  return new Intl.DateTimeFormat("en-IN", { dateStyle: "long", timeZone: "UTC" }).format(
    new Date(iso),
  );
}

/**
 * The standard tool page (Phase 1 §4): breadcrumb, H1, intro, calculator with result,
 * reserved ad position, explanation sections, FAQs, related tools, review details.
 * Every tool uses this so pages stay consistent from 1 tool to 50.
 */
export function ToolPage({ tool, intro, calculator, sections, faqs }: ToolPageProps) {
  const hasRelated = relatedActiveTools(tool).length > 0;
  const category = getCategory(tool.category);
  const hubHref = categoryHref(tool.category);
  const toc = [
    ...sections.map(({ id, title }) => ({ id, title })),
    ...(faqs.length > 0 ? [{ id: "faq", title: "Common questions" }] : []),
    ...(hasRelated ? [{ id: "related", title: "Related tools" }] : []),
  ];

  return (
    <Container className="pt-4 pb-8">
      {tool.status === "active" && (
        <JsonLd
          data={breadcrumbJsonLd([
            { name: "Home", path: "/" },
            ...(hubHref ? [{ name: category.name, path: hubHref }] : []),
            { name: tool.name, path: `/${tool.slug}` },
          ])}
        />
      )}
      <Breadcrumb
        items={[
          { name: "Home", href: "/" },
          { name: category.name, ...(hubHref ? { href: hubHref } : {}) },
          // The current page repeats the H1 directly below; hidden on phones to keep one line.
          { name: tool.name, hideOnMobile: true },
        ]}
      />

      <header className="mt-4 max-w-prose">
        <h1 className="text-h1 text-ink">{tool.name}</h1>
        <div className="mt-2 text-muted">{intro}</div>
      </header>

      {tool.status === "under-review" && (
        <Callout tone="warning" title="Under review: not published" className="mt-5 max-w-prose">
          <p>{tool.reviewNotice}</p>
        </Callout>
      )}

      <div className="mt-5">{calculator}</div>

      <div className="mt-8">
        <AdSlot id="after-result" />
      </div>

      <div className="mt-8 lg:mt-12 lg:grid lg:grid-cols-[minmax(0,1fr)_15rem] lg:gap-12">
        <div className="space-y-10 lg:space-y-12">
          {sections.map((section) => (
            <Section key={section.id} id={section.id} title={section.title}>
              <div className="prose-tool">{section.content}</div>
            </Section>
          ))}
          {faqs.length > 0 && (
            <Section id="faq" title="Common questions" className="max-w-prose">
              <FaqList items={faqs} />
            </Section>
          )}
          {hasRelated && (
            <Section id="related" title="Related tools" className="max-w-prose">
              <RelatedTools tool={tool} />
            </Section>
          )}
          <footer className="text-small max-w-prose border-t border-line pt-4 text-muted">
            {hubHref && (
              <p className="mb-2">
                Part of <Link href={hubHref}>{category.name}</Link>.{" "}
                <Link href="/tools">See all tools</Link>.
              </p>
            )}
            <p>
              Last reviewed on{" "}
              <time dateTime={tool.lastReviewed}>{formatReviewDate(tool.lastReviewed)}</time>.
              Formulas are tested against independently worked examples before publishing (
              <Link href="/methodology">how we calculate</Link>).
            </p>
            <p className="mt-2">
              Results are for general information and are not financial, tax or legal advice.
              Everything is calculated in your browser; nothing you enter is sent or stored.
            </p>
          </footer>
        </div>

        {toc.length > 1 && (
          <aside className="hidden lg:block">
            <nav aria-label="On this page" className="sticky top-6">
              <p className="text-small font-semibold text-ink">On this page</p>
              <ul className="mt-2 border-l border-line">
                {toc.map((item) => (
                  <li key={item.id}>
                    <a
                      href={`#${item.id}`}
                      className="text-small -ml-px block border-l-2 border-transparent py-1.5 pl-3 text-muted no-underline hover:border-primary hover:text-primary"
                    >
                      {item.title}
                    </a>
                  </li>
                ))}
              </ul>
            </nav>
          </aside>
        )}
      </div>
    </Container>
  );
}
