import { Link } from "@/components/ui/link";
import { Badge } from "@/components/ui/badge";
import { CATEGORIES, activeToolsInCategory, categoryHref, toolHref } from "@/lib/tools/registry";
import { CategoryIcon } from "./category-icon";

/**
 * Categories with their active tools, for the header's Categories panel and the mobile
 * menu. Categories without a hub are listed as "Coming soon", not linked.
 */
export function CategoryNavList({ showTools = false }: { showTools?: boolean }) {
  return (
    <ul className="divide-y divide-line">
      {CATEGORIES.map((category) => {
        const href = categoryHref(category.id);
        const tools = activeToolsInCategory(category.id);
        return (
          <li key={category.id} className="py-2">
            {href ? (
              <Link
                href={href}
                className="flex min-h-11 items-center gap-3 font-semibold no-underline"
              >
                <CategoryIcon category={category.id} className="size-5" />
                {category.name}
              </Link>
            ) : (
              <span className="flex min-h-11 items-center gap-3 font-semibold text-muted">
                <CategoryIcon category={category.id} className="size-5" />
                {category.name}
                <Badge>Coming soon</Badge>
              </span>
            )}
            {showTools && tools.length > 0 && (
              <ul className="ml-8">
                {tools.map((tool) => (
                  <li key={tool.id}>
                    <Link
                      href={toolHref(tool)}
                      className="flex min-h-11 items-center text-ink no-underline hover:text-primary"
                    >
                      {tool.name}
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </li>
        );
      })}
    </ul>
  );
}
