import type { Metadata } from "next";
import { Link } from "@/components/ui/link";
import { CategoryIcon } from "./category-icon";
import { ToolCard } from "./tool-card";
import { Breadcrumb } from "@/components/layout/breadcrumb";
import { breadcrumbJsonLd, JsonLd } from "@/seo/json-ld";
import { Container } from "@/components/layout/container";
import { Section } from "@/components/layout/section";
import { Badge } from "@/components/ui/badge";
import {
  activeToolsInCategory,
  CATEGORIES,
  categoryHref,
  getCategory,
  hasHub,
  plannedToolsInCategory,
  type ToolCategory,
} from "@/lib/tools/registry";
import { pageMetadata } from "@/seo/page-metadata";

/** Metadata for a category hub page (see src/app/[category]/page.tsx). */
export function categoryHubMetadata(id: ToolCategory): Metadata {
  const category = getCategory(id);
  return pageMetadata({
    title: category.title,
    description: category.metaDescription,
    path: `/${category.slug}`,
  });
}

/** A category hub: its active tools, what is coming next, and the other categories. */
export function CategoryHub({ id }: { id: ToolCategory }) {
  const category = getCategory(id);
  if (!hasHub(id))
    throw new Error(`Category ${id} has no active tools and must not have a hub page`);
  const tools = activeToolsInCategory(category.id);
  const planned = plannedToolsInCategory(category.id);
  const others = CATEGORIES.filter((c) => c.id !== category.id);

  return (
    <Container className="pt-4 pb-8">
      <JsonLd
        data={breadcrumbJsonLd([
          { name: "Home", path: "/" },
          { name: category.name, path: `/${category.slug}` },
        ])}
      />
      <Breadcrumb items={[{ name: "Home", href: "/" }, { name: category.name }]} />
      <header className="mt-4 max-w-prose">
        <h1 className="text-h1 flex items-center gap-3 text-ink">
          <CategoryIcon category={category.id} className="size-8" />
          {category.name}
        </h1>
        <p className="mt-2 text-lg text-muted">{category.description}</p>
      </header>

      <div className="mt-8 space-y-10 md:space-y-12">
        <Section id="tools" title={tools.length === 1 ? "Calculator" : "Calculators"}>
          <ul className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {tools.map((tool) => (
              <li key={tool.id}>
                <ToolCard tool={tool} showCategory={false} />
              </li>
            ))}
          </ul>
        </Section>

        {planned.length > 0 && (
          <Section id="coming-soon" title="Coming next">
            <ul className="max-w-prose divide-y divide-line border-y border-line">
              {planned.map((tool) => (
                <li
                  key={tool.id}
                  className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1 py-3"
                >
                  <span>
                    <span className="block font-semibold text-ink">{tool.name}</span>
                    <span className="text-small block text-muted">{tool.shortDescription}</span>
                  </span>
                  <Badge>Coming soon</Badge>
                </li>
              ))}
            </ul>
          </Section>
        )}

        <Section id="other-categories" title="Other categories">
          <ul className="flex max-w-prose flex-wrap gap-x-6 gap-y-2">
            {others.map((other) => {
              const href = categoryHref(other.id);
              return (
                <li key={other.id} className="flex min-h-11 items-center gap-2">
                  {href ? (
                    <Link href={href}>{other.name}</Link>
                  ) : (
                    <>
                      <span className="text-muted">{other.name}</span>
                      <Badge>Coming soon</Badge>
                    </>
                  )}
                </li>
              );
            })}
          </ul>
          <p className="mt-4 max-w-prose text-muted">
            Every calculator shows its formula and working.{" "}
            <Link href="/methodology">How we calculate and check results</Link>.
          </p>
        </Section>
      </div>
    </Container>
  );
}
