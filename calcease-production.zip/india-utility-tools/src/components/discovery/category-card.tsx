import { Link } from "@/components/ui/link";
import { Badge } from "@/components/ui/badge";
import {
  activeToolsInCategory,
  categoryHref,
  plannedToolsInCategory,
  type CategoryDefinition,
} from "@/lib/tools/registry";
import { CategoryIcon } from "./category-icon";

/**
 * A category in a list. Categories with a hub link to it and say how many calculators
 * it has; categories without active tools are not links and say what is coming.
 */
export function CategoryCard({ category }: { category: CategoryDefinition }) {
  const href = categoryHref(category.id);
  const active = activeToolsInCategory(category.id).length;
  const planned = plannedToolsInCategory(category.id);

  const body = (
    <>
      <span className="flex items-start gap-3">
        <CategoryIcon category={category.id} className="mt-0.5 size-6" />
        <span className="min-w-0 flex-1">
          <span className={`text-h3 block ${href ? "text-primary" : "text-ink"}`}>
            {category.name}
          </span>
          <span className="mt-1 block text-muted">{category.shortDescription}</span>
        </span>
      </span>
      <span className="text-small mt-3 block text-muted">
        {href ? (
          `${active} ${active === 1 ? "calculator" : "calculators"}${planned.length > 0 ? `, ${planned.length} more coming` : ""}`
        ) : (
          <span className="flex flex-wrap items-center gap-2">
            <Badge>Coming soon</Badge>
            <span>{planned.map((tool) => tool.name.replace(/ Calculator$/, "")).join(", ")}</span>
          </span>
        )}
      </span>
    </>
  );

  return href ? (
    <Link
      href={href}
      className="block h-full rounded-lg border border-line bg-surface p-4 no-underline hover:border-primary md:p-6"
    >
      {body}
    </Link>
  ) : (
    <div className="h-full rounded-lg border border-dashed border-line bg-canvas p-4 md:p-6">
      {body}
    </div>
  );
}
