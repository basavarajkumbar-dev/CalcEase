import { ButtonLink } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { getCategory, isActive, toolHref, type ToolDefinition } from "@/lib/tools/registry";
import { CategoryIcon } from "./category-icon";

export interface ToolCardProps {
  tool: ToolDefinition;
  /** Show the category name above the tool name (homepage, search); hide it on category hubs. */
  showCategory?: boolean;
  /** Heading level for the tool name, to fit the page outline. */
  headingLevel?: "h2" | "h3";
}

/**
 * A tool in a list. Active tools get one clear action ("Open calculator"); coming-soon
 * tools are shown muted with a "Coming soon" badge and no link, so nobody can reach a
 * page that does not exist.
 */
export function ToolCard({ tool, showCategory = true, headingLevel = "h3" }: ToolCardProps) {
  const Heading = headingLevel;
  const category = getCategory(tool.category);
  const active = isActive(tool);

  return (
    <article
      className={`flex h-full flex-col rounded-lg border p-4 md:p-6 ${
        active ? "border-line bg-surface" : "border-dashed border-line bg-canvas"
      }`}
    >
      {showCategory && (
        <p className="text-small flex items-center gap-2 text-muted">
          <CategoryIcon category={tool.category} className="size-4" />
          {category.name}
        </p>
      )}
      <div className={`flex flex-wrap items-center gap-x-3 gap-y-1 ${showCategory ? "mt-2" : ""}`}>
        <Heading className={`text-h3 ${active ? "text-ink" : "text-muted"}`}>{tool.name}</Heading>
        {!active && <Badge>Coming soon</Badge>}
      </div>
      <p className={`mt-2 flex-1 ${active ? "text-ink" : "text-muted"}`}>{tool.shortDescription}</p>
      {active && (
        <div className="mt-4">
          <ButtonLink href={toolHref(tool)} ariaLabel={`Open calculator: ${tool.name}`}>
            Open calculator
          </ButtonLink>
        </div>
      )}
    </article>
  );
}
