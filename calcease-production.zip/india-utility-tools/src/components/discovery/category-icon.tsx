import type { ToolCategory } from "@/lib/tools/registry";
import {
  BriefcaseBusiness,
  Calculator,
  CalendarDays,
  Wallet,
  type IconProps,
} from "@/components/ui/icons";

const ICONS: Record<ToolCategory, (props: IconProps) => React.JSX.Element> = {
  finance: Wallet,
  salary: BriefcaseBusiness,
  math: Calculator,
  "date-time": CalendarDays,
};

/** The icon for a category. Decorative: always paired with the category name. */
export function CategoryIcon({
  category,
  className = "size-6",
}: {
  category: ToolCategory;
  className?: string;
}) {
  const Icon = ICONS[category];
  return <Icon aria-hidden="true" className={`shrink-0 text-primary ${className}`} />;
}
