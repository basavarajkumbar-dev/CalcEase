import { Link } from "@/components/ui/link";
import { toolHref, type ActiveTool } from "@/lib/tools/registry";
import { CategoryIcon } from "./category-icon";

/**
 * A compact, fully clickable link to a calculator (homepage highlights). The whole tile is
 * one link, so it is a large touch target with a single, clear accessible name.
 */
export function ToolTile({ tool }: { tool: ActiveTool }) {
  return (
    <Link
      href={toolHref(tool)}
      className="group flex h-full items-start gap-3 rounded-lg border border-line bg-surface p-4 no-underline transition-colors duration-100 hover:border-primary md:p-5"
    >
      <span className="mt-0.5 flex size-10 shrink-0 items-center justify-center rounded-md bg-primary-soft">
        <CategoryIcon category={tool.category} className="size-5" />
      </span>
      <span className="min-w-0">
        <span className="text-h3 block text-ink group-hover:text-primary">{tool.name}</span>
        <span className="text-small mt-1 block text-muted">{tool.shortDescription}</span>
      </span>
    </Link>
  );
}
