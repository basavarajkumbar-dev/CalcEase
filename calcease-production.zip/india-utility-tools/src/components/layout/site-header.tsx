import { Link } from "@/components/ui/link";
import { SITE_PAGES } from "@/config/site";
import { CategoryNavList } from "@/components/discovery/category-nav-list";
import { BrandLink } from "./brand-link";
import { Container } from "./container";
import { HeaderPanels } from "./header-panels";
import { MobileMenu } from "./mobile-menu";

/**
 * Desktop (≥1024px): brand, All tools, Categories, Search tools.
 * Phones and tablets: brand, search button, menu button.
 * Navigation content is rendered on the server and passed to the small client islands.
 */
export function SiteHeader() {
  return (
    <header className="relative border-b border-line bg-surface">
      <Container className="flex min-h-14 items-center justify-between gap-3">
        <BrandLink />
        <div className="flex items-center gap-1">
          <nav aria-label="Main" className="hidden lg:block">
            <Link
              href="/tools"
              className="inline-flex min-h-11 items-center px-3 font-semibold text-ink no-underline hover:text-primary"
            >
              All tools
            </Link>
          </nav>
          <HeaderPanels categories={<CategoryNavList />} />
          <MobileMenu brand={<BrandLink />}>
            <p className="text-small mt-4 font-semibold text-muted">Categories</p>
            <CategoryNavList showTools />
            <ul className="mt-2 border-t border-line pt-2">
              <li>
                <Link
                  href="/tools"
                  className="flex min-h-11 items-center font-semibold no-underline"
                >
                  All tools
                </Link>
              </li>
              {SITE_PAGES.filter((page) => page.group === "about").map((page) => (
                <li key={page.id}>
                  <Link
                    href={page.href}
                    className="flex min-h-11 items-center text-ink no-underline hover:text-primary"
                  >
                    {page.name}
                  </Link>
                </li>
              ))}
            </ul>
          </MobileMenu>
        </div>
      </Container>
    </header>
  );
}
