import { Link } from "@/components/ui/link";
import { Lock } from "@/components/ui/icons";
import { SITE_NAME, SITE_PAGES, SITE_TAGLINE } from "@/config/site";
import { activeTools, categoriesWithHubs, toolHref } from "@/lib/tools/registry";
import { Container } from "./container";

interface FooterGroup {
  title: string;
  links: { name: string; href: string }[];
}

/** Footer navigation, generated from the tool registry and the site-page list. */
export function SiteFooter() {
  const groups: FooterGroup[] = [
    {
      title: "Tools",
      links: [
        ...activeTools().map((tool) => ({ name: tool.name, href: toolHref(tool) })),
        { name: "All tools", href: "/tools" },
      ],
    },
    {
      title: "Categories",
      links: categoriesWithHubs().map((category) => ({
        name: category.name,
        href: `/${category.slug}`,
      })),
    },
    {
      title: "About",
      links: SITE_PAGES.filter((page) => page.group === "about").map(({ name, href }) => ({
        name,
        href,
      })),
    },
    {
      title: "Legal",
      links: SITE_PAGES.filter((page) => page.group === "legal").map(({ name, href }) => ({
        name,
        href,
      })),
    },
  ].filter((group) => group.links.length > 0);

  return (
    <footer className="mt-16 border-t border-line bg-surface">
      <Container className="py-8 md:py-12">
        <div className="grid gap-8 lg:grid-cols-[1.2fr_3fr]">
          <div>
            <p className="font-bold text-ink">{SITE_NAME}</p>
            <p className="text-small mt-1 text-muted">{SITE_TAGLINE}</p>
            <p className="text-small mt-2 flex max-w-narrow gap-2 text-muted">
              <Lock aria-hidden="true" className="mt-0.5 size-4 shrink-0" />
              <span>
                Calculations run in your browser. Nothing you enter is sent to a server or stored.
              </span>
            </p>
          </div>
          <div className="grid grid-cols-2 gap-x-6 gap-y-6 md:grid-cols-4">
            {groups.map((group) => (
              <nav key={group.title} aria-label={`Footer: ${group.title}`}>
                <h2 className="text-small font-semibold text-ink">{group.title}</h2>
                <ul className="mt-1">
                  {group.links.map((link) => (
                    <li key={link.href}>
                      <Link
                        href={link.href}
                        className="text-small inline-flex min-h-11 min-w-11 items-center"
                      >
                        {link.name}
                      </Link>
                    </li>
                  ))}
                </ul>
              </nav>
            ))}
          </div>
        </div>
        <p className="text-small mt-8 border-t border-line pt-6 text-muted">
          © {new Date().getFullYear()} {SITE_NAME}. Results are estimates for general information,
          not financial, tax or legal advice.
        </p>
      </Container>
    </footer>
  );
}
