import { Link } from "@/components/ui/link";

export interface Crumb {
  name: string;
  /** Omit for the current page, or for a level that has no page yet (no dead links). */
  href?: string;
  /** Hide this level on phones to keep the trail on one line (it stays on wider screens). */
  hideOnMobile?: boolean;
}

/** Breadcrumb trail. Wraps onto a second line instead of overflowing on narrow screens. */
export function Breadcrumb({ items }: { items: readonly Crumb[] }) {
  return (
    <nav aria-label="Breadcrumb" className="text-small text-muted">
      <ol className="flex flex-wrap items-center gap-x-2 gap-y-1">
        {items.map((item, index) => {
          const isCurrent = index === items.length - 1;
          return (
            <li
              key={item.name}
              className={`items-center gap-2 ${item.hideOnMobile ? "hidden md:flex" : "flex"}`}
            >
              {index > 0 && (
                <span aria-hidden="true" className="text-line-strong">
                  /
                </span>
              )}
              {isCurrent ? (
                <span aria-current="page" className="text-ink">
                  {item.name}
                </span>
              ) : item.href ? (
                <Link
                  href={item.href}
                  className="inline-flex min-h-6 items-center text-muted hover:text-primary"
                >
                  {item.name}
                </Link>
              ) : (
                <span>{item.name}</span>
              )}
            </li>
          );
        })}
      </ol>
    </nav>
  );
}
