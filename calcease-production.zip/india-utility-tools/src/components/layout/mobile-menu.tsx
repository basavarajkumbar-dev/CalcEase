"use client";

import { useRef, useState, type ReactNode } from "react";
import { Menu, X } from "@/components/ui/icons";

/**
 * Full-screen navigation for phones and tablets, built on the native <dialog> element:
 * showModal() makes the rest of the page inert (focus stays in the menu), Escape closes
 * it, and the browser returns focus to the Menu button. Background scrolling is locked
 * in CSS while it is open (`html:has(dialog[open])`).
 */
export function MobileMenu({ brand, children }: { brand: ReactNode; children: ReactNode }) {
  const dialog = useRef<HTMLDialogElement>(null);
  const [open, setOpen] = useState(false);

  function show() {
    dialog.current?.showModal();
    setOpen(true);
  }

  function hide() {
    dialog.current?.close();
  }

  return (
    <>
      <button
        type="button"
        className="inline-flex min-h-11 min-w-11 items-center justify-center rounded-md px-2 text-ink hover:bg-canvas lg:hidden"
        aria-haspopup="dialog"
        aria-expanded={open}
        aria-controls="mobile-menu"
        onClick={show}
      >
        <Menu aria-hidden="true" className="size-6" />
        <span className="sr-only">Menu</span>
      </button>
      <dialog
        ref={dialog}
        id="mobile-menu"
        aria-label="Menu"
        onClose={() => setOpen(false)}
        onClick={(event) => {
          if ((event.target as HTMLElement).closest("a")) hide();
        }}
        className="m-0 h-dvh max-h-none w-full max-w-none bg-surface p-0 text-ink backdrop:bg-transparent"
      >
        <div className="flex min-h-14 items-center justify-between gap-3 border-b border-line px-4 md:px-6">
          {brand}
          <button
            type="button"
            autoFocus
            onClick={hide}
            className="inline-flex min-h-11 min-w-11 items-center justify-center rounded-md px-2 text-ink hover:bg-canvas"
          >
            <X aria-hidden="true" className="size-6" />
            <span className="sr-only">Close menu</span>
          </button>
        </div>
        <nav aria-label="Menu" className="overflow-y-auto px-4 pb-8 md:px-6">
          {children}
        </nav>
      </dialog>
    </>
  );
}
