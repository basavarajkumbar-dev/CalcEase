import type { ReactNode } from "react";

export interface SectionProps {
  /** Anchor id; also used by the page's "On this page" list. */
  id: string;
  title: string;
  children: ReactNode;
  className?: string;
}

/** A titled content section. Vertical rhythm between sections lives here, nowhere else. */
export function Section({ id, title, children, className = "" }: SectionProps) {
  return (
    <section aria-labelledby={`${id}-title`} className={`scroll-mt-4 ${className}`} id={id}>
      <h2 id={`${id}-title`} className="text-h2 text-ink">
        {title}
      </h2>
      <div className="mt-4">{children}</div>
    </section>
  );
}
