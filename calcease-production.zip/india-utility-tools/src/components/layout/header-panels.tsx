"use client";

import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import { ChevronDown, Search, X } from "@/components/ui/icons";
import { SearchBox } from "@/components/search/search-box";
import { Container } from "./container";

type Panel = "search" | "categories" | null;

/** Shared look; the display value is set per button so `hidden lg:inline-flex` can't conflict. */
const triggerLook =
  "min-h-11 min-w-11 items-center justify-center gap-2 rounded-md px-2 font-semibold text-ink hover:bg-canvas aria-expanded:bg-primary-soft aria-expanded:text-primary";

/**
 * Header disclosure panels: search (all sizes) and categories (desktop). One open at a
 * time. Escape closes and returns focus to the button that opened the panel; choosing a
 * link, clicking outside the header, or tabbing out of it closes it too.
 */
export function HeaderPanels({ categories }: { categories: ReactNode }) {
  const [open, setOpen] = useState<Panel>(null);
  const root = useRef<HTMLDivElement>(null);
  const searchButton = useRef<HTMLButtonElement>(null);
  const categoriesButton = useRef<HTMLButtonElement>(null);

  const close = useCallback((returnFocus: boolean) => {
    setOpen((current) => {
      if (returnFocus)
        (current === "categories" ? categoriesButton : searchButton).current?.focus();
      return null;
    });
  }, []);

  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") close(true);
    };
    const onPointer = (event: PointerEvent) => {
      if (!root.current?.closest("header")?.contains(event.target as Node)) close(false);
    };
    document.addEventListener("keydown", onKey);
    document.addEventListener("pointerdown", onPointer);
    return () => {
      document.removeEventListener("keydown", onKey);
      document.removeEventListener("pointerdown", onPointer);
    };
  }, [open, close]);

  const toggle = (panel: Exclude<Panel, null>) =>
    setOpen((current) => (current === panel ? null : panel));

  const panelClass =
    "absolute inset-x-0 top-full z-20 border-b border-line bg-surface-raised py-4 shadow-raised motion-safe:animate-[panel-in_120ms_ease-out]";

  return (
    <div
      ref={root}
      className="flex items-center gap-1"
      onBlur={(event) => {
        const header = root.current?.closest("header");
        if (event.relatedTarget && header && !header.contains(event.relatedTarget as Node))
          close(false);
      }}
      onClick={(event) => {
        if ((event.target as HTMLElement).closest("a")) close(false);
      }}
    >
      <button
        ref={categoriesButton}
        type="button"
        className={`${triggerLook} hidden lg:inline-flex`}
        aria-expanded={open === "categories"}
        aria-controls="header-categories-panel"
        onClick={() => toggle("categories")}
      >
        Categories
        <ChevronDown
          aria-hidden="true"
          className={`size-5 transition-transform duration-100 ${open === "categories" ? "rotate-180" : ""}`}
        />
      </button>
      <button
        ref={searchButton}
        type="button"
        className={`${triggerLook} inline-flex`}
        aria-expanded={open === "search"}
        aria-controls="header-search-panel"
        onClick={() => toggle("search")}
      >
        {open === "search" ? (
          <X aria-hidden="true" className="size-6" />
        ) : (
          <Search aria-hidden="true" className="size-6" />
        )}
        <span className="sr-only lg:not-sr-only">Search tools</span>
      </button>

      {open === "search" && (
        <div id="header-search-panel" className={panelClass}>
          <Container className="max-w-prose">
            <SearchBox autoFocus onNavigate={() => close(false)} />
          </Container>
        </div>
      )}
      {open === "categories" && (
        <div id="header-categories-panel" className={`${panelClass} hidden lg:block`}>
          <Container>
            <nav aria-label="Categories" className="max-w-narrow">
              {categories}
            </nav>
          </Container>
        </div>
      )}
    </div>
  );
}
