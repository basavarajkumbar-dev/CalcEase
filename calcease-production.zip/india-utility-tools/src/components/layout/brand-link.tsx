import { Link } from "@/components/ui/link";
import { SITE_NAME } from "@/config/site";

export function BrandLink() {
  return (
    <Link
      href="/"
      aria-label={`${SITE_NAME} home`}
      className="flex min-h-11 items-center gap-2 text-lg font-bold text-ink no-underline hover:text-ink"
    >
      <svg aria-hidden="true" viewBox="0 0 32 32" className="size-8 shrink-0">
        <rect width="32" height="32" rx="8" fill="var(--color-primary)" />
        <path
          d="M8 13.5h16M10 18.5h12M12.5 23.5h7"
          stroke="#fff"
          strokeWidth="2.6"
          strokeLinecap="round"
        />
        <circle cx="16" cy="8.5" r="2" fill="#fff" />
      </svg>
      <span className="tracking-tight">
        Calc<span className="text-primary">Ease</span>
      </span>
    </Link>
  );
}
