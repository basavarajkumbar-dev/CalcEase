import type { ReactNode } from "react";

/** Page column: 16px gutters on phones, 24px from 768px, 1152px maximum width. */
export function Container({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  return <div className={`mx-auto w-full max-w-page px-4 md:px-6 ${className}`}>{children}</div>;
}
