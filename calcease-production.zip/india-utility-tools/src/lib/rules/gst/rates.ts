/**
 * GST rate presets, versioned. Values are taken only from the official sources listed,
 * never from memory. Add a new entry (and set `effectiveTo` on the old one) when the GST
 * Council changes the rate structure.
 */
import { ruleSetOn, type RuleSetMeta } from "../types";

export interface GstPreset {
  /** Rate in percent. */
  rate: number;
  /** Name used in the official source. */
  name: string;
}

export interface GstRuleSet extends RuleSetMeta {
  presets: readonly GstPreset[];
}

export const GST_RULE_SETS: readonly GstRuleSet[] = [
  {
    version: "2025-09-22",
    effectiveFrom: "2025-09-22",
    reviewedOn: "2026-10-07",
    presets: [
      { rate: 5, name: "Merit rate" },
      { rate: 18, name: "Standard rate" },
      { rate: 40, name: "Special de-merit rate" },
    ],
    sources: [
      {
        name: "Press Information Bureau: Recommendations of the 56th Meeting of the GST Council (3 September 2025)",
        url: "https://www.pib.gov.in/PressReleasePage.aspx?PRID=2163555",
        retrieved: "2026-10-07",
      },
      {
        name: "GST Council: Recommendations of the 56th Meeting of the GST Council",
        url: "https://gstcouncil.gov.in/recommendations-56th-meeting-gst-council-held-new-delhi",
        retrieved: "2026-10-07",
      },
    ],
    notes: [
      "The 56th GST Council replaced the 4-tier structure with a standard rate of 18%, a merit rate of 5% and a special de-merit rate of 40% for a select few goods and services, plus nil-rated items.",
      "Effective 22 September 2025 for services and for all goods except pan masala, gutkha, cigarettes, chewing tobacco products, unmanufactured tobacco and bidi, which continued at their existing rates for a transition period.",
      "Some goods carry special rates outside these presets (for example precious metals and stones). These are not offered as presets because they were not confirmed from a primary source; enter them with “Other rate”.",
      "The rate for a specific product or service depends on its HSN or SAC classification. Check the applicable notification or the invoice.",
    ],
  },
];

/** The rule set in force on a date. */
export function gstRulesOn(isoDate: string): GstRuleSet | undefined {
  return ruleSetOn(GST_RULE_SETS, isoDate);
}

/** The newest rule set (used by the calculator, which works with current rates). */
export const CURRENT_GST_RULES: GstRuleSet = GST_RULE_SETS[GST_RULE_SETS.length - 1]!;
