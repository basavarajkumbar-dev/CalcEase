/**
 * Shape shared by every set of regulatory rule data (GST, income tax, PF, professional
 * tax …). Rule values never live inside formulas: calculators receive them from a
 * versioned rule set, and every set records where its values come from.
 */
export interface RuleSource {
  /** Human-readable name of the official document. */
  name: string;
  url: string;
  /** Date the source was read and checked (ISO). */
  retrieved: string;
}

export interface RuleSetMeta {
  /** Identifier for this version, usually its effective date. */
  version: string;
  /** First date the rules apply (ISO). */
  effectiveFrom: string;
  /** Last date they apply, if they have been replaced (ISO). */
  effectiveTo?: string;
  /** Date a person last checked these values against the sources (ISO). */
  reviewedOn: string;
  sources: readonly RuleSource[];
  /** Assumptions, exceptions and anything the user must know. */
  notes: readonly string[];
}

/** Picks the rule set in force on a date (ISO yyyy-mm-dd compares correctly as text). */
export function ruleSetOn<T extends RuleSetMeta>(
  sets: readonly T[],
  isoDate: string,
): T | undefined {
  return sets.find(
    (s) => s.effectiveFrom <= isoDate && (s.effectiveTo === undefined || isoDate <= s.effectiveTo),
  );
}
