/**
 * Income-tax rates for salaried individuals (resident, below 60), versioned.
 *
 * STATUS: UNDER REVIEW. Values were taken only from the official sources listed and have
 * NOT been reviewed by a chartered accountant. The CTC calculator that uses them is
 * excluded from production builds until that review is done (docs/reviews/ctc-to-in-hand.md).
 */
import { ruleSetOn, type RuleSetMeta } from "../types";

export interface TaxSlab {
  /** Upper limit of the slab in rupees (inclusive); null for the top slab. */
  upTo: number | null;
  /** Rate in percent. */
  rate: number;
}

export interface RegimeRules {
  slabs: readonly TaxSlab[];
  /** Standard deduction from salary, in rupees. */
  standardDeduction: number;
  /** Full rebate up to this taxable income. */
  rebateIncomeLimit: number;
  /** Largest rebate. */
  rebateMax: number;
  /** Above the limit, tax is capped at the income over the limit (new regime only). */
  rebateMarginalRelief: boolean;
  /** Whether professional tax paid is deducted from salary income in this regime. */
  professionalTaxDeductible: boolean;
}

export interface IncomeTaxRuleSet extends RuleSetMeta {
  status: "under-review";
  /** Financial / tax year label, e.g. "2026-27". */
  taxYear: string;
  newRegime: RegimeRules;
  oldRegime: RegimeRules;
  /** Health and Education Cess, percent of tax (and surcharge). */
  cessRate: number;
  /** Surcharge applies above this income; the calculator only covers incomes up to it. */
  surchargeFrom: number;
}

export const INCOME_TAX_RULE_SETS: readonly IncomeTaxRuleSet[] = [
  {
    status: "under-review",
    version: "2026-27",
    taxYear: "2026-27",
    effectiveFrom: "2026-04-01",
    effectiveTo: "2027-03-31",
    reviewedOn: "2026-10-07",
    newRegime: {
      slabs: [
        { upTo: 400_000, rate: 0 },
        { upTo: 800_000, rate: 5 },
        { upTo: 1_200_000, rate: 10 },
        { upTo: 1_600_000, rate: 15 },
        { upTo: 2_000_000, rate: 20 },
        { upTo: 2_400_000, rate: 25 },
        { upTo: null, rate: 30 },
      ],
      standardDeduction: 75_000,
      rebateIncomeLimit: 1_200_000,
      rebateMax: 60_000,
      rebateMarginalRelief: true,
      professionalTaxDeductible: false,
    },
    oldRegime: {
      slabs: [
        { upTo: 250_000, rate: 0 },
        { upTo: 500_000, rate: 5 },
        { upTo: 1_000_000, rate: 20 },
        { upTo: null, rate: 30 },
      ],
      standardDeduction: 50_000,
      rebateIncomeLimit: 500_000,
      rebateMax: 12_500,
      rebateMarginalRelief: false,
      professionalTaxDeductible: true,
    },
    cessRate: 4,
    surchargeFrom: 5_000_000,
    sources: [
      {
        name: "Income Tax Department: Tax rates for individuals, AY 2026-27 (slabs, rebate, surcharge, cess)",
        url: "https://www.incometax.gov.in/iec/foportal/help/individual/return-applicable-1",
        retrieved: "2026-10-07",
      },
      {
        name: "Union Budget 2026-27 speech (Income-tax Act, 2025 in force from 1 April 2026; no rate changes announced)",
        url: "https://www.indiabudget.gov.in/doc/budget_speech.pdf",
        retrieved: "2026-10-07",
      },
      {
        name: "Union Budget 2025-26 speech (new-regime slabs, rebate up to ₹12 lakh, marginal relief)",
        url: "https://www.indiabudget.gov.in/budget2025-26/doc/budget_speech.pdf",
        retrieved: "2026-10-07",
      },
      {
        name: "Union Budget 2024-25 speech (standard deduction ₹75,000 in the new regime)",
        url: "https://www.indiabudget.gov.in/budget2024-25/doc/budget_speech.pdf",
        retrieved: "2026-10-07",
      },
      {
        name: "Income Tax Department: Section 87A text (marginal relief mechanism)",
        url: "https://www.incometaxindia.gov.in/w/section-87a-25",
        retrieved: "2026-10-07",
      },
    ],
    notes: [
      "The Income-tax Act, 2025 replaced the Income-tax Act, 1961 from 1 April 2026. The 2026-27 rates are those confirmed for AY 2026-27, with no change announced in the 2026-27 Budget; the section numbers and exact wording under the new Act need professional confirmation.",
      "Not reviewed by a chartered accountant.",
    ],
  },
];

export function incomeTaxRulesOn(isoDate: string): IncomeTaxRuleSet | undefined {
  return ruleSetOn(INCOME_TAX_RULE_SETS, isoDate);
}

export const CURRENT_INCOME_TAX_RULES = INCOME_TAX_RULE_SETS[INCOME_TAX_RULE_SETS.length - 1]!;
