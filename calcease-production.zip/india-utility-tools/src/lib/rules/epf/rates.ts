/**
 * Employees' Provident Fund contribution rules, versioned. STATUS: UNDER REVIEW (used only
 * by the CTC calculator, which is excluded from production builds).
 */
import { ruleSetOn, type RuleSetMeta } from "../types";

export interface EpfRuleSet extends RuleSetMeta {
  status: "under-review";
  /** Employee contribution, percent of PF wages (basic + DA + retaining allowance). */
  employeeRate: number;
  /** Employer contribution (EPF + EPS together), percent of PF wages. */
  employerRate: number;
  /** Monthly wage ceiling for mandatory contributions. */
  wageCeiling: number;
}

const SOURCES = {
  rate: {
    name: "Government of West Bengal, Labour Department: The Employees' Provident Funds Act (summary: employee's contribution 12% of monthly pay)",
    url: "https://www.wb.gov.in/acts/act_labour_employees_provident_fund.pdf",
    retrieved: "2026-10-07",
  },
  ceiling: {
    name: "Ministry of Labour and Employment: Cabinet approves higher EPFO wage ceiling of Rs. 25,000 (16 September 2026)",
    url: "https://www.labour.gov.in/static/uploads/2026/09/4f607a88c5342aeb980c6b999997caab.pdf",
    retrieved: "2026-10-07",
  },
};

const NOTES = [
  "Employer contribution is shown as 12% in total (EPF and EPS together); admin and EDLI charges are not part of it.",
  "Many employers contribute on the full basic salary rather than the capped wage; the calculator lets you choose.",
  "Under the Code on Social Security, 2020, 'wages' for PF may include part of the allowances when they exceed half of pay. Not modelled; needs professional confirmation.",
];

export const EPF_RULE_SETS: readonly EpfRuleSet[] = [
  {
    status: "under-review",
    version: "ceiling-15000",
    effectiveFrom: "2014-09-01",
    effectiveTo: "2026-09-16",
    reviewedOn: "2026-10-07",
    employeeRate: 12,
    employerRate: 12,
    wageCeiling: 15_000,
    sources: [SOURCES.rate, SOURCES.ceiling],
    notes: [
      ...NOTES,
      "Start date of the ₹15,000 ceiling not verified from a primary source (only the end is).",
    ],
  },
  {
    status: "under-review",
    version: "ceiling-25000",
    effectiveFrom: "2026-09-17",
    reviewedOn: "2026-10-07",
    employeeRate: 12,
    employerRate: 12,
    wageCeiling: 25_000,
    sources: [SOURCES.rate, SOURCES.ceiling],
    notes: NOTES,
  },
];

export function epfRulesOn(isoDate: string): EpfRuleSet | undefined {
  return ruleSetOn(EPF_RULE_SETS, isoDate);
}

export const CURRENT_EPF_RULES = EPF_RULE_SETS[EPF_RULE_SETS.length - 1]!;
