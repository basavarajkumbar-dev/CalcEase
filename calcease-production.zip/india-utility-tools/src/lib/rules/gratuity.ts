/**
 * Gratuity accrual used by the CTC calculator (UNDER REVIEW). Only the rate formula is
 * used: 15 days' wages per completed year, with the monthly wage divided by 26.
 */
import type { RuleSource } from "./types";

export const GRATUITY_SOURCE: RuleSource = {
  name: "Government of Puducherry, Labour Department: The Payment of Gratuity Act, 1972 (summary: 15 days' wages per year; monthly wage ÷ 26)",
  url: "https://py.gov.in/sites/default/files/labour-paymentgratuity.pdf",
  retrieved: "2026-10-08",
};
