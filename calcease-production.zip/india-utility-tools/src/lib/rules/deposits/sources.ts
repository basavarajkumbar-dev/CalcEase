/**
 * Published bank methods behind the FD and RD calculators. These are conventions, not
 * rates: there is no single regulation that fixes the arithmetic, so the sources are the
 * banks' own published methods (docs/specs/fd-calculator.md §2, rd-calculator.md §2).
 */
import type { RuleSource } from "../types";

export const DEPOSIT_METHOD_REVIEWED = "2026-10-07";

export const FD_METHOD_SOURCES: readonly RuleSource[] = [
  {
    name: "TJSB Sahakari Bank: Method of calculation of interest on deposits",
    url: "https://www.tjsb.bank.in/assets/images/pages_pdf/interest-rates/METHOD-OF-CALCULATION-OF-INTEREST-ON-DEPOSITS.pdf",
    retrieved: "2026-10-07",
  },
  {
    name: "AU Small Finance Bank: Basis for interest calculation on term deposits",
    url: "https://www.au.bank.in/notice-board-language/basis-for-interest-calculation-on-term-deposits/English.pdf",
    retrieved: "2026-10-07",
  },
  {
    name: "CSB Bank: Method of interest calculation",
    url: "https://www.csb.co.in/pdf/Method-2022.pdf",
    retrieved: "2026-10-07",
  },
  {
    name: "Reserve Bank of India: Master Circular on Interest Rates on Rupee Deposits (2004)",
    url: "https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=1927",
    retrieved: "2026-10-07",
  },
  {
    name: "ICICI Bank: FD calculator (method and worked example)",
    url: "https://www.icici.bank.in/personal-banking/deposits/fixed-deposit/fd-calculator",
    retrieved: "2026-10-07",
  },
];

export const RD_METHOD_SOURCES: readonly RuleSource[] = [
  {
    name: "ICICI Bank: RD calculator (formula and worked example)",
    url: "https://www.icici.bank.in/personal-banking/deposits/recurring-deposits/rd-calculator",
    retrieved: "2026-10-07",
  },
  FD_METHOD_SOURCES[0]!,
  FD_METHOD_SOURCES[1]!,
];
