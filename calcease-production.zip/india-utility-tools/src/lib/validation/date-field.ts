/**
 * Validation for one date input (the ISO value of <input type="date">, or a value from a
 * shared link). Wording lives in the UI layer.
 */
import { isInRange, parseIsoDate, type PlainDate } from "@/lib/calc/date/plain-date";

export type DateFieldError =
  { code: "REQUIRED" } | { code: "INVALID_DATE" } | { code: "OUT_OF_RANGE" };

export type DateFieldResult = { ok: true; value: PlainDate } | { ok: false; error: DateFieldError };

export function validateDateField(text: string): DateFieldResult {
  const trimmed = text.trim();
  if (trimmed === "") return { ok: false, error: { code: "REQUIRED" } };
  const date = parseIsoDate(trimmed);
  if (!date) return { ok: false, error: { code: "INVALID_DATE" } };
  if (!isInRange(date)) return { ok: false, error: { code: "OUT_OF_RANGE" } };
  return { ok: true, value: date };
}
