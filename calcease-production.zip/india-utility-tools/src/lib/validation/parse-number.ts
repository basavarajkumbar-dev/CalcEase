/**
 * Converts what a user typed into a number, or a typed error.
 * The UI never does arithmetic on strings; everything passes through here first.
 */
import { MAX_ABS_INPUT } from "../calc/result";

export type ParseErrorCode = "REQUIRED" | "NOT_A_NUMBER" | "OUT_OF_RANGE";

export type ParseResult = { ok: true; value: number } | { ok: false; error: ParseErrorCode };

/** Optional sign, digits with an optional decimal part, or a leading decimal point. */
const NUMBER_PATTERN = /^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$/;

/**
 * Accepts digits, one decimal point, a leading + / - / − (Unicode minus), Indian or
 * Western thousands separators, and surrounding spaces. Rejects letters (including
 * scientific notation and hex), symbols such as % or ₹, and empty input.
 */
export function parseNumberInput(text: string): ParseResult {
  const trimmed = text.trim();
  if (trimmed === "") return { ok: false, error: "REQUIRED" };

  const normalised = trimmed.replace(/−/g, "-").replace(/,/g, "").replace(/\s/g, "");
  if (!NUMBER_PATTERN.test(normalised)) return { ok: false, error: "NOT_A_NUMBER" };

  const value = Number(normalised);
  if (!Number.isFinite(value)) return { ok: false, error: "NOT_A_NUMBER" };
  if (Math.abs(value) > MAX_ABS_INPUT) return { ok: false, error: "OUT_OF_RANGE" };

  return { ok: true, value: value === 0 ? 0 : value };
}
