/**
 * Spec-driven validation for one numeric input. Each calculator declares a rule per
 * field (taken from its specification); this module turns typed text into a number or
 * a typed error. User-facing wording lives in the UI layer
 * (src/components/calculator/field-messages.ts), not here.
 */
import { parseNumberInput } from "./parse-number";

export interface NumberFieldRule {
  /** Smallest allowed value (inclusive unless `minExclusive`). */
  min?: number;
  minExclusive?: boolean;
  /** Largest allowed value (inclusive). */
  max?: number;
  /** Whole numbers only (months, years, instalments). */
  integer?: boolean;
}

export type NumberFieldError =
  | { code: "REQUIRED" }
  | { code: "NOT_A_NUMBER" }
  | { code: "NOT_INTEGER" }
  | { code: "OUT_OF_RANGE" };

export type NumberFieldResult =
  { ok: true; value: number } | { ok: false; error: NumberFieldError };

export function validateNumberField(text: string, rule: NumberFieldRule): NumberFieldResult {
  const parsed = parseNumberInput(text);
  if (!parsed.ok) {
    // The parser's own ±10^12 guard is reported as a range problem for this field.
    return {
      ok: false,
      error: { code: parsed.error === "OUT_OF_RANGE" ? "OUT_OF_RANGE" : parsed.error },
    };
  }
  const value = parsed.value;
  if (rule.integer && !Number.isInteger(value))
    return { ok: false, error: { code: "NOT_INTEGER" } };
  if (rule.min !== undefined && (rule.minExclusive ? value <= rule.min : value < rule.min)) {
    return { ok: false, error: { code: "OUT_OF_RANGE" } };
  }
  if (rule.max !== undefined && value > rule.max)
    return { ok: false, error: { code: "OUT_OF_RANGE" } };
  return { ok: true, value };
}

/** Characters that can never become part of a valid number (letters, %, ₹ …). */
const IMPOSSIBLE_CHARACTER = /[^\d.,+\-−\s]/;

/**
 * Whether to show a field's error now (design system §9): range and integer problems
 * and impossible characters at once; half-typed text such as "-" or "." only after the
 * user leaves the field; an empty field never (the result panel asks for it instead).
 */
export function shouldShowFieldError(
  text: string,
  result: NumberFieldResult,
  touched: boolean,
): boolean {
  if (result.ok || result.error.code === "REQUIRED") return false;
  if (result.error.code === "NOT_A_NUMBER") return touched || IMPOSSIBLE_CHARACTER.test(text);
  return true;
}
