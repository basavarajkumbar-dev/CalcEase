/**
 * Page details for tools that are built but held back for expert review. See ReviewTool
 * in registry.ts and docs/reviews/.
 */
import type { ReviewTool } from "./registry";

export const CTC_REVIEW_TOOL: ReviewTool = {
  id: "ctc-in-hand",
  slug: "ctc-to-in-hand-salary-calculator",
  name: "CTC to In-Hand Salary Calculator",
  category: "salary",
  status: "under-review",
  shortDescription: "Monthly take-home pay from your CTC under the old or new tax regime.",
  keywords: ["ctc", "in-hand", "take home", "salary", "tax", "pf"],
  title: "CTC to In-Hand Salary Calculator (Tax Year 2026-27)",
  metaDescription:
    "Monthly take-home pay from your CTC after PF, professional tax and income tax under the new or old regime, for tax year 2026-27.",
  related: ["salary-budget-planner", "percentage-hike-calculator", "experience-calculator"],
  lastReviewed: "2026-10-07",
  reviewNotice:
    "Under review: this calculator's tax and PF rules come from official sources but have not yet been checked by a chartered accountant. It is not published.",
};
