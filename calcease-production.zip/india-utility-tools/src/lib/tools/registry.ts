/**
 * The tool registry: the single source of truth for categories and tools.
 *
 * Everything that lists tools is generated from here: homepage, category hubs, the
 * /tools index, header menus, footer, search, related tools, page metadata and the
 * sitemap. Adding a tool means adding (or activating) one entry.
 *
 * Two kinds of tool entry:
 * - `active`: a working calculator with a page. Linked everywhere, in the sitemap.
 * - `coming-soon`: planning data only. Never routed, never linked, never in the
 *   sitemap. Kept here so search can answer "emi" honestly ("coming soon"), so
 *   categories can say what is planned, and so related-tool references can be
 *   validated before the tool exists. Shown only with a clear "Coming soon" label.
 */

/* ------------------------------------------------------------------ categories */

export type ToolCategory = "finance" | "salary" | "math" | "date-time";

export interface CategoryDefinition {
  id: ToolCategory;
  /** URL path segment of the hub page, e.g. "math" → /math. */
  slug: string;
  name: string;
  /** One line for cards and menus. */
  shortDescription: string;
  /** Hub page introduction (one or two sentences). */
  description: string;
  /** <title> text without the site name. */
  title: string;
  /** Meta description for the hub page. */
  metaDescription: string;
}

/** In display order. */
export const CATEGORIES: readonly CategoryDefinition[] = [
  {
    id: "finance",
    slug: "finance",
    name: "Finance",
    shortDescription: "Loans, savings and interest",
    description:
      "Calculators for loan EMIs, SIPs, fixed and recurring deposits, and compound interest.",
    title: "Finance Calculators: EMI, SIP, FD and Interest",
    metaDescription:
      "Free finance calculators for India: loan EMI, SIP returns, fixed and recurring deposits, and compound interest, with the formulas explained.",
  },
  {
    id: "salary",
    slug: "salary",
    name: "Salary & Career",
    shortDescription: "Pay, hikes and work dates",
    description:
      "Calculators for in-hand salary, salary hikes, notice periods and work experience.",
    title: "Salary & Career Calculators",
    metaDescription:
      "Free salary calculators for India: CTC to in-hand pay, percentage hike, notice period end date and total work experience.",
  },
  {
    id: "math",
    slug: "math",
    name: "Math & Everyday",
    shortDescription: "Percentages and everyday sums",
    description:
      "Simple tools for percentages, discounts and everyday calculations, with the working shown so you can check every answer.",
    title: "Math & Everyday Calculators",
    metaDescription:
      "Free everyday math calculators: percentages, percentage change, and adding or removing a percent, with formulas and worked examples.",
  },
  {
    id: "date-time",
    slug: "date-time",
    name: "Date & Time",
    shortDescription: "Ages and days between dates",
    description:
      "Calculators for exact age, the days between two dates, and adding or subtracting days.",
    title: "Date & Time Calculators",
    metaDescription:
      "Free date calculators: exact age, days between two dates, and adding or subtracting days, months or years.",
  },
];

/* ----------------------------------------------------------------------- tools */

interface ToolBase {
  /** Stable identifier; never changes, even if the slug or name does. */
  id: string;
  /** URL path segment, e.g. "percentage-calculator" → /percentage-calculator. */
  slug: string;
  name: string;
  category: ToolCategory;
  /** One sentence for cards, menus and search results. */
  shortDescription: string;
  /** Extra lower-case words people search for. */
  keywords: readonly string[];
}

export interface ActiveTool extends ToolBase {
  status: "active";
  /** <title> without the site name; keep under ~60 characters. */
  title: string;
  /** Meta description, 120–160 characters. */
  metaDescription: string;
  /** Slugs of related tools (active or coming soon); only active ones are ever shown. */
  related: readonly string[];
  /** Shown in the homepage's "Start here" / popular section. */
  featured: boolean;
  /** ISO date the calculation and content were last reviewed. */
  lastReviewed: string;
}

export interface PlannedTool extends ToolBase {
  status: "coming-soon";
}

/**
 * A finished tool waiting for expert review (Phase 5: CTC to In-Hand, which needs a
 * chartered accountant's sign-off). Publicly it is still "coming soon": it has no page in
 * production builds, is not in the sitemap or search as available, and is never linked.
 * Review builds (ENABLE_UNDER_REVIEW_TOOLS=1) render its page, marked "Under review" and
 * noindex. Its public entry in TOOLS stays a PlannedTool.
 */
export interface ReviewTool extends Omit<ActiveTool, "status" | "featured"> {
  status: "under-review";
  /** Why it is held back, shown at the top of the page in review builds. */
  reviewNotice: string;
}

export type ToolDefinition = ActiveTool | PlannedTool;

export const TOOLS: readonly ToolDefinition[] = [
  // Math & Everyday
  {
    id: "percentage",
    slug: "percentage-calculator",
    name: "Percentage Calculator",
    category: "math",
    status: "active",
    shortDescription:
      "Find a percentage of a number, percentage change, or increase and decrease by a percent.",
    keywords: [
      "percent",
      "%",
      "percentage change",
      "increase",
      "decrease",
      "hike",
      "discount",
      "marks",
    ],
    title: "Percentage Calculator – % Change, Increase, Decrease",
    metaDescription:
      "Free percentage calculator. Find X% of a number, what percent one number is of another, percentage increase or decrease, and add or subtract a percent.",
    related: ["calculator", "discount-calculator", "percentage-hike-calculator", "gst-calculator"],
    featured: true,
    lastReviewed: "2026-10-07",
  },
  {
    id: "discount",
    slug: "discount-calculator",
    name: "Discount Calculator",
    category: "math",
    status: "active",
    shortDescription:
      "Price after a discount, the real discount on a sale price, and stacked offers like 20% + 10%.",
    keywords: ["sale", "offer", "price", "off", "savings", "extra discount"],
    title: "Discount Calculator – Sale Price, Savings & Extra % Off",
    metaDescription:
      "Free discount calculator. Find the price after a percentage off, the real discount on a sale price, and what 20% + extra 10% off actually comes to.",
    related: ["percentage-calculator", "gst-calculator", "percentage-hike-calculator"],
    featured: false,
    lastReviewed: "2026-10-07",
  },
  {
    id: "gst",
    slug: "gst-calculator",
    name: "GST Calculator",
    category: "math",
    status: "active",
    shortDescription:
      "Add GST to a price or remove it from an inclusive price, with the CGST + SGST or IGST split.",
    keywords: [
      "tax",
      "goods and services tax",
      "cgst",
      "sgst",
      "igst",
      "inclusive",
      "exclusive",
      "mrp",
    ],
    title: "GST Calculator – Add or Remove GST, CGST/SGST & IGST Split",
    metaDescription:
      "Free GST calculator for India. Add GST to a price or remove it from a GST-inclusive price at 5%, 18%, 40% or any rate, with the CGST, SGST and IGST split.",
    related: ["discount-calculator", "percentage-calculator"],
    featured: true,
    lastReviewed: "2026-10-07",
  },
  {
    id: "calculator",
    slug: "calculator",
    name: "Calculator",
    category: "math",
    status: "active",
    shortDescription:
      "A simple calculator with brackets, percent and history, for touch or keyboard.",
    keywords: [
      "basic calculator",
      "arithmetic",
      "add",
      "subtract",
      "multiply",
      "divide",
      "online calculator",
    ],
    title: "Online Calculator – Simple Calculator with Percent & Brackets",
    metaDescription:
      "Free online calculator. Add, subtract, multiply and divide with brackets and percent, using touch or your keyboard, with a history of your calculations.",
    related: ["percentage-calculator", "discount-calculator", "gst-calculator"],
    featured: true,
    lastReviewed: "2026-10-07",
  },
  // Finance
  {
    id: "lumpsum",
    slug: "lumpsum-calculator",
    name: "Lumpsum Calculator",
    category: "finance",
    status: "active",
    shortDescription: "Estimated value of a one-time investment at an expected yearly return.",
    keywords: ["lump sum", "one-time investment", "mutual fund", "returns", "future value"],
    title: "Lumpsum Calculator – One-Time Investment Returns",
    metaDescription:
      "Free lumpsum calculator. Estimate the value of a one-time investment at an expected yearly return, with estimated returns year by year.",
    related: ["sip-calculator", "fd-calculator", "compound-interest-calculator"],
    featured: true,
    lastReviewed: "2026-10-07",
  },
  {
    id: "emi",
    slug: "emi-calculator",
    name: "EMI Calculator",
    category: "finance",
    status: "active",
    shortDescription:
      "Monthly instalment, total interest and repayment schedule for a loan, with prepayment.",
    keywords: [
      "loan",
      "home loan",
      "car loan",
      "personal loan",
      "instalment",
      "interest",
      "amortization",
      "prepayment",
    ],
    title: "EMI Calculator – Home, Car & Personal Loan EMI with Schedule",
    metaDescription:
      "Free EMI calculator. Monthly EMI, total interest and a month-by-month repayment schedule for home, car and personal loans, with the effect of a part-prepayment.",
    related: ["sip-calculator", "fd-calculator", "compound-interest-calculator"],
    featured: true,
    lastReviewed: "2026-10-07",
  },
  {
    id: "sip",
    slug: "sip-calculator",
    name: "SIP Calculator",
    category: "finance",
    status: "active",
    shortDescription:
      "Estimated value of a monthly mutual fund investment, with an optional yearly step-up.",
    keywords: ["mutual fund", "investment", "step-up", "returns", "systematic investment plan"],
    title: "SIP Calculator – Mutual Fund SIP Returns with Step-Up",
    metaDescription:
      "Free SIP calculator. Estimate the value of a monthly mutual fund SIP at an expected return, with a yearly step-up and a year-by-year table.",
    related: ["lumpsum-calculator", "emi-calculator", "compound-interest-calculator"],
    featured: true,
    lastReviewed: "2026-10-07",
  },
  {
    id: "fd",
    slug: "fd-calculator",
    name: "FD Calculator",
    category: "finance",
    status: "active",
    shortDescription: "Maturity amount, interest and maturity date for a bank fixed deposit.",
    keywords: ["fixed deposit", "bank", "interest", "maturity", "cumulative", "quarterly payout"],
    title: "FD Calculator – Fixed Deposit Maturity & Interest (Bank Method)",
    metaDescription:
      "Free FD calculator. Maturity amount, interest and maturity date for a bank fixed deposit, with quarterly compounding and part quarters calculated the way banks do.",
    related: ["rd-calculator", "compound-interest-calculator"],
    featured: false,
    lastReviewed: "2026-10-07",
  },
  {
    id: "rd",
    slug: "rd-calculator",
    name: "RD Calculator",
    category: "finance",
    status: "active",
    shortDescription: "Maturity amount and interest on a bank recurring deposit.",
    keywords: ["recurring deposit", "bank", "interest", "maturity", "monthly deposit"],
    title: "RD Calculator – Recurring Deposit Maturity & Interest",
    metaDescription:
      "Free RD calculator. Maturity amount and interest on a bank recurring deposit, using the quarterly-compounding formula banks publish.",
    related: ["fd-calculator", "compound-interest-calculator"],
    featured: false,
    lastReviewed: "2026-10-07",
  },
  {
    id: "compound-interest",
    slug: "compound-interest-calculator",
    name: "Compound Interest Calculator",
    category: "finance",
    status: "active",
    shortDescription:
      "Growth of a lump sum with interest compounded yearly, quarterly or monthly, year by year.",
    keywords: ["interest", "compounding", "savings", "simple interest", "effective rate"],
    title: "Compound Interest Calculator – Yearly, Quarterly & Monthly",
    metaDescription:
      "Free compound interest calculator. See how a lump sum grows with interest compounded yearly, half-yearly, quarterly or monthly, with a year-by-year table.",
    related: ["fd-calculator", "rd-calculator", "percentage-calculator"],
    featured: false,
    lastReviewed: "2026-10-07",
  },
  // Salary & Career
  {
    id: "ctc-in-hand",
    slug: "ctc-to-in-hand-salary-calculator",
    name: "CTC to In-Hand Salary Calculator",
    category: "salary",
    status: "coming-soon",
    shortDescription: "Monthly take-home pay from your CTC under the old or new tax regime.",
    keywords: ["salary", "take home", "ctc", "income tax", "pf", "net pay"],
  },
  {
    id: "percentage-hike",
    slug: "percentage-hike-calculator",
    name: "Percentage Hike Calculator",
    category: "salary",
    status: "active",
    shortDescription:
      "New salary after a hike, or the hike percentage between two salaries, monthly or yearly.",
    keywords: ["salary", "increment", "appraisal", "raise", "pay rise", "lpa", "pay cut"],
    title: "Salary Hike Calculator – New Salary & Hike Percentage",
    metaDescription:
      "Free salary hike calculator. Work out your new salary after a percentage hike, or the hike between two salaries, per month or per year (LPA).",
    related: [
      "salary-budget-planner",
      "experience-calculator",
      "percentage-calculator",
      "discount-calculator",
    ],
    featured: false,
    lastReviewed: "2026-10-07",
  },
  {
    id: "notice-period",
    slug: "notice-period-calculator",
    name: "Notice Period Calculator",
    category: "salary",
    status: "active",
    shortDescription: "Your expected last working day from the resignation date and notice period.",
    keywords: ["resignation", "last working day", "lwd", "notice", "relieving date"],
    title: "Notice Period Calculator – Last Working Day",
    metaDescription:
      "Free notice period calculator. Find your expected last working day from your resignation date and notice period in days, with the counting rule explained.",
    related: ["experience-calculator", "salary-budget-planner", "date-add-subtract-calculator"],
    featured: false,
    lastReviewed: "2026-10-08",
  },
  {
    id: "experience",
    slug: "experience-calculator",
    name: "Experience Calculator",
    category: "salary",
    status: "active",
    shortDescription: "Total work experience in years, months and days between two dates.",
    keywords: ["work experience", "years", "service", "tenure", "joining date"],
    title: "Experience Calculator – Work Experience in Years & Months",
    metaDescription:
      "Free work experience calculator. Total experience in years, months and days from your joining date to your last working day or today.",
    related: ["notice-period-calculator", "percentage-hike-calculator", "salary-budget-planner"],
    featured: false,
    lastReviewed: "2026-10-08",
  },
  {
    id: "salary-budget",
    slug: "salary-budget-planner",
    name: "Salary Budget Planner",
    category: "salary",
    status: "active",
    shortDescription:
      "Plan your take-home pay: expenses, surplus, savings, investments and emergency fund.",
    keywords: ["budget", "50 30 20", "monthly budget", "emergency fund", "savings", "expenses"],
    title: "Salary Budget Planner – Plan Your Monthly Take-Home Pay",
    metaDescription:
      "Free salary budget planner. See your monthly surplus, savings rate and emergency-fund cover, with an adjustable reference allocation instead of one fixed rule.",
    related: [
      "ctc-to-in-hand-salary-calculator",
      "percentage-hike-calculator",
      "emi-calculator",
      "sip-calculator",
      "lumpsum-calculator",
      "compound-interest-calculator",
    ],
    featured: false,
    lastReviewed: "2026-10-08",
  },
  // Date & Time
  {
    id: "age",
    slug: "age-calculator",
    name: "Age Calculator",
    category: "date-time",
    status: "active",
    shortDescription:
      "Exact age in years, months and days from a date of birth, plus your next birthday.",
    keywords: ["birthday", "date of birth", "dob", "how old", "age in days"],
    title: "Age Calculator – Exact Age in Years, Months & Days",
    metaDescription:
      "Free age calculator. Find your exact age in years, months and days from your date of birth, on today's date or any date, with your next birthday.",
    related: ["date-difference-calculator", "date-add-subtract-calculator"],
    featured: false,
    lastReviewed: "2026-10-07",
  },
  {
    id: "date-difference",
    slug: "date-difference-calculator",
    name: "Date Difference Calculator",
    category: "date-time",
    status: "active",
    shortDescription:
      "Days, weeks, months and years between two dates, with weekdays and an inclusive option.",
    keywords: ["days between dates", "duration", "count days", "weekdays", "working days"],
    title: "Date Difference Calculator – Days Between Two Dates",
    metaDescription:
      "Free date difference calculator. Count the days, weeks, months and years between two dates, with weekdays and an option to include the end date.",
    related: ["age-calculator", "date-add-subtract-calculator"],
    featured: false,
    lastReviewed: "2026-10-07",
  },
  {
    id: "date-add-subtract",
    slug: "date-add-subtract-calculator",
    name: "Date Add / Subtract Calculator",
    category: "date-time",
    status: "active",
    shortDescription: "The date a number of days, weeks, months or years before or after another.",
    keywords: ["add days", "subtract days", "future date", "deadline", "add months"],
    title: "Add or Subtract Days from a Date – Date Calculator",
    metaDescription:
      "Free date calculator. Find the date a number of days, weeks, months or years after or before any date, with month-end dates handled correctly.",
    related: ["date-difference-calculator", "age-calculator"],
    featured: false,
    lastReviewed: "2026-10-07",
  },
];

/* --------------------------------------------------------------------- helpers */

export function isActive(tool: ToolDefinition): tool is ActiveTool {
  return tool.status === "active";
}

export function activeTools(): ActiveTool[] {
  return TOOLS.filter(isActive);
}

export function plannedTools(): PlannedTool[] {
  return TOOLS.filter((tool): tool is PlannedTool => tool.status === "coming-soon");
}

export function featuredTools(): ActiveTool[] {
  return activeTools().filter((tool) => tool.featured);
}

/** An active tool by slug. Throws at build time if a page references a missing or inactive tool. */
export function getActiveTool(slug: string): ActiveTool {
  const tool = TOOLS.find((t) => t.slug === slug);
  if (!tool) throw new Error(`Tool not registered: ${slug}`);
  if (!isActive(tool)) throw new Error(`Tool is not active: ${slug}`);
  return tool;
}

/** Only active tools have a URL. */
export function toolHref(tool: ActiveTool): string {
  return `/${tool.slug}`;
}

export function getCategory(id: ToolCategory): CategoryDefinition {
  const category = CATEGORIES.find((c) => c.id === id);
  if (!category) throw new Error(`Unknown category: ${id}`);
  return category;
}

export function categoryBySlug(slug: string): CategoryDefinition | undefined {
  return CATEGORIES.find((c) => c.slug === slug);
}

export function activeToolsInCategory(id: ToolCategory): ActiveTool[] {
  return activeTools().filter((tool) => tool.category === id);
}

export function plannedToolsInCategory(id: ToolCategory): PlannedTool[] {
  return plannedTools().filter((tool) => tool.category === id);
}

/**
 * A category gets a hub page only when it has at least one active tool, so there are
 * never empty or "coming soon" pages for search engines to index (Phase 4 decision).
 */
export function hasHub(id: ToolCategory): boolean {
  return activeToolsInCategory(id).length > 0;
}

export function categoriesWithHubs(): CategoryDefinition[] {
  return CATEGORIES.filter((c) => hasHub(c.id));
}

/** Hub URL, or undefined while the category has no active tools (render plain text, not a link). */
export function categoryHref(id: ToolCategory): string | undefined {
  return hasHub(id) ? `/${getCategory(id).slug}` : undefined;
}

/** Related tools that can actually be opened right now, in the registry's chosen order. */
export function relatedActiveTools(tool: ActiveTool | ReviewTool): ActiveTool[] {
  return tool.related.flatMap((slug) => activeTools().filter((t) => t.slug === slug));
}
