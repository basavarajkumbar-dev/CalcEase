/**
 * Client-side search over the tool registry. With 13–50 tools a scored word match is
 * instant and predictable; no search library, index or service is needed.
 */
import { CATEGORIES, type ToolDefinition } from "./registry";

/** Lower-cases, folds accents, turns punctuation into spaces and collapses whitespace. */
export function normaliseQuery(text: string): string {
  return text
    .normalize("NFKD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9%₹]+/g, " ")
    .trim();
}

const CATEGORY_NAME = new Map(CATEGORIES.map((c) => [c.id, normaliseQuery(c.name)]));

/** Most results shown at once; keeps the list scannable and rendering cheap on slow phones. */
export const MAX_RESULTS = 8;

/**
 * Tools matching every word of the query. Score per word: start of a word in the name
 * 3, keyword 2, category name or description 1. A one-character word only matches the
 * start of a name or keyword word (otherwise "p" would match almost every description).
 * Active tools come before coming-soon tools; then higher score; then name. An empty
 * query returns nothing. At most MAX_RESULTS are returned.
 */
export function searchTools(query: string, tools: readonly ToolDefinition[]): ToolDefinition[] {
  const words = normaliseQuery(query).split(" ").filter(Boolean);
  if (words.length === 0) return [];

  const scored = tools.flatMap((tool) => {
    const nameWords = normaliseQuery(tool.name).split(" ");
    const keywords = tool.keywords.map(normaliseQuery).join(" | ");
    const keywordWords = keywords.split(/[ |]+/);
    const category = CATEGORY_NAME.get(tool.category) ?? "";
    const description = normaliseQuery(tool.shortDescription);
    let score = 0;
    for (const word of words) {
      if (nameWords.some((part) => part.startsWith(word))) score += 3;
      else if (word.length === 1) {
        if (keywordWords.some((part) => part.startsWith(word))) score += 2;
        else return [];
      } else if (keywords.includes(word)) score += 2;
      else if (category.includes(word) || description.includes(word)) score += 1;
      else return [];
    }
    return [{ tool, score }];
  });

  scored.sort(
    (a, b) =>
      Number(b.tool.status === "active") - Number(a.tool.status === "active") ||
      b.score - a.score ||
      a.tool.name.localeCompare(b.tool.name),
  );
  return scored.slice(0, MAX_RESULTS).map((entry) => entry.tool);
}

/** Shown when a search finds nothing. Every one is tested to return a result. */
export const SEARCH_SUGGESTIONS = ["percentage", "discount", "EMI", "salary", "age"] as const;
