/**
 * Indian rupee display: ₹12,50,000 grouping and amounts in words (lakh / crore).
 * Display only; calculations never see these strings.
 */
import type { FormattedNumber } from "./number";

const WHOLE_RUPEES = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});
const WITH_PAISE = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

export type PaiseMode = "auto" | "always" | "never";

/** Rounds to whole paise (half away from zero), the unit Indian amounts are settled in. */
export function roundToPaise(value: number): number {
  const rounded = Math.sign(value) * Math.round(Math.abs(value) * 100);
  return rounded / 100 + 0;
}

/**
 * ₹ with Indian grouping.
 * - "auto" (default): paise shown only when the amount, rounded to paise, has them.
 * - "always": always two decimals (₹1,104.00).
 * - "never": whole rupees (₹1,104), for summaries such as EMI or maturity headlines.
 */
export function formatCurrency(value: number, paise: PaiseMode = "auto"): FormattedNumber {
  if (!Number.isFinite(value)) throw new RangeError("formatCurrency received a non-finite value");
  const toPaise = roundToPaise(value);
  const usePaise = paise === "always" || (paise === "auto" && !Number.isInteger(toPaise));
  const shown = usePaise ? toPaise : Math.sign(value) * Math.round(Math.abs(value)) + 0;
  let text = (usePaise ? WITH_PAISE : WHOLE_RUPEES).format(shown);
  if (/^-₹0(?:\.0+)?$/.test(text)) text = text.slice(1);
  return { text, isRounded: shown !== value };
}

const ONES = [
  "",
  "one",
  "two",
  "three",
  "four",
  "five",
  "six",
  "seven",
  "eight",
  "nine",
  "ten",
  "eleven",
  "twelve",
  "thirteen",
  "fourteen",
  "fifteen",
  "sixteen",
  "seventeen",
  "eighteen",
  "nineteen",
];
const TENS = ["", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"];

function belowHundred(n: number): string {
  if (n < 20) return ONES.at(n) ?? "";
  const tens = TENS.at(Math.floor(n / 10)) ?? "";
  const ones = n % 10;
  return ones ? `${tens}-${ONES.at(ones)}` : tens;
}

function belowThousand(n: number): string {
  const hundreds = Math.floor(n / 100);
  const rest = n % 100;
  const parts = [];
  if (hundreds) parts.push(`${ONES.at(hundreds)} hundred`);
  if (rest) parts.push(belowHundred(rest));
  return parts.join(" ");
}

/** Whole number in the Indian system: crore, lakh, thousand, hundred. */
export function integerToIndianWords(n: number): string {
  if (!Number.isInteger(n) || n < 0)
    throw new RangeError("integerToIndianWords needs a non-negative integer");
  if (n === 0) return "zero";
  const parts = [];
  const crore = Math.floor(n / 1e7);
  let rest = n % 1e7;
  if (crore) parts.push(`${integerToIndianWords(crore)} crore`);
  const lakh = Math.floor(rest / 1e5);
  rest %= 1e5;
  if (lakh) parts.push(`${belowHundred(lakh)} lakh`);
  const thousand = Math.floor(rest / 1000);
  rest %= 1000;
  if (thousand) parts.push(`${belowHundred(thousand)} thousand`);
  if (rest) parts.push(belowThousand(rest));
  return parts.join(" ");
}

/** Largest amount spelled out; beyond this words stop being useful. */
const WORDS_LIMIT = 1e15;

/**
 * "Twelve lakh fifty thousand rupees", "One hundred four rupees and fifteen paise".
 * Rounded to paise first. Returns undefined beyond ₹10^15.
 */
export function amountInWords(value: number): string | undefined {
  if (!Number.isFinite(value) || Math.abs(value) >= WORDS_LIMIT) return undefined;
  const totalPaise = Math.round(Math.abs(value) * 100);
  const rupees = Math.floor(totalPaise / 100);
  const paise = totalPaise % 100;
  let words: string;
  if (rupees === 0 && paise > 0) words = `${integerToIndianWords(paise)} paise`;
  else {
    words = `${integerToIndianWords(rupees)} ${rupees === 1 ? "rupee" : "rupees"}`;
    if (paise) words += ` and ${integerToIndianWords(paise)} paise`;
  }
  if (value < 0 && totalPaise > 0) words = `minus ${words}`;
  return words.charAt(0).toUpperCase() + words.slice(1);
}

/** Short form for labels: 12.5 lakh, 1.25 crore, 85,000. */
export function compactIndian(value: number): string {
  const abs = Math.abs(value);
  const sign = value < 0 ? "−" : "";
  const fmt = (n: number) => new Intl.NumberFormat("en-IN", { maximumFractionDigits: 2 }).format(n);
  if (abs >= 1e7) return `${sign}${fmt(abs / 1e7)} crore`;
  if (abs >= 1e5) return `${sign}${fmt(abs / 1e5)} lakh`;
  return `${sign}${fmt(abs)}`;
}
