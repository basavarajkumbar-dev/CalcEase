/**
 * Display text for calendar dates and durations. Dates are formatted by hand rather than
 * with Date/Intl.DateTimeFormat: a PlainDate has no time zone, and the text must not
 * depend on the device's time zone or locale data.
 */
import type { PlainDate } from "@/lib/calc/date/plain-date";
import { isoWeekday } from "@/lib/calc/date/plain-date";
import { formatInteger } from "./number";

const MONTHS = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
] as const;

const WEEKDAYS = [
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
  "Sunday",
] as const;

/** "7 October 2026" (Indian day-month-year order). */
export function formatLongDate(d: PlainDate): string {
  return `${d.day} ${MONTHS[d.month - 1]} ${d.year}`;
}

/** ISO weekday 1–7 → "Monday" … "Sunday". */
export function weekdayName(isoDay: number): string {
  return WEEKDAYS[isoDay - 1] ?? "";
}

/** "Wednesday, 7 October 2026". */
export function formatDateWithWeekday(d: PlainDate): string {
  return `${weekdayName(isoWeekday(d))}, ${formatLongDate(d)}`;
}

/** "1 day", "2,500 days". */
export function plural(count: number, unit: string): string {
  return `${formatInteger(count)} ${unit}${count === 1 ? "" : "s"}`;
}

/** "1 year, 2 weeks and 3 days": the non-zero parts in order; "0 days" if all are zero. */
export function formatDuration(parts: {
  years?: number;
  months?: number;
  weeks?: number;
  days?: number;
}): string {
  const text = (
    [
      [parts.years, "year"],
      [parts.months, "month"],
      [parts.weeks, "week"],
      [parts.days, "day"],
    ] as const
  )
    .filter(([n]) => n)
    .map(([n, unit]) => plural(n!, unit));
  if (text.length === 0) return "0 days";
  if (text.length === 1) return text[0]!;
  return `${text.slice(0, -1).join(", ")} and ${text[text.length - 1]}`;
}

/** "1 year, 2 months and 3 days"; zero parts are left out; all zero gives "0 days". */
export function formatYmd({
  years,
  months,
  days,
}: {
  years: number;
  months: number;
  days: number;
}): string {
  // Only these three: callers often pass a richer object (e.g. one that also has weeks).
  return formatDuration({ years, months, days });
}
