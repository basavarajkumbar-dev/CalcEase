/**
 * Display formatting. The only place where results are rounded (spec, section 7).
 * Uses the Indian digit grouping system via Intl.NumberFormat("en-IN").
 */

const LOCALE = "en-IN";

const twoDecimals = new Intl.NumberFormat(LOCALE, { maximumFractionDigits: 2 });
const twoSignificant = new Intl.NumberFormat(LOCALE, { maximumSignificantDigits: 2 });
const fifteenSignificant = new Intl.NumberFormat(LOCALE, { maximumSignificantDigits: 15 });

export interface FormattedNumber {
  /** Text to display, e.g. "12,50,000" or "16.67". */
  text: string;
  /** True when the displayed text is not the exact value (so the UI can say so). */
  isRounded: boolean;
}

/**
 * Formats a number for display:
 * - |v| ≥ 0.01: up to 2 decimal places, trailing zeros removed
 * - 0 < |v| < 0.01: 2 significant digits, so tiny values never show as "0"
 * - |v| ≥ 10^15: at most 15 significant digits (the limit of double precision)
 * Rounding is half away from zero. Negative zero displays as "0".
 */
export function formatNumber(value: number): FormattedNumber {
  if (!Number.isFinite(value)) {
    throw new RangeError("formatNumber received a non-finite value");
  }
  const abs = Math.abs(value);
  let formatter = twoDecimals;
  if (abs !== 0 && abs < 0.01) formatter = twoSignificant;
  else if (abs >= 1e15) formatter = fifteenSignificant;

  let text = formatter.format(value);
  // Intl renders values that round to zero from below as "-0".
  if (/^-0(?:\.0*)?$/.test(text)) text = "0";

  const displayed = Number(text.replace(/,/g, ""));
  return { text, isRounded: displayed !== value };
}

/** Formats a percentage value (already multiplied by 100), e.g. 16.666… → "16.67%". */
export function formatPercent(value: number): FormattedNumber {
  const formatted = formatNumber(value);
  return { ...formatted, text: `${formatted.text}%` };
}

const inputEcho = new Intl.NumberFormat("en-IN", { maximumSignificantDigits: 15 });

/**
 * Echoes a user's input (or an exact value) back with Indian grouping and up to 15
 * significant digits, so "0.123456" is not shortened to "0.12" in explanations.
 */
export function formatExact(value: number): string {
  const text = inputEcho.format(value);
  return /^-0(?:\.0*)?$/.test(text) ? "0" : text;
}

const integer = new Intl.NumberFormat(LOCALE, { maximumFractionDigits: 0 });

/** Whole numbers with Indian grouping: 12345 → "12,345". */
export function formatInteger(value: number): string {
  return integer.format(value);
}
