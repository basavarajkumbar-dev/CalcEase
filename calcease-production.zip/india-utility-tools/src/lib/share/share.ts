/**
 * Share-or-copy logic, kept free of browser globals: the caller passes in the
 * capabilities it has (usually `navigator`), which keeps this unit-testable.
 *
 * Order: Web Share API (Android Chrome, iOS Safari) → clipboard → manual fallback.
 */

export interface ShareData {
  title: string;
  /** The message, e.g. "From 600 to 500 is a decrease of 16.67%." */
  text: string;
  /** Absolute URL to include. Later phases will put calculator inputs in it. */
  url: string;
}

export interface ShareEnvironment {
  share?: ((data: ShareData) => Promise<void>) | undefined;
  canShare?: ((data: ShareData) => boolean) | undefined;
  clipboard?: { writeText: (text: string) => Promise<void> } | undefined;
}

export type ShareOutcome = "shared" | "copied" | "cancelled" | "unavailable";

/** The text placed on the clipboard when native sharing is unavailable. */
export function clipboardText(data: ShareData): string {
  return `${data.text}\n${data.url}`;
}

export async function shareOrCopy(data: ShareData, env: ShareEnvironment): Promise<ShareOutcome> {
  const canNativeShare =
    typeof env.share === "function" && (env.canShare ? env.canShare(data) : true);
  if (canNativeShare && env.share) {
    try {
      await env.share(data);
      return "shared";
    } catch (error) {
      // The user closed the share sheet: not an error, do nothing.
      if (error instanceof Error && error.name === "AbortError") return "cancelled";
      // Any other failure (e.g. NotAllowedError): fall through to the clipboard.
    }
  }
  if (env.clipboard) {
    try {
      await env.clipboard.writeText(clipboardText(data));
      return "copied";
    } catch {
      return "unavailable";
    }
  }
  return "unavailable";
}
