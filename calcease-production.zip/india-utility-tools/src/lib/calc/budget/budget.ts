/**
 * Salary Budget Planner. Specification: docs/specs/salary-budget-planner.md
 *
 * Planning arithmetic only: it organises the user's own numbers and shows an adjustable
 * reference allocation. Not financial advice, and no rule is presented as universal.
 */
import { checkInputs, type CalcErrorCode, type Outcome } from "../result";

export type BudgetError =
  | CalcErrorCode
  | "INCOME_NOT_POSITIVE"
  | "AMOUNT_NEGATIVE"
  | "MONTHS_OUT_OF_RANGE"
  | "SHARE_OUT_OF_RANGE";

export interface BudgetInput {
  /** Monthly take-home salary. */
  income: number;
  /** Monthly essential expenses (rent, food, transport, utilities, insurance …). */
  essentials: number;
  /** Monthly EMIs and other debt payments. */
  emi: number;
  /** Monthly discretionary ("wants") spending. */
  wants: number;
  /** Emergency savings already set aside. */
  emergencySavings: number;
  /** Monthly amount the user already invests. */
  investments: number;
  /** Emergency-fund target in months of essentials + EMIs (reference: 3 to 6). */
  emergencyMonths: number;
  /** Reference: share of the money left after essentials and EMIs kept for wants (%). */
  wantsShare: number;
  /** Share of savings directed to the emergency fund while it is below target (%). */
  emergencyShare: number;
  /** Optional savings goal in rupees (0 = none). */
  goal: number;
}

export interface Allocation {
  needs: number;
  debt: number;
  wants: number;
  /** Emergency fund / other savings. */
  savings: number;
  investments: number;
}

export interface BudgetResult {
  income: number;
  /** essentials + EMIs + wants. */
  totalExpenses: number;
  /** income − total expenses (negative when spending exceeds income). */
  surplus: number;
  /** surplus − current investments: what is left unallocated (negative = over-committed). */
  unallocated: number;
  expensePercent: number;
  /** max(0, surplus) as a share of income: what is available to save or invest. */
  savingsInvestPercent: number;
  investPercent: number;
  debtPercent: number;
  emergency: {
    /** Monthly essentials + EMIs, the basis of the target. */
    monthlyBasis: number;
    target: number;
    current: number;
    shortfall: number;
    /** Months of essentials + EMIs covered; null when there are none. */
    coverageMonths: number | null;
  };
  /** Suggested split of the available surplus (emergency fund first while below target). */
  suggested: { available: number; toEmergency: number; toInvestments: number };
  /** Months to reach the emergency target at the suggested amount; 0 if reached; null if never. */
  monthsToEmergencyTarget: number | null;
  /** max(0, unallocated): amount available for additional saving or investing. */
  additionalAvailable: number;
  /** Months to the optional goal saving the whole available surplus (no returns assumed). */
  monthsToGoal: number | null;
  /** The user's own plan, by category. */
  plan: Allocation;
  /** The adjustable reference allocation, by category. */
  reference: Allocation;
}

export const BUDGET_LIMITS = { maxAmount: 1e10, minMonths: 1, maxMonths: 24 } as const;
export const BUDGET_DEFAULTS = { emergencyMonths: 6, wantsShare: 60, emergencyShare: 50 } as const;

export function salaryBudget(input: BudgetInput): Outcome<BudgetResult, BudgetError> {
  const { income, essentials, emi, wants, emergencySavings, investments } = input;
  const { emergencyMonths, wantsShare, emergencyShare, goal } = input;
  const amounts = [income, essentials, emi, wants, emergencySavings, investments, goal];
  const problem = checkInputs(...amounts, emergencyMonths, wantsShare, emergencyShare);
  if (problem) return { ok: false, error: problem };
  if (income <= 0) return { ok: false, error: "INCOME_NOT_POSITIVE" };
  if (amounts.some((a) => a < 0)) return { ok: false, error: "AMOUNT_NEGATIVE" };
  if (amounts.some((a) => a > BUDGET_LIMITS.maxAmount)) return { ok: false, error: "OUT_OF_RANGE" };
  if (emergencyMonths < BUDGET_LIMITS.minMonths || emergencyMonths > BUDGET_LIMITS.maxMonths)
    return { ok: false, error: "MONTHS_OUT_OF_RANGE" };
  if ([wantsShare, emergencyShare].some((s) => s < 0 || s > 100))
    return { ok: false, error: "SHARE_OUT_OF_RANGE" };

  const pct = (x: number) => (x * 100) / income;
  const commitments = essentials + emi;
  const totalExpenses = commitments + wants;
  const surplus = income - totalExpenses;
  const unallocated = surplus - investments;
  const available = Math.max(0, surplus);

  const target = commitments * emergencyMonths;
  const shortfall = Math.max(0, target - emergencySavings);
  const toEmergency = shortfall > 0 ? Math.min(shortfall, (available * emergencyShare) / 100) : 0;

  // Reference: commitments are taken as they are (rent and EMIs cannot change overnight);
  // what is left is shared between wants and savings, emergency fund first.
  const left = Math.max(0, income - commitments);
  const refWants = (left * wantsShare) / 100;
  const refSave = left - refWants;
  const refEmergency = shortfall > 0 ? Math.min(shortfall, (refSave * emergencyShare) / 100) : 0;

  return {
    ok: true,
    value: {
      income,
      totalExpenses,
      surplus,
      unallocated,
      expensePercent: pct(totalExpenses),
      savingsInvestPercent: pct(available),
      investPercent: pct(investments),
      debtPercent: pct(emi),
      emergency: {
        monthlyBasis: commitments,
        target,
        current: emergencySavings,
        shortfall,
        coverageMonths: commitments > 0 ? emergencySavings / commitments : null,
      },
      suggested: { available, toEmergency, toInvestments: available - toEmergency },
      monthsToEmergencyTarget:
        shortfall === 0 ? 0 : toEmergency > 0 ? Math.ceil(shortfall / toEmergency - 1e-9) : null,
      additionalAvailable: Math.max(0, unallocated),
      monthsToGoal: goal > 0 && available > 0 ? Math.ceil(goal / available - 1e-9) : null,
      plan: {
        needs: essentials,
        debt: emi,
        wants,
        savings: Math.max(0, unallocated),
        investments,
      },
      reference: {
        needs: essentials,
        debt: emi,
        wants: refWants,
        savings: refEmergency,
        investments: refSave - refEmergency,
      },
    },
  };
}
