/**
 * SIP future value. Specification: docs/specs/sip-calculator.md
 *
 * Instalments at the start of each month (so each earns a full month in its first
 * month); the expected yearly return is turned into a monthly rate either by dividing by
 * 12 or as the compounded monthly equivalent, which fund houses differ on. An optional
 * step-up raises the instalment by a percentage every 12 months.
 */
import { checkInputs, type CalcErrorCode, type Outcome } from "../result";

export type MonthlyRateMethod = "divide12" | "equivalent";

export type SipError =
  | CalcErrorCode
  | "INSTALMENT_NOT_POSITIVE"
  | "RETURN_OUT_OF_RANGE"
  | "YEARS_OUT_OF_RANGE"
  | "STEP_UP_OUT_OF_RANGE";

export const SIP_LIMITS = { returnMax: 50, yearsMax: 50, stepUpMax: 50 } as const;

export interface SipYear {
  year: number;
  /** Monthly instalment during this year. */
  instalment: number;
  /** Total invested by the end of this year. */
  invested: number;
  /** Estimated value at the end of this year. */
  value: number;
}

export interface SipResult {
  invested: number;
  value: number;
  gains: number;
  /** Monthly rate used, in percent. */
  monthlyRate: number;
  years: readonly SipYear[];
}

export function monthlyRate(annualPercent: number, method: MonthlyRateMethod): number {
  return method === "divide12"
    ? annualPercent / 1200
    : Math.expm1(Math.log1p(annualPercent / 100) / 12);
}

/** Value at the end of 12 months of start-of-month instalments of 1: ((1+i)^12 − 1) ÷ i × (1+i). */
function yearFactor(i: number): number {
  return i === 0 ? 12 : (Math.expm1(12 * Math.log1p(i)) / i) * (1 + i);
}

export function sipValue(
  instalment: number,
  annualReturn: number,
  years: number,
  stepUpPercent: number,
  method: MonthlyRateMethod,
): Outcome<SipResult, SipError> {
  const problem = checkInputs(instalment, annualReturn, years, stepUpPercent);
  if (problem) return { ok: false, error: problem };
  if (instalment <= 0) return { ok: false, error: "INSTALMENT_NOT_POSITIVE" };
  if (annualReturn < 0 || annualReturn > SIP_LIMITS.returnMax)
    return { ok: false, error: "RETURN_OUT_OF_RANGE" };
  if (!Number.isInteger(years) || years < 1 || years > SIP_LIMITS.yearsMax)
    return { ok: false, error: "YEARS_OUT_OF_RANGE" };
  if (stepUpPercent < 0 || stepUpPercent > SIP_LIMITS.stepUpMax)
    return { ok: false, error: "STEP_UP_OUT_OF_RANGE" };

  const i = monthlyRate(annualReturn, method);
  const yearGrowth = Math.pow(1 + i, 12);
  const factor = yearFactor(i);
  const rows: SipYear[] = [];
  let value = 0;
  let invested = 0;
  let current = instalment;
  for (let year = 1; year <= years; year += 1) {
    // Last year's value grows for 12 months; this year's 12 instalments are added.
    value = value * yearGrowth + current * factor;
    invested += current * 12;
    rows.push({ year, instalment: current, invested, value });
    current *= 1 + stepUpPercent / 100;
  }
  if (!Number.isFinite(value)) return { ok: false, error: "RESULT_TOO_LARGE" };
  return {
    ok: true,
    value: { invested, value, gains: value - invested, monthlyRate: i * 100, years: rows },
  };
}
