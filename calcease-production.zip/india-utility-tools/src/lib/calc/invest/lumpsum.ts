/**
 * Lumpsum (one-time) investment future value. Specification: docs/specs/lumpsum-calculator.md
 *
 * FV = P × (1 + r ÷ 100)^n — the expected yearly return compounded once a year for n whole
 * years. An illustration at a constant assumed return, not a forecast.
 */
import { checkInputs, type CalcErrorCode, type Outcome } from "../result";

export type LumpsumError =
  CalcErrorCode | "AMOUNT_NOT_POSITIVE" | "RETURN_OUT_OF_RANGE" | "YEARS_OUT_OF_RANGE";

export const LUMPSUM_LIMITS = { returnMax: 50, yearsMax: 50 } as const;

export interface LumpsumYear {
  year: number;
  value: number;
}

export interface LumpsumResult {
  invested: number;
  value: number;
  /** Estimated returns: value − invested. */
  gains: number;
  years: readonly LumpsumYear[];
}

export function lumpsumValue(
  amount: number,
  annualReturn: number,
  years: number,
): Outcome<LumpsumResult, LumpsumError> {
  const problem = checkInputs(amount, annualReturn, years);
  if (problem) return { ok: false, error: problem };
  if (amount <= 0) return { ok: false, error: "AMOUNT_NOT_POSITIVE" };
  if (annualReturn < 0 || annualReturn > LUMPSUM_LIMITS.returnMax)
    return { ok: false, error: "RETURN_OUT_OF_RANGE" };
  if (!Number.isInteger(years) || years < 1 || years > LUMPSUM_LIMITS.yearsMax)
    return { ok: false, error: "YEARS_OUT_OF_RANGE" };

  const growth = 1 + annualReturn / 100;
  const rows: LumpsumYear[] = [];
  for (let year = 1; year <= years; year += 1)
    rows.push({ year, value: amount * Math.pow(growth, year) });
  const value = rows[rows.length - 1]!.value;
  if (!Number.isFinite(value)) return { ok: false, error: "RESULT_TOO_LARGE" };
  return { ok: true, value: { invested: amount, value, gains: value - amount, years: rows } };
}
