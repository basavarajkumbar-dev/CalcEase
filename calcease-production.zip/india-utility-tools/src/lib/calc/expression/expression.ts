/**
 * A small, safe arithmetic evaluator for the general Calculator.
 * Specification: docs/specs/calculator.md
 *
 * Never uses eval() or Function(): the text is split into tokens from a fixed alphabet and
 * evaluated by a recursive-descent parser. Grammar (usual precedence, left to right):
 *
 *   expression := term (("+" | "−") term)*
 *   term       := unary (("×" | "÷") unary)*
 *   unary      := ("−" | "+") unary | postfix
 *   postfix    := primary "%"*
 *   primary    := number | "(" expression ")"
 *
 * Percent: x% is x ÷ 100 (200 × 10% = 20), except directly after + or −, where it is that
 * percentage of the value on the left, as on a handheld calculator (100 + 10% = 110).
 */
import type { Outcome } from "../result";

export type ExpressionError =
  "EMPTY" | "INVALID" | "UNBALANCED_PARENTHESES" | "DIVIDE_BY_ZERO" | "TOO_LARGE" | "TOO_LONG";

/** Longest expression accepted, and deepest bracket nesting. */
export const EXPRESSION_LIMITS = { maxLength: 200, maxDepth: 30, maxAbs: 1e15 } as const;

type Token =
  | { kind: "number"; value: number }
  | { kind: "op"; op: "+" | "-" | "*" | "/" }
  | { kind: "percent" }
  | { kind: "open" }
  | { kind: "close" };

const OPS: Record<string, "+" | "-" | "*" | "/"> = {
  "+": "+",
  "-": "-",
  "−": "-",
  "*": "*",
  "×": "*",
  x: "*",
  X: "*",
  "/": "/",
  "÷": "/",
};

class ParseError extends Error {
  constructor(readonly code: ExpressionError) {
    super(code);
  }
}

function tokenize(text: string): Token[] {
  const tokens: Token[] = [];
  let i = 0;
  while (i < text.length) {
    const ch = text[i]!;
    if (ch === " " || ch === ",") {
      // Spaces and digit-grouping commas are ignored.
      i += 1;
    } else if ((ch >= "0" && ch <= "9") || ch === ".") {
      let j = i;
      let dots = 0;
      while (
        j < text.length &&
        ((text[j]! >= "0" && text[j]! <= "9") || text[j] === "." || text[j] === ",")
      ) {
        if (text[j] === ".") dots += 1;
        j += 1;
      }
      const raw = text.slice(i, j).replace(/,/g, "");
      if (dots > 1 || raw === ".") throw new ParseError("INVALID");
      tokens.push({ kind: "number", value: Number(raw) });
      i = j;
    } else if (ch in OPS) {
      tokens.push({ kind: "op", op: OPS[ch]! });
      i += 1;
    } else if (ch === "%") {
      tokens.push({ kind: "percent" });
      i += 1;
    } else if (ch === "(") {
      tokens.push({ kind: "open" });
      i += 1;
    } else if (ch === ")") {
      tokens.push({ kind: "close" });
      i += 1;
    } else {
      throw new ParseError("INVALID");
    }
  }
  return tokens;
}

/** A value, remembering whether it was written as a bare percentage (for + and −). */
interface Value {
  value: number;
  percent: boolean;
}

function check(n: number): number {
  if (!Number.isFinite(n) || Math.abs(n) > EXPRESSION_LIMITS.maxAbs)
    throw new ParseError("TOO_LARGE");
  return n;
}

class Parser {
  private pos = 0;
  private depth = 0;
  constructor(private readonly tokens: Token[]) {}

  parse(): number {
    const result = this.expression();
    if (this.pos < this.tokens.length) {
      throw new ParseError(this.peek()?.kind === "close" ? "UNBALANCED_PARENTHESES" : "INVALID");
    }
    return check(result.percent ? result.value / 100 : result.value);
  }

  private peek(): Token | undefined {
    return this.tokens[this.pos];
  }

  private expression(): Value {
    let left = this.term();
    for (let t = this.peek(); t?.kind === "op" && (t.op === "+" || t.op === "-"); t = this.peek()) {
      this.pos += 1;
      // A percentage on the left of + or − is a plain number: 10% + 5 = 5.1.
      if (left.percent) left = { value: left.value / 100, percent: false };
      const right = this.term();
      const amount = right.percent ? (left.value * right.value) / 100 : right.value;
      left = {
        value: check(t.op === "+" ? left.value + amount : left.value - amount),
        percent: false,
      };
    }
    return left;
  }

  private term(): Value {
    let left = this.unary();
    for (let t = this.peek(); t?.kind === "op" && (t.op === "*" || t.op === "/"); t = this.peek()) {
      this.pos += 1;
      const right = this.unary();
      const a = left.percent ? left.value / 100 : left.value;
      const b = right.percent ? right.value / 100 : right.value;
      if (t.op === "/" && b === 0) throw new ParseError("DIVIDE_BY_ZERO");
      left = { value: check(t.op === "*" ? a * b : a / b), percent: false };
    }
    return left;
  }

  private unary(): Value {
    const t = this.peek();
    if (t?.kind === "op" && (t.op === "-" || t.op === "+")) {
      this.pos += 1;
      const inner = this.unary();
      return { value: t.op === "-" ? -inner.value : inner.value, percent: inner.percent };
    }
    return this.postfix();
  }

  private postfix(): Value {
    let result = this.primary();
    while (this.peek()?.kind === "percent") {
      this.pos += 1;
      // A second % applies to an already-percent value: 50%% = 0.5%.
      result = result.percent
        ? { value: result.value / 100, percent: true }
        : { value: result.value, percent: true };
    }
    return result;
  }

  private primary(): Value {
    const t = this.peek();
    if (!t) throw new ParseError("INVALID");
    if (t.kind === "number") {
      this.pos += 1;
      return { value: check(t.value), percent: false };
    }
    if (t.kind === "open") {
      this.pos += 1;
      this.depth += 1;
      if (this.depth > EXPRESSION_LIMITS.maxDepth) throw new ParseError("TOO_LONG");
      const inner = this.expression();
      if (this.peek()?.kind !== "close") throw new ParseError("UNBALANCED_PARENTHESES");
      this.pos += 1;
      this.depth -= 1;
      // A bracketed value is a plain number: (10%) is 0.1.
      return { value: inner.percent ? inner.value / 100 : inner.value, percent: false };
    }
    if (t.kind === "close") throw new ParseError("UNBALANCED_PARENTHESES");
    throw new ParseError("INVALID");
  }
}

/** Evaluates an arithmetic expression. Never throws; never returns NaN, Infinity or −0. */
export function evaluateExpression(text: string): Outcome<number, ExpressionError> {
  if (typeof text !== "string") return { ok: false, error: "INVALID" };
  if (text.length > EXPRESSION_LIMITS.maxLength) return { ok: false, error: "TOO_LONG" };
  if (text.trim() === "") return { ok: false, error: "EMPTY" };
  try {
    const tokens = tokenize(text);
    const value = new Parser(tokens).parse();
    return { ok: true, value: value === 0 ? 0 : value };
  } catch (error) {
    if (error instanceof ParseError) return { ok: false, error: error.code };
    return { ok: false, error: "INVALID" };
  }
}

/**
 * The value as plain text the parser can read back (no grouping, no exponent), with
 * binary floating-point noise removed: 0.1 + 0.2 gives "0.3".
 */
export function plainNumber(value: number): string {
  const text = value.toLocaleString("en-US", { useGrouping: false, maximumSignificantDigits: 15 });
  return text === "-0" ? "0" : text;
}
