export {
  discountByPercent,
  discountFromSalePrice,
  stackedDiscount,
  type DiscountError,
  type DiscountResult,
} from "./discount";
