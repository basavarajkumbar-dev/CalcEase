/**
 * Discount calculations. Specification: docs/specs/discount-calculator.md
 * Built on the Percentage engine so rounding behaviour is identical across tools.
 */
import {
  calculateDecreaseBy,
  calculatePercentChange,
  calculatePercentOf,
} from "../percentage/percentage";
import { checkInputs, type CalcErrorCode, type Outcome } from "../result";

export type DiscountError =
  | CalcErrorCode
  | "PRICE_NOT_POSITIVE"
  | "DISCOUNT_OUT_OF_RANGE"
  | "SALE_ABOVE_PRICE"
  | "SALE_NEGATIVE";

export interface DiscountResult {
  /** Amount saved in rupees. */
  saving: number;
  /** Price paid after the discount(s). */
  final: number;
  /** Discount as a percentage of the original price (effective, for stacked discounts). */
  percent: number;
}

/** Shared input checks from spec §3. */
function checkPrice(price: number): DiscountError | null {
  const problem = checkInputs(price);
  if (problem) return problem;
  return price > 0 ? null : "PRICE_NOT_POSITIVE";
}

function checkDiscount(...discounts: number[]): DiscountError | null {
  const problem = checkInputs(...discounts);
  if (problem) return problem;
  return discounts.every((d) => d >= 0 && d <= 100) ? null : "DISCOUNT_OUT_OF_RANGE";
}

const zero = (n: number) => (n === 0 ? 0 : n);

/** Price after d% off. */
export function discountByPercent(
  price: number,
  discount: number,
): Outcome<DiscountResult, DiscountError> {
  const problem = checkPrice(price) ?? checkDiscount(discount);
  if (problem) return { ok: false, error: problem };
  const saving = calculatePercentOf(discount, price);
  const final = calculateDecreaseBy(price, discount);
  if (!saving.ok || !final.ok) return { ok: false, error: "RESULT_TOO_LARGE" };
  return { ok: true, value: { saving: saving.value, final: zero(final.value), percent: discount } };
}

/** Discount implied by a sale price. */
export function discountFromSalePrice(
  price: number,
  sale: number,
): Outcome<DiscountResult, DiscountError> {
  const problem = checkPrice(price) ?? checkInputs(sale);
  if (problem) return { ok: false, error: problem };
  if (sale < 0) return { ok: false, error: "SALE_NEGATIVE" };
  if (sale > price) return { ok: false, error: "SALE_ABOVE_PRICE" };
  const change = calculatePercentChange(price, sale);
  if (!change.ok) return { ok: false, error: change.error };
  return {
    ok: true,
    value: { saving: zero(price - sale), final: sale, percent: zero(-change.value) },
  };
}

/** Two discounts applied one after the other: the extra discount applies to the reduced price. */
export function stackedDiscount(
  price: number,
  first: number,
  extra: number,
): Outcome<DiscountResult, DiscountError> {
  const problem = checkPrice(price) ?? checkDiscount(first, extra);
  if (problem) return { ok: false, error: problem };
  const afterFirst = calculateDecreaseBy(price, first);
  if (!afterFirst.ok) return { ok: false, error: afterFirst.error };
  const final = calculateDecreaseBy(afterFirst.value, extra);
  if (!final.ok) return { ok: false, error: final.error };
  const saving = price - final.value;
  return {
    ok: true,
    value: {
      saving: zero(saving),
      final: zero(final.value),
      percent: zero((saving * 100) / price),
    },
  };
}
