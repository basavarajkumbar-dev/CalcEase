/**
 * Loan EMI on a reducing balance, with the repayment schedule and an optional one-time
 * part-prepayment. Specification: docs/specs/emi-calculator.md
 */
import { checkInputs, type CalcErrorCode, type Outcome } from "../result";

export type EmiError =
  | CalcErrorCode
  | "PRINCIPAL_NOT_POSITIVE"
  | "RATE_OUT_OF_RANGE"
  | "TENURE_OUT_OF_RANGE"
  | "PREPAYMENT_MONTH_OUT_OF_RANGE"
  | "PREPAYMENT_NOT_POSITIVE"
  | "PREPAYMENT_TOO_LARGE";

export const EMI_LIMITS = { rateMax: 50, monthsMax: 480 } as const;

export interface ScheduleRow {
  month: number;
  payment: number;
  interest: number;
  principal: number;
  /** Part-prepayment made right after this month's EMI (0 if none). */
  prepayment: number;
  /** Outstanding balance after this month's payment (and any prepayment). */
  balance: number;
}

export interface EmiResult {
  emi: number;
  /** Payments actually made (fewer than the tenure after a prepayment). */
  months: number;
  totalInterest: number;
  /** Everything paid: EMIs, the smaller final EMI if any, and the prepayment. */
  totalPaid: number;
  schedule: readonly ScheduleRow[];
}

export interface Prepayment {
  /** Made right after this EMI (1-based). */
  afterMonth: number;
  amount: number;
}

/** EMI = P × r × (1 + r)^n ÷ ((1 + r)^n − 1), r = annual rate ÷ 1,200; P ÷ n at 0%. */
export function emiAmount(principal: number, ratePercent: number, months: number): number {
  const r = ratePercent / 1200;
  if (r === 0) return principal / months;
  // expm1/log1p keep full precision for small rates.
  const growthMinusOne = Math.expm1(months * Math.log1p(r));
  return (principal * r * (growthMinusOne + 1)) / growthMinusOne;
}

export function loanEmi(
  principal: number,
  ratePercent: number,
  months: number,
  prepayment?: Prepayment,
): Outcome<EmiResult, EmiError> {
  const problem = checkInputs(principal, ratePercent, months);
  if (problem) return { ok: false, error: problem };
  if (principal <= 0) return { ok: false, error: "PRINCIPAL_NOT_POSITIVE" };
  if (ratePercent < 0 || ratePercent > EMI_LIMITS.rateMax)
    return { ok: false, error: "RATE_OUT_OF_RANGE" };
  if (!Number.isInteger(months) || months < 1 || months > EMI_LIMITS.monthsMax)
    return { ok: false, error: "TENURE_OUT_OF_RANGE" };
  if (prepayment) {
    const p = checkInputs(prepayment.amount, prepayment.afterMonth);
    if (p) return { ok: false, error: p };
    if (
      !Number.isInteger(prepayment.afterMonth) ||
      prepayment.afterMonth < 1 ||
      prepayment.afterMonth >= months
    )
      return { ok: false, error: "PREPAYMENT_MONTH_OUT_OF_RANGE" };
    if (prepayment.amount <= 0) return { ok: false, error: "PREPAYMENT_NOT_POSITIVE" };
  }

  const r = ratePercent / 1200;
  const emi = emiAmount(principal, ratePercent, months);
  const schedule: ScheduleRow[] = [];
  let balance = principal;
  let totalInterest = 0;
  let totalPaid = 0;
  // Floating-point residue left after the last scheduled EMI (≈ 1e-9 of the loan) is
  // folded into the final payment so the schedule closes at exactly zero.
  const tolerance = principal * 1e-9;

  // Until a prepayment changes the loan, each balance is computed directly as the present
  // value of the EMIs still to pay. Carrying it forward month by month instead multiplies
  // rounding error by (1 + r) every month (about 10⁵ times over 40 years at 30%).
  const presentValue = (remaining: number) =>
    r === 0 ? emi * remaining : (emi * -Math.expm1(-remaining * Math.log1p(r))) / r;
  let prepaidAlready = false;

  for (let month = 1; balance > 0; month += 1) {
    const interest = balance * r;
    const isLast = prepaidAlready
      ? balance + interest <= emi + tolerance
      : month >= months || balance + interest <= emi + tolerance;
    const payment = isLast ? balance + interest : emi;
    let next = isLast
      ? 0
      : prepaidAlready
        ? balance + interest - payment
        : presentValue(months - month);
    let prepaid = 0;
    if (prepayment && month === prepayment.afterMonth && !isLast) {
      if (prepayment.amount >= next) return { ok: false, error: "PREPAYMENT_TOO_LARGE" };
      prepaid = prepayment.amount;
      next -= prepaid;
      prepaidAlready = true;
    }
    totalInterest += interest;
    totalPaid += payment + prepaid;
    schedule.push({
      month,
      payment,
      interest,
      principal: payment - interest,
      prepayment: prepaid,
      balance: next,
    });
    balance = next;
    if (month > EMI_LIMITS.monthsMax) return { ok: false, error: "RESULT_TOO_LARGE" };
  }
  return {
    ok: true,
    value: { emi, months: schedule.length, totalInterest, totalPaid, schedule },
  };
}

/**
 * Outstanding balance right after a given EMI, without prepayment: the present value of
 * the EMIs still to pay, emi × (1 − (1 + r)^−(n − k)) ÷ r. (Mathematically equal to
 * P(1 + r)^k − emi((1 + r)^k − 1) ÷ r, but without that form's cancellation late in
 * long, high-rate loans.)
 */
export function balanceAfter(
  principal: number,
  ratePercent: number,
  months: number,
  after: number,
): number {
  const r = ratePercent / 1200;
  const emi = emiAmount(principal, ratePercent, months);
  const remaining = months - after;
  if (r === 0) return principal - emi * after;
  return (emi * -Math.expm1(-remaining * Math.log1p(r))) / r;
}
