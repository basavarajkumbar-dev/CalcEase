/**
 * Salary hike calculations. Specification: docs/specs/percentage-hike-calculator.md
 * Built on the Percentage engine.
 */
import {
  calculateIncreaseBy,
  calculatePercentChange,
  calculatePercentOf,
  changeDirection,
} from "../percentage/percentage";
import { checkInputs, type CalcErrorCode, type Outcome } from "../result";
import type { ChangeDirection } from "../percentage/percentage";

export type HikeError =
  CalcErrorCode | "SALARY_NOT_POSITIVE" | "HIKE_OUT_OF_RANGE" | "NEW_SALARY_NEGATIVE";

export type PayPeriod = "month" | "year";

export interface HikeResult {
  /** Change in rupees for the entered period (negative for a pay cut). */
  change: number;
  /** New salary for the entered period. */
  result: number;
  /** Change as a percentage of the current salary. */
  percent: number;
  direction: ChangeDirection;
}

/** Spec §3: hikes from −100% (pay falls to zero) to 1,000%. */
export const HIKE_RANGE = { min: -100, max: 1000 } as const;

const zero = (n: number) => (n === 0 ? 0 : n);

export function salaryAfterHike(current: number, hike: number): Outcome<HikeResult, HikeError> {
  const problem = checkInputs(current, hike);
  if (problem) return { ok: false, error: problem };
  if (current <= 0) return { ok: false, error: "SALARY_NOT_POSITIVE" };
  if (hike < HIKE_RANGE.min || hike > HIKE_RANGE.max)
    return { ok: false, error: "HIKE_OUT_OF_RANGE" };
  const change = calculatePercentOf(hike, current);
  const result = calculateIncreaseBy(current, hike);
  if (!change.ok || !result.ok) return { ok: false, error: "RESULT_TOO_LARGE" };
  return {
    ok: true,
    value: {
      change: change.value,
      result: zero(result.value),
      percent: hike,
      direction: changeDirection(hike),
    },
  };
}

export function hikeBetweenSalaries(current: number, next: number): Outcome<HikeResult, HikeError> {
  const problem = checkInputs(current, next);
  if (problem) return { ok: false, error: problem };
  if (current <= 0) return { ok: false, error: "SALARY_NOT_POSITIVE" };
  if (next < 0) return { ok: false, error: "NEW_SALARY_NEGATIVE" };
  const percent = calculatePercentChange(current, next);
  if (!percent.ok) return { ok: false, error: percent.error };
  return {
    ok: true,
    value: {
      change: zero(next - current),
      result: next,
      percent: percent.value,
      direction: changeDirection(percent.value),
    },
  };
}

/** The same amount expressed per month or per year (× 12 or ÷ 12, no rounding). */
export function convertPeriod(amount: number, from: PayPeriod): number {
  return from === "month" ? amount * 12 : amount / 12;
}
