export {
  convertPeriod,
  HIKE_RANGE,
  hikeBetweenSalaries,
  salaryAfterHike,
  type HikeError,
  type HikeResult,
  type PayPeriod,
} from "./hike";
