/**
 * The five calculation modes offered by the Percentage Calculator, with the
 * input definitions the UI renders. Kept beside the maths so the UI never has to
 * know which function belongs to which mode.
 */
import type { CalcResult } from "../result";
import {
  calculateDecreaseBy,
  calculateIncreaseBy,
  calculatePercentChange,
  calculatePercentOf,
  calculateWhatPercent,
} from "./percentage";

export type PercentageMode =
  "percentOf" | "whatPercent" | "percentChange" | "increaseBy" | "decreaseBy";

export interface ModeInput {
  /** Label shown above the field. */
  label: string;
  /** Example value used as the placeholder. */
  example: string;
  /** Unit shown after the field, if any. */
  suffix?: "%";
}

export interface ModeDefinition {
  id: PercentageMode;
  /** Option text in the mode selector, phrased as the user's question. */
  question: string;
  inputs: readonly [ModeInput, ModeInput];
  /** True when the result itself is a percentage. */
  resultIsPercent: boolean;
  calculate: (a: number, b: number) => CalcResult;
}

export const PERCENTAGE_MODES: readonly ModeDefinition[] = [
  {
    id: "percentOf",
    question: "What is X% of a number?",
    inputs: [
      { label: "Percentage", example: "20", suffix: "%" },
      { label: "Of the number", example: "500" },
    ],
    resultIsPercent: false,
    calculate: calculatePercentOf,
  },
  {
    id: "whatPercent",
    question: "A number is what % of another?",
    inputs: [
      { label: "Number (part)", example: "100" },
      { label: "Of the total (whole)", example: "500" },
    ],
    resultIsPercent: true,
    calculate: calculateWhatPercent,
  },
  {
    id: "percentChange",
    question: "% increase or decrease",
    inputs: [
      { label: "From (original value)", example: "500" },
      { label: "To (new value)", example: "600" },
    ],
    resultIsPercent: true,
    calculate: calculatePercentChange,
  },
  {
    id: "increaseBy",
    question: "Increase a number by X%",
    inputs: [
      { label: "Number", example: "500" },
      { label: "Increase by", example: "20", suffix: "%" },
    ],
    resultIsPercent: false,
    calculate: calculateIncreaseBy,
  },
  {
    id: "decreaseBy",
    question: "Decrease a number by X%",
    inputs: [
      { label: "Number", example: "500" },
      { label: "Decrease by", example: "20", suffix: "%" },
    ],
    resultIsPercent: false,
    calculate: calculateDecreaseBy,
  },
];

export function getMode(id: PercentageMode): ModeDefinition {
  const mode = PERCENTAGE_MODES.find((m) => m.id === id);
  if (!mode) throw new Error(`Unknown percentage mode: ${id}`);
  return mode;
}

export function isPercentageMode(value: string): value is PercentageMode {
  return PERCENTAGE_MODES.some((m) => m.id === value);
}
