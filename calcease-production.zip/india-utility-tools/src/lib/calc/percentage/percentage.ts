/**
 * Percentage calculations. Pure functions: no React, no Next.js, no browser APIs.
 * Specification: docs/specs/percentage-calculator.md
 *
 * Every function multiplies before dividing by 100 so that results with an exact
 * decimal answer stay exact in binary floating point (spec, section 1).
 * Results are full precision; rounding happens only in the display layer.
 */
import { checkInputs, failure, success, type CalcResult } from "../result";

/** What is `percent`% of `value`? Example: 20% of 500 = 100. */
export function calculatePercentOf(percent: number, value: number): CalcResult {
  const problem = checkInputs(percent, value);
  if (problem) return failure(problem);
  return success((percent * value) / 100);
}

/** `part` is what percentage of `whole`? Example: 100 of 500 = 20 (%). */
export function calculateWhatPercent(part: number, whole: number): CalcResult {
  const problem = checkInputs(part, whole);
  if (problem) return failure(problem);
  if (whole === 0) return failure("DIVISION_BY_ZERO");
  return success((part * 100) / whole);
}

/**
 * Signed percentage change from `from` to `to`, relative to |from|.
 * Positive = increase, negative = decrease. Examples: 500 → 600 = 20; 600 → 500 = -16.67.
 * Dividing by |from| keeps the sign meaning "went up / went down" for negative starts
 * (spec, section 1).
 */
export function calculatePercentChange(from: number, to: number): CalcResult {
  const problem = checkInputs(from, to);
  if (problem) return failure(problem);
  if (from === 0) return failure("DIVISION_BY_ZERO");
  return success(((to - from) * 100) / Math.abs(from));
}

/** `value` increased by `percent`%. Example: 500 increased by 20% = 600. */
export function calculateIncreaseBy(value: number, percent: number): CalcResult {
  const problem = checkInputs(value, percent);
  if (problem) return failure(problem);
  return success(value + (value * percent) / 100);
}

/** `value` decreased by `percent`%. Example: 500 decreased by 20% = 400. */
export function calculateDecreaseBy(value: number, percent: number): CalcResult {
  const problem = checkInputs(value, percent);
  if (problem) return failure(problem);
  return success(value - (value * percent) / 100);
}

export type ChangeDirection = "increase" | "decrease" | "none";

/** Direction of a signed percentage change, for labelling without relying on colour. */
export function changeDirection(signedChange: number): ChangeDirection {
  if (signedChange > 0) return "increase";
  if (signedChange < 0) return "decrease";
  return "none";
}
