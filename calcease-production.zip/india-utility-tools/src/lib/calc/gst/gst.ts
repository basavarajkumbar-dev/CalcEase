/**
 * GST calculations. Specification: docs/specs/gst-calculator.md
 * Rates are inputs: presets come from src/lib/rules/gst, never from this file.
 */
import { checkInputs, type CalcErrorCode, type Outcome } from "../result";

export type GstError = CalcErrorCode | "AMOUNT_NOT_POSITIVE" | "RATE_OUT_OF_RANGE";

export interface GstResult {
  /** Price before GST (taxable value). */
  base: number;
  /** GST amount. */
  gst: number;
  /** Price including GST. */
  total: number;
  /** Each of CGST and SGST/UTGST for an intra-state supply (gst ÷ 2). */
  half: number;
}

export const GST_RATE_RANGE = { min: 0, max: 100 } as const;

function check(amount: number, rate: number): GstError | null {
  const problem = checkInputs(amount, rate);
  if (problem) return problem;
  if (amount <= 0) return "AMOUNT_NOT_POSITIVE";
  if (rate < GST_RATE_RANGE.min || rate > GST_RATE_RANGE.max) return "RATE_OUT_OF_RANGE";
  return null;
}

const zero = (n: number) => (n === 0 ? 0 : n);

function result(base: number, gst: number, total: number): Outcome<GstResult, GstError> {
  if (![base, gst, total].every(Number.isFinite)) return { ok: false, error: "RESULT_TOO_LARGE" };
  return { ok: true, value: { base, gst: zero(gst), total, half: zero(gst / 2) } };
}

/** Add GST at `rate`% to a price before tax. */
export function gstExclusive(amount: number, rate: number): Outcome<GstResult, GstError> {
  const problem = check(amount, rate);
  if (problem) return { ok: false, error: problem };
  const gst = (amount * rate) / 100;
  return result(amount, gst, amount + gst);
}

/** Split a GST-inclusive price into the price before tax and the GST at `rate`%. */
export function gstInclusive(total: number, rate: number): Outcome<GstResult, GstError> {
  const problem = check(total, rate);
  if (problem) return { ok: false, error: problem };
  const base = (total * 100) / (100 + rate);
  return result(base, total - base, total);
}
