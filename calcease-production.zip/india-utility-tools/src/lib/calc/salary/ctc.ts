/**
 * CTC to in-hand salary. Specification: docs/specs/ctc-to-in-hand-salary-calculator.md
 * STATUS: UNDER REVIEW — not published; see docs/reviews/ctc-to-in-hand.md.
 *
 * Rates are inputs (from src/lib/rules), never constants in this file.
 */
import type { EpfRuleSet } from "../../rules/epf/rates";
import type { IncomeTaxRuleSet, RegimeRules } from "../../rules/income-tax/rates";
import { checkInputs, type CalcErrorCode, type Outcome } from "../result";

export type Regime = "new" | "old";
export type PfMode = "full" | "capped" | "none";

export type CtcError =
  | CalcErrorCode
  | "CTC_NOT_POSITIVE"
  | "BASIC_OUT_OF_RANGE"
  | "COSTS_TOO_HIGH"
  | "ABOVE_SURCHARGE_THRESHOLD";

export interface CtcInput {
  ctc: number;
  /** Basic salary as a percentage of CTC. */
  basicPercent: number;
  /** Is the employer's PF contribution part of the CTC? (Usually yes.) */
  employerPfInCtc: boolean;
  pfMode: PfMode;
  /**
   * Gratuity included in the CTC, accrued at 15 days' basic per year with the monthly
   * basic divided by 26 (Payment of Gratuity Act rate): basic × 15 ÷ 26 ÷ 12 a year.
   * Optional; employers differ.
   */
  gratuityInCtc?: boolean;
  /** Other employer costs included in the CTC (insurance …), yearly. */
  otherEmployerCosts: number;
  /** Professional tax, monthly. */
  professionalTaxMonthly: number;
  regime: Regime;
  /** Old regime only: deductions and exemptions claimed (80C, 80D, HRA …), yearly. */
  oldRegimeDeductions: number;
}

export interface TaxBreakdown {
  taxableIncome: number;
  slabTax: number;
  rebate: number;
  cess: number;
  totalTax: number;
}

export interface CtcResult extends TaxBreakdown {
  basic: number;
  employerPf: number;
  employeePf: number;
  gratuity: number;
  /** Gross salary: CTC minus the employer's PF and other employer costs. */
  gross: number;
  professionalTax: number;
  inHandYearly: number;
  inHandMonthly: number;
}

/** Tax on an income under a slab table (before rebate and cess). */
export function slabTax(income: number, slabs: RegimeRules["slabs"]): number {
  let tax = 0;
  let lower = 0;
  for (const slab of slabs) {
    const upper = slab.upTo ?? Number.POSITIVE_INFINITY;
    if (income > lower) tax += ((Math.min(income, upper) - lower) * slab.rate) / 100;
    lower = upper;
  }
  return tax;
}

export function incomeTax(taxable: number, regime: RegimeRules, cessRate: number): TaxBreakdown {
  const income = Math.max(0, taxable);
  const tax = slabTax(income, regime.slabs);
  let rebate = 0;
  if (income <= regime.rebateIncomeLimit) rebate = Math.min(tax, regime.rebateMax);
  else if (regime.rebateMarginalRelief)
    rebate = Math.max(0, tax - (income - regime.rebateIncomeLimit));
  const afterRebate = tax - rebate;
  const cess = (afterRebate * cessRate) / 100;
  return { taxableIncome: income, slabTax: tax, rebate, cess, totalTax: afterRebate + cess };
}

export function ctcToInHand(
  input: CtcInput,
  taxRules: IncomeTaxRuleSet,
  epf: EpfRuleSet,
): Outcome<CtcResult, CtcError> {
  const {
    ctc,
    basicPercent,
    employerPfInCtc,
    pfMode,
    otherEmployerCosts,
    professionalTaxMonthly,
    regime,
    oldRegimeDeductions,
  } = input;
  const problem = checkInputs(
    ctc,
    basicPercent,
    otherEmployerCosts,
    professionalTaxMonthly,
    oldRegimeDeductions,
  );
  if (problem) return { ok: false, error: problem };
  if (ctc <= 0) return { ok: false, error: "CTC_NOT_POSITIVE" };
  if (basicPercent <= 0 || basicPercent > 100) return { ok: false, error: "BASIC_OUT_OF_RANGE" };

  const basic = (ctc * basicPercent) / 100;
  const pfWagesMonthly =
    pfMode === "none"
      ? 0
      : pfMode === "capped"
        ? Math.min(basic / 12, epf.wageCeiling)
        : basic / 12;
  const employeePf = (pfWagesMonthly * 12 * epf.employeeRate) / 100;
  const employerPf = (pfWagesMonthly * 12 * epf.employerRate) / 100;
  const gratuity = input.gratuityInCtc ? ((basic / 12) * 15) / 26 : 0;
  const gross = ctc - (employerPfInCtc ? employerPf : 0) - gratuity - otherEmployerCosts;
  const professionalTax = professionalTaxMonthly * 12;
  if (gross <= employeePf + professionalTax) return { ok: false, error: "COSTS_TOO_HIGH" };

  const rules = regime === "new" ? taxRules.newRegime : taxRules.oldRegime;
  const taxable =
    gross -
    rules.standardDeduction -
    (rules.professionalTaxDeductible ? professionalTax : 0) -
    (regime === "old" ? oldRegimeDeductions : 0);
  if (taxable > taxRules.surchargeFrom) return { ok: false, error: "ABOVE_SURCHARGE_THRESHOLD" };

  const tax = incomeTax(taxable, rules, taxRules.cessRate);
  const inHandYearly = gross - employeePf - professionalTax - tax.totalTax;
  return {
    ok: true,
    value: {
      ...tax,
      basic,
      employerPf,
      employeePf,
      gratuity,
      gross,
      professionalTax,
      inHandYearly,
      inHandMonthly: inHandYearly / 12,
    },
  };
}
