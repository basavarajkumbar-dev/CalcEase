/**
 * Recurring deposit maturity with quarterly compounding, using the formula banks publish:
 *   M = R × [(1 + i)^n − 1] ÷ [1 − (1 + i)^(−1/3)],  i = rate ÷ 400, n = quarters.
 * Specification: docs/specs/rd-calculator.md
 */
import { checkInputs, type CalcErrorCode, type Outcome } from "../result";

export type RdError =
  | CalcErrorCode
  | "INSTALMENT_NOT_POSITIVE"
  | "RATE_OUT_OF_RANGE"
  | "TENURE_OUT_OF_RANGE"
  | "TENURE_NOT_WHOLE_QUARTERS";

export interface RdResult {
  maturity: number;
  deposited: number;
  interest: number;
}

export const RD_LIMITS = { rateMax: 20, minMonths: 3, maxMonths: 120 } as const;

export function recurringDeposit(
  instalment: number,
  rate: number,
  months: number,
): Outcome<RdResult, RdError> {
  const problem = checkInputs(instalment, rate, months);
  if (problem) return { ok: false, error: problem };
  if (instalment <= 0) return { ok: false, error: "INSTALMENT_NOT_POSITIVE" };
  if (rate <= 0 || rate > RD_LIMITS.rateMax) return { ok: false, error: "RATE_OUT_OF_RANGE" };
  if (!Number.isInteger(months) || months < RD_LIMITS.minMonths || months > RD_LIMITS.maxMonths)
    return { ok: false, error: "TENURE_OUT_OF_RANGE" };
  if (months % 3 !== 0) return { ok: false, error: "TENURE_NOT_WHOLE_QUARTERS" };

  const i = rate / 400;
  const n = months / 3;
  // expm1/log1p keep full precision for small rates.
  const growth = Math.expm1(n * Math.log1p(i));
  const monthly = -Math.expm1(-Math.log1p(i) / 3);
  const maturity = (instalment * growth) / monthly;
  if (!Number.isFinite(maturity)) return { ok: false, error: "RESULT_TOO_LARGE" };
  const deposited = instalment * months;
  return { ok: true, value: { maturity, deposited, interest: maturity - deposited } };
}
