/**
 * Compound interest. Specification: docs/specs/compound-interest-calculator.md
 */
import { checkInputs, type CalcErrorCode, type Outcome } from "../result";

export const COMPOUNDING = { yearly: 1, halfYearly: 2, quarterly: 4, monthly: 12 } as const;
export type Compounding = keyof typeof COMPOUNDING;

export type CompoundError =
  CalcErrorCode | "PRINCIPAL_NOT_POSITIVE" | "RATE_OUT_OF_RANGE" | "TIME_OUT_OF_RANGE";

export interface YearRow {
  /** 1, 2, …; the last row may be a part year (e.g. 2.5). */
  year: number;
  interest: number;
  balance: number;
}

export interface CompoundResult {
  amount: number;
  interest: number;
  /** Simple interest on the same principal, rate and time, for comparison. */
  simpleInterest: number;
  /** Effective annual rate in percent: (1 + r/n)^n − 1. */
  effectiveRate: number;
  years: readonly YearRow[];
}

export const CI_LIMITS = { rateMax: 100, yearsMax: 100 } as const;

/** A = P (1 + r / 100n)^(n·t). Part periods use the same formula with a fractional power. */
export function compoundInterest(
  principal: number,
  ratePercent: number,
  years: number,
  compounding: Compounding,
): Outcome<CompoundResult, CompoundError> {
  const problem = checkInputs(principal, ratePercent, years);
  if (problem) return { ok: false, error: problem };
  if (principal <= 0) return { ok: false, error: "PRINCIPAL_NOT_POSITIVE" };
  if (ratePercent < 0 || ratePercent > CI_LIMITS.rateMax)
    return { ok: false, error: "RATE_OUT_OF_RANGE" };
  if (years <= 0 || years > CI_LIMITS.yearsMax) return { ok: false, error: "TIME_OUT_OF_RANGE" };

  const n = COMPOUNDING[compounding];
  // growth(t) − 1, computed with expm1/log1p so small interest on a large principal keeps
  // full precision (A − P would lose digits to cancellation).
  const gain = (t: number) => Math.expm1(n * t * Math.log1p(ratePercent / (100 * n)));
  const growth = (t: number) => 1 + gain(t);
  const interest = principal * gain(years);
  const amount = principal + interest;
  if (!Number.isFinite(amount)) return { ok: false, error: "RESULT_TOO_LARGE" };

  const rows: YearRow[] = [];
  let previous = principal;
  for (let y = 1; y < years + 1; y += 1) {
    const t = Math.min(y, years);
    const balance = principal * growth(t);
    rows.push({ year: t, interest: balance - previous, balance });
    previous = balance;
  }
  return {
    ok: true,
    value: {
      amount,
      interest,
      simpleInterest: (principal * ratePercent * years) / 100,
      effectiveRate: gain(1) * 100,
      years: rows,
    },
  };
}
