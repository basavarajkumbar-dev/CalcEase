/**
 * Fixed deposit maturity, following the method published by Indian banks.
 * Specification: docs/specs/fd-calculator.md
 *
 * - Interest is compounded every completed quarter, counted from the deposit date.
 * - For the broken period after the last completed quarter, simple interest on the
 *   accumulated amount for the actual number of days, at rate × days ÷ 365.
 * - Deposits shorter than a bank-specific limit (3, 6 or 12 months) earn simple interest
 *   for the actual number of days.
 */
import { checkInputs, type CalcErrorCode, type Outcome } from "../result";
import {
  addMonths,
  compareDates,
  isInRange,
  toDayNumber,
  type PlainDate,
} from "../date/plain-date";

export type FdPayout = "cumulative" | "quarterly";
export type SimpleInterestBelow = 3 | 6 | 12;

export type FdError =
  | CalcErrorCode
  | "PRINCIPAL_NOT_POSITIVE"
  | "RATE_OUT_OF_RANGE"
  | "TENURE_TOO_SHORT"
  | "TENURE_TOO_LONG"
  | "MATURITY_OUT_OF_RANGE";

export interface FdInput {
  principal: number;
  /** Annual rate in percent. */
  rate: number;
  start: PlainDate;
  maturity: PlainDate;
  payout: FdPayout;
  /** Deposits shorter than this many months earn simple interest. */
  simpleBelowMonths: SimpleInterestBelow;
}

export interface FdResult {
  /** Amount paid at maturity: principal + interest (cumulative) or principal (payout). */
  maturityAmount: number;
  /** Total interest over the deposit. */
  interest: number;
  /** Interest paid each completed quarter (quarterly payout only). */
  quarterlyPayout?: number;
  /** Interest for the broken period, paid at maturity (quarterly payout only). */
  finalPayout?: number;
  totalDays: number;
  /** Completed quarters (0 for simple interest). */
  quarters: number;
  /** Days after the last completed quarter. */
  brokenDays: number;
  /** True when the whole deposit earns simple interest (short deposit). */
  simple: boolean;
}

export const FD_LIMITS = { rateMax: 20, minDays: 7, maxMonths: 120 } as const;
const DAYS_IN_YEAR = 365;

export function fixedDeposit(input: FdInput): Outcome<FdResult, FdError> {
  const { principal, rate, start, maturity, payout, simpleBelowMonths } = input;
  const problem = checkInputs(principal, rate);
  if (problem) return { ok: false, error: problem };
  if (principal <= 0) return { ok: false, error: "PRINCIPAL_NOT_POSITIVE" };
  if (rate <= 0 || rate > FD_LIMITS.rateMax) return { ok: false, error: "RATE_OUT_OF_RANGE" };
  if (!isInRange(start) || !isInRange(maturity))
    return { ok: false, error: "MATURITY_OUT_OF_RANGE" };

  const totalDays = toDayNumber(maturity) - toDayNumber(start);
  if (totalDays < FD_LIMITS.minDays) return { ok: false, error: "TENURE_TOO_SHORT" };
  if (compareDates(maturity, addMonths(start, FD_LIMITS.maxMonths).date) > 0)
    return { ok: false, error: "TENURE_TOO_LONG" };

  const simple = compareDates(maturity, addMonths(start, simpleBelowMonths).date) < 0;
  if (simple) {
    const interest = (principal * rate * totalDays) / (100 * DAYS_IN_YEAR);
    return {
      ok: true,
      value: {
        maturityAmount: principal + interest,
        interest,
        ...(payout === "quarterly" ? { quarterlyPayout: 0, finalPayout: interest } : {}),
        totalDays,
        quarters: 0,
        brokenDays: totalDays,
        simple: true,
      },
    };
  }

  // Completed quarters, each counted from the deposit date (so 31st-of-month deposits
  // do not drift): the most k with start + 3k months ≤ maturity.
  let quarters = Math.floor(
    ((maturity.year - start.year) * 12 + (maturity.month - start.month)) / 3,
  );
  while (compareDates(addMonths(start, 3 * quarters).date, maturity) > 0) quarters -= 1;
  const lastQuarter = addMonths(start, 3 * quarters).date;
  const brokenDays = toDayNumber(maturity) - toDayNumber(lastQuarter);
  const brokenFactor = (rate * brokenDays) / (100 * DAYS_IN_YEAR);

  if (payout === "quarterly") {
    const quarterlyPayout = (principal * rate) / 400;
    const finalPayout = principal * brokenFactor;
    return {
      ok: true,
      value: {
        maturityAmount: principal,
        interest: quarterlyPayout * quarters + finalPayout,
        quarterlyPayout,
        finalPayout,
        totalDays,
        quarters,
        brokenDays,
        simple: false,
      },
    };
  }

  const accumulated = principal * Math.pow(1 + rate / 400, quarters);
  const maturityAmount = accumulated * (1 + brokenFactor);
  return {
    ok: true,
    value: {
      maturityAmount,
      interest: maturityAmount - principal,
      totalDays,
      quarters,
      brokenDays,
      simple: false,
    },
  };
}
