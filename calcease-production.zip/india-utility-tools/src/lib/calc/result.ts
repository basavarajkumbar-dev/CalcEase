/**
 * Shared result and input-guard types for every calculation in src/lib/calc.
 *
 * Calculations never throw for bad input and never return NaN, Infinity or -0.
 * They return a discriminated union so callers (UI, tests, a future API) must
 * handle the error case explicitly.
 */

/** Largest accepted absolute input value: 10^12 (one lakh crore). See the spec, section 2. */
export const MAX_ABS_INPUT = 1e12;

export type CalcErrorCode =
  "NOT_A_NUMBER" | "OUT_OF_RANGE" | "DIVISION_BY_ZERO" | "RESULT_TOO_LARGE";

export type CalcResult = { ok: true; value: number } | { ok: false; error: CalcErrorCode };

export function success(value: number): CalcResult {
  // Valid inputs can still overflow when dividing by a tiny number, e.g. a change
  // from 5e-324 (regression found by property testing). Never leak Infinity.
  if (!Number.isFinite(value)) return failure("RESULT_TOO_LARGE");
  // Normalise -0 to 0 (e.g. 0% of -500).
  return { ok: true, value: value === 0 ? 0 : value };
}

export function failure(error: CalcErrorCode): CalcResult {
  return { ok: false, error };
}

/**
 * Checks that every input is a finite number within ±MAX_ABS_INPUT.
 * Returns the first problem found, or null when all inputs are valid.
 */
export function checkInputs(...inputs: number[]): CalcErrorCode | null {
  for (const input of inputs) {
    if (typeof input !== "number" || !Number.isFinite(input)) return "NOT_A_NUMBER";
  }
  for (const input of inputs) {
    if (Math.abs(input) > MAX_ABS_INPUT) return "OUT_OF_RANGE";
  }
  return null;
}

/**
 * Result type for calculations that return several values (e.g. saving and final price)
 * or have their own error codes. Same contract as CalcResult: never throws, never
 * returns non-finite numbers.
 */
export type Outcome<T, E extends string = CalcErrorCode> =
  { ok: true; value: T } | { ok: false; error: E };
