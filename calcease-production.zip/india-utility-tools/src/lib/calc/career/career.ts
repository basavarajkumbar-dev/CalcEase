/**
 * Work experience and notice period, on the plain-date engine (no time zones).
 * Specifications: docs/specs/experience-calculator.md, docs/specs/notice-period-calculator.md
 */
import type { Outcome } from "../result";
import { dateDifference, type DateDifference } from "../date/difference";
import { addDays, compareDates, isInRange, toDayNumber, type PlainDate } from "../date/plain-date";

export type ExperienceError = "END_BEFORE_JOINING" | "OUT_OF_RANGE";

/**
 * Experience from the joining date to the end (relieving) date. By default both dates
 * count as days worked (joined 1 Jan 2020, last day 31 Dec 2024 = exactly 5 years).
 */
export function workExperience(
  joining: PlainDate,
  end: PlainDate,
  includeEnd = true,
): Outcome<DateDifference, ExperienceError> {
  if (!isInRange(joining) || !isInRange(end)) return { ok: false, error: "OUT_OF_RANGE" };
  if (compareDates(end, joining) < 0) return { ok: false, error: "END_BEFORE_JOINING" };
  return { ok: true, value: dateDifference(joining, end, includeEnd) };
}

export type NoticeError = "NOTICE_OUT_OF_RANGE" | "OUT_OF_RANGE";

export const NOTICE_LIMITS = { minDays: 1, maxDays: 365 } as const;

export interface NoticeResult {
  lastWorkingDay: PlainDate;
  /** First day of the notice period. */
  firstNoticeDay: PlainDate;
  /** Calendar days from today to the last working day (negative once it has passed). */
  daysUntilLastDay?: number;
  /** Notice days already served by today, counted the same way as the notice period. */
  daysServed?: number;
}

/**
 * Last working day for a notice period of `days` calendar days.
 * Default: the notice starts the day after resignation, so it ends `days` days later
 * (resign 8 Oct, 30 days → 7 Nov). With countResignationDay, the resignation date is day 1
 * (→ 6 Nov). `today` is optional, for the remaining-days figures.
 */
export function noticePeriod(
  resignation: PlainDate,
  days: number,
  countResignationDay = false,
  today?: PlainDate,
): Outcome<NoticeResult, NoticeError> {
  if (!Number.isInteger(days) || days < NOTICE_LIMITS.minDays || days > NOTICE_LIMITS.maxDays)
    return { ok: false, error: "NOTICE_OUT_OF_RANGE" };
  if (!isInRange(resignation)) return { ok: false, error: "OUT_OF_RANGE" };
  const firstNoticeDay = countResignationDay ? resignation : addDays(resignation, 1);
  const lastWorkingDay = addDays(firstNoticeDay, days - 1);
  if (!isInRange(lastWorkingDay)) return { ok: false, error: "OUT_OF_RANGE" };
  if (!today) return { ok: true, value: { lastWorkingDay, firstNoticeDay } };
  const served = toDayNumber(today) - toDayNumber(firstNoticeDay) + 1;
  return {
    ok: true,
    value: {
      lastWorkingDay,
      firstNoticeDay,
      daysUntilLastDay: toDayNumber(lastWorkingDay) - toDayNumber(today),
      daysServed: Math.min(days, Math.max(0, served)),
    },
  };
}
