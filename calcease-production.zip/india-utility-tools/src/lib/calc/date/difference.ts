/**
 * Differences between two dates. Specification: docs/specs/date-engine.md §4
 */
import { addDays, addMonths, compareDates, toDayNumber, type PlainDate } from "./plain-date";

export interface YearsMonthsDays {
  years: number;
  months: number;
  days: number;
}

/**
 * Calendar difference from `start` to a later (or equal) `end`: the most whole months
 * such that start + months (clamped) is not after end, then the remaining days.
 * Same convention as Python's dateutil.relativedelta.
 */
export function calendarDifference(start: PlainDate, end: PlainDate): YearsMonthsDays {
  if (compareDates(end, start) < 0) throw new RangeError("end is before start");
  let months = (end.year - start.year) * 12 + (end.month - start.month);
  let anchor = addMonths(start, months).date;
  if (compareDates(anchor, end) > 0) {
    months -= 1;
    anchor = addMonths(start, months).date;
  }
  return {
    years: Math.floor(months / 12),
    months: months % 12,
    days: toDayNumber(end) - toDayNumber(anchor),
  };
}

/** Monday-to-Friday days in [start, end): the start counts, the end does not. */
export function weekdaysBetween(start: PlainDate, end: PlainDate): number {
  const a = toDayNumber(start);
  const b = toDayNumber(end);
  if (b <= a) return 0;
  const total = b - a;
  let count = Math.floor(total / 7) * 5;
  // ISO weekday of the first day in the leftover part (1 = Monday).
  let weekday = ((((a + Math.floor(total / 7) * 7 + 3) % 7) + 7) % 7) + 1;
  for (let i = 0; i < total % 7; i += 1) {
    if (weekday <= 5) count += 1;
    weekday = weekday === 7 ? 1 : weekday + 1;
  }
  return count;
}

export interface DateDifference extends YearsMonthsDays {
  /** Total days between the dates (plus one when the end date is included). */
  totalDays: number;
  /** totalDays as whole weeks and remaining days. */
  weeks: number;
  weekRemainderDays: number;
  /** Whole calendar months (years × 12 + months). */
  totalMonths: number;
  /** Monday–Friday days counted (public holidays are not removed). */
  weekdays: number;
  /** True when the dates were entered in reverse order (the result is the same). */
  reversed: boolean;
}

/**
 * Difference between two dates in either order. By default the end date is not counted
 * (1 → 2 January is 1 day). With includeEnd, both dates count (1 → 2 January is 2 days):
 * this is the same as moving the later date one day on.
 */
export function dateDifference(
  first: PlainDate,
  second: PlainDate,
  includeEnd = false,
): DateDifference {
  const reversed = compareDates(second, first) < 0;
  const start = reversed ? second : first;
  const last = reversed ? first : second;
  const end = includeEnd ? addDays(last, 1) : last;
  const ymd = calendarDifference(start, end);
  const totalDays = toDayNumber(end) - toDayNumber(start);
  return {
    ...ymd,
    totalDays,
    weeks: Math.floor(totalDays / 7),
    weekRemainderDays: totalDays % 7,
    totalMonths: ymd.years * 12 + ymd.months,
    weekdays: weekdaysBetween(start, end),
    reversed,
  };
}
