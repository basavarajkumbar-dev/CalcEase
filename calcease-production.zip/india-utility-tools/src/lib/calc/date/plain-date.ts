/**
 * Calendar dates without time zones. Specification: docs/specs/date-engine.md
 *
 * A PlainDate is a day on the (proleptic) Gregorian calendar, with no time and no time
 * zone. JavaScript Date is never used for arithmetic: Date values are instants, and
 * converting them to calendar days depends on the device's time zone and daylight
 * saving, which is how "days between" tools end up a day out.
 */

export interface PlainDate {
  year: number;
  /** 1–12 */
  month: number;
  /** 1–31 */
  day: number;
}

/** Dates the tools accept: 1 January 1900 to 31 December 2199 (spec §2). */
export const DATE_RANGE = {
  min: { year: 1900, month: 1, day: 1 },
  max: { year: 2199, month: 12, day: 31 },
} as const satisfies { min: PlainDate; max: PlainDate };

export function isLeapYear(year: number): boolean {
  return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
}

export function daysInMonth(year: number, month: number): number {
  if (month === 2) return isLeapYear(year) ? 29 : 28;
  return [4, 6, 9, 11].includes(month) ? 30 : 31;
}

export function isValidDate(d: PlainDate): boolean {
  return (
    Number.isInteger(d.year) &&
    Number.isInteger(d.month) &&
    Number.isInteger(d.day) &&
    d.month >= 1 &&
    d.month <= 12 &&
    d.day >= 1 &&
    d.day <= daysInMonth(d.year, d.month)
  );
}

const ISO = /^(\d{4})-(\d{2})-(\d{2})$/;

/** Parses "YYYY-MM-DD" (the value of <input type="date">). Invalid dates give undefined. */
export function parseIsoDate(text: string): PlainDate | undefined {
  const match = ISO.exec(text);
  if (!match) return undefined;
  const date = { year: Number(match[1]), month: Number(match[2]), day: Number(match[3]) };
  return isValidDate(date) ? date : undefined;
}

const pad = (n: number, width: number) => String(n).padStart(width, "0");

export function formatIsoDate(d: PlainDate): string {
  return `${pad(d.year, 4)}-${pad(d.month, 2)}-${pad(d.day, 2)}`;
}

/**
 * Days since 1970-01-01 (negative before). Algorithm "days_from_civil" by Howard Hinnant,
 * exact for every Gregorian date: http://howardhinnant.github.io/date_algorithms.html
 */
export function toDayNumber({ year, month, day }: PlainDate): number {
  const y = month <= 2 ? year - 1 : year;
  const era = Math.floor(y / 400);
  const yoe = y - era * 400;
  const doy = Math.floor((153 * (month + (month > 2 ? -3 : 9)) + 2) / 5) + day - 1;
  const doe = yoe * 365 + Math.floor(yoe / 4) - Math.floor(yoe / 100) + doy;
  return era * 146097 + doe - 719468;
}

/** Inverse of toDayNumber ("civil_from_days"). */
export function fromDayNumber(days: number): PlainDate {
  const z = days + 719468;
  const era = Math.floor(z / 146097);
  const doe = z - era * 146097;
  const yoe = Math.floor(
    (doe - Math.floor(doe / 1460) + Math.floor(doe / 36524) - Math.floor(doe / 146096)) / 365,
  );
  const doy = doe - (365 * yoe + Math.floor(yoe / 4) - Math.floor(yoe / 100));
  const mp = Math.floor((5 * doy + 2) / 153);
  const day = doy - Math.floor((153 * mp + 2) / 5) + 1;
  const month = mp < 10 ? mp + 3 : mp - 9;
  return { year: yoe + era * 400 + (month <= 2 ? 1 : 0), month, day };
}

/** Negative if a is earlier than b, 0 if the same day, positive if later. */
export function compareDates(a: PlainDate, b: PlainDate): number {
  return toDayNumber(a) - toDayNumber(b);
}

export function isInRange(d: PlainDate): boolean {
  return compareDates(d, DATE_RANGE.min) >= 0 && compareDates(d, DATE_RANGE.max) <= 0;
}

export function addDays(d: PlainDate, days: number): PlainDate {
  return fromDayNumber(toDayNumber(d) + days);
}

/**
 * Moves by whole calendar months. If the day does not exist in the target month, it is
 * clamped to the month's last day (31 January + 1 month = 28 or 29 February).
 */
export function addMonths(d: PlainDate, months: number): { date: PlainDate; clamped: boolean } {
  const index = d.year * 12 + (d.month - 1) + months;
  const year = Math.floor(index / 12);
  const month = index - year * 12 + 1;
  const last = daysInMonth(year, month);
  return { date: { year, month, day: Math.min(d.day, last) }, clamped: d.day > last };
}

/** ISO weekday: 1 = Monday … 7 = Sunday. 1 January 1970 was a Thursday. */
export function isoWeekday(d: PlainDate): number {
  return ((((toDayNumber(d) + 3) % 7) + 7) % 7) + 1;
}
