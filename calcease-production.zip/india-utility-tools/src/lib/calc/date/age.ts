/**
 * Age from a date of birth. Specification: docs/specs/age-calculator.md
 */
import type { Outcome } from "../result";
import { calendarDifference, type YearsMonthsDays } from "./difference";
import { compareDates, daysInMonth, isoWeekday, toDayNumber, type PlainDate } from "./plain-date";

export type AgeError = "BIRTH_AFTER_DATE";

export interface AgeResult extends YearsMonthsDays {
  totalDays: number;
  totalWeeks: number;
  weekRemainderDays: number;
  totalMonths: number;
  /** The birthday on or after the as-of date. */
  nextBirthday: PlainDate;
  /** 0 when the as-of date is the birthday. */
  daysToNextBirthday: number;
  /** Age reached on nextBirthday. */
  nextAge: number;
  /** ISO weekday of the date of birth (1 = Monday). */
  bornWeekday: number;
  /** Born on 29 February: birthdays in other years are counted on 28 February. */
  leapDayBirthday: boolean;
}

/** The birthday in a given year; 29 February becomes 28 February in common years. */
export function birthdayIn(birth: PlainDate, year: number): PlainDate {
  return { year, month: birth.month, day: Math.min(birth.day, daysInMonth(year, birth.month)) };
}

export function ageOn(birth: PlainDate, asOf: PlainDate): Outcome<AgeResult, AgeError> {
  if (compareDates(asOf, birth) < 0) return { ok: false, error: "BIRTH_AFTER_DATE" };
  const ymd = calendarDifference(birth, asOf);
  const totalDays = toDayNumber(asOf) - toDayNumber(birth);
  let nextBirthday = birthdayIn(birth, asOf.year);
  if (compareDates(nextBirthday, asOf) < 0) nextBirthday = birthdayIn(birth, asOf.year + 1);
  return {
    ok: true,
    value: {
      ...ymd,
      totalDays,
      totalWeeks: Math.floor(totalDays / 7),
      weekRemainderDays: totalDays % 7,
      totalMonths: ymd.years * 12 + ymd.months,
      nextBirthday,
      daysToNextBirthday: toDayNumber(nextBirthday) - toDayNumber(asOf),
      nextAge: nextBirthday.year - birth.year,
      bornWeekday: isoWeekday(birth),
      leapDayBirthday: birth.month === 2 && birth.day === 29,
    },
  };
}
