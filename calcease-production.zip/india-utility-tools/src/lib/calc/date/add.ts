/**
 * Adding to or subtracting from a date. Specification: docs/specs/date-add-subtract-calculator.md
 */
import type { Outcome } from "../result";
import { addDays, addMonths, isInRange, type PlainDate } from "./plain-date";

export interface DateShift {
  years: number;
  months: number;
  weeks: number;
  days: number;
}

export type ShiftError = "RESULT_OUT_OF_RANGE";

export interface ShiftResult {
  date: PlainDate;
  /** The day of the month did not exist after moving by months, so it was clamped. */
  clamped: boolean;
  /** The date after the years and months step, before weeks and days. */
  afterMonths: PlainDate;
}

/**
 * Years and months first (as whole calendar months, clamping the day to the month's
 * end), then weeks and days. Subtracting applies the same steps backwards.
 */
export function shiftDate(
  from: PlainDate,
  shift: DateShift,
  direction: "add" | "subtract",
): Outcome<ShiftResult, ShiftError> {
  const sign = direction === "add" ? 1 : -1;
  const months = addMonths(from, sign * (shift.years * 12 + shift.months));
  const date = addDays(months.date, sign * (shift.weeks * 7 + shift.days));
  if (!isInRange(date)) return { ok: false, error: "RESULT_OUT_OF_RANGE" };
  return { ok: true, value: { date, clamped: months.clamped, afterMonths: months.date } };
}
