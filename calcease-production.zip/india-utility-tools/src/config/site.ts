/** Site-wide settings. The brand is used everywhere from here; change it here only. */
export const SITE_NAME = "CalcEase";

export const SITE_TAGLINE = "Simple calculations. Clear decisions.";

/** The production domain. Canonical URLs, Open Graph URLs, the sitemap and robots.txt use it. */
export const PRODUCTION_URL = "https://calculatorfordailyuse.com";

/**
 * Absolute origin for canonical and Open Graph URLs, the sitemap and robots.txt. Always the
 * production domain, so preview deployments and local builds never advertise their own
 * hosts as canonical. NEXT_PUBLIC_SITE_URL can override it (e.g. for a staging domain).
 */
function resolveSiteUrl(): string {
  const explicit = process.env.NEXT_PUBLIC_SITE_URL;
  return (explicit || PRODUCTION_URL).replace(/\/$/, "");
}

export const SITE_URL = resolveSiteUrl();

export type SitePageStatus = "published" | "draft";

export interface SitePage {
  /** Stable key used by pages to find their entry. */
  id: "about" | "contact" | "methodology" | "privacy" | "terms" | "disclaimer";
  name: string;
  href: string;
  /** Footer group. */
  group: "about" | "legal";
  /**
   * draft: the page exists for navigation but its content is incomplete (owner details
   * or legal review missing). Draft pages show a visible notice, are marked noindex and
   * are left out of the sitemap. Flip to "published" once the content is final.
   */
  status: SitePageStatus;
  title: string;
  description: string;
}

/** Trust and legal pages, in footer order. */
export const SITE_PAGES: readonly SitePage[] = [
  {
    id: "about",
    name: "About",
    href: "/about",
    group: "about",
    status: "draft",
    title: "About",
    description: "Who builds these calculators, and why.",
  },
  {
    id: "methodology",
    name: "How we calculate",
    href: "/methodology",
    group: "about",
    status: "published",
    title: "How We Calculate and Check Results",
    description:
      "How every calculator is specified, tested against independently worked examples, and rounded, before it is published.",
  },
  {
    id: "contact",
    name: "Contact",
    href: "/contact",
    group: "about",
    status: "draft",
    title: "Contact",
    description: "How to report a wrong result or get in touch.",
  },
  {
    id: "privacy",
    name: "Privacy policy",
    href: "/privacy",
    group: "legal",
    status: "draft",
    title: "Privacy Policy",
    description: "What happens to the numbers you enter, and what data this site collects.",
  },
  {
    id: "terms",
    name: "Terms of use",
    href: "/terms",
    group: "legal",
    status: "draft",
    title: "Terms of Use",
    description: "The terms for using this website and its calculators.",
  },
  {
    id: "disclaimer",
    name: "Disclaimer",
    href: "/disclaimer",
    group: "legal",
    status: "draft",
    title: "Disclaimer",
    description:
      "Calculator results are estimates for general information, not professional advice.",
  },
];

export function getSitePage(id: SitePage["id"]): SitePage {
  const page = SITE_PAGES.find((p) => p.id === id);
  if (!page) throw new Error(`Unknown site page: ${id}`);
  return page;
}
