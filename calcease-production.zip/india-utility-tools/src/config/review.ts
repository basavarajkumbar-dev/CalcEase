/**
 * Review builds. Tools awaiting expert review (e.g. CTC to In-Hand, which needs a
 * chartered accountant's sign-off) only get a page when the site is built with
 * ENABLE_UNDER_REVIEW_TOOLS=1, for reviewers. Production builds leave it unset, so those
 * pages do not exist (404), are not in the sitemap and are never linked.
 */
export const UNDER_REVIEW_TOOLS_ENABLED = process.env.ENABLE_UNDER_REVIEW_TOOLS === "1";
