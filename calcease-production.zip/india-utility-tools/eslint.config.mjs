import { defineConfig, globalIgnores } from "eslint/config";
import nextVitals from "eslint-config-next/core-web-vitals";
import nextTs from "eslint-config-next/typescript";

export default defineConfig([
  ...nextVitals,
  ...nextTs,
  globalIgnores([".next/**", "out/**", "playwright-report/**", "test-results/**", "next-env.d.ts"]),
  {
    // Architecture rule: the calculation, validation, formatting and math
    // libraries must stay pure TypeScript, independent of React, Next.js and
    // the browser, so they can be tested in isolation and reused (e.g. an API).
    files: ["src/lib/**/*.ts"],
    rules: {
      "no-restricted-imports": [
        "error",
        {
          patterns: [
            {
              group: ["react", "react-dom", "react/*", "react-dom/*"],
              message: "src/lib must not depend on React.",
            },
            { group: ["next", "next/*"], message: "src/lib must not depend on Next.js." },
            { group: ["@/components/*", "@/app/*"], message: "src/lib must not import UI code." },
          ],
        },
      ],
      "no-restricted-globals": [
        "error",
        "window",
        "document",
        "navigator",
        "localStorage",
        "sessionStorage",
        "fetch",
        "location",
      ],
    },
  },

  {
    // Use the site's Link (no automatic prefetching), see src/components/ui/link.tsx.
    files: ["src/**/*.tsx"],
    ignores: ["src/components/ui/link.tsx"],
    rules: {
      "no-restricted-imports": [
        "error",
        {
          paths: [
            { name: "next/link", message: 'Import { Link } from "@/components/ui/link" instead.' },
          ],
        },
      ],
    },
  },
]);
