import { defineConfig, devices } from "@playwright/test";

const PORT = 3100;
const BASE_URL = `http://127.0.0.1:${PORT}`;

/**
 * End-to-end tests run against the production build (`next start`), the same
 * output that is deployed. Run `pnpm build` first; CI does this automatically.
 *
 * PLAYWRIGHT_CHROMIUM_PATH lets a machine with a pre-installed Chromium use it
 * instead of downloading one; CI uses the browser from `playwright install`.
 */
const executablePath = process.env.PLAYWRIGHT_CHROMIUM_PATH;

export default defineConfig({
  testDir: "./tests/e2e",
  fullyParallel: true,
  forbidOnly: Boolean(process.env.CI),
  retries: process.env.CI ? 1 : 0,
  reporter: process.env.CI ? [["list"], ["html", { open: "never" }]] : "list",
  use: {
    baseURL: BASE_URL,
    trace: "retain-on-failure",
    ...(executablePath ? { launchOptions: { executablePath } } : {}),
  },
  projects: [
    // Primary target: a mid-range Android phone (Phase 1, section 2).
    { name: "mobile-chrome", use: { ...devices["Pixel 7"] } },
    { name: "desktop-chrome", use: { ...devices["Desktop Chrome"] } },
    // Firefox and WebKit (Safari's engine) run in CI, which installs them. Set
    // PLAYWRIGHT_ALL_BROWSERS=1 locally after `pnpm exec playwright install`.
    ...(process.env.PLAYWRIGHT_ALL_BROWSERS
      ? [
          { name: "desktop-firefox", use: { ...devices["Desktop Firefox"] } },
          { name: "desktop-webkit", use: { ...devices["Desktop Safari"] } },
          { name: "mobile-webkit", use: { ...devices["iPhone 13"] } },
        ]
      : []),
  ],
  webServer: {
    command: `pnpm start --port ${PORT} --hostname 127.0.0.1`,
    url: BASE_URL,
    reuseExistingServer: !process.env.CI,
    timeout: 60_000,
  },
});
