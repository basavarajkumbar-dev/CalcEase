# Design system

Source of truth for all UI. Tokens live in `src/app/globals.css`; components live in
`src/components`. If code and this document disagree, update one of them in the same
pull request.

## 1. Philosophy

The site should say "this helps me solve my problem quickly" within seconds, on a
mid-range Android phone held in one hand.

- **The answer is the hero.** The one bold element on any tool page is the result:
  a large number in tabular figures with the worked equation under it, like a
  calculation slip. Everything around it is quiet.
- **Structure over decoration.** Hierarchy comes from type size, weight and spacing.
  Borders separate things; shadows are reserved for overlays that float above the
  page. No gradients, glass effects, illustrations or decorative motion.
- **Plain, specific words.** Sentence case everywhere. Labels say what to type, errors
  say how to fix it, buttons say what will happen.
- **Mobile first.** Every component is designed at 360 px first. Wider screens get
  more columns, never bigger decoration.
- **Restrained by construction.** Tailwind's default palette, shadows, radii and
  breakpoints are removed, so only the tokens below can be used.

## 2. Colour

Semantic tokens only; components never use raw hex values. Contrast ratios are
measured against `surface` (#FFFFFF) unless noted.

| Token               | Value                 | Use                                               |                     Contrast |
| ------------------- | --------------------- | ------------------------------------------------- | ---------------------------: |
| `canvas`            | `#F4F6F8`             | Page background                                   |                            — |
| `surface`           | `#FFFFFF`             | Calculator, cards, inputs                         |                            — |
| `surface-raised`    | `#FFFFFF`             | Menu and search overlays (with `shadow-raised`)   |                            — |
| `ink`               | `#16202A`             | Body text, headings, result numbers               |                       16.5:1 |
| `muted`             | `#4A5563`             | Helper text, secondary text                       |                        7.6:1 |
| `line`              | `#D5DBE1`             | Decorative dividers, card borders                 |                 (decorative) |
| `line-strong`       | `#6B7684`             | Input and select borders                          |                        4.6:1 |
| `primary`           | `#0B5D4B`             | Links, primary buttons, result accent, focus ring |                        7.8:1 |
| `primary-hover`     | `#084A3C`             | Hover state                                       |                       10.2:1 |
| `primary-active`    | `#063A2F`             | Pressed state                                     |                       12.7:1 |
| `primary-soft`      | `#E7F2EE`             | Result background                                 |                   ink 14.4:1 |
| `success` / `-soft` | `#1C6B3A` / `#EAF5EE` | Confirmations ("Link copied")                     |                5.9:1 on soft |
| `warning` / `-soft` | `#8A4B00` / `#FFF4E0` | Caveats, assumptions                              |                6.2:1 on soft |
| `error` / `-soft`   | `#B42318` / `#FDEFEE` | Invalid input, impossible calculations            |                5.9:1 on soft |
| `info` / `-soft`    | `#1F4F99` / `#EBF1FB` | Neutral notes                                     |                7.0:1 on soft |
| `chart-accent`      | `#B45309`             | Second series in charts (with `primary`)          | 5.0:1; 4.4:1 on primary-soft |

Rules:

- All text meets WCAG 2.2 AA (4.5:1); every pairing above exceeds it.
- Colour never carries meaning alone. Errors have an icon, text and a thicker border;
  increase/decrease has an arrow and a word; status callouts have an icon and a title.
- The primary green is for action and for the answer. It is not used as decoration.
- Charts (Phase 5) use `primary` and `chart-accent`, and always have a text legend that
  states every figure, so no information depends on telling the colours apart.

## 3. Typography

One family: the device's system font (`system-ui` stack: Roboto on Android, San
Francisco on Apple devices, Segoe UI on Windows). Zero bytes to download, no layout
shift from font swapping, excellent hinting for Indian English on every platform.
Rupee (₹) and Indian digit grouping render natively.

All numbers that people compare use tabular figures (`numeric` utility, built into
`text-result` and table cells), so columns of amounts line up digit by digit.

| Role          | Utility       | Mobile                    | Desktop (≥1024px) |
| ------------- | ------------- | ------------------------- | ----------------- |
| H1            | `text-h1`     | 28px / 1.2, bold          | 36px              |
| H2            | `text-h2`     | 22px / 1.3, bold          | 24px              |
| H3            | `text-h3`     | 17px / 1.4, semibold      | same              |
| Body          | `text-body`   | 16px / 1.6                | same              |
| Small         | `text-small`  | 14px / 1.5                | same              |
| Label         | `text-label`  | 16px / 1.4, semibold      | same              |
| Helper        | `text-helper` | 14px / 1.45, `muted`      | same              |
| Result number | `text-result` | 40px / 1.1, bold, tabular | 48px              |
| Table         | `text-table`  | 15px / 1.45               | same              |

Inputs use 18px text so iOS Safari does not zoom on focus and digits are easy to read.
Reading width is capped at 42rem (about 70 characters) with `max-w-prose`.

## 4. Spacing, radius, shadow, borders

**Spacing scale** (Tailwind units, 1 unit = 4px). Use only these steps:

| Step | px  | Typical use                                                   |
| ---- | --- | ------------------------------------------------------------- |
| 1    | 4   | Icon to text                                                  |
| 2    | 8   | Label to input, tight lists                                   |
| 3    | 12  | Inside small components                                       |
| 4    | 16  | Page side gutter, between form fields, card padding on mobile |
| 6    | 24  | Card padding on desktop, between groups                       |
| 8    | 32  | Between page sections on mobile                               |
| 12   | 48  | Between page sections on desktop                              |
| 16   | 64  | Before the footer                                             |

**Radius:** `rounded-sm` 6px (badges, inline code), `rounded-md` 8px (inputs,
buttons), `rounded-lg` 12px (calculator, cards, panels). Nothing else is rounded.

**Shadow:** one token, `shadow-raised`, only for overlays that float above content
(search panel, mobile menu). Cards and the calculator use a 1px `line` border.

**Borders:** 1px `line` for structure; 1px `line-strong` for form controls; 2px
`error` for an invalid field (thickness changes as well as colour).

## 5. Dark mode: deferred

Decision: no dark mode for the MVP.

Why:

- **Value is modest for this product.** Visits are short (one calculation, under two
  minutes). Dark mode matters most for long reading sessions.
- **The cost multiplies with every future tool.** Each EMI chart, SIP chart and
  amortization table would need a second palette and double the visual and contrast
  testing. Display ads (Phase 9) are designed for light pages and look broken on dark
  ones.
- **A half-done theme is worse than none.** Inputs, charts or ads left light inside a
  dark page are jarring.

How it stays cheap to add later: every colour is a semantic token, so dark mode is a
second set of values for the same token names under `prefers-color-scheme: dark`, plus
removing `color-scheme: light`. No component code should need to change. Revisit after
launch if analytics or feedback show demand.

## 6. Breakpoints and layout

Two breakpoints, mobile first:

| Name | Min width | What changes                                                                                              |
| ---- | --------- | --------------------------------------------------------------------------------------------------------- |
| base | 0         | Single column. Design baseline 360px. 16px side gutters.                                                  |
| `md` | 768px     | Two-column grids (tool cards, inputs side by side), 24px gutters.                                         |
| `lg` | 1024px    | Desktop header nav; calculator shows inputs and result side by side; article plus "On this page" sidebar. |

Widths: page container max 72rem (1152px, `max-w-page`); reading column max 42rem (`max-w-prose`); menus and short notes max 24rem (`max-w-narrow`). Tailwind's default container sizes are removed, so only these three exist.

## 7. Components

| Component         | File                              | Notes                                                                                                                                                      |
| ----------------- | --------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `Container`       | `layout/container.tsx`            | Page width and gutters.                                                                                                                                    |
| `Section`         | `layout/section.tsx`              | Content section with an anchored H2; feeds the page's table of contents.                                                                                   |
| `ToolPage`        | `tool/tool-page.tsx`              | Standard tool-page template (Phase 1 §4 anatomy). Every tool uses it.                                                                                      |
| `SiteHeader`      | `layout/site-header.tsx`          | Brand, desktop nav, search and menu triggers.                                                                                                              |
| `HeaderPanels`    | `layout/header-panels.tsx`        | Client island: opens one panel at a time (search or menu), Escape closes, focus returns to the trigger.                                                    |
| `SiteFooter`      | `layout/site-footer.tsx`          | Tools by category, site pages (only those that exist), privacy note.                                                                                       |
| `Breadcrumb`      | `layout/breadcrumb.tsx`           | `nav` + ordered list; wraps instead of overflowing; current page marked `aria-current`.                                                                    |
| `SearchBox`       | `search/search-box.tsx`           | Client-side search over the tool registry.                                                                                                                 |
| `NumberInput`     | `ui/number-input.tsx`             | Label, optional prefix/suffix unit, helper text, error, disabled. `inputmode="decimal"`.                                                                   |
| `SelectInput`     | `ui/select-input.tsx`             | Native select with label and helper text.                                                                                                                  |
| `Button`          | `ui/button.tsx`                   | `primary`, `secondary`, `ghost` variants; min 44px tall; also renders links.                                                                               |
| `ShareButton`     | `ui/share-button.tsx`             | Web Share API, clipboard fallback, status message.                                                                                                         |
| `Callout`         | `ui/callout.tsx`                  | `info`, `warning`, `error`, `success`: icon + optional title + text. Replaces separate InfoBox/WarningBox components.                                      |
| `ResultPanel`     | `calculator/result-panel.tsx`     | States: `result`, `empty`, `invalid`, `error`. Supports primary value, sentence, working, amount in words, secondary rows, actions.                        |
| `SummaryList`     | `ui/summary-list.tsx`             | Label/value rows (`dl`) for secondary results and breakdowns.                                                                                              |
| `DataTable`       | `ui/data-table.tsx`               | Captioned table; numeric columns right-aligned and tabular; explicit, keyboard-focusable horizontal scroll region when needed.                             |
| `FaqList`         | `content/faq-list.tsx`            | `<details>` disclosures: zero JavaScript, accessible by default.                                                                                           |
| `RelatedTools`    | `tool/related-tools.tsx`          | From the registry; renders nothing until related tools exist.                                                                                              |
| `AdSlot`          | `ads/ad-slot.tsx`                 | Reserved, labelled development placeholder; renders nothing in production.                                                                                 |
| `Card`            | `ui/card.tsx`                     | Bordered surface. Used for tool cards, not for every section.                                                                                              |
| `ToolCard`        | `discovery/tool-card.tsx`         | A tool in a list. Active: name, description, "Open calculator" button (accessible name includes the tool). Coming soon: dashed muted card, badge, no link. |
| `CategoryCard`    | `discovery/category-card.tsx`     | A category. With a hub: a link with the calculator count. Without: dashed, not a link, "Coming soon" with planned tool names.                              |
| `CategoryNavList` | `discovery/category-nav-list.tsx` | Categories (and optionally their tools) for the desktop Categories panel and the mobile menu.                                                              |
| `CategoryHub`     | `discovery/category-hub.tsx`      | Category hub page body: tools, coming next, other categories.                                                                                              |
| `Badge`           | `ui/badge.tsx`                    | Small neutral status label ("Coming soon"). Meaning carried by its words.                                                                                  |
| `MobileMenu`      | `layout/mobile-menu.tsx`          | Full-screen native `<dialog>` menu for phones and tablets.                                                                                                 |
| `InfoPage`        | `content/info-page.tsx`           | Layout for trust and legal pages, with a visible draft notice when unfinished.                                                                             |

Not created, on purpose: `PageShell` (the root layout already is one), `Stack` and
`Grid` (Tailwind's `space-y-*`, `flex` and `grid` say the same thing with no
abstraction), separate `Label`/`HelperText`/`ErrorMessage` exports (they only ever
appear inside a field, so they live inside `NumberInput`/`SelectInput` through a
shared `FieldShell`), `SecondaryButton` (a `variant` of `Button`).

### Buttons

| Variant     | Look                                             | Use                                        |
| ----------- | ------------------------------------------------ | ------------------------------------------ |
| `primary`   | `primary` fill, white text                       | The main action on a screen (one per view) |
| `secondary` | `surface` fill, `line-strong` border, `ink` text | Supporting actions (Share)                 |
| `ghost`     | No fill or border, `primary` text                | Header icon buttons, low-emphasis actions  |

All: min height 44px (`md` size) or 48px (`lg`), radius `md`, 16px semibold text,
icon 20px. States: hover darkens, active darkens further, focus shows the global ring,
disabled is 50% opacity with `cursor-not-allowed` and `aria-disabled`.

### Inputs

Label above (never a placeholder as label), optional helper text under the label,
field 48px tall with 18px text, unit inside the field (₹ before, % after), error under
the field with an icon. `inputmode="decimal"` for numeric keyboards; `type="text"`
because `type="number"` rejects Indian grouping, changes on scroll and silently drops
invalid characters.

### Result panel

Sits inside the calculator, directly below (mobile) or beside (desktop) the inputs, on
`primary-soft` with a 4px `primary` top rule. Order: label ("Your result"), primary
value in `text-result`, a plain sentence, optional amount in words, optional summary
rows, the working, then actions. Not a live region itself; a debounced polite live
region announces the sentence after typing pauses.

### Tables

`DataTable` takes a caption (required, for screen readers and context), columns with
`align` and `numeric` flags, and rows. On narrow screens a table that fits stays a
table. A table that cannot fit (amortization schedules) scrolls inside its own region:
the region is focusable, labelled by the caption, and shows a visible "Scroll sideways
to see all columns" note. The page itself never scrolls sideways.

### Charts (style only; none built yet)

Hand-written SVG, no chart library. Requirements for the first chart (EMI/SIP):
wrap in `<figure>` with a `<figcaption>` stating the finding; give the SVG
`role="img"` and an `aria-label`; always pair it with a `DataTable` of the same
numbers; series colours from tokens (`primary`, `info`, `warning`), distinguished by
labels or patterns as well as colour; axis text `text-small` in `muted`; numbers
tabular; minimum 3:1 contrast for marks against `surface`.

### Alerts / callouts

`Callout` with a tone icon (Info, TriangleAlert, CircleAlert, CircleCheck) and text.
Use `warning` for assumptions and limits, `error` only for something the user must fix,
`info` for neutral notes, `success` for confirmations.

### Navigation

Header 56px. Phones and tablets: brand, Search button, Menu button (44×44 targets,
labelled). Desktop (`lg`): brand, "All tools" link, "Categories" button, labelled
"Search tools" button.

- **Search and Categories** are disclosure panels below the header (`shadow-raised`).
  One open at a time; Escape returns focus to the button that opened it; choosing a
  link, clicking outside or tabbing out closes it.
- **Mobile menu** is a full-screen native `<dialog>` opened with `showModal()`: the
  page behind is inert, focus starts on "Close menu", Tab stays inside, Escape closes
  it, focus returns to the Menu button, and page scrolling is locked while it is open.
- **Breadcrumb** sits under the header in `text-small`, `muted`; separators are hidden
  from screen readers. Tool pages: Home / Category / Tool, with the tool name hidden on
  phones (it repeats the H1 below) so the trail stays on one line. A category with no
  hub page is plain text, never a dead link. The homepage has no breadcrumb.
- **Footer**: Tools, Categories, About, Legal groups, all generated from the registry
  and the site-page list; two columns on phones, four on desktop.

### Coming-soon pattern

Planned tools and categories are shown only where they help someone understand what is
coming (homepage categories, /tools, a hub's "Coming next", search results). They are
always muted, dashed or badged with the words "Coming soon", and are never links.

## 8. Accessibility requirements

- WCAG 2.2 AA. Automated axe checks run in CI on every page and state.
- Semantic landmarks: `header`, `nav` (labelled), `main`, `footer`, `search`.
- Every input has a visible label; helper and error text are linked with
  `aria-describedby`; invalid fields have `aria-invalid`.
- Results are announced through one polite live region after a 750 ms pause, never on
  every keystroke.
- Visible focus on everything (3px ring); logical DOM order equals visual order.
- Touch targets at least 44×44px.
- No information by colour alone; respect `prefers-reduced-motion`.
- Text resizes to 200% without loss (rem units, no fixed heights on text containers).

## 9. Interaction states

| State    | Treatment                                                         |
| -------- | ----------------------------------------------------------------- |
| Hover    | Darker colour step (`primary-hover`) or underline thickening      |
| Active   | `primary-active`                                                  |
| Focus    | 3px `primary` outline, 2px offset                                 |
| Disabled | 50% opacity, not focusable for inputs, `aria-disabled` on buttons |
| Invalid  | 2px `error` border, error icon and message under the field        |
| Empty    | Result panel says what to enter; no error colour                  |
| Loading  | None. Calculations are instant; no spinners or skeletons.         |

## 10. Motion

Only state changes the user caused: menu and search panels fade in over 120 ms;
buttons change colour over 100 ms. No entrance, scroll or continuous animation. All
motion is disabled under `prefers-reduced-motion`.

## 11. Ads (reserved, not implemented)

`AdSlot` marks where an ad may appear: after the result and its explanation, never
between inputs and result, never sticky. It reserves its height in the server HTML
(280px on mobile, 250px on desktop) so a future ad cannot shift content. It renders a
labelled "Ad space (development placeholder)" box only when
`NEXT_PUBLIC_SHOW_AD_PLACEHOLDERS=1`, and nothing at all otherwise.

## 12. Icons

Icons are Lucide designs (ISC licence) drawn as plain inline SVG from
`src/components/ui/icons.tsx`, not the `lucide-react` package. The package's runtime
(React context and `forwardRef` wrappers) would ship to every page through the header
for about ten icons; inlining saves that and removes a dependency. Rules: 20px inside
buttons and fields, 24px in the header, `currentColor` stroke, always `aria-hidden`
with a visible or screen-reader text label beside it. To add an icon, copy its SVG
nodes from lucide.dev into `icons.tsx`.

## 13. Layout-shift rules

- Nothing appears above content after first paint: no banners, no late-loading
  headers, no web fonts.
- The result panel always occupies its space (an empty-state message, never nothing),
  so typing never moves the content below it.
- Overlays (menu, search) float above the page with `shadow-raised` and do not push
  content down.
- Ad positions reserve their height in the server HTML (§11). Measured CLS with
  placeholders on: 0.
