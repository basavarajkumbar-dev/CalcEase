# Review request: CTC to In-Hand Salary Calculator

**Status: awaiting review by a chartered accountant. Not published.**

The Phase 5 brief requires that tax calculations are not based on memory, that regulatory
values come from official sources, and that expert verification is never claimed falsely.
No chartered accountant was available, so this calculator is built and tested but
excluded from production. It renders only in a review build:

```bash
ENABLE_UNDER_REVIEW_TOOLS=1 pnpm build && pnpm start
# open /ctc-to-in-hand-salary-calculator (marked "Under review", noindex)
```

## What to check

| #   | Item                                               | Current implementation                                                           | Source used                                                                                                                                                |
| --- | -------------------------------------------------- | -------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 1   | New-regime slabs, tax year 2026-27                 | 0/5/10/15/20/25/30% at 4/8/12/16/20/24 lakh                                      | incometax.gov.in (AY 2026-27); Budget 2026-27 speech announced no change                                                                                   |
| 2   | Old-regime slabs                                   | 0/5/20/30% at 2.5/5/10 lakh                                                      | incometax.gov.in                                                                                                                                           |
| 3   | Standard deduction                                 | ₹75,000 new, ₹50,000 old                                                         | Budget 2024-25 speech                                                                                                                                      |
| 4   | Rebate and marginal relief                         | New: ₹60,000 up to ₹12 lakh, relief above; old: ₹12,500 up to ₹5 lakh, no relief | incometax.gov.in; Budget 2025-26 speech; Section 87A text (older version, ₹7 lakh)                                                                         |
| 5   | Cess                                               | 4% of tax after rebate                                                           | incometax.gov.in                                                                                                                                           |
| 6   | Professional tax                                   | Deducted from salary in the old regime only                                      | **Not sourced: please confirm**                                                                                                                            |
| 7   | Rounding                                           | None (no rounding of total income or tax)                                        | **Not sourced: please confirm**                                                                                                                            |
| 8   | Section references under the Income-tax Act, 2025  | Not shown on the page                                                            | **Please supply**                                                                                                                                          |
| 9   | PF rate                                            | 12% employee, 12% employer (EPF + EPS together)                                  | Govt of West Bengal summary of the EPF Act                                                                                                                 |
| 10  | PF wage ceiling                                    | ₹25,000 from 17 Sep 2026; ₹15,000 before                                         | Ministry of Labour release, 16 Sep 2026 (start of ₹15,000 not verified)                                                                                    |
| 11  | PF "wages" under the Code on Social Security, 2020 | Basic only (user's basic %)                                                      | **Please confirm** whether the 50% rule changes the base                                                                                                   |
| 12  | Scope                                              | Resident, under 60, salary only, taxable ≤ ₹50 lakh                              | —                                                                                                                                                          |
| 13  | Gratuity in CTC (optional)                         | basic × 15 ÷ 26 ÷ 12 a year (≈ 4.81% of basic)                                   | Payment of Gratuity Act summary (Govt of Puducherry). **Please confirm** this accrual convention and the wage definition under the Code on Social Security |
| 14  | Professional tax                                   | Entered by the user (state-specific)                                             | Not sourced per state: **please advise** whether to add state tables                                                                                       |

Test vectors: `tests/fixtures/ctc.json` (hand-worked; independently re-derived by
`scripts/fixture_checks/ctc.py`). Unit tests: `tests/unit/ctc.test.ts`.

## To publish after review

1. Record the reviewer's name, qualification and date in this file and in the rule data
   (`reviewedOn`, notes), and fix anything they flag.
2. Change the rule sets' `status` from `"under-review"`, move the tool from
   `review-tools.ts` to an active entry in the registry, remove the `notFound()` gate,
   and add its tests to the released-tools list.
3. Only then describe it as professionally reviewed.
