# Specification: Discount Calculator

| Field         | Value                                                          |
| ------------- | -------------------------------------------------------------- |
| Status        | Approved for build (Phase 5, wave 1)                           |
| URL           | `/discount-calculator`                                         |
| Library       | `src/lib/calc/discount/` (built on `src/lib/calc/percentage/`) |
| Test vectors  | `tests/fixtures/discount.json`                                 |
| Last reviewed | 2026-10-07                                                     |

## 1. Purpose

Answer the three questions shoppers actually ask: what will I pay after X% off, what
discount am I really getting from a sale price, and what does "20% + extra 10% off"
come to.

## 2. Modes

| Id              | Question                                              | Inputs                                                   | Outputs                                                                                                          |
| --------------- | ----------------------------------------------------- | -------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------- |
| `percentOff`    | Price after X% off                                    | Original price P, discount d%                            | You save S = P × d ÷ 100; you pay F = P − S                                                                      |
| `fromSalePrice` | What discount is this sale price?                     | Original price P, sale price F                           | You save S = P − F; discount d = S × 100 ÷ P                                                                     |
| `stacked`       | Two discounts one after the other ("20% + extra 10%") | Original price P, first discount d1%, extra discount d2% | Price after both F = P × (1 − d1/100) × (1 − d2/100); total saving S = P − F; effective discount e = S × 100 ÷ P |

Why `stacked` is included: retailers in India commonly advertise "flat X% + extra Y%",
and buyers often assume the discounts add up. They don't: 20% + 10% is 28%, not 30%.
The calculator shows the effective single discount so the comparison is honest.

## 3. Inputs and valid ranges

| Input              | Unit | Range                   | Notes                                           |
| ------------------ | ---- | ----------------------- | ----------------------------------------------- |
| Original price P   | ₹    | more than 0, up to 10¹² | A price of 0 has no meaningful discount         |
| Discount d, d1, d2 | %    | 0 to 100                | 0% is valid (no discount); 100% is valid (free) |
| Sale price F       | ₹    | 0 to 10¹²               | Must not exceed P (see errors)                  |

Decimals are accepted everywhere. Negative numbers are rejected by the ranges above,
with a message stating the allowed range.

## 4. Formulas as implemented

Uses the Percentage engine (multiply before dividing by 100, spec of the Percentage
Calculator §1):

- `percentOff`: S = `calculatePercentOf(d, P)`; F = `calculateDecreaseBy(P, d)`.
- `fromSalePrice`: S = P − F; d = `calculatePercentChange(P, F)` negated (a fall from P to F).
- `stacked`: F1 = `calculateDecreaseBy(P, d1)`; F = `calculateDecreaseBy(F1, d2)`;
  S = P − F; e = S × 100 ÷ P. The extra discount applies to the already-reduced price.

## 5. Errors

| Case                                   | Result                                                                              |
| -------------------------------------- | ----------------------------------------------------------------------------------- |
| Sale price greater than original price | Error: "The sale price is higher than the original price, so there is no discount." |
| Any input outside its range            | Field error stating the range, e.g. "Enter a discount between 0% and 100%."         |

## 6. Rounding and display

Full precision internally. Money is shown with ₹ and Indian grouping; paise are shown
only when present after rounding to the paise (e.g. ₹1,104.15, ₹900). Percentages use
the shared percentage display (up to 2 decimals). A note appears when a displayed
value is rounded.

## 7. Examples (also test vectors)

| Mode          | Inputs                       | Expected                         |
| ------------- | ---------------------------- | -------------------------------- |
| percentOff    | P = 1,000, d = 10            | S = 100, F = 900                 |
| percentOff    | P = 1,299, d = 15            | S = 194.85, F = 1,104.15         |
| percentOff    | P = 2,499, d = 0             | S = 0, F = 2,499                 |
| percentOff    | P = 2,499, d = 100           | S = 2,499, F = 0                 |
| percentOff    | P = 849.5, d = 12.5          | S = 106.1875, F = 743.3125       |
| fromSalePrice | P = 2,000, F = 1,500         | S = 500, d = 25                  |
| fromSalePrice | P = 999, F = 666             | S = 333, d = 33.333… (100/3)     |
| fromSalePrice | P = 500, F = 500             | S = 0, d = 0                     |
| fromSalePrice | P = 500, F = 0               | S = 500, d = 100                 |
| fromSalePrice | P = 500, F = 600             | Error (sale price higher)        |
| stacked       | P = 1,000, d1 = 20, d2 = 10  | F = 720, S = 280, e = 28         |
| stacked       | P = 3,999, d1 = 50, d2 = 20  | F = 1,599.6, S = 2,399.4, e = 60 |
| stacked       | P = 1,000, d1 = 0, d2 = 10   | F = 900, e = 10                  |
| stacked       | P = 1,000, d1 = 100, d2 = 50 | F = 0, e = 100                   |

## 8. Edge cases

- 100% discount gives a price of ₹0 (valid).
- Stacked discounts never exceed 100% because each factor is between 0 and 1.
- Sale price equal to original: 0% discount (valid), shown as "no discount".

## 9. Verification

Expected values are hand-worked and re-derived with exact rational arithmetic in
`scripts/fixture_checks/discount.py` (independent of the TypeScript code). Any of
them can be reproduced in a spreadsheet: `=A1*B1/100`, `=A1-A1*B1/100`,
`=(A1-B1)/A1*100`, `=A1*(1-B1/100)*(1-C1/100)`.

## 10. Review requirements

Arithmetic only; no external rules. Reviewed by the developer against this spec.
Taxes (GST) are out of scope: a printed price in India normally already includes GST.
