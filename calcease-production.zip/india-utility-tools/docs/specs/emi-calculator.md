# Specification: EMI Calculator

| Field         | Value                                 |
| ------------- | ------------------------------------- |
| Status        | Approved for build (Phase 5, wave 5)  |
| URL           | `/emi-calculator`                     |
| Library       | `src/lib/calc/loan/emi.ts`            |
| Test vectors  | `tests/fixtures/emi-sip.json` → `emi` |
| Last reviewed | 2026-10-07                            |

## 1. Purpose

Monthly instalment (EMI), total interest and repayment schedule for a loan on a reducing
balance, with an optional one-time part-prepayment.

## 2. Formula

EMI = P × r × (1 + r)^n ÷ ((1 + r)^n − 1), with r = annual rate ÷ 1,200 (monthly rate)
and n months; EMI = P ÷ n at 0%. Source: ICICI Bank home loan EMI calculator (same
formula; ₹10,00,000 at 7.25% for 120 months ≈ ₹11,740):
https://www.icici.bank.in/calculator/home-loan-emi-calculator

Each month: interest = balance × r; principal repaid = EMI − interest; new balance =
balance − principal.

## 3. Inputs

| Input                      | Range                                                                           | Default    |
| -------------------------- | ------------------------------------------------------------------------------- | ---------- |
| Loan amount                | more than ₹0, up to ₹10¹²                                                       | ₹25,00,000 |
| Interest rate              | 0% to 50% a year                                                                | 8.5%       |
| Tenure                     | years 0–40 + months 0–11 (whole); 1 to 480 months                               | 20 years   |
| Part-prepayment (optional) | amount more than ₹0 and less than the balance then; after EMI number 1 to n − 1 | off        |

## 4. Rounding and closing at zero

All values keep full precision; amounts are shown to the paisa. Floating-point residue
after the last EMI (around 10⁻⁹ of the loan) is folded into the final payment, so the
schedule always closes at exactly ₹0. Banks usually round the EMI to the rupee (often
up) and adjust the final instalment; their figures can differ by a few rupees. The page
says so.

## 5. Part-prepayment

Made right after the chosen EMI; the EMI stays the same and the tenure shortens (the last
EMI is smaller). Shows the new number of EMIs, months saved and interest saved. Reducing
the EMI instead (keeping the tenure) is a bank choice not modelled. Prepayment charges are not included; the page tells users to check their loan terms.

## 6. Outputs

EMI; total interest; total paid; principal vs interest proportion bar (with the same
figures as text); yearly summary table; full monthly schedule in a disclosure (columns:
month, EMI, interest, principal, balance; prepayment shown in its month).

## 7. Examples (test vectors)

| Loan                                                          | EMI        | Total interest                  |
| ------------------------------------------------------------- | ---------- | ------------------------------- |
| ₹10,00,000, 7.25%, 120 months                                 | ₹11,740.10 | ₹4,08,812.49                    |
| ₹50,00,000, 8.5%, 240 months                                  | ₹43,391.16 | ₹54,13,878.80                   |
| ₹2,00,000, 12%, 24 months                                     | ₹9,414.69  | ₹25,952.67                      |
| ₹5,00,000, 0%, 12 months                                      | ₹41,666.67 | ₹0                              |
| ₹10,00,000, 7.25%, 120 months, ₹1,00,000 prepaid after EMI 12 | 105 EMIs   | ₹3,25,485.03 (₹83,327.46 saved) |

## 8. Verification

`scripts/fixture_checks/emi_sip.py` runs every loan month by month with exact fractions
and checks the balance closes at zero. Property tests: principal repaid = loan; balance
formula = schedule; prepayment never increases interest.

## 9. Not covered

Processing fees, insurance, GST on fees, floating-rate resets, pre-EMI interest and the
annual percentage rate (APR). Users enter their own rate.
