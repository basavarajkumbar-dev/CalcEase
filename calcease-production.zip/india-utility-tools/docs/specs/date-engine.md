# Specification: Plain-date engine

| Field         | Value                                                       |
| ------------- | ----------------------------------------------------------- |
| Status        | Approved for build (Phase 5, wave 3)                        |
| Library       | `src/lib/calc/date/` (formatting: `src/lib/format/date.ts`) |
| Used by       | Age, Date Difference, Date Add / Subtract calculators       |
| Test vectors  | `tests/fixtures/dates.json`                                 |
| Last reviewed | 2026-10-07                                                  |

## 1. Why a separate engine

JavaScript `Date` values are instants in time. Turning them into calendar days depends
on the device's time zone and daylight-saving rules, which is how online "days between
dates" tools end up one day out (for example across a DST change, or for users outside
the time zone the developer tested in). India has no DST, but visitors' devices may be
set to any zone. So every calculation uses a **PlainDate** `{year, month, day}` with no
time and no zone, and integer day numbers. `Date` is used only to read today's date on
the user's device (see §6).

## 2. Calendar and range

- Proleptic Gregorian calendar (the calendar in use in India for civil purposes).
- Accepted dates: **1 January 1900 to 31 December 2199**. This covers every living
  person's date of birth and practical planning horizons, and avoids pre-1900 calendar
  questions. Results outside the range are errors, never wrapped or guessed.
- Leap years: divisible by 4, except centuries not divisible by 400 (1900 and 2100 are
  not leap years; 2000 is).

## 3. Day numbers

`toDayNumber` gives days since 1 January 1970 using Howard Hinnant's `days_from_civil`
algorithm (exact integer arithmetic), and `fromDayNumber` is its inverse. Property
tests check both against `Date.UTC` (which is time-zone free) across the whole range.
Weekday: 1 January 1970 was a Thursday; ISO numbering 1 = Monday … 7 = Sunday.

## 4. Conventions

| Question                                   | Convention                                                                                                                                                                                                 | Example                                                                  |
| ------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------ |
| Adding months when the day doesn't exist   | Clamp to the last day of the month                                                                                                                                                                         | 31 Jan 2026 + 1 month = 28 Feb 2026; 31 Jan 2024 + 1 month = 29 Feb 2024 |
| Adding years to 29 February                | Clamp                                                                                                                                                                                                      | 29 Feb 2024 + 1 year = 28 Feb 2025                                       |
| Mixed amounts (years, months, weeks, days) | Years and months first (as whole months, clamped), then weeks and days                                                                                                                                     | 31 Jan 2026 + 1 month + 1 day = 1 Mar 2026                               |
| Subtracting                                | Same steps with negative amounts                                                                                                                                                                           | 31 Mar 2026 − 1 month = 28 Feb 2026                                      |
| Difference in years, months, days          | Most whole months _m_ such that start + _m_ months (clamped) is not after the end; the rest is days                                                                                                        | 31 Jan → 1 Mar 2023 = 1 month 1 day (29 days)                            |
| Counting the end date                      | Not counted by default (1 → 2 Jan is 1 day). Option: include it (1 → 2 Jan is 2 days), which equals moving the later date on by one day                                                                    | 1 Jan → 31 Dec 2024 inclusive = 1 year (366 days)                        |
| Dates in reverse order                     | Swapped; the result says so                                                                                                                                                                                |                                                                          |
| Weekdays                                   | Monday–Friday days counted from the start date up to (not including) the end date, or including it when the option is on. Public holidays are **not** removed, because they vary by state and organisation |                                                                          |
| Leap-day birthdays                         | In common years the birthday is 28 February, consistent with the month clamp above                                                                                                                         | Born 29 Feb 2000: 23 on 28 Feb 2023                                      |

These match Python's `dateutil.relativedelta`, which is used to verify the fixtures.
The leap-day birthday rule is a convention, not a legal determination: some laws and
organisations treat 1 March as the birthday in common years. Pages say so.

## 5. Inputs

Dates are entered with the native date picker (`<input type="date">`), which gives an
ISO `YYYY-MM-DD` string and shows the user's local format. Values from shared links must
match `^\d{4}-\d{2}-\d{2}$` and be real dates in range, or they are ignored. Whole-number
amounts (years, months, weeks, days) use the number field with `integer: true`.

## 6. Today's date

"Today" is read from the user's device after the page loads (`useToday`), in the
device's own time zone, so it matches the user's calendar. The static HTML cannot know
it, so results that depend on today appear once the page is interactive.

## 7. Verification

`tests/fixtures/dates.json` values were worked by hand and are re-derived independently
by `scripts/fixture_checks/dates.py` using Python's `datetime`, `dateutil.relativedelta`
and `numpy.busday_count`. Property tests (`tests/unit/dates.test.ts`) check: day numbers
equal `Date.UTC` days; round trips; start + (years, months) + days = end; order
independence; weekday counts equal day-by-day counts; add then subtract days returns the
start; age in years increases exactly on birthdays.
