# Specification: FD Calculator

| Field         | Value                                                     |
| ------------- | --------------------------------------------------------- |
| Status        | Approved for build (Phase 5, wave 4)                      |
| URL           | `/fd-calculator`                                          |
| Library       | `src/lib/calc/deposit/fd.ts` (dates: `src/lib/calc/date`) |
| Test vectors  | `tests/fixtures/deposits.json` → `fd`                     |
| Last reviewed | 2026-10-07                                                |

## 1. Purpose

Maturity amount and interest on a bank fixed deposit, using the calculation method banks
publish, with the maturity date.

## 2. Bank method (sources)

There is no single current regulation that fixes the arithmetic; each bank publishes its
"method of calculation of interest on deposits". Checked on 2026-10-07:

| Point                                               | What the sources say                                                                                                                                                     |
| --------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Compounding                                         | Quarterly on completion of exact quarters from the deposit date (TJSB Sahakari Bank; AU Small Finance Bank; CSB Bank: "interest is compounded quarterly")                |
| Broken period after the last full quarter           | Simple interest on the accumulated amount for the actual number of days (TJSB; AU)                                                                                       |
| Day count                                           | 365 days a year (CSB "even in the case of leap year"; RBI Master Circular 2004 for incomplete quarters). AU uses 366 in leap years.                                      |
| Short deposits: simple interest for the actual days | Below 3 months (RBI Master Circular 2004; AU), below 6 months (CSB), below 12 months (TJSB; ICICI Bank: "Short-term FD: interest calculated … on simple interest basis") |

Sources:

- TJSB Sahakari Bank, Method of calculation of interest on deposits:
  https://www.tjsb.bank.in/assets/images/pages_pdf/interest-rates/METHOD-OF-CALCULATION-OF-INTEREST-ON-DEPOSITS.pdf
- AU Small Finance Bank, Basis for interest calculation on term deposits:
  https://www.au.bank.in/notice-board-language/basis-for-interest-calculation-on-term-deposits/English.pdf
- CSB Bank, Method of interest calculation: https://www.csb.co.in/pdf/Method-2022.pdf
- RBI Master Circular on Interest Rates on Rupee Deposits (17 September 2004):
  https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=1927
- ICICI Bank FD calculator page (method and a worked example):
  https://www.icici.bank.in/personal-banking/deposits/fixed-deposit/fd-calculator

Because the short-deposit limit differs between banks, it is an input (default 3 months,
the RBI circular's figure), shown only when the deposit is shorter than 12 months, the
only case where the choice changes the answer. 366-day leap years are not offered; the
page says some banks use them.

## 3. Inputs

| Input                 | Range                                                                 | Default     |
| --------------------- | --------------------------------------------------------------------- | ----------- |
| Deposit amount        | more than ₹0, up to ₹10¹²                                             | ₹1,00,000   |
| Interest rate         | more than 0%, up to 20%                                               | 7%          |
| Tenure                | years 0–10, months 0–11, days 0–365 (whole); total 7 days to 10 years | 1 year      |
| Deposit date          | 1 Jan 1900 – 31 Dec 2199                                              | Today       |
| Interest payout       | At maturity (cumulative) / Every quarter                              | At maturity |
| Simple interest below | 3 / 6 / 12 months (shown when tenure < 12 months)                     | 3 months    |

Maturity date = deposit date + tenure (years and months first, then days; date engine
§4).

## 4. Calculation

- Short deposit (maturity before deposit date + limit): interest = P × r × days ÷ 36,500.
- Otherwise, q = most whole quarters with deposit date + 3q months ≤ maturity date;
  b = days from that date to maturity.
  - Cumulative: A = P × (1 + r ÷ 400)^q × (1 + r × b ÷ 36,500).
  - Quarterly payout: P × r ÷ 400 each quarter, plus P × r × b ÷ 36,500 at maturity;
    the principal is repaid at maturity.

Monthly payout (paid at a discounted rate), TDS, senior-citizen rates and premature
withdrawal penalties are not calculated; the page says so. Users enter their bank's rate.

## 5. Errors

| Code                  | Message                                        |
| --------------------- | ---------------------------------------------- |
| TENURE_TOO_SHORT      | "A fixed deposit must be for at least 7 days." |
| TENURE_TOO_LONG       | "Enter a tenure of up to 10 years."            |
| MATURITY_OUT_OF_RANGE | Date range message                             |

## 6. Examples (test vectors)

| Deposit                                       | Result                                   |
| --------------------------------------------- | ---------------------------------------- |
| ₹1,00,000 at 6.6%, 3 years                    | ₹1,21,699.44 (ICICI example: ~₹1,21,699) |
| ₹1,00,000 at 7%, 7 Oct 2026 + 1y 2m 10d       | 4 quarters + 71 days: ₹1,08,645.39       |
| ₹50,000 at 6%, 90 days                        | simple: ₹739.73 interest                 |
| ₹50,000 at 6%, 6 months, limit 12 months      | simple, 182 days: ₹1,495.89              |
| ₹2,00,000 at 7.25%, 2 years, quarterly payout | ₹3,625 a quarter, ₹29,000 in all         |

## 7. Verification

`scripts/fixture_checks/deposits.py` re-derives each case quarter by quarter with exact
fractions and dateutil quarter dates. Property tests: whole-quarter FDs equal quarterly
compound interest; interest never falls when the deposit is held a day longer (across the
simple/compound switch and every quarter boundary).

## 8. Review

The method follows published bank documents, not a regulation that applies to every
bank. Results can differ from a bank's by small amounts (rounding, 366-day years). The
page states this.
