# Specification: RD Calculator

| Field         | Value                                 |
| ------------- | ------------------------------------- |
| Status        | Approved for build (Phase 5, wave 4)  |
| URL           | `/rd-calculator`                      |
| Library       | `src/lib/calc/deposit/rd.ts`          |
| Test vectors  | `tests/fixtures/deposits.json` → `rd` |
| Last reviewed | 2026-10-07                            |

## 1. Purpose

Maturity amount and interest on a bank recurring deposit.

## 2. Formula (sources)

M = R × [(1 + i)^n − 1] ÷ [1 − (1 + i)^(−1/3)], with R the monthly instalment,
i = annual rate ÷ 400 and n the number of quarters. Interest compounds quarterly.

- TJSB Sahakari Bank, Method of calculation of interest on deposits (same formula, for
  completed quarters).
- ICICI Bank RD calculator page (same formula; worked example ₹5,000 a month at 8% for
  one year = ₹62,647):
  https://www.icici.bank.in/personal-banking/deposits/recurring-deposits/rd-calculator
- AU Small Finance Bank: RD interest "applied on a quarterly capitalization basis".

The formula is the sum of each instalment's growth: an instalment with k months to go
grows to R × (1 + i)^(k/3). The verifier adds the instalments up one by one to confirm.

## 3. Inputs

| Input              | Range                                            | Default   |
| ------------------ | ------------------------------------------------ | --------- |
| Monthly instalment | more than ₹0, up to ₹10¹²                        | ₹5,000    |
| Interest rate      | more than 0%, up to 20%                          | 7%        |
| Tenure             | 3 to 120 months, whole quarters (multiples of 3) | 12 months |

## 4. Uncertainty: tenures that are not whole quarters

Banks state the formula for completed quarters; for leftover months the treatment
differs (TJSB adds simple interest month by month; others are not specific). Rather than
show a figure we cannot attribute, the calculator accepts whole quarters only and says
so. **Open for review**: support part quarters once a primary method is confirmed.

## 5. Not covered

Missed-instalment penalties, TDS and premature closure.

## 6. Examples (test vectors)

| R      | Rate | Months | Maturity                           |
| ------ | ---- | ------ | ---------------------------------- |
| 5,000  | 8%   | 12     | 62,646.63 (ICICI example: ₹62,647) |
| 2,000  | 7%   | 36     | 80,274.60                          |
| 5,000  | 7%   | 60     | 3,59,663.95                        |
| 10,000 | 7.5% | 120    | 17,85,760.32                       |

A popular finance site lists ₹88,663.63 for the second example and ₹4,24,433.46 for the
third. Both disagree with the published formula (and with adding up the instalments), so
they were not used.
