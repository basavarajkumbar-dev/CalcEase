# Specification: Date Difference Calculator

| Field         | Value                                                                 |
| ------------- | --------------------------------------------------------------------- |
| Status        | Approved for build (Phase 5, wave 3)                                  |
| URL           | `/date-difference-calculator`                                         |
| Library       | `src/lib/calc/date/difference.ts` (engine: docs/specs/date-engine.md) |
| Test vectors  | `tests/fixtures/dates.json` → `difference`                            |
| Last reviewed | 2026-10-07                                                            |

## 1. Purpose

Time between two dates in years, months and days, and as total days, weeks and
weekdays.

## 2. Inputs

| Input                | Range                    | Default                                                      |
| -------------------- | ------------------------ | ------------------------------------------------------------ |
| Start date           | 1 Jan 1900 – 31 Dec 2199 | Today (empty field = today)                                  |
| End date             | same                     | 31 December of the current year (empty until today is known) |
| Include the end date | yes / no                 | No                                                           |

## 3. Outputs

Years, months and days; total days; weeks and days; total whole months; weekdays
(Monday–Friday, holidays not removed). If the end date is before the start date, the
dates are swapped and the result says so.

## 4. Convention summary

End date not counted by default: 1 → 2 January = 1 day. With "include the end date",
1 → 2 January = 2 days (useful for leave, hotel-free counting of days present, notice
periods counted inclusively). See date-engine §4.

## 5. Examples (test vectors)

| From        | To          | Include end | Result                                         |
| ----------- | ----------- | ----------- | ---------------------------------------------- |
| 1 Jan 2024  | 31 Dec 2024 | no          | 11 months 30 days; 365 days; 261 weekdays      |
| 1 Jan 2024  | 31 Dec 2024 | yes         | 1 year; 366 days; 262 weekdays                 |
| 31 Jan 2023 | 1 Mar 2023  | no          | 1 month 1 day; 29 days                         |
| 25 Dec 2025 | 1 Jan 2026  | no          | 7 days; 5 weekdays                             |
| 7 Oct 2026  | 29 Feb 2000 | no          | reversed: 26 years 7 months 8 days; 9,717 days |

## 6. Not covered

Public holidays and working-day rules (bank holidays, Saturdays at some employers) are
not applied; the page says so.
