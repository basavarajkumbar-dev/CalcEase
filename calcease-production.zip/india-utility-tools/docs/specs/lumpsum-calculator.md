# Specification: Lumpsum Calculator

| Field         | Value                                                                           |
| ------------- | ------------------------------------------------------------------------------- |
| Status        | Published                                                                       |
| URL           | `/lumpsum-calculator` (Finance)                                                 |
| Library       | `src/lib/calc/invest/lumpsum.ts`                                                |
| Test vectors  | `tests/fixtures/lumpsum.json` (verified by `scripts/fixture_checks/lumpsum.py`) |
| Last reviewed | 2026-10-07                                                                      |

## Formula

Value = P × (1 + r ÷ 100)^n: one-time investment P, expected yearly return r (%),
compounded once a year for n whole years. Estimated returns = value − P.

Reference: Groww lumpsum calculator, ₹15,00,000 at 12% for 5 years ≈ ₹26,43,513, which
matches yearly compounding (₹26,43,512.52), although its text mentions six-monthly
compounding (that would give about ₹26,86,271).

## Inputs and errors

| Input              | Range                     | Error               |
| ------------------ | ------------------------- | ------------------- |
| Initial investment | more than ₹0, up to ₹10¹² | AMOUNT_NOT_POSITIVE |
| Expected return    | 0% to 50% a year          | RETURN_OUT_OF_RANGE |
| Period             | whole years, 1 to 50      | YEARS_OUT_OF_RANGE  |

Non-finite input → NOT_A_NUMBER; a non-finite result → RESULT_TOO_LARGE.

## Outputs

Invested amount, estimated returns, estimated maturity value, a proportion bar with a
text legend, and a year-by-year value table.

## Examples (test vectors)

| Investment               | Value        |
| ------------------------ | ------------ |
| ₹1,00,000, 12%, 10 years | ₹3,10,584.82 |
| ₹50,000, 8%, 5 years     | ₹73,466.40   |
| ₹2,00,000, 10%, 1 year   | ₹2,20,000    |
| ₹1,00,000, 0%, 5 years   | ₹1,00,000    |

## Disclaimer

Returns are estimates at a constant assumed return, not guaranteed; before tax, expense
ratios and exit loads. No investment recommendation is made.
