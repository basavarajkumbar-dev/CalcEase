# Specification: SIP Calculator

| Field         | Value                                 |
| ------------- | ------------------------------------- |
| Status        | Approved for build (Phase 5, wave 5)  |
| URL           | `/sip-calculator`                     |
| Library       | `src/lib/calc/invest/sip.ts`          |
| Test vectors  | `tests/fixtures/emi-sip.json` → `sip` |
| Last reviewed | 2026-10-07                            |

## 1. Purpose

Estimated value of a monthly SIP (systematic investment plan) at an assumed yearly
return, with an optional yearly step-up.

## 2. Formula and conventions

M = P × ((1 + i)^n − 1) ÷ i × (1 + i): instalments at the **start** of each month, n
months, monthly rate i. Sources: HDFC Mutual Fund SIP calculator ("assumes SIP on the
first Business Day of every month"); Groww SIP calculator (same formula).

**Monthly rate: two conventions exist.**

| Method                                            | i for 12% a year | Used by                             |
| ------------------------------------------------- | ---------------- | ----------------------------------- |
| Yearly return ÷ 12                                | 1%               | The Phase 5 brief; many calculators |
| Compounded monthly equivalent, (1 + r)^(1/12) − 1 | 0.949%           | HDFC Mutual Fund; Groww ("not 1%")  |

Both are offered. The default is ÷ 12, as the brief specifies, and the page states which
is in use. **Open for the owner's decision**: whether to make the monthly-equivalent
method the default, because the two fund-house references checked use it, and ÷ 12 gives
a higher figure (₹99.9 lakh vs ₹92.0 lakh for ₹10,000 a month for 20 years at 12%).

Step-up: the instalment rises by s% after every 12 instalments.

## 3. Inputs

| Input              | Range                     | Default |
| ------------------ | ------------------------- | ------- |
| Monthly investment | more than ₹0, up to ₹10¹² | ₹10,000 |
| Expected return    | 0% to 50% a year          | 12%     |
| Years              | whole, 1 to 50            | 10      |
| Yearly step-up     | 0% to 50%                 | 0%      |
| Monthly rate       | ÷ 12 / monthly equivalent | ÷ 12    |

## 4. Outputs

Estimated value, amount invested, estimated gains, invested-vs-gains proportion bar with
the figures as text, year-by-year table (instalment, invested to date, value).

## 5. Examples (test vectors)

| SIP                               | Method            | Value                             |
| --------------------------------- | ----------------- | --------------------------------- |
| ₹1,000 × 12 months, 12%           | ÷ 12              | ₹12,809.33                        |
| ₹1,000 × 12 months, 12%           | equivalent        | ₹12,766.50 (Groww: ≈ ₹12,766)     |
| ₹5,000 × 10 years, 12%            | ÷ 12              | ₹11,61,695.38                     |
| ₹10,000 × 20 years, 12%           | ÷ 12 / equivalent | ₹99,91,479.19 / ₹91,98,573.56     |
| ₹5,000, 10% step-up, 3 years, 12% | ÷ 12              | ₹2,38,204.97 (₹1,98,600 invested) |
| ₹2,000, 10% step-up, 5 years, 0%  | —                 | ₹1,46,522.40                      |

## 6. Disclaimer

Mutual fund returns are not guaranteed and vary; the result is an illustration at a
constant assumed return, before tax, expense ratio effects already reflected in NAV,
and exit loads. Not investment advice.
