# Specification: Percentage Hike Calculator

| Field         | Value                                                      |
| ------------- | ---------------------------------------------------------- |
| Status        | Approved for build (Phase 5, wave 1)                       |
| URL           | `/percentage-hike-calculator`                              |
| Library       | `src/lib/calc/hike/` (built on `src/lib/calc/percentage/`) |
| Test vectors  | `tests/fixtures/hike.json`                                 |
| Last reviewed | 2026-10-07                                                 |

## 1. Purpose

Salary hikes: what will my new salary be after an X% hike, and what percentage hike
does an offer or appraisal letter actually give me. The result always separates the
**percentage** change from the **absolute** change in rupees.

## 2. Modes

| Id                | Question                    | Inputs                         | Outputs                                        |
| ----------------- | --------------------------- | ------------------------------ | ---------------------------------------------- |
| `byPercent`       | New salary after an X% hike | Current salary C, hike h%      | Increase A = C × h ÷ 100; new salary N = C + A |
| `betweenSalaries` | Hike between two salaries   | Current salary C, new salary N | Increase A = N − C; hike h = A × 100 ÷ C       |

Both modes have a **pay period** choice: per month or per year. The result shows the
figures for the chosen period and also the other one (× 12 or ÷ 12), because Indian
offers are often quoted per year (LPA) while pay arrives monthly.

## 3. Inputs and valid ranges

| Input            | Unit   | Range                   | Notes                                                       |
| ---------------- | ------ | ----------------------- | ----------------------------------------------------------- |
| Current salary C | ₹      | more than 0, up to 10¹² |                                                             |
| Hike h           | %      | −100 to 1,000           | Negative values are pay cuts; −100% means pay falls to zero |
| New salary N     | ₹      | 0 to 10¹²               | Lower than C means a pay cut                                |
| Pay period       | choice | month / year            | Display only; does not change the percentage                |

## 4. Formulas as implemented

Uses the Percentage engine:

- `byPercent`: A = `calculatePercentOf(h, C)`; N = `calculateIncreaseBy(C, h)`.
- `betweenSalaries`: A = N − C; h = `calculatePercentChange(C, N)`.
- Other period: monthly × 12 = yearly; yearly ÷ 12 = monthly. No rounding before display.

## 5. Wording

- h > 0: "a hike of h%" / "an increase of ₹A".
- h = 0: "no change".
- h < 0: "a pay cut of |h|%" / "a decrease of ₹|A|". Direction is always written in
  words and shown with an arrow, never by colour alone.

## 6. Rounding and display

Full precision internally. Money with ₹ and Indian grouping, paise only when present;
percentages up to 2 decimals with a "rounded" note when applicable. Annual figures use
"LPA" (lakh per annum) as a secondary label when the yearly amount is at least ₹1 lakh,
e.g. "₹8,40,000 a year (8.4 LPA)".

## 7. Examples (also test vectors)

| Mode            | Inputs                     | Expected                        |
| --------------- | -------------------------- | ------------------------------- |
| byPercent       | C = 50,000, h = 10         | A = 5,000, N = 55,000           |
| byPercent       | C = 8,40,000, h = 12.5     | A = 1,05,000, N = 9,45,000      |
| byPercent       | C = 45,000, h = 0          | A = 0, N = 45,000               |
| byPercent       | C = 45,000, h = 7.25       | A = 3,262.5, N = 48,262.5       |
| byPercent       | C = 60,000, h = −10        | A = −6,000, N = 54,000          |
| byPercent       | C = 60,000, h = −100       | A = −60,000, N = 0              |
| byPercent       | C = 10¹², h = 1,000        | A = 10¹³, N = 1.1 × 10¹³        |
| betweenSalaries | C = 45,000, N = 52,650     | A = 7,650, h = 17               |
| betweenSalaries | C = 6,00,000, N = 7,20,000 | A = 1,20,000, h = 20            |
| betweenSalaries | C = 30,000, N = 40,000     | A = 10,000, h = 33.333… (100/3) |
| betweenSalaries | C = 50,000, N = 50,000     | A = 0, h = 0                    |
| betweenSalaries | C = 50,000, N = 45,000     | A = −5,000, h = −10             |
| betweenSalaries | C = 50,000, N = 0          | A = −50,000, h = −100           |
| period          | 70,000 a month             | 8,40,000 a year (8.4 LPA)       |
| period          | 12,00,000 a year           | 1,00,000 a month                |

## 8. Edge cases

- Identical salaries: 0% and ₹0, "no change".
- Very large values stay finite (largest result 1.1 × 10¹³).
- A hike computed on CTC is not the same as a hike in take-home pay (tax, PF); the page
  says so and links to the CTC calculator once it exists.

## 9. Verification

Hand-worked and re-derived with exact rational arithmetic in
`scripts/fixture_checks/hike.py`. Spreadsheet equivalents: `=A1*B1/100`,
`=A1+A1*B1/100`, `=(B1-A1)/A1*100`.

## 10. Review requirements

Arithmetic only; no tax or payroll rules. Reviewed by the developer against this spec.
