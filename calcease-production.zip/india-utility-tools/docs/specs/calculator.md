# Specification: Calculator (general purpose)

| Field         | Value                                                                                 |
| ------------- | ------------------------------------------------------------------------------------- |
| Status        | Published                                                                             |
| URL           | `/calculator` (Math & Everyday)                                                       |
| Library       | `src/lib/calc/expression/expression.ts`                                               |
| Test vectors  | `tests/fixtures/calculator.json` (verified by `scripts/fixture_checks/calculator.py`) |
| Last reviewed | 2026-10-07                                                                            |

## Safety

No `eval()`, `Function()` or dynamic code. Input is tokenized from a fixed alphabet
(digits, `.`, `,` grouping, `+ − - × * x ÷ /`, `%`, brackets, spaces) and evaluated by a
recursive-descent parser. Any other character is an error. Limits: 200 characters,
bracket depth 30, |value| ≤ 10¹⁵. The function never throws and never returns NaN,
Infinity or −0 (fuzz-tested over 2,000 random inputs).

## Rules

- Precedence: brackets, then unary minus, then × ÷, then + −; left to right.
- Percent: x% = x ÷ 100 (200 × 10% = 20; 50% = 0.5). Directly after + or −, it is that
  percentage of the value on the left (100 + 10% = 110; 500 − 20% = 400). A bracketed
  percentage is a plain number ((10%) + 1 = 1.1).
- Implicit multiplication (2(3)) is not supported: INVALID.
- Display: 15 significant digits with Indian grouping, so 0.1 + 0.2 shows 0.3.

## Errors

EMPTY, INVALID, UNBALANCED_PARENTHESES, DIVIDE_BY_ZERO, TOO_LARGE, TOO_LONG, each with a
plain-language message.

## UI

Text field (keyboard: digits, operators, Enter = equals, Esc = clear, Backspace) plus a
touch keypad (56px keys, labelled for screen readers). After =, a digit starts a new
calculation and an operator continues from the result. History (last 20) lives only in
page memory: not stored or sent. Results are announced through a polite live region.
