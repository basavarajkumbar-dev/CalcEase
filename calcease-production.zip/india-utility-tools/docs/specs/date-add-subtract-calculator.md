# Specification: Date Add / Subtract Calculator

| Field         | Value                                                          |
| ------------- | -------------------------------------------------------------- |
| Status        | Approved for build (Phase 5, wave 3)                           |
| URL           | `/date-add-subtract-calculator`                                |
| Library       | `src/lib/calc/date/add.ts` (engine: docs/specs/date-engine.md) |
| Test vectors  | `tests/fixtures/dates.json` → `shift`                          |
| Last reviewed | 2026-10-07                                                     |

## 1. Purpose

The date a number of years, months, weeks and days after or before a date.

## 2. Inputs

| Input           | Range                     | Default               |
| --------------- | ------------------------- | --------------------- |
| Start date      | 1 Jan 1900 – 31 Dec 2199  | Today (empty = today) |
| Add or subtract | choice                    | Add                   |
| Years           | whole number 0 – 300      | 0                     |
| Months          | whole number 0 – 3,600    | 0                     |
| Weeks           | whole number 0 – 15,000   | 0                     |
| Days            | whole number 0 – 1,10,000 | 30                    |

Empty amount fields count as 0. The result must fall within the date range, otherwise:
"The result is outside the dates this calculator supports (1 January 1900 to
31 December 2199)."

## 3. Rules

Years and months first, as whole calendar months, clamping the day to the end of a
shorter month; then weeks and days. When clamping happened, the result says so
("31 January + 1 month: February has no 31st, so the date moves to 28 February").

## 4. Examples (test vectors)

| Start       | Change                           | Result                |
| ----------- | -------------------------------- | --------------------- |
| 7 Oct 2026  | + 90 days                        | 5 Jan 2027            |
| 7 Oct 2026  | − 45 days                        | 23 Aug 2026           |
| 31 Jan 2026 | + 1 month                        | 28 Feb 2026 (clamped) |
| 29 Feb 2024 | + 1 year                         | 28 Feb 2025 (clamped) |
| 31 Jan 2026 | + 1 month 1 day                  | 1 Mar 2026            |
| 7 Oct 2026  | + 1 year 2 months 3 weeks 4 days | 1 Jan 2028            |

## 5. Not covered

Business-day and holiday-aware deadlines (for example "30 working days") are not
calculated; the page says so. Legal limitation periods have their own counting rules.
