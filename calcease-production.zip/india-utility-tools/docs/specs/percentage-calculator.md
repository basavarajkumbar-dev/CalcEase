# Specification: Percentage Calculator

| Field         | Value                            |
| ------------- | -------------------------------- |
| Status        | Draft for review (Phase 2)       |
| URL           | `/percentage-calculator`         |
| Library       | `src/lib/calc/percentage/`       |
| Test vectors  | `tests/fixtures/percentage.json` |
| Last reviewed | 2026-10-07                       |

This document is the source of truth for the Percentage Calculator. Code and tests
must follow it; if they disagree, the spec is reviewed first, then the code is fixed.

## 1. Supported calculations

Five calculation modes cover the six operations required by the brief. Percentage
increase (C) and percentage decrease (D) are one mode, **percentage change**, because
the user does not have to know the direction in advance: the result says "increase"
or "decrease". This avoids an error state where someone picks "increase" and enters a
falling value.

| Id              | Question the user asks | Inputs                 | Formula (as implemented) | Example                               |
| --------------- | ---------------------- | ---------------------- | ------------------------ | ------------------------------------- |
| `percentOf`     | What is P% of X?       | `percent` P, `value` X | (P × X) ÷ 100            | 20% of 500 = 100                      |
| `whatPercent`   | A is what % of B?      | `part` A, `whole` B    | (A × 100) ÷ B            | 100 of 500 = 20%                      |
| `percentChange` | % change from A to B   | `from` A, `to` B       | ((B − A) × 100) ÷ \|A\|  | 500 → 600 = +20%; 600 → 500 = −16.67% |
| `increaseBy`    | X increased by P%      | `value` X, `percent` P | X + (X × P) ÷ 100        | 500 + 20% = 600                       |
| `decreaseBy`    | X decreased by P%      | `value` X, `percent` P | X − (X × P) ÷ 100        | 500 − 20% = 400                       |

### Why the formulas are written in this order

All are algebraically identical to the textbook forms (P/100 × X, A/B × 100, and so
on). The order is chosen for floating-point accuracy: multiplying first and dividing by
100 last keeps the result exact whenever the true answer is a "nice" decimal. For
example `12.5 × 80 = 1000` exactly, then `1000 ÷ 100 = 10` exactly, whereas
`0.125 × 80` relies on 0.125 being exactly representable (it happens to be, but 0.07
is not). Increase/decrease use `X ± X×P/100` rather than `X × (1 ± P/100)` for the
same reason: `1 + 20/100 = 1.2` is not exactly representable in binary.

### Percentage change sign convention

Change is divided by the **absolute value** of the starting value. This keeps the sign
meaning "went up" or "went down" even for negative starting values:

- −100 → −50 is an increase of 50% (the value rose by 50, half the size of the start).
- Dividing by the signed start would report −50%, which reads as a fall. That
  convention is mathematically possible but misleading for everyday users, so it is
  rejected. The page explains this in the "How it works" section.

## 2. Inputs

| Property      | Rule                                                                                                                                                               |
| ------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Type          | Real numbers. Units: plain numbers, or percent (%) where the label says so.                                                                                        |
| Decimals      | Allowed, any number of decimal places.                                                                                                                             |
| Negatives     | Allowed in every input (see edge cases).                                                                                                                           |
| Zero          | Allowed in every input, except where it is a divisor (section 4).                                                                                                  |
| Range         | −1,000,000,000,000 to 1,000,000,000,000 (±10¹², one lakh crore) for every input.                                                                                   |
| Accepted text | Digits, one decimal point, optional leading `+`, `-` or `−` (Unicode minus), Indian or Western thousands separators (`1,00,000` or `100,000`), surrounding spaces. |
| Rejected text | Letters (including scientific notation such as `1e5`), more than one decimal point, symbols such as `%` or `₹` typed into the field, empty input.                  |

**Why ±10¹²?** It covers any realistic everyday amount (₹1 lakh crore) while keeping
every intermediate value far below 2⁵³ ≈ 9 × 10¹⁵, so integer inputs are represented
exactly in IEEE-754 doubles.

Parsing (text → number) is the job of the validation layer
(`src/lib/validation/parse-number.ts`). The calculation functions receive numbers only,
but still re-check them (finite, within range) so they are safe when called directly,
for example from a future API.

## 3. Outputs

Each calculation returns either a success with a full-precision `number`, or a typed
error code. It never returns a formatted string, `NaN`, `Infinity` or `-0`
(negative zero is normalised to `0`).

```ts
type CalcResult = { ok: true; value: number } | { ok: false; error: CalcErrorCode };
```

## 4. Error states

| Code                 | When                                                                                                                                                                   | User message                                                                               |
| -------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------ |
| `NOT_A_NUMBER`       | Input is `NaN`, `±Infinity`, or text that cannot be parsed                                                                                                             | "Enter a number, for example 250 or 12.5."                                                 |
| `OUT_OF_RANGE`       | \|input\| > 10¹²                                                                                                                                                       | "Enter a number between −1,00,00,00,00,000 and 1,00,00,00,00,000."                         |
| `DIVISION_BY_ZERO`   | `whatPercent` with whole = 0; `percentChange` with from = 0                                                                                                            | Mode-specific, see below                                                                   |
| `RESULT_TOO_LARGE`   | Inputs are valid but the result overflows to ±Infinity. Only reachable by dividing by an extremely small number (e.g. a change from 0.000…0005 with hundreds of zeros) | "The result is too large to show. Check the values you entered."                           |
| `REQUIRED` (UI only) | Field is empty                                                                                                                                                         | No error is shown while empty; the result area says "Enter both values to see the result." |

Division-by-zero messages:

- `whatPercent`, whole = 0: "The whole can't be 0, because a percentage of nothing is undefined."
- `percentChange`, from = 0: "The starting value can't be 0. A change from 0 can't be expressed as a percentage."

## 5. Zero behaviour (explicit decisions)

| Case                | Result | Reason                  |
| ------------------- | ------ | ----------------------- |
| 0% of 500           | 0      | Valid                   |
| 20% of 0            | 0      | Valid                   |
| 0 is what % of 500  | 0%     | Valid                   |
| 100 is what % of 0  | Error  | Division by zero        |
| 0 is what % of 0    | Error  | 0 ÷ 0 is undefined      |
| Change 0 → 100      | Error  | Division by zero        |
| Change 0 → 0        | Error  | 0 ÷ 0 is undefined      |
| Change 500 → 0      | −100%  | Valid (a full decrease) |
| 500 increased by 0% | 500    | Valid                   |
| 0 increased by 20%  | 0      | Valid                   |

## 6. Negative-value behaviour

Negative numbers are valid inputs; the formulas apply unchanged.

| Case                  | Result | Note                                                                         |
| --------------------- | ------ | ---------------------------------------------------------------------------- |
| −20% of 500           | −100   |                                                                              |
| 20% of −500           | −100   |                                                                              |
| −100 is what % of 500 | −20%   |                                                                              |
| Change −100 → −50     | +50%   | Increase; divided by \|start\| (section 1)                                   |
| Change −50 → −100     | −100%  | Decrease                                                                     |
| Change −100 → 100     | +200%  |                                                                              |
| 500 increased by −20% | 400    | Same as decreasing by 20%                                                    |
| 500 decreased by 150% | −250   | Mathematically valid; the page notes that decreases above 100% go below zero |

## 7. Precision and rounding

- **Calculation layer:** full IEEE-754 double precision. No rounding, no `toFixed`.
- **Display layer** (`src/lib/format/number.ts`) rounds once, at the end:
  - |value| ≥ 0.01: up to **2 decimal places**, trailing zeros removed (`16.67`, `20`, `12.5`).
  - 0 < |value| < 0.01: **2 significant digits** (`0.0012`), so a tiny non-zero
    result never displays as a misleading `0`.
  - |value| ≥ 10¹⁵: at most 15 significant digits, because digits beyond that are not
    meaningful in double precision.
  - Rounding mode: half away from zero (`Intl.NumberFormat` default, `halfExpand`),
    applied to the binary value: 0.125 → 0.13 and −0.125 → −0.13. A decimal such as
    1.005 is stored as 1.00499999… in binary and therefore displays as 1 (not 1.01);
    this affects only the last displayed digit and is accepted for display purposes.
  - Grouping: Indian system via `Intl.NumberFormat("en-IN")` (`12,50,000`).
  - Negative zero after rounding displays as `0`.
  - When the displayed value differs from the exact value, the UI says
    "Rounded to 2 decimal places".
- **Tests** compare against fixture values with a relative tolerance of 1 × 10⁻¹²
  (absolute 1 × 10⁻⁹ near zero), because the fixtures are written as exact decimals
  and the implementation is binary floating point.

## 8. Display rules

- The primary result is shown large, with `%` for `whatPercent` and `percentChange`.
- `percentChange` shows the magnitude with a direction word: "Increase of 20%",
  "Decrease of 16.67%", or "No change" when the values are equal. Direction is never
  conveyed by colour alone.
- A one-line sentence restates the question with the answer, for example
  "20% of 500 is 100".
- The worked formula with the user's numbers is shown beneath.

## 9. Worked examples (also in the fixtures)

| Mode            | Inputs       | Exact result | Displayed          |
| --------------- | ------------ | ------------ | ------------------ |
| `percentOf`     | 20, 500      | 100          | 100                |
| `percentOf`     | 12.5, 80     | 10           | 10                 |
| `percentOf`     | 7.5, 200     | 15           | 15                 |
| `percentOf`     | 18, 1,25,000 | 22,500       | 22,500             |
| `whatPercent`   | 100, 500     | 20           | 20%                |
| `whatPercent`   | 1, 3         | 33.333…      | 33.33%             |
| `whatPercent`   | 2.5, 12.5    | 20           | 20%                |
| `percentChange` | 500 → 600    | 20           | Increase of 20%    |
| `percentChange` | 600 → 500    | −16.666…     | Decrease of 16.67% |
| `increaseBy`    | 500, 20      | 600          | 600                |
| `decreaseBy`    | 500, 20      | 400          | 400                |
| `increaseBy`    | 49,999, 18   | 58,998.82    | 58,998.82          |

## 10. Edge cases

1. Increasing by P% then decreasing by P% does **not** return the original value
   (500 + 10% = 550; 550 − 10% = 495). The reverse percentage that does is
   P ÷ (1 + P/100) × 100 (≈ 9.09% for 10%). This is a common user confusion, so the
   page explains it, and a property test verifies it.
2. Very large inputs (10¹²) remain finite: the largest possible result is
   10¹² × 10¹² ÷ 100 = 10²², well within double range.
3. Very small fractions (e.g. 0.0001% of 1) are computed and displayed with
   significant digits rather than shown as 0.
4. Inputs with Indian grouping (`1,25,000`) are accepted.
5. Dividing by an extremely small non-zero value can overflow even though both
   inputs are in range: a change from 5 × 10⁻³²⁴ to −8.9 × 10⁻¹⁸ is −∞ in double
   precision. This returns `RESULT_TOO_LARGE`. Found by property testing on
   2026-10-07; kept as a permanent regression test.

## 11. Verification

- Expected values in `tests/fixtures/percentage.json` were worked out by hand as exact
  decimals or fractions, not by running this code.
- `scripts/verify-fixtures.py` independently re-derives every fixture with Python's
  exact rational arithmetic (`fractions.Fraction`), a separate implementation in a
  separate language, and fails if any fixture is wrong. It runs in CI.
- `tests/unit/percentage.test.ts` checks the TypeScript implementation against the
  same fixtures, plus boundary and error cases.
- `tests/property/percentage.property.test.ts` checks mathematical invariants over
  thousands of random inputs.

## 12. Sources

The formulas are the elementary arithmetic definitions of percentage (per cent = per
hundred). The only convention choice is the |start| denominator for percentage change
(section 1). Expected values were worked out by hand and re-derived with exact
rational arithmetic as described in section 11. Reviewers can reproduce any vector in
a spreadsheet with `=A1*B1/100`, `=A1/B1*100` and `=(B1-A1)/ABS(A1)*100`.
