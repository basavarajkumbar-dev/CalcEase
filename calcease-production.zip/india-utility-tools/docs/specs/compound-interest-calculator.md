# Specification: Compound Interest Calculator

| Field         | Value                                       |
| ------------- | ------------------------------------------- |
| Status        | Approved for build (Phase 5, wave 4)        |
| URL           | `/compound-interest-calculator`             |
| Library       | `src/lib/calc/deposit/compound.ts`          |
| Test vectors  | `tests/fixtures/deposits.json` → `compound` |
| Last reviewed | 2026-10-07                                  |

## 1. Purpose

Growth of a lump sum with interest compounded yearly, half-yearly, quarterly or monthly,
with a year-by-year table and a comparison with simple interest.

## 2. Inputs

| Input       | Range                                                          | Default   |
| ----------- | -------------------------------------------------------------- | --------- |
| Principal   | more than ₹0, up to ₹10¹²                                      | ₹1,00,000 |
| Annual rate | 0% to 100%                                                     | 8%        |
| Time        | years (0–100, whole) + months (0–11, whole); total more than 0 | 5 years   |
| Compounding | yearly / half-yearly / quarterly / monthly                     | Quarterly |

## 3. Formula

A = P × (1 + r ÷ 100n)^(n × t), with n compounding periods a year and t in years
(months ÷ 12). Interest = A − P. Effective annual rate = (1 + r ÷ 100n)^n − 1.
Simple interest for comparison = P × r × t ÷ 100.

## 4. Year-by-year table

One row per year: interest earned in the year and the balance at its end. A final part
year (e.g. 2.5 years) gets its own row. The table is the text equivalent of growth over
time; no chart is drawn.

## 5. Part periods

When n × t is not a whole number (e.g. 1.5 years compounded yearly), the formula is used
with a fractional power, as in standard textbooks. For a time shorter than one
compounding period this gives slightly less than simple interest. Banks may instead pay
simple interest for a part period; the FD Calculator follows the bank method.

## 6. Examples (test vectors)

| P        | r   | t         | n           | A                              |
| -------- | --- | --------- | ----------- | ------------------------------ |
| 1,00,000 | 10% | 2 years   | yearly      | 1,21,000                       |
| 1,00,000 | 8%  | 3 years   | quarterly   | 1,26,824.18                    |
| 50,000   | 12% | 1.5 years | half-yearly | 59,550.80                      |
| 10,000   | 5%  | 10 years  | monthly     | 16,470.09                      |
| 1,00,000 | 10% | 1.5 years | yearly      | 1,15,368.97 (fractional power) |

## 7. Verification

Exact fractions in `scripts/fixture_checks/deposits.py` (50-digit decimals for
fractional powers). Property tests: yearly rows sum to the total and end at A; compound ≥
simple interest once a full period has passed.
