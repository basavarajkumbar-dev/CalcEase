# Specification: Salary Budget Planner

| Field         | Value                                                                                              |
| ------------- | -------------------------------------------------------------------------------------------------- |
| Status        | Published                                                                                          |
| URL           | `/salary-budget-planner` (Salary & Career)                                                         |
| Library       | `src/lib/calc/budget/budget.ts`                                                                    |
| Test vectors  | `tests/fixtures/budget.json` (verified with exact fractions by `scripts/fixture_checks/budget.py`) |
| Last reviewed | 2026-10-08                                                                                         |

## Definitions (all monthly unless stated)

| Term              | Meaning                                                                                                                    |
| ----------------- | -------------------------------------------------------------------------------------------------------------------------- |
| Income            | Take-home salary (after tax and deductions)                                                                                |
| Essentials        | Rent/housing, food, transport, utilities, insurance/health, other essentials. Entered as one total, or itemised and summed |
| EMIs              | Loan EMIs and other debt payments                                                                                          |
| Wants             | Discretionary spending                                                                                                     |
| Emergency savings | Amount already set aside (a balance, not monthly)                                                                          |
| Investments       | Amount the user already invests each month                                                                                 |

## Formulas

- Total expenses = essentials + EMIs + wants.
- Surplus = income − total expenses (negative = spending exceeds income).
- Unallocated = surplus − investments (negative = investments exceed the surplus).
- Expense % = total expenses ÷ income × 100; savings/investment % = max(0, surplus) ÷ income
  × 100; investment % and debt % likewise.
- Additional available to save or invest = max(0, unallocated).

## Emergency fund

- Monthly basis = essentials + EMIs (loan payments continue in an emergency).
- Target = basis × target months (configurable 1–24; default 6; 3–6 shown as a common
  reference). Shortfall = max(0, target − current savings).
- Coverage = current savings ÷ basis months (shown to one decimal, rounded down; "no
  essentials entered" when the basis is 0).

## Allocation logic

**Suggested split of the surplus** (A = max(0, surplus)): while there is a shortfall,
emergency share e% (default 50%) of A goes to the emergency fund, capped at the shortfall;
the rest to investments. Months to target = ⌈shortfall ÷ emergency amount⌉ (0 if reached,
none if nothing can be set aside).

**Balanced reference** (labelled a reference, adjustable): essentials and EMIs are taken as
they are; left = max(0, income − essentials − EMIs); wants = left × w% (default 60%); saving
= the rest, split emergency-first as above. Because commitments come first, high rent or
EMIs reduce the reference for wants and saving, and when essentials + EMIs are 50% of income
the defaults give the 50/30/20 split. It is never presented as a rule.

**Goal (optional):** months = ⌈goal ÷ A⌉, assuming no returns.

## Validation

Income > 0; every amount ≥ 0 and ≤ ₹10¹⁰; target months 1–24 (whole); shares 0–100%.
Errors: INCOME_NOT_POSITIVE, AMOUNT_NEGATIVE, OUT_OF_RANGE, MONTHS_OUT_OF_RANGE,
SHARE_OUT_OF_RANGE, NOT_A_NUMBER. Empty optional fields count as 0.

## Rounding

Full precision internally; amounts shown to the paisa, percentages to 2 decimals, months
whole (ceiling) or to one decimal (coverage, rounded down so cover is never overstated).

## Assumptions and disclaimer

No interest, returns or inflation. The planner organises the user's own numbers; suggested
and reference amounts are not personalised advice, and no product is recommended.
