# Specification: Age Calculator

| Field         | Value                                                          |
| ------------- | -------------------------------------------------------------- |
| Status        | Approved for build (Phase 5, wave 3)                           |
| URL           | `/age-calculator`                                              |
| Library       | `src/lib/calc/date/age.ts` (engine: docs/specs/date-engine.md) |
| Test vectors  | `tests/fixtures/dates.json` → `age`                            |
| Last reviewed | 2026-10-07                                                     |

## 1. Purpose

Exact age in years, months and days from a date of birth, on today's date or any other
date, plus totals and the next birthday.

## 2. Inputs

| Input         | Range                    | Default                                |
| ------------- | ------------------------ | -------------------------------------- |
| Date of birth | 1 Jan 1900 – 31 Dec 2199 | 1 January 2000                         |
| Age on        | same range               | Empty = today (from the user's device) |

## 3. Outputs

- Age: years, months, days (date-engine §4 difference convention).
- Totals: months, weeks (+ days), days.
- Next birthday: date, weekday, days to go, age reached; "Happy birthday" when 0 days.
- Day of the week of birth.

## 4. Errors

| Case                                  | Message                                                                                             |
| ------------------------------------- | --------------------------------------------------------------------------------------------------- |
| Date of birth after the "age on" date | "The date of birth is after the date you are calculating the age on."                               |
| Missing or invalid date               | Field error: "Enter a date of birth." / "Enter a date between 1 January 1900 and 31 December 2199." |

## 5. Edge cases

- Born on 29 February: birthdays in common years on 28 February (stated on the page and in
  the result).
- Born on the "age on" date: age 0 days.
- Month-end births (31 January): a month is complete on the last day of shorter months.

## 6. Examples (test vectors)

| Born        | On          | Age                                                                            |
| ----------- | ----------- | ------------------------------------------------------------------------------ |
| 15 Aug 1990 | 7 Oct 2026  | 36 years, 1 month, 22 days; 13,202 days; next birthday 15 Aug 2027 in 312 days |
| 29 Feb 2000 | 28 Feb 2023 | 23 years exactly (birthday)                                                    |
| 29 Feb 2000 | 27 Feb 2023 | 22 years, 11 months, 29 days                                                   |
| 8 Oct 1985  | 7 Oct 2026  | 40 years, 11 months, 29 days; turns 41 tomorrow                                |
| 31 Jan 1995 | 28 Feb 2026 | 31 years, 1 month                                                              |

## 7. Not covered

Age for official purposes (school admission cut-offs, retirement, exam eligibility) is
defined by each rule, often "as on" a given date and sometimes counting differently. The
page tells users to check the specific rule.
