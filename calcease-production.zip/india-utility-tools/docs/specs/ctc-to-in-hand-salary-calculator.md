# Specification: CTC to In-Hand Salary Calculator

| Field         | Value                                                                                                                                           |
| ------------- | ----------------------------------------------------------------------------------------------------------------------------------------------- |
| Status        | **Under review: not published.** Built; excluded from production builds until a chartered accountant signs off (docs/reviews/ctc-to-in-hand.md) |
| URL           | `/ctc-to-in-hand-salary-calculator` (review builds only: `ENABLE_UNDER_REVIEW_TOOLS=1`; always noindex)                                         |
| Library       | `src/lib/calc/salary/ctc.ts`                                                                                                                    |
| Rule data     | `src/lib/rules/income-tax/rates.ts` (tax year 2026-27), `src/lib/rules/epf/rates.ts`                                                            |
| Test vectors  | `tests/fixtures/ctc.json`                                                                                                                       |
| Last reviewed | 2026-10-07 (sources only; no professional review)                                                                                               |

## 1. Purpose

Estimated monthly take-home pay from an annual CTC, for a resident individual below 60
with only salary income, under the new (default) or old tax regime.

## 2. Calculation

1. Basic = CTC × basic %.
2. PF wages a month = basic ÷ 12 (or capped at the wage ceiling, or none). Employee PF =
   employer PF = 12% of PF wages.
3. Gross = CTC − employer PF (if part of CTC) − gratuity (optional: basic × 15 ÷ 26 ÷ 12 a
   year, the Payment of Gratuity Act rate) − other employer costs.
4. Taxable = gross − standard deduction − professional tax (old regime only) − claimed
   deductions (old regime only).
5. Tax = slab tax − rebate (full up to the limit; new regime marginal relief above it),
   - 4% cess on the remainder.
6. In-hand = gross − employee PF − professional tax − tax; monthly = ÷ 12.

## 3. Rule values and sources (tax year 2026-27)

| Value              | New regime                                                                                 | Old regime                                  | Source                                                                                                                          |
| ------------------ | ------------------------------------------------------------------------------------------ | ------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------- |
| Slabs              | 0–4L nil; 4–8L 5%; 8–12L 10%; 12–16L 15%; 16–20L 20%; 20–24L 25%; above 30%                | 0–2.5L nil; 2.5–5L 5%; 5–10L 20%; above 30% | incometax.gov.in (AY 2026-27); Budget 2025-26 speech; Budget 2026-27 speech (no change; Income-tax Act, 2025 from 1 April 2026) |
| Standard deduction | ₹75,000                                                                                    | ₹50,000                                     | Budget 2024-25 speech (new-regime increase)                                                                                     |
| Rebate             | up to ₹60,000 if taxable ≤ ₹12 lakh; marginal relief above                                 | up to ₹12,500 if taxable ≤ ₹5 lakh          | incometax.gov.in; Section 87A text (mechanism)                                                                                  |
| Cess               | 4%                                                                                         | 4%                                          | incometax.gov.in                                                                                                                |
| Surcharge          | from ₹50 lakh: not modelled; such inputs are refused                                       | same                                        | incometax.gov.in                                                                                                                |
| PF                 | 12% employee, 12% employer; wage ceiling ₹25,000 a month from 17 Sep 2026 (₹15,000 before) |                                             | Govt of West Bengal EPF Act summary; Ministry of Labour release, 16 Sep 2026                                                    |

## 4. Items that need professional confirmation

See docs/reviews/ctc-to-in-hand.md. In short: section references and wording under the
Income-tax Act, 2025; professional tax not deductible in the new regime; rounding of
income and tax; the 2014 start of the ₹15,000 ceiling; whether "wages" for PF under the
Code on Social Security, 2020 changes the PF base for typical CTC structures.

## 5. Examples (test vectors)

| Case                                                    | Result                                                        |
| ------------------------------------------------------- | ------------------------------------------------------------- |
| New regime, taxable ₹12,50,000                          | slab tax ₹67,500; marginal relief ₹17,500; tax + cess ₹52,000 |
| Old regime, taxable ₹7,00,000                           | ₹52,500 + cess = ₹54,600 (no marginal relief)                 |
| CTC ₹12 lakh, basic 50%, full PF, new regime            | gross ₹11,28,000; tax nil; in-hand ₹88,000 a month            |
| CTC ₹20 lakh, basic 40%, PF capped, PT ₹200, new regime | tax ₹1,84,912; in-hand ₹1,45,057.33 a month                   |
| Same, old regime, ₹2,00,000 deductions                  | tax ₹3,39,019.20; in-hand ₹1,32,215.07 a month                |

## 6. Known effect worth showing reviewers

Just above ₹12 lakh, marginal relief caps tax before cess at the income over ₹12 lakh, but
cess (4%) is added on top, so take-home pay falls slightly as income rises over a narrow
band. This follows from the rules as written; the reviewer should confirm.
