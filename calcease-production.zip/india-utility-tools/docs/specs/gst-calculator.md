# Specification: GST Calculator

| Field         | Value                                               |
| ------------- | --------------------------------------------------- |
| Status        | Approved for build (Phase 5, wave 2)                |
| URL           | `/gst-calculator`                                   |
| Library       | `src/lib/calc/gst/`                                 |
| Rule data     | `src/lib/rules/gst/rates.ts` (version `2025-09-22`) |
| Test vectors  | `tests/fixtures/gst.json`                           |
| Last reviewed | 2026-10-07                                          |

## 1. Purpose

Add GST to a price before tax, or work out the price before tax and the GST inside a
price that already includes it; show the CGST + SGST/UTGST or IGST split.

## 2. Modes

| Id          | Question                                 | Inputs                     | Outputs                                                 |
| ----------- | ---------------------------------------- | -------------------------- | ------------------------------------------------------- |
| `exclusive` | Add GST to a price                       | Price before GST B, rate r | GST G = B × r ÷ 100; total T = B + G                    |
| `inclusive` | Remove GST from a price that includes it | Total price T, rate r      | Price before GST B = T × 100 ÷ (100 + r); GST G = T − B |

Split, for both modes:

| Supply                                            | Components                                                                                                 |
| ------------------------------------------------- | ---------------------------------------------------------------------------------------------------------- |
| Within one state or union territory (intra-state) | CGST = G ÷ 2 and SGST (or UTGST in a union territory without its own legislature) = G ÷ 2, each at r ÷ 2 % |
| Between states, or imports (inter-state)          | IGST = G at r %                                                                                            |

The calculator does not decide which applies: the user chooses, and the page explains
the rule of thumb (same state → CGST + SGST; different states → IGST) and that the
place-of-supply rules decide in practice.

## 3. Inputs and valid ranges

| Input           | Unit   | Range                        | Notes                                                                   |
| --------------- | ------ | ---------------------------- | ----------------------------------------------------------------------- |
| Amount (B or T) | ₹      | more than 0, up to 10¹²      |                                                                         |
| Rate (preset)   | %      | 5, 18, 40 from the rule data | Official structure in force from 22 September 2025                      |
| Rate (other)    | %      | 0 to 100                     | For special or older rates (e.g. 3%, 0.25%, 12%, 28% on older invoices) |
| Supply type     | choice | intra-state / inter-state    |                                                                         |

## 4. Rule data

Presets come only from `src/lib/rules/gst/rates.ts`, which records the source
documents, retrieval date, effective date and notes. Verified 2026-10-07 against:

- PIB, "Recommendations of the 56th Meeting of the GST Council" (3 September 2025):
  standard rate 18%, merit rate 5%, special de-merit rate 40%; rate changes effective
  22 September 2025 (tobacco products excepted for a transition period).
  https://www.pib.gov.in/PressReleasePage.aspx?PRID=2163555
- GST Council, recommendations page for the 56th meeting.
  https://gstcouncil.gov.in/recommendations-56th-meeting-gst-council-held-new-delhi

Special rates (e.g. on precious metals and stones) were **not** confirmed from a primary
source during this review, so they are not presets; users can type them as "Other rate".

## 5. Formulas and rounding

Full precision internally (inclusive mode divides by (100 + r) exactly, no rounding of
the base before the GST is worked out). Displayed to the paisa. The split halves are
shown to the paisa each; if G has an odd number of paise the two halves are shown
rounded and a note says so (on real invoices each component is rounded by the
supplier's billing system).

## 6. Errors

| Case                                  | Message                                                         |
| ------------------------------------- | --------------------------------------------------------------- |
| Amount not more than 0, or above 10¹² | "Enter an amount of more than ₹0 and up to ₹1,00,00,00,00,000." |
| Other rate outside 0–100%             | "Enter a rate between 0% and 100%."                             |

## 7. Examples (also test vectors)

| Mode      | Inputs             | Expected                                     |
| --------- | ------------------ | -------------------------------------------- |
| exclusive | B = 1,000, r = 18  | G = 180, T = 1,180; CGST = SGST = 90         |
| exclusive | B = 2,499.5, r = 5 | G = 124.975, T = 2,624.475                   |
| exclusive | B = 50,000, r = 40 | G = 20,000, T = 70,000                       |
| exclusive | B = 1,000, r = 0   | G = 0, T = 1,000                             |
| exclusive | B = 100, r = 0.25  | G = 0.25, T = 100.25                         |
| inclusive | T = 1,180, r = 18  | B = 1,000, G = 180                           |
| inclusive | T = 1,000, r = 5   | B = 20,000/21 ≈ 952.38, G = 1,000/21 ≈ 47.62 |
| inclusive | T = 999, r = 40    | B = 4,995/7 ≈ 713.57, G = 1,998/7 ≈ 285.43   |
| inclusive | T = 1,050, r = 5   | B = 1,000, G = 50; CGST = SGST = 25          |
| inclusive | T = 500, r = 0     | B = 500, G = 0                               |

## 8. Edge cases

- 0% (nil-rated or exempt): GST 0; the result says no GST applies at 0%.
- Inclusive then exclusive returns the original amount (property test).
- The calculator does not handle compensation cess, TCS, reverse charge or composition
  scheme, and says so.

## 9. Verification

Hand-worked values re-derived with exact rational arithmetic in
`scripts/fixture_checks/gst.py`. Spreadsheet equivalents: `=A1*B1/100`,
`=A1*100/(100+B1)`.

## 10. Review requirements

Rate presets must be re-checked against the official sources whenever the GST Council
changes rates, and at least every 6 months. The page shows the effective date and last
review date. Disclaimer: an estimate; actual tax depends on the classification of the
goods or services and the transaction.
