# Specification: Notice Period Calculator

| Field         | Value                                                                      |
| ------------- | -------------------------------------------------------------------------- |
| Status        | Published                                                                  |
| URL           | `/notice-period-calculator` (Salary & Career)                              |
| Library       | `src/lib/calc/career/career.ts` (`noticePeriod`), on the plain-date engine |
| Test vectors  | `tests/fixtures/career.json` → `notice` (verified with datetime)           |
| Last reviewed | 2026-10-08                                                                 |

## Convention

Calendar days, including weekends and holidays.

- **Default (exclusive of the resignation date):** the notice starts the day after
  resignation; last working day = resignation date + N days. Resign 8 Oct 2026, 30 days →
  7 Nov 2026.
- **Option "count the resignation date as day 1":** last working day = resignation date +
  N − 1 days → 6 Nov 2026.

Either way the notice spans exactly N calendar days (property-tested).

## Inputs and outputs

- Resignation date (defaults to today), notice period 1–365 whole days.
- Last working day with weekday; notice start; days from today to the last day (or "passed
  X days ago", or "today"); notice days served so far (0 to N).

## Not covered

Notice in months, working-day clauses, leave set-off, early release and buyout: the page
says the contract and HR policy decide.
