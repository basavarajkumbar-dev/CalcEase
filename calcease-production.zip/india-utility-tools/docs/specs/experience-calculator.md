# Specification: Experience Calculator

| Field         | Value                                                                        |
| ------------- | ---------------------------------------------------------------------------- |
| Status        | Published                                                                    |
| URL           | `/experience-calculator` (Salary & Career)                                   |
| Library       | `src/lib/calc/career/career.ts` (`workExperience`), on the plain-date engine |
| Test vectors  | `tests/fixtures/career.json` → `experience` (verified with dateutil)         |
| Last reviewed | 2026-10-08                                                                   |

## Rules

- Inputs: joining date, last working day (defaults to today on the device); dates 1900–2199.
- Convention: **both dates count by default** (joined 1 Jan 2020, last day 31 Dec 2024 =
  5 years). Option: leave the last day out.
- Years, months, days by the date-engine convention (whole months from the joining date,
  month-end clamped, then days), so leap years and month ends are handled. Same-day dates =
  1 day (inclusive) or 0 days.
- End date before joining date: error "The end date is before the joining date". End date
  in the future: allowed and labelled "projected".
- Also shown: total months, total days, years to one decimal (rounded down).

## Examples

| Joining → end           | Inclusive | Result                    |
| ----------------------- | --------- | ------------------------- |
| 2020-01-01 → 2024-12-31 | yes       | 5 years (1,827 days)      |
| same                    | no        | 4 years 11 months 30 days |
| 2024-02-29 → 2025-02-28 | yes       | 1 year 1 day              |
| 2023-01-31 → 2023-02-28 | yes       | 1 month 1 day             |
| 2018-07-16 → 2026-10-08 | yes       | 8 years 2 months 23 days  |
