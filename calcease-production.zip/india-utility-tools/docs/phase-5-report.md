# Phase 5 report: MVP calculator suite

Date: 7 October 2026. All figures below were measured in this environment; nothing is
estimated unless it says so.

## A. Tools completed

Twelve calculators are published (registry status `active`), built in five waves, each
behind a gate.

| Wave    | Calculator                                                         | URL                             |
| ------- | ------------------------------------------------------------------ | ------------------------------- |
| Phase 2 | Percentage Calculator (moved onto the shared framework in Phase 5) | `/percentage-calculator`        |
| 1       | Discount Calculator                                                | `/discount-calculator`          |
| 1       | Percentage Hike Calculator                                         | `/percentage-hike-calculator`   |
| 2       | GST Calculator                                                     | `/gst-calculator`               |
| 3       | Age Calculator                                                     | `/age-calculator`               |
| 3       | Date Difference Calculator                                         | `/date-difference-calculator`   |
| 3       | Date Add / Subtract Calculator                                     | `/date-add-subtract-calculator` |
| 4       | Compound Interest Calculator                                       | `/compound-interest-calculator` |
| 4       | FD Calculator                                                      | `/fd-calculator`                |
| 4       | RD Calculator                                                      | `/rd-calculator`                |
| 5       | EMI Calculator                                                     | `/emi-calculator`               |
| 5       | SIP Calculator                                                     | `/sip-calculator`               |

All four category hubs are now live: `/finance`, `/salary`, `/math` and `/date-time`.

## B. Tools withheld

| Tool or feature                                    | Status                                                                                                                                                                                                                                 | Why                                                                                                                                                                                   |
| -------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **CTC to In-Hand Salary Calculator**               | Built and tested, **held under review**. In production builds the route is a 404, it is left out of the sitemap and it is never linked. Review builds (`ENABLE_UNDER_REVIEW_TOOLS=1`) render it noindex with an "Under review" notice. | No chartered accountant was available. Tax and PF values come only from official sources, but several points still need professional confirmation (`docs/reviews/ctc-to-in-hand.md`). |
| RD tenures that are not whole quarters             | Not offered. Users are told why.                                                                                                                                                                                                       | Banks publish the formula only for completed quarters and treat leftover months differently. I could not attribute a method to a primary source.                                      |
| FD with 366-day leap years (AU Small Finance Bank) | Not offered. Stated on the page.                                                                                                                                                                                                       | Most published methods use 365 days. Offering both would need a bank picker.                                                                                                          |
| SIP monthly-rate default                           | ÷ 12 is the default and the monthly equivalent is an option. **The default is the owner's decision.**                                                                                                                                  | See G and L.                                                                                                                                                                          |
| Notice Period and Experience calculators           | Still "coming soon"                                                                                                                                                                                                                    | Outside the Phase 5 list.                                                                                                                                                             |

## C. Architecture: how the framework evolved

- **One state hook for every calculator** (`useCalculatorState`). It handles:
  - number, choice and text (ISO date) fields;
  - per-mode memory (`scopeField`);
  - client-only defaults such as today's date (`defaults`);
  - error timing (`touched`);
  - share links.
  - Spec objects are module constants.
- **Inputs travel in the URL fragment (`#amount=…`), not the query string.**
  - Wave 1 found that rewriting the query string made the browser send inputs to the server in a Referer header.
  - Now inputs are never sent anywhere. Opening a link and typing are both covered by regression tests.
- **Shared result pieces:**
  - `ResultPanel` gained a `chart` slot and `reserveSpace`. The latter holds space for results that need today's date, which took CLS on the date pages from 0.11–0.14 to 0.
  - New: `DisclosureTable` for long schedules, `ProportionBar` (chart plus text legend), `SourceList`, `DateInput`, `Checkbox` and `useToday`.
- **Review gating.**
  - A `ReviewTool` type and `src/config/review.ts` let finished-but-unreviewed tools exist only in review builds.
  - The public registry still lists such a tool as "coming soon".
- **Performance guards.**
  - A non-prefetching `Link` plus a lint rule banning `next/link`, so the homepage does not download calculators.
  - Each calculator is a client island loaded only on its own page.
- **Layering is unchanged and lint-enforced:** UI → validation → pure calc (`src/lib/calc`, no React or browser globals) → format → UI.
  - Rule values live in `src/lib/rules`, never in formulas.

## D. Calculation engines (reusable)

| Engine                                                                                                                             | Module                                            | Used by                                                                     |
| ---------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------- | --------------------------------------------------------------------------- |
| Percentage                                                                                                                         | `calc/percentage`                                 | Percentage, Discount, Hike                                                  |
| Discount, hike                                                                                                                     | `calc/discount`, `calc/hike`                      | Their calculators                                                           |
| GST                                                                                                                                | `calc/gst`                                        | GST                                                                         |
| **Plain-date engine**: day numbers (Hinnant), month clamping, calendar difference (dateutil convention), weekdays, age, date shift | `calc/date`                                       | Age, Date Difference, Date Add/Subtract, FD (maturity date and broken days) |
| Compounding, FD (bank method), RD (bank formula)                                                                                   | `calc/deposit`                                    | Compound Interest, FD, RD                                                   |
| EMI: schedule closing at zero, one-time prepayment                                                                                 | `calc/loan`                                       | EMI                                                                         |
| SIP: start-of-month, two monthly-rate methods, step-up                                                                             | `calc/invest`                                     | SIP                                                                         |
| CTC → in-hand: slab tax, rebate with marginal relief, cess, PF                                                                     | `calc/salary`                                     | CTC (under review)                                                          |
| Formatting: Indian currency, amount in words, dates without `Date`, durations                                                      | `format/currency`, `format/date`, `format/number` | All                                                                         |

## E. Rule data (versioned, with sources)

| Rule set                                                                                                                         | Version / effective                 | Status           | Sources (all retrieved 2026-10-07)                                                                                                                                             |
| -------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------- | ---------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| GST rate presets: 5% Merit, 18% Standard, 40% Special de-merit                                                                   | `2025-09-22`, from 22 Sep 2025      | Published        | PIB release on the 56th GST Council meeting; GST Council recommendations page                                                                                                  |
| FD/RD calculation methods (conventions, not rates)                                                                               | Reviewed 2026-10-07                 | Published        | TJSB Sahakari Bank and AU Small Finance Bank method documents; CSB Bank; RBI Master Circular on Interest Rates on Rupee Deposits (2004); ICICI Bank FD and RD calculator pages |
| Income tax, tax year 2026-27: slabs (both regimes), standard deduction, rebate and marginal relief, 4% cess, surcharge threshold | `2026-27`, 1 Apr 2026 – 31 Mar 2027 | **Under review** | incometax.gov.in (AY 2026-27 rates); Budget speeches 2026-27, 2025-26 and 2024-25; Section 87A text on incometaxindia.gov.in                                                   |
| EPF: 12% employee and employer; wage ceiling ₹15,000 up to 16 Sep 2026, then ₹25,000                                             | Two versions                        | **Under review** | Ministry of Labour release (16 Sep 2026); Government of West Bengal summary of the EPF Act                                                                                     |

Every rule set records its version, effective dates, review date, source URLs with
retrieval dates, and notes. Unit tests check that sources exist and that the right set
is picked by date. The EPF ceiling change (17 Sep 2026) is after my training data, so
it was only caught because the rule was looked up rather than recalled.

## F. Testing (actual numbers)

| Check                                                                                                                  | Result                                                                                                                                                                                                                                                 |
| ---------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Unit tests (Vitest)                                                                                                    | **394 passed**, 0 failed                                                                                                                                                                                                                               |
| Property-based assertions (fast-check `fc.assert`, 100 random cases each by default)                                   | **33** across 8 files                                                                                                                                                                                                                                  |
| Independent fixture checks (`scripts/verify-fixtures.py`: exact fractions, or 50-digit decimals for fractional powers) | **442 verified**, 0 failed                                                                                                                                                                                                                             |
| End-to-end (Playwright, Chromium desktop and Chromium mobile emulation)                                                | **287 passed**, 0 failed, 49 skipped                                                                                                                                                                                                                   |
| Accessibility                                                                                                          | 24 axe-core scans (WCAG 2.2 AA rule set) in the e2e suite, covering every calculator including error states and open tables: **0 violations**. Also a 44 × 44 px touch-target test. CTC review build scanned separately: 0 violations.                 |
| Typecheck, lint, format                                                                                                | Clean                                                                                                                                                                                                                                                  |
| Production build                                                                                                       | Passing (normal build and review build)                                                                                                                                                                                                                |
| CI                                                                                                                     | **Not run.** The GitHub Actions workflow exists, but no GitHub repository is connected, so it has never executed. Firefox and WebKit e2e runs are configured for CI only, since those browsers cannot be downloaded here; they are among the 49 skips. |

Most skipped tests are deliberate per-project skips, such as desktop-only keyboard tests on mobile and explicit-viewport tests run once.

## G. Verification (financial calculators)

| Calculator        | Independent references                                                                                                                                                              | Status                 | Unresolved                                                                                                                                                                         |
| ----------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| GST               | Official rate releases (E); formulas re-derived with exact fractions                                                                                                                | 48 fixture checks pass | None                                                                                                                                                                               |
| Compound Interest | Exact fractions in Python; textbook formula                                                                                                                                         | Pass                   | Below one compounding period, compound interest is lower than simple interest under the fractional-power formula. This is correct maths, now documented.                           |
| FD                | Bank method documents (E). ICICI example: ₹1,00,000 at 6.6% for 3 years ≈ ₹1,21,699, **matches to the rupee**. The verifier recomputes quarter by quarter.                          | Pass                   | Banks disagree on the short-deposit limit (3, 6 or 12 months), so it is an input. 366-day leap years are not modelled.                                                             |
| RD                | ICICI example: ₹5,000 a month at 8% for 1 year ≈ ₹62,647, **matches**. TJSB and ICICI publish the same formula. The verifier adds up each instalment separately.                    | Pass                   | Part-quarter tenures are not supported. A popular finance site's RD figures (₹88,663.63; ₹4,24,433.46) contradict the formula and were rejected.                                   |
| EMI               | ICICI example: ₹10,00,000 at 7.25% for 120 months ≈ ₹11,740, **matches**. The verifier runs every loan month by month with exact fractions and confirms the balance reaches 0.      | Pass                   | Lender rounding (EMI to the rupee, adjusted last EMI) is not modelled; the page says so.                                                                                           |
| SIP               | HDFC Mutual Fund (formula, start-of-month timing); Groww example: ₹1,000 a month at 12% ≈ ₹12,766, **matches the monthly-equivalent method**. The verifier adds up each instalment. | Pass                   | **Convention conflict:** the brief's default (÷ 12) differs from both references, which use the compounded monthly equivalent. Both are offered; the default awaits your decision. |
| CTC (withheld)    | Official sources (E); hand-worked tax cases re-derived exactly                                                                                                                      | 38 checks pass         | Needs chartered-accountant review (12 items in `docs/reviews/ctc-to-in-hand.md`).                                                                                                  |

**Errors that independent verification caught during Phase 5:**

- Two wrong hand-worked fixture values in Wave 1.
- A paisa error in my "interest saved" figure (₹83,327.46, not .47).
- A floating-point leak inside my own CTC verifier.
- A wording bug where "1 year and 52 weeks" appeared instead of "1 year".

All of these were fixed before their wave's gate passed.

## H. Performance

Lighthouse 13.5, mobile profile, simulated throttling, local production server. Medians
of 3–5 runs per page.

| Page                                  |         Perf |           LCP |           TBT |                                           CLS |        JS (gzip) |
| ------------------------------------- | -----------: | ------------: | ------------: | --------------------------------------------: | ---------------: |
| Homepage                              |           97 |         2.06s |         169ms |                                             0 |         145.1 KB |
| Percentage / Discount / Hike (Wave 1) |        98–99 |         ≈2.0s |         noisy |                                             0 |          ≈151 KB |
| GST                                   |           96 |         1.82s |         164ms |                                             0 |         152.0 KB |
| Age / Date Difference / Add-Subtract  |        97–98 |    2.05–2.09s |     112–154ms | **0** (was 0.14 / 0.11 / 0.03 before the fix) |   152.0–152.4 KB |
| Compound Interest / FD / RD           | 97 / 98 / 96 |    2.11–2.24s |     139–208ms |                                             0 |   151.5–154.4 KB |
| EMI / SIP                             |      98 / 98 | 1.95s / 1.90s | 135ms / 112ms |                                             0 | 154.8 / 154.2 KB |
| `/finance` hub                        |           94 |         1.64s |         230ms |                                             0 |         144.9 KB |

Accessibility, best practices and SEO scored 100 on every page measured.

**INP** is a field metric, so it cannot be measured in a lab. As in Phases 2–4, the lab proxy is the longest event duration while typing into a field, at phone size with 4× CPU throttling. Three runs per page:

| Page              | Worst event (ms)   |
| ----------------- | ------------------ |
| EMI               | 144, 136, 112      |
| GST               | 104, 80, 72        |
| SIP               | 88, 96, 104        |
| FD                | 88, 96, 72         |
| Age (date picker) | no event over 16ms |

All are under the 200ms target. EMI is the slowest, and slower than Phase 4's tool page (40–56ms), because it rebuilds two schedule tables (up to 480 rows) on every keystroke, even while they are closed. Rendering the tables only when opened would cut this; it is listed in K.

**Compared with Phase 4** (tool page 149.3 KB, homepage 149.3 KB, LCP ≈ 2.05s, CLS 0):

- The homepage is **4.2 KB lighter** (145.1 KB), because calculator prefetching was removed.
- Each calculator page carries only its own code: 151.5–154.8 KB. That is 6.4–9.7 KB above the homepage, within the ≤ 30 KB page-specific budget I proposed (not yet confirmed by you).
- Adding eleven calculators did not increase any other page's JavaScript.
- LCP stays around 2.0s, which misses the < 2.0s target by about 0.05–0.2s on some pages. As in earlier phases, Lighthouse's simulated LCP on this site is bimodal and noisy.
- The < 90 KB JS target remains missed because the framework runtime alone is about 137 KB.

## I. UX decisions

- **Inputs:**
  - Native date pickers. They follow the device locale, so Indian devices show DD/MM/YYYY.
  - "Today" is the device's date.
  - Results that need today reserve their space.
- **Empty optional fields count as 0** (months, days, step-up, professional tax). Required fields say what is missing.
- **Bank-specific choices appear only when they change the answer.** For example, the FD short-deposit rule is shown only when the deposit is under 12 months.
- **Long tables (yearly and monthly schedules) sit in closed disclosures** under the calculator, so the answer stays near the top. Tables too wide for a phone become labelled, keyboard-focusable scroll areas, which fixed an axe violation found in Wave 5.
- **Charts:**
  - Only two charts: principal vs interest (EMI) and invested vs gains (SIP).
  - Each is a simple bar with a text legend stating every figure.
  - A new `chart-accent` token is used; colour never carries meaning alone.
- **Every result shows:**
  - a plain-language sentence;
  - the working;
  - a note when anything is rounded;
  - for financial tools, what is not covered and the sources, with checked dates.
- **Mode labels were shortened to fit 360 px.** For example, "Discount + extra discount".

## J. SEO

| URL                                          | Title / description       | Canonical                                       | Sitemap | Indexing                                        |
| -------------------------------------------- | ------------------------- | ----------------------------------------------- | ------- | ----------------------------------------------- |
| Twelve published calculator URLs (A)         | Unique, from the registry | Base URL (inputs are only ever in the fragment) | Yes     | index                                           |
| `/finance`, `/salary`, `/math`, `/date-time` | Unique                    | Yes                                             | Yes     | index                                           |
| `/ctc-to-in-hand-salary-calculator`          | Set                       | —                                               | **No**  | **404 in production**; noindex in review builds |
| Notice Period, Experience                    | —                         | —                                               | No      | 404 (planned)                                   |

E2E tests check the sitemap's exact contents, unique titles, canonicals and Open Graph images.

## K. Known issues (honest list)

1. **No CI run and no deployment.** No GitHub or Vercel account is connected. Nothing has run on Vercel.
2. **CTC is unreviewed** and must stay unpublished until a chartered accountant signs off.
3. **SIP default:** the ÷ 12 default overstates value compared with fund-house references (₹99.9 lakh vs ₹92.0 lakh for ₹10,000 a month for 20 years at 12%). Awaiting your decision.
4. **RD part quarters and FD 366-day leap years** are not modelled.
5. **The FD short-deposit default (3 months) follows an RBI circular from 2004.** Several banks use 6 or 12 months.
6. **LCP is about 2.0–2.2s** against a < 2.0s target, and total JS (≈ 145–155 KB) misses the < 90 KB target. Both are dominated by the framework.
7. **Firefox and WebKit untested.** No manual screen-reader (TalkBack or VoiceOver) session has been run. Only automated axe checks have been done.
8. **Lender and bank rounding** (EMI to the rupee, interest rounding) is not modelled. Pages say figures may differ by a few rupees.
9. **EMI typing latency** is 112–144ms in the lab (4× CPU). It is under target, but it is the highest on the site, because closed schedule tables are re-rendered on every keystroke.
10. **The homepage heading "Popular tools"** (a Phase 4 rule once there is more than one tool) implies usage data the site does not have yet. The featured list is hand-picked, so a neutral heading such as "Start here" would be more accurate. This is a small copy change, not made in this phase.
11. **Draft legal pages** (About, Contact, Privacy, Terms, Disclaimer) still need the owner's name, a contact email and legal review.

## L. Deviations from the brief and from Phases 1–4

1. **Share links use the URL fragment (`#k=v`)** instead of the brief's `?amount=` example. This is a privacy fix: query strings were sent to the server. Old `?` links are still read.
2. **The SIP monthly rate offers two methods.** Phase 1 proposed ÷ 12 as the default "to be validated". Validation found that the fund-house references use the compounded monthly equivalent. The default is kept as ÷ 12 pending your decision.
3. **The RD calculator accepts whole quarters only**, applying the brief's "stop if uncertain" rule.
4. **GST special rates (3%, 0.25%) are not presets**, because they were not confirmed from a primary source. "Other rate" covers them.
5. **CTC**, as required, is withheld rather than published.
6. **Eight tools are now marked featured** and appear on the homepage and the 404 page. With Finance live, the "Coming soon" category state no longer appears on the homepage.
7. **Phase 4 tests were updated** where they assumed empty categories or planned tools that are now live.
8. **Design system:** added the `chart-accent` token, the Checkbox, DateInput, DisclosureTable and ProportionBar components, and a `chart` slot on ResultPanel. All are documented in `docs/design-system.md` (the new components are described in their source headers).

## M. Recommended Phase 6

Based on the current state, in this order:

1. **Connect GitHub and Vercel, run CI** (Chromium, Firefox, WebKit) and deploy a preview. Check real-device Core Web Vitals.
2. **Owner decisions:**
   - the SIP default method;
   - the JS budget (≤ 30 KB page-specific);
   - FD short-deposit default;
   - legal page details.
3. **CTC review:** engage a chartered accountant with `docs/reviews/ctc-to-in-hand.md`, then publish through the documented steps.
4. **Trust and analytics:** Search Console, a privacy-respecting analytics set-up consistent with the privacy page, and a "Report a problem" link per calculator.
5. **Manual accessibility pass** with TalkBack and VoiceOver.
6. **Only then add more tools** (Notice Period, Experience), reusing the date engine. Revisit LCP if field data shows it above 2.5s.

Phase 6 has not been started.
