# Phase 3 report: Design System and UI

Date: 2026-10-07. Every number below comes from runs in the build environment on that
date. Nothing is estimated, and no manual testing is claimed that was not done.

## A. Design decisions

The visual direction is a quiet, practical tool with one strong element: **the
answer**. On every tool page the result is a large number in tabular figures with the
plain-language sentence and the worked equation beneath it, on a soft green panel with
a dark green top rule, like a calculation slip. Everything else (header, inputs,
explanation) is neutral, bordered rather than shadowed, and left-aligned.

- **One accent colour.** A deep "ledger" green (`#0B5D4B`) is used only for actions,
  links, focus and the result. It reads as trustworthy and calm, not as a trading or
  sales site. Status colours appear only when they mean something.
- **System font only.** No downloads, no font-swap layout shift, native rendering of ₹
  and Indian digit grouping. Numbers use tabular figures so they line up.
- **Sentence case everywhere.** No all-caps labels, no decorative eyebrows.
- **Desktop is not a stretched phone.** From 1024px the calculator puts inputs and
  result side by side, and the explanation gets an "On this page" sidebar. The page is
  capped at 1152px and text at 42rem.
- **Instant results (option B).** Results update as soon as both values are valid.
  Errors appear immediately only for characters that can never be valid (letters,
  symbols). Half-typed values such as "-" or "." are flagged only after leaving the
  field. Screen readers hear the result once, 750ms after typing pauses. A Calculate
  button would add a tap and hide the relationship between inputs and answer, for no
  benefit on a calculation this cheap.
- **Dark mode deferred** (reasons in `docs/design-system.md` §5). Tokens are semantic,
  so adding it later is a second set of token values, not a component rewrite.

## B. Design system

Full specification: `docs/design-system.md`. Tokens: `src/app/globals.css`.

**Colour** (all text pairs measured ≥ 4.5:1)

| Token                                                     | Value                                      |  Contrast on white |
| --------------------------------------------------------- | ------------------------------------------ | -----------------: |
| canvas / surface                                          | `#F4F6F8` / `#FFFFFF`                      |                  — |
| ink (text)                                                | `#16202A`                                  |             16.5:1 |
| muted                                                     | `#4A5563`                                  |              7.6:1 |
| line / line-strong                                        | `#D5DBE1` / `#6B7684`                      | decorative / 4.6:1 |
| primary / hover / active                                  | `#0B5D4B` / `#084A3C` / `#063A2F`          |  7.8 / 10.2 / 12.7 |
| primary-soft (result background)                          | `#E7F2EE`                                  |   ink on it 14.4:1 |
| success, warning, error, info (on their soft backgrounds) | `#1C6B3A`, `#8A4B00`, `#B42318`, `#1F4F99` | 5.9, 6.2, 5.9, 7.0 |

Tailwind's default palette, shadows, radii and breakpoints are removed, so only these
tokens can be used.

**Typography**: H1 28/36px, H2 22/24px, H3 17px, body 16px, small 14px, label 16px
semibold, helper 14px muted, result 40/48px bold tabular, table 15px. Inputs 18px.

**Spacing**: 4px base; allowed steps 4, 8, 12, 16, 24, 32, 48, 64px.

**Radius**: 6px (badges, code), 8px (inputs, buttons), 12px (cards, calculator).

**Shadow**: one token, overlays only (search and menu panels).

**Breakpoints**: two, `md` 768px and `lg` 1024px.

## C. Components created

| Area         | Components                                                                                                                                                 |
| ------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Layout       | `Container`, `Section`, `ToolPage` (standard tool-page template), `CalculatorFrame`                                                                        |
| Navigation   | `SiteHeader`, `HeaderPanels` (search and menu, one at a time), `Breadcrumb`, `SiteFooter`                                                                  |
| Search       | `SearchBox` (registry search, results as links, live result count)                                                                                         |
| Form         | `NumberInput` (label, helper, prefix/suffix unit, error, disabled), `SelectInput`, shared `FieldShell`                                                     |
| Actions      | `Button` and `ButtonLink` (`primary`, `secondary`, `ghost`; `md` 44px, `lg` 48px), `ShareButton`                                                           |
| Content      | `Card`, `ResultPanel` (result, empty, invalid, error states; amount in words; summary rows; actions), `Callout` (info, warning, error, success), `FaqList` |
| Data         | `DataTable` (caption, row headers, numeric columns, explicit scroll region for wide tables), `SummaryList`                                                 |
| Other        | `AdSlot` (development placeholder only), `LiveAnnouncer`, inline `icons`                                                                                   |
| Error states | 404 page (doubles as "tool unavailable", with search and available tools), `error.tsx` generic error page                                                  |

Deliberately not created: `PageShell`, `Stack`, `Grid` (Tailwind utilities say the same
thing), separate `Label`/`HelperText`/`ErrorMessage` exports, `SecondaryButton` (a
variant), `InfoBox`/`WarningBox` (tones of `Callout`), a chart container (no chart
exists yet; style and accessibility rules are documented instead).

Pure logic added to the library, with unit tests: `src/lib/tools/search.ts` and
`src/lib/share/share.ts` (share sheet, then clipboard, then a clear message).

## D. Percentage Calculator UX

Breadcrumb, H1 and a one-line description, then the calculator card: "What do you want
to calculate?" (native select, 5 options), two labelled inputs with units, and the
result directly below (phones) or beside (desktop). The result shows "Your result" (or
"Your result: a decrease" with a down arrow), the number, the sentence, the working,
"Rounded to 2 decimal places. Exact value: …" when rounded, extra rows such as "Amount
added", and a Share button. Each option opens with a worked example so there is always
an answer on first load. Below: the reserved ad position (empty in production), "How it
is calculated", a worked-examples table, a "Things that often catch people out"
section with callouts, FAQs as disclosures, and review and disclaimer details.

At 360 × 800 the whole result, including the Share button, is visible without
scrolling (an automated test enforces this).

## E. Responsive QA

Screenshots of every width are in `phase3-screenshots` (delivered with this report).
Horizontal overflow was measured on both pages at each width.

| Width      | Horizontal overflow | Notes                                                                                                                                                            |
| ---------- | ------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 360 (×800) | 0px, both pages     | Result and Share button above the fold. Breadcrumb shortened to one line (category hidden below 768px). Menu and search panels overlay without shifting content. |
| 390 (×844) | 0px                 | Same layout, more room.                                                                                                                                          |
| 412 (×915) | 0px                 | Simulated on-screen keyboard (412 × 420 viewport): focused field stays visible, no overflow (automated test).                                                    |
| 768        | 0px                 | Inputs side by side in one row; result full width below; tool cards in two columns.                                                                              |
| 1024       | 0px                 | Inputs and result side by side; "On this page" sidebar; inline header links.                                                                                     |
| 1280       | 0px                 | Same as 1024, content capped at 1152px; each input at most 560px wide (enforced by a test).                                                                      |

Visual QA findings that were fixed during the phase:

1. Result sentence fell below the fold at 360 × 800: shortened the description,
   hid the breadcrumb category on phones, and tightened field spacing.
2. Inline formulas fell back to a monospace font (a second family): now the body font
   with tabular figures.
3. The homepage promised "Nothing is sent, stored or tracked". "Tracked" would become
   untrue once analytics arrive (Phase 9), so it now says "Nothing you type is sent or
   stored".

## F. Accessibility

Automated (all passing):

- axe-core, WCAG 2.0/2.1/2.2 A and AA rules, on mobile and desktop Chrome: homepage;
  calculator in default, field-error and calculation-error states; open menu; open
  search with results; 404 page. **0 violations.**
- Lighthouse accessibility 100 on both pages.
- Keyboard: tab order, select, inputs, FAQ disclosures with Enter, Escape closes header
  panels and returns focus to the button that opened them.
- Live region announces "25% of 80 is 20." after typing pauses (not per keystroke).
- Touch targets: every header button, field, select, button, FAQ summary and footer
  link measured ≥ 44 × 44px.
- Errors: `aria-invalid`, message linked by `aria-describedby`, icon plus text, 2px
  border (never colour alone). Increase/decrease shown with an arrow and a word.
- Contrast of every token pair computed (section B).

Manual: **not done.** No TalkBack (Android) or other screen-reader session was run;
this environment has no Android device or screen reader. This remains open (L).

## G. Performance

Lighthouse 13.5, mobile profile, simulated throttling (150ms RTT, 1.6 Mbps, 4× CPU),
local production server. Phase 3: median of 7 runs (tool page) and 3 runs (homepage).

| Metric                                             | Phase 2 tool page |     Phase 3 tool page | Phase 3 homepage | Target                                       |
| -------------------------------------------------- | ----------------: | --------------------: | ---------------: | -------------------------------------------- |
| Lighthouse performance                             |                99 |            98 (97–99) |               99 | 90+ ✔                                        |
| Accessibility / Best practices / SEO               |   100 / 100 / 100 |       100 / 100 / 100 |  100 / 100 / 100 |                                              |
| LCP (simulated)                                    |             1.91s | **2.06s** (1.61–2.26) |            1.79s | < 2.0s: **missed on the tool page by 0.06s** |
| FCP                                                |             0.78s |                 0.78s |            0.77s |                                              |
| CLS                                                |                 0 |                     0 |                0 | < 0.05 ✔ (also 0 with ad placeholders on)    |
| Total blocking time                                |              91ms |                 102ms |             95ms |                                              |
| Worst interaction, 4× CPU throttle (lab INP proxy) |              64ms |      56–72ms (3 runs) |                — | < 200ms ✔ in lab                             |
| JavaScript (gzip)                                  |          141.2 KB |              146.7 KB |         146.7 KB | < 90 KB ✘ (framework ≈ 137 KB)               |
| CSS (gzip)                                         |            3.9 KB |                5.6 KB |           5.6 KB |                                              |
| HTML (gzip)                                        |            5.8 KB |                9.4 KB |           6.0 KB |                                              |
| Total transfer                                     |          154.5 KB |              166.5 KB |         169.4 KB |                                              |

Why it got slightly worse, exactly:

- **+5.5 KB JavaScript on every page**: the header island (search panel, menu, tool
  registry for search; ≈ 9.1 KB chunk including shared link code) and the Share button
  (≈ 1 KB) on tool pages; the calculator's own chunk is now 5.0 KB.
- **+3.6 KB HTML** on the tool page: more content (worked-examples table, callouts,
  FAQs, sidebar).
- **+1.7 KB CSS**: new components.
- **LCP**: the largest element is the intro paragraph, which actually paints about
  150ms after the server responds. Lighthouse's simulation counts JavaScript downloads
  that start before that paint, so its LCP estimate lands at either about 1.6s or about
  2.05s from run to run; with slightly more JavaScript, more runs land on the higher
  value. The real lever is the ≈ 137 KB of framework JavaScript (the open budget
  decision from Phase 2).

Optimisations tried and measured:

| Attempt                                                  | Result                                                                                                                                   | Kept? |
| -------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------- | ----- |
| Replace the `lucide-react` package with inline SVG icons | −0.9 KB JS, one dependency removed                                                                                                       | Yes   |
| Inline the CSS into the HTML (`experimental.inlineCss`)  | LCP median 1.88s, but FCP worse (0.92s), +17 KB per page (CSS duplicated in the HTML and framework payload), not cacheable, experimental | No    |
| Load the header search code only when opened             | +2 KB JS (lazy-loading overhead), no LCP improvement beyond noise                                                                        | No    |

## H. Dependencies

No new runtime or development dependencies at the end of the phase. `lucide-react` was
added, measured and then removed in favour of inline SVG using Lucide's icon shapes
(ISC licence, attribution in `src/components/ui/icons.tsx`).

## I. Screenshots

Delivered as `phase3-screenshots.zip`: tool page and homepage at 360, 390, 412, 768,
1024 and 1280px (first screen, plus full pages at 360 and 1280); states: decrease
result, field error, calculation error, empty, menu open, search open, keyboard focus.

## J. Tests (actual counts)

| Suite                                           |                         Count | Result                                                                                                                                                       |
| ----------------------------------------------- | ----------------------------: | ------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Unit and property tests (Vitest)                |                           164 | Pass (was 150; +7 search, +7 share)                                                                                                                          |
| Fixture verification (Python, exact arithmetic) |                            64 | Pass                                                                                                                                                         |
| Playwright e2e, mobile and desktop Chrome       | 104 run, 30 skipped by design | Pass                                                                                                                                                         |
| of which accessibility (axe) tests              |         5 per browser profile | Pass, 0 violations                                                                                                                                           |
| New design-system e2e tests                     |                15 per profile | Pass: menu, search, breadcrumb, share/clipboard, FAQ keyboard, table semantics, sidebar, ad slot absent, 404 state, keyboard viewport, above-the-fold result |
| Typecheck, ESLint, Prettier                     |                             — | Pass, 0 warnings                                                                                                                                             |
| Production build                                |                             — | Pass; all routes static                                                                                                                                      |
| GitHub Actions CI                               |                             — | **Not run**: no GitHub repository (L)                                                                                                                        |
| Firefox, desktop WebKit, iPhone WebKit          |                             — | **Not run locally**: browser downloads are blocked in this environment; configured to run in CI                                                              |

Skipped tests are deliberate: viewport-width tests run once on desktop, keyboard-only
tests on desktop, and phone-only tests (menu button, keyboard viewport) on the mobile
profile.

## K. Deviations from Phase 1 and Phase 2

| Deviation                                                                                                            | Reason                                                                                                                                                            |
| -------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Lucide icons inlined instead of the `lucide-react` package                                                           | Same icons, less JavaScript, one fewer dependency (G).                                                                                                            |
| Increase/decrease result shows the magnitude with an arrow and "a decrease" in the label, instead of "↓ 16.67%" text | Icon arrows are clearer and consistent with the icon set; meaning still carried by words.                                                                         |
| Breadcrumb category ("Math & Everyday") is plain text, and hidden below 768px                                        | No category hub pages exist yet (Phase 4); no dead links. Hidden on phones to keep the trail on one line.                                                         |
| Footer trust and legal links (About, Privacy, Terms, Disclaimer, Methodology, Contact) are configured but not shown  | The pages don't exist yet; linking them would create 404s. Each appears automatically when its `published` flag is set.                                           |
| Share button shares the result sentence and page URL, not the inputs                                                 | Shareable input URLs need URL state; deferred to avoid a content flash on static pages. The share API already takes a URL, so only the URL builder changes later. |
| Dark mode deferred                                                                                                   | Documented in `docs/design-system.md` §5.                                                                                                                         |
| Calculator mode selector stays a native select, not a segmented control                                              | Five options do not fit a segmented control at 360px; native select uses the phone's own picker.                                                                  |
| "Vercel preview" and "CI passes" (assumed done by this phase's brief)                                                | Not done in Phase 2 or 3: no GitHub or Vercel account is connected to this session.                                                                               |

## L. Known issues

1. **No GitHub repository, CI run or Vercel preview yet.** Needs your accounts.
2. **No manual screen-reader test (TalkBack).** Needs a real Android device.
3. **Firefox and Safari engines untested locally**; they run in CI once it exists.
   Real iOS Safari and real Chrome on Android have not been tested on devices.
4. **Tool-page LCP 2.06s (simulated) vs 2.0s target**, and **JavaScript 146.7 KB vs
   90 KB**. Both trace to framework JavaScript; needs the budget decision.
5. **Android minus key**: many `inputmode="decimal"` keyboards have no minus key.
   Negative values are rare for this tool and work by paste or on desktop; a ± toggle
   was not added because it is an extra control for a rare case. Revisit with the first
   tool where negatives are common.
6. **Desktop homepage has generous empty space on the right** at 1280px because there is
   only one tool; it will fill as tools are added.
7. **The search field shows the browser's own clear (×) button** in Chrome, styled by
   the browser rather than the design system. Harmless; can be restyled later.

## M. Recommendation

Before Phase 4, unblock the two outstanding items: connect GitHub (so CI runs on all
four browser engines) and Vercel (preview URL), and decide the JavaScript budget.

Then **Phase 4: Homepage and Navigation**: category hub pages (`/math`, …) so
breadcrumbs link to them; the trust and legal pages the footer is waiting for (About,
Methodology, Privacy, Terms, Disclaimer, Contact); `/tools` A–Z index; and URL-based
shareable results if you want them before Phase 5. Phase 4 has not been started.
