# Phase 2 report: Project Foundation and Percentage Calculator

Date: 2026-10-07. All numbers below come from runs in the build environment on that
date; nothing is estimated.

## A. What was built

- Next.js 16.4 App Router project, React 19.3, TypeScript 6.0 in strict mode (plus
  `noUncheckedIndexedAccess`, `exactOptionalPropertyTypes`, `noImplicitOverride`)
- Tailwind CSS 4 with a small set of design tokens (all text colours ≥ 4.5:1 contrast)
- ESLint 9 with `eslint-config-next` and a custom rule that fails the build if
  `src/lib` imports React, Next.js or UI code, or uses browser globals (verified by a
  deliberate violation)
- Prettier, pnpm 10.28 (pinned via `packageManager`), exact dependency versions
- Isolated calculation library: percentage functions, shared result type, input guard
- Validation layer (text → number) and formatting layer (number → Indian-grouped text)
- Specification `docs/specs/percentage-calculator.md`
- Hand-derived fixtures `tests/fixtures/percentage.json` plus an independent Python
  verifier using exact rational arithmetic
- Unit, boundary, regression and property tests (Vitest + fast-check)
- Percentage Calculator page (`/percentage-calculator`) with 5 modes, live results,
  inline validation, explanation, worked examples and FAQs
- Minimal homepage, header, footer, breadcrumb, 404 page, favicon
- Tool registry driving the homepage list, page metadata and sitemap
- Basic SEO: title, description, canonical, Open Graph, `lang="en-IN"`, robots.txt,
  sitemap.xml
- Playwright tests: user flows, errors, keyboard, axe accessibility, 6 viewport widths,
  SEO tags, privacy (no network calls, no storage, first-party only)
- GitHub Actions CI workflow
- README with architecture, commands and an "add a new calculator" guide

## B. Important files

| File                                     | Purpose                                                          |
| ---------------------------------------- | ---------------------------------------------------------------- |
| `docs/specs/percentage-calculator.md`    | Source of truth: formulas, ranges, zero/negative rules, rounding |
| `src/lib/calc/result.ts`                 | `CalcResult` type, ±10¹² input guard, -0 and Infinity protection |
| `src/lib/calc/percentage/percentage.ts`  | The five pure calculation functions                              |
| `src/lib/calc/percentage/modes.ts`       | Mode definitions (labels, examples) wired to the functions       |
| `src/lib/validation/parse-number.ts`     | Parses typed text, accepts `1,25,000` and `−`, rejects `1e5`     |
| `src/lib/format/number.ts`               | The only rounding: 2 dp, significant digits for tiny values      |
| `src/lib/tools/registry.ts`              | Tool registry (Percentage Calculator only)                       |
| `src/lib/tools/metadata.ts`              | Builds title, description, canonical, Open Graph per tool        |
| `src/components/calculator/*`            | Calculator UI, result panel, debounced screen-reader announcer   |
| `src/app/percentage-calculator/page.tsx` | Tool page (server component) with explanation content            |
| `tests/fixtures/percentage.json`         | 64 hand-derived vectors (calculation, parsing, formatting)       |
| `scripts/verify-fixtures.py`             | Re-derives fixtures with exact fractions, independent of TS code |
| `eslint.config.mjs`                      | Includes the calculation-library isolation rule                  |
| `.github/workflows/ci.yml`               | CI pipeline                                                      |

## C. Architecture

UI (text state) → `parseNumberInput` (number or typed error) → calculation function
(`CalcResult` with full precision) → `formatNumber` (rounded display text plus an
`isRounded` flag) → UI. Calculation functions re-validate their inputs, so they are
safe to call from a future API without the UI. See README, "Architecture".

## D. Testing (actual counts)

| Suite                                | Tests | Result                                                                                                                                  |
| ------------------------------------ | ----: | --------------------------------------------------------------------------------------------------------------------------------------- |
| Unit: percentage calculations        |    96 | Pass                                                                                                                                    |
| Unit: input parsing                  |    26 | Pass                                                                                                                                    |
| Unit: formatting                     |    19 | Pass                                                                                                                                    |
| Property tests (fast-check)          |     9 | Pass (2,000 to 5,000 random cases each)                                                                                                 |
| Fixture verification (Python, exact) |    64 | Pass                                                                                                                                    |
| Playwright e2e, mobile + desktop     |    70 | Pass (20 skipped by design: viewport-width and keyboard tests run on desktop only)                                                      |
| of which axe accessibility tests     |     6 | Pass: 16 page scans (default, field error and calculation error states, homepage), 0 violations against WCAG 2.0/2.1/2.2 A and AA rules |
| Production build                     |     — | Pass, no warnings; all 5 routes static                                                                                                  |
| Typecheck, ESLint, Prettier          |     — | Pass, 0 errors, 0 warnings                                                                                                              |

Bugs found during the phase, both now permanent tests:

1. **Fixture error** (caught by the Python verifier): a vector used an input of
   1,000,000,000,001, which is above the ±10¹² limit. Corrected to 999,999,999,999.
2. **Wrong error code on overflow** (caught by a property test): a percentage change
   from 5 × 10⁻³²⁴ overflows to −Infinity. The code already blocked Infinity but
   reported `NOT_A_NUMBER`. Added `RESULT_TOO_LARGE` with its own message, updated the
   spec, and added a regression test.

## E. CI

On every pull request and push to `main`: frozen-lockfile install, typecheck, ESLint,
Prettier check, unit and property tests, Python fixture verification, production
build, then (second job, using the build) Playwright on mobile and desktop Chrome with
axe. The workflow has not yet run on GitHub because no repository exists yet (see H).

## F. Deployment

Not yet done; needs your GitHub and Vercel accounts (see H). The production build that
Vercel would run passes locally, and the app was served with `next start` for all
tests and measurements.

## G. Performance baseline

Lighthouse 13.5, mobile profile, simulated throttling (150 ms RTT, 1.6 Mbps, 4× CPU
slowdown), local production server, median of 3 runs.

| Metric                                                                |    Calculator page | Homepage | Phase 1 target | Status                        |
| --------------------------------------------------------------------- | -----------------: | -------: | -------------- | ----------------------------- |
| Lighthouse performance                                                |                 99 |      100 | 90+            | Met                           |
| Lighthouse accessibility                                              |                100 |      100 | —              |                               |
| Lighthouse best practices                                             |                100 |      100 | —              |                               |
| Lighthouse SEO                                                        |                100 |      100 | —              |                               |
| LCP                                                                   | 1.91 s (1.61–1.91) |   1.89 s | < 2.0 s        | Met, with little margin       |
| CLS                                                                   |                  0 |        0 | < 0.05         | Met                           |
| Total Blocking Time                                                   |              91 ms |    51 ms | (INP proxy)    |                               |
| Worst interaction (lab INP proxy, 4× CPU throttle, Pixel 7 emulation) |              64 ms |        — | INP < 200 ms   | Met in lab; field data needed |
| JavaScript transferred (gzip)                                         |             141 KB |   141 KB | < 90 KB        | **Missed**                    |
| Total page weight                                                     |             155 KB |   157 KB | —              |                               |

Why the JavaScript budget is missed: the calculator's own code is about 3.6 KB gzip.
The remaining ~137 KB is the Next.js App Router and React 19 runtime that every page
loads (two chunks of 72 KB and 46 KB). No project change can remove it while keeping
the approved stack; Vercel's Brotli compression will reduce it somewhat. Options are
listed under I.

INP is a field metric and cannot be measured in a lab; the figure above is the longest
event duration recorded while tapping and typing under 4× CPU throttling.

## H. Known issues and remaining work

1. **GitHub repository not created.** No GitHub account is connected to this session.
   The project is committed locally on `main` and delivered as a zip.
2. **Vercel preview not deployed.** Requires connecting the repository in your Vercel
   account. Then verify the preview against the Phase 2 checklist.
3. **CI not yet run on GitHub.** It will run on the first push. The action versions
   (`actions/checkout@v4` and others) could not be checked against the latest
   releases from here; bump them on first push if newer majors exist.
4. **JavaScript budget missed** (see G); needs a decision.
5. **Minus key on Android:** `inputmode="decimal"` keyboards on many Android phones
   have no minus key. Negative values work by paste, desktop or keyboards that show
   it. Revisit in Phase 3 (for example a "±" toggle) if negative inputs matter.
6. **Calculator needs JavaScript to recalculate.** Without JavaScript the page shows
   the worked example and all explanations, but typing does nothing.
7. **Local Playwright used Chromium 141** (pre-installed) rather than the version
   pinned by Playwright 1.63. CI installs the matching browser.
8. **Brand name and domain are placeholders** (`src/config/site.ts`); canonical URLs
   use `NEXT_PUBLIC_SITE_URL`, which must be set in Vercel for production.
9. **Manual screen-reader pass** (TalkBack) has not been done; automated axe checks
   and live-region tests pass.

## I. Deviations from Phase 1

| Change                                                       | Why                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| ------------------------------------------------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| TypeScript 6.0.3 instead of the newest 7.0.2                 | `typescript-eslint` (used by `eslint-config-next`) supports TypeScript < 6.1 only.                                                                                                                                                                                                                                                                                                                                                      |
| ESLint 9 instead of 10                                       | `eslint-config-next` plugins are built against ESLint 9.                                                                                                                                                                                                                                                                                                                                                                                |
| `src/app/` instead of root `app/`                            | Keeps all application code under `src/`; supported by Next.js.                                                                                                                                                                                                                                                                                                                                                                          |
| Increase and decrease are one mode, "% increase or decrease" | The user does not need to know the direction in advance; avoids an error state. Both spec cases C and D are covered and tested.                                                                                                                                                                                                                                                                                                         |
| No `src/lib/dates/` folder yet                               | Brief: no folders that are not currently useful. Created with the first date tool.                                                                                                                                                                                                                                                                                                                                                      |
| No Lucide yet                                                | No icon is needed yet; adding the package now would be an unused dependency.                                                                                                                                                                                                                                                                                                                                                            |
| No structured data yet                                       | Brief allows deferring; the page has no element that needs it for rich results today. `BreadcrumbList` and `WebApplication` come in the SEO phase.                                                                                                                                                                                                                                                                                      |
| No shareable result URLs                                     | Phase 1 differentiator, not in Phase 2 scope. Canonical tags already exclude query strings so it can be added safely.                                                                                                                                                                                                                                                                                                                   |
| JavaScript budget of 90 KB                                   | Not achievable with the approved Next.js stack (framework alone ≈ 137 KB gzip). Proposed: keep Lighthouse 90+, LCP, CLS and INP as hard gates and redefine the JS budget as "≤ 30 KB gzip of page-specific JavaScript on top of the framework". The alternative, a lighter framework (for example Astro with small interactive islands), would be an architecture change and is not recommended at this stage. **Needs your decision.** |

## J. Recommended Phase 3 (not started)

Design System and UI: confirm the visual direction and brand, finalise tokens (colour,
type scale, spacing, dark mode decision), build the remaining primitives the first
calculator suite needs (segmented control, slider with numeric input, result table,
chart container, toggle), define the standard tool-page template from Phase 1
section 4 as a reusable layout, solve the Android minus-key issue, add Lucide when
the first icon is needed, and run a manual TalkBack pass.
