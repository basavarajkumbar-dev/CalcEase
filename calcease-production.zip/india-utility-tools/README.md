# CalcEase

> Simple calculations. Clear decisions.

Free, mobile-first calculators for everyday money, work and dates in India, at
**https://calculatorfordailyuse.com**. Every result shows its working; calculations run
entirely in the browser.

| Category        | Calculators                                                                                                                                                 |
| --------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Finance         | Compound Interest, EMI, FD, Lumpsum, RD, SIP                                                                                                                |
| Salary & Career | Experience, Notice Period, Percentage Hike, Salary Budget Planner; CTC to In-Hand is **under review** (not published; see `docs/reviews/ctc-to-in-hand.md`) |
| Math & Everyday | Calculator, Discount, GST, Percentage                                                                                                                       |
| Date & Time     | Age, Date Add / Subtract, Date Difference                                                                                                                   |

Trust pages: `/methodology` is published; `/about`, `/contact`, `/privacy`, `/terms` and
`/disclaimer` are drafts marked noindex until the owner's details and legal review are
added (`src/config/site.ts`).

UI rules, tokens and components are documented in
[`docs/design-system.md`](docs/design-system.md). Specifications for every calculator
are in [`docs/specs/`](docs/specs/).

## Tech stack

| Area            | Choice                                                                                       |
| --------------- | -------------------------------------------------------------------------------------------- |
| Framework       | Next.js 16 (App Router), React 19, every page statically rendered                            |
| Language        | TypeScript 6, strict mode plus extra strictness flags                                        |
| Styling         | Tailwind CSS 4; semantic design tokens in `src/app/globals.css`                              |
| Icons           | Lucide designs as inline SVG (`src/components/ui/icons.tsx`)                                 |
| Unit tests      | Vitest, with fast-check for property-based tests                                             |
| End-to-end      | Playwright with axe-core: Chrome (mobile and desktop) locally; plus Firefox and WebKit in CI |
| Lint / format   | ESLint 9 (`eslint-config-next`), Prettier                                                    |
| Package manager | pnpm 10 (version pinned in `package.json`)                                                   |
| CI              | GitHub Actions                                                                               |
| Hosting         | Vercel (static output, portable to any static host)                                          |

There is no database, no API route, no authentication, no analytics and no
advertising. Calculations run entirely in the browser.

## Requirements

- Node.js 22 (see `.nvmrc`)
- pnpm 10 (`corepack enable` installs the pinned version)
- Python 3.8+ (only for `pnpm test:fixtures`, the independent fixture check)

## Getting started

```bash
corepack enable
pnpm install
pnpm dev            # http://localhost:3000
```

## Commands

| Command              | What it does                                                         |
| -------------------- | -------------------------------------------------------------------- |
| `pnpm dev`           | Development server with hot reload                                   |
| `pnpm build`         | Production build (static pages in `.next`)                           |
| `pnpm start`         | Serve the production build                                           |
| `pnpm typecheck`     | TypeScript type check, no output files                               |
| `pnpm lint`          | ESLint, including the calculation-library isolation rule             |
| `pnpm format`        | Format everything with Prettier                                      |
| `pnpm format:check`  | Fail if anything is not formatted                                    |
| `pnpm test`          | Unit and property tests (Vitest)                                     |
| `pnpm test:fixtures` | Re-derive every test fixture with exact rational arithmetic (Python) |
| `pnpm test:e2e`      | End-to-end, accessibility, responsive and SEO tests (needs a build)  |
| `pnpm check`         | Everything above except build and e2e, as CI runs it                 |

First-time Playwright setup: `pnpm exec playwright install chromium`. On a machine
with a Chromium already installed, set `PLAYWRIGHT_CHROMIUM_PATH` to its executable.
To also run Firefox, desktop Safari (WebKit) and iPhone (WebKit), install them with
`pnpm exec playwright install firefox webkit` and set `PLAYWRIGHT_ALL_BROWSERS=1`.

## Environment variables

| Variable                           | Purpose                                                                                                                                                                       |
| ---------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `NEXT_PUBLIC_SITE_URL`             | Optional override of the site origin used for canonical URLs, Open Graph, the sitemap and robots.txt. Default: `https://calculatorfordailyuse.com`. Not needed in production. |
| `ENABLE_UNDER_REVIEW_TOOLS`        | Set to `1` (build time) only for reviewer builds: renders tools under review (CTC), noindex. Never set in production.                                                         |
| `NEXT_PUBLIC_SHOW_AD_PLACEHOLDERS` | Set to `1` (build time) to show labelled placeholders where ads will go, for layout testing. Never set in production.                                                         |

## Project structure

```
docs/design-system.md          UI source of truth: tokens, type, spacing, components, accessibility
docs/specs/                    Calculation specifications (source of truth for formulas)
scripts/verify-fixtures.py     Independent check of test fixtures with exact arithmetic
scripts/og-image-source.tsx    Source of public/og-image.png (the share image); see the file for how to regenerate
src/
  app/                         Next.js routes: pages, layout, 404, error, robots.txt, sitemap.xml
  components/
    ads/                       AdSlot: reserved ad position (placeholder only, no ad code)
    discovery/                 ToolCard, CategoryCard, CategoryNavList, CategoryHub
    calculator/                CalculatorFrame, ResultPanel, LiveAnnouncer, PercentageCalculator
    content/                   FaqList
    layout/                    Header (+ menu/search panels), footer, container, section, breadcrumb
    search/                    SearchBox (client-side search over the tool registry)
    tool/                      ToolPage template, RelatedTools
    ui/                        NumberInput, SelectInput, Button, ShareButton, Callout,
                               DataTable, SummaryList, Card, icons
  config/site.ts               Site name, tagline, URL and trust/legal page list (draft/published)
  seo/                         pageMetadata(): title, description, canonical, Open Graph, noindex
  lib/                         Pure TypeScript: no React, no Next.js, no browser APIs
    calc/                      Calculations; one folder per tool
      result.ts                Shared result type, input range guard
      percentage/              Percentage functions and mode definitions
    validation/                Text input → number (parsing, range checks)
    format/                    Number → display text (the only place rounding happens)
    tools/                     Tool registry (single source of truth) and search
    share/                     Share-or-copy logic (Web Share API, clipboard fallback)
tests/
  fixtures/                    Hand-derived test vectors (JSON)
  unit/                        Vitest unit tests
  property/                    fast-check property tests
  e2e/                         Playwright tests
```

`src/app` sits inside `src/` (rather than at the root) so all application code lives
in one place; Next.js supports both layouts.

## Architecture

```
User types "1,25,000"
   │
   ▼
UI component (src/components)        holds text state, shows labels and errors
   │  text
   ▼
Validation (src/lib/validation)      parseNumberInput → number, or REQUIRED / NOT_A_NUMBER / OUT_OF_RANGE
   │  number
   ▼
Calculation (src/lib/calc)           pure function → { ok: true, value } or { ok: false, error }
   │  full-precision number
   ▼
Formatting (src/lib/format)          formatNumber → "1,47,500", rounding flag
   │  text
   ▼
UI renders the result and announces it to screen readers
```

### Rules for the calculation library (`src/lib`)

1. Pure TypeScript only. ESLint fails the build if code in `src/lib` imports React,
   Next.js or UI code, or uses browser globals such as `window` or `fetch`.
2. Functions take numbers and return a `CalcResult`. They never throw for bad input,
   and never return `NaN`, `Infinity`, `-0` or formatted strings.
3. No rounding inside formulas. Full precision is kept; rounding happens once, for
   display, in `src/lib/format`.
4. Every input is re-checked (finite, within ±10¹²) even if the UI validated it, so the
   functions are safe to expose later through an API.

## How to add a new calculator

1. **Write the spec** in `docs/specs/<tool>.md`: formulas, inputs and ranges, zero and
   negative behaviour, rounding, error states, examples, edge cases, sources. Get it
   reviewed before writing code. Copy the structure of
   `docs/specs/percentage-calculator.md`.
2. **Write the fixtures** in `tests/fixtures/<tool>.json` from independent sources
   (hand calculation, official examples, spreadsheet functions). Never generate
   expected values by running the code under test. Extend
   `scripts/verify-fixtures.py` (or add a sibling script) to re-derive them.
3. **Implement** pure functions in `src/lib/calc/<tool>/`, returning `CalcResult`.
4. **Test**: unit tests against the fixtures, boundary and error tests, and property
   tests for real mathematical invariants. Any bug found becomes a regression test.
5. **Build the UI** in `src/components/calculator/` from the shared primitives:
   `CalculatorFrame` for the card, `NumberInput`/`SelectInput` for fields, `ResultPanel`
   for every state, `ShareButton` for sharing. Build the page in
   `src/app/<slug>/page.tsx` with the `ToolPage` template and `toolMetadata("<slug>")`.
   Do not add colours, shadows or font sizes outside the design tokens.
6. **Activate** the tool in `src/lib/tools/registry.ts`: change its entry from
   `status: "coming-soon"` to `"active"` and add `title`, `metaDescription`, `related`,
   `featured` and `lastReviewed`. The homepage, category hub (created automatically for
   a category's first active tool), `/tools`, header menus, footer, search, related
   tools and sitemap all pick it up. Unit tests check slugs, ids and related links.
7. **Add e2e tests** in `tests/e2e/` for the main flow and at least one error case.
8. Run `pnpm check && pnpm build && pnpm test:e2e`, then open a pull request.

## Continuous integration

`.github/workflows/ci.yml` runs on every pull request and on pushes to `main`:

1. Install with the frozen lockfile
2. TypeScript typecheck
3. ESLint
4. Prettier check
5. Unit and property tests
6. Independent fixture verification
7. Production build
8. Playwright end-to-end, accessibility, responsive and SEO tests against the build,
   in Chrome (Pixel 7 and desktop), Firefox, desktop WebKit and iPhone WebKit

Protect `main` in GitHub (Settings → Branches) and require both CI jobs to pass, so
broken code cannot be merged.

## Contributor guide

- Branch from `main`, keep pull requests small, and describe what changed and how it
  was tested.
- Never put maths or business rules in React components.
- Never trust a formula or expected value from an AI tool without independent
  verification; cite sources in the spec.
- Add a dependency only when it clearly pays for its maintenance and bundle cost, and
  say why in the pull request.
- Keep pages fast: server components by default, `"use client"` only for the
  interactive part of a tool.
- Accessibility is part of done: visible labels, keyboard operation, errors linked to
  fields, no meaning conveyed by colour alone.

## Deployment (Vercel)

No Vercel-specific code is needed: it is a standard Next.js app.

1. Push this repository to GitHub (repository `calcease`, branch `main`).
2. In Vercel: **Add New → Project → Import** the `calcease` repository. Vercel detects
   Next.js and pnpm (from `pnpm-lock.yaml` and `packageManager`); keep the default build
   command (`pnpm build`) and output settings. No environment variables are required.
3. Deploy, then open the `*.vercel.app` URL and run the smoke test below.
4. **Settings → Domains → Add** `calculatorfordailyuse.com` (and `www.calculatorfordailyuse.com`,
   redirecting to the apex). Vercel shows the DNS records to create at your domain
   registrar; add exactly those, then wait for Vercel to show the domain as valid.
5. Submit `https://calculatorfordailyuse.com/sitemap.xml` in Google Search Console.

### Smoke test after deployment

- Home, `/tools`, `/finance`, `/salary`, `/math`, `/date-time` load without console errors.
- Search "emi" finds the EMI Calculator; Enter opens it.
- Every calculator shows a result with its defaults; change one input and the result updates.
- Spot checks: EMI ₹10,00,000 at 7.25% for 10 years → ₹11,740.10; SIP ₹1,000 × 12 months
  at 12% → ₹12,809.33; GST ₹1,000 + 18% → ₹1,180; Calculator (100+50)×2 → 300.
- `/ctc-to-in-hand-salary-calculator` and `/no-such-page` return the 404 page.
- `/robots.txt` lists `https://calculatorfordailyuse.com/sitemap.xml`; `/sitemap.xml` lists
  only `https://calculatorfordailyuse.com/...` URLs.
- View source of a calculator page: `<link rel="canonical">` is
  `https://calculatorfordailyuse.com/<slug>` and `og:url` matches.
- On a phone (or 360px wide): no sideways scrolling, keypad and inputs fit.
