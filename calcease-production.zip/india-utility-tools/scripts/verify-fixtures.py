#!/usr/bin/env python3
"""Independently re-derive every calculator's test fixtures with exact arithmetic.

Each module in scripts/fixture_checks/ re-implements one calculator's specification in
Python using fractions.Fraction (exact, no floating point), separately from the
TypeScript code, and compares the results with the hand-worked values in
tests/fixtures/. A wrong fixture would otherwise let a wrong implementation pass.

Usage: python3 scripts/verify-fixtures.py
"""

import importlib
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))

# (module in scripts/fixture_checks, fixture file in tests/fixtures)
CHECKS = [
    ("percentage", "percentage.json"),
    ("discount", "discount.json"),
    ("hike", "hike.json"),
    ("gst", "gst.json"),
    ("dates", "dates.json"),
    ("deposits", "deposits.json"),
    ("emi_sip", "emi-sip.json"),
    ("ctc", "ctc.json"),
    ("lumpsum", "lumpsum.json"),
    ("calculator", "calculator.json"),
    ("career", "career.json"),
    ("budget", "budget.json"),
]


def main():
    total = 0
    failures = []
    for module_name, fixture in CHECKS:
        module = importlib.import_module(f"fixture_checks.{module_name}")
        result = module.check(ROOT / "tests" / "fixtures" / fixture)
        total += result.count
        failures += result.failures
        print(f"  {module_name}: {result.count} checks")
    if failures:
        print(f"{len(failures)} fixture value(s) failed independent verification:")
        for failure in failures:
            print("  -", failure)
        sys.exit(1)
    print(f"All {total} fixture checks verified independently (exact fractions; 50-digit decimals for fractional powers).")


if __name__ == "__main__":
    main()
