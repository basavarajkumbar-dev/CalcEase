import { ImageResponse } from "next/og";
import { SITE_NAME, SITE_TAGLINE } from "@/config/site";

/**
 * Source of public/og-image.png, the brand image used when any page is shared.
 *
 * This is NOT a route. It was an `opengraph-image.tsx` file in src/app, but that file
 * convention made Next.js ship ~3.9 KB of extra router code to every page (measured in
 * docs/phase-4-report.md, section I), so the PNG is pre-rendered and committed instead.
 * To change the image: copy this file to src/app/opengraph-image.tsx, run `pnpm build &&
 * pnpm start`, save http://localhost:3000/opengraph-image as public/og-image.png, then
 * move the file back here.
 */
export const alt = `${SITE_NAME}: ${SITE_TAGLINE}`;
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

export default function OpengraphImage() {
  return new ImageResponse(
    <div
      style={{
        width: "100%",
        height: "100%",
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
        background: "#F4F6F8",
        padding: 80,
        borderTop: "16px solid #0B5D4B",
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 24 }}>
        <svg width="88" height="88" viewBox="0 0 32 32">
          <rect width="32" height="32" rx="8" fill="#0B5D4B" />
          <path
            d="M8 13.5h16M10 18.5h12M12.5 23.5h7"
            stroke="#fff"
            strokeWidth="2.6"
            strokeLinecap="round"
          />
          <circle cx="16" cy="8.5" r="2" fill="#fff" />
        </svg>
        <div style={{ fontSize: 48, fontWeight: 700, color: "#16202A" }}>{SITE_NAME}</div>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
        <div style={{ fontSize: 72, fontWeight: 700, color: "#16202A", lineHeight: 1.1 }}>
          {SITE_TAGLINE}
        </div>
        <div style={{ fontSize: 36, color: "#4A5563" }}>
          Finance • Salary • Math &amp; Everyday • Date &amp; Time
        </div>
      </div>
    </div>,
    size,
  );
}
