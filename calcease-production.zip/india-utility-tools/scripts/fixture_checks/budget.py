"""Salary Budget Planner fixtures, with exact fractions, written from the spec."""

import json
import math
from fractions import Fraction

from .common import Checker, exact, frac

DEFAULTS = {"emergencyMonths": 6, "wantsShare": 60, "emergencyShare": 50, "goal": 0}


def plan(raw):
    i = {**DEFAULTS, **raw}
    if i["income"] <= 0:
        return "INCOME_NOT_POSITIVE"
    keys = ["income", "essentials", "emi", "wants", "emergencySavings", "investments", "goal"]
    if any(i[k] < 0 for k in keys):
        return "AMOUNT_NEGATIVE"
    if not 1 <= i["emergencyMonths"] <= 24:
        return "MONTHS_OUT_OF_RANGE"
    if not (0 <= i["wantsShare"] <= 100 and 0 <= i["emergencyShare"] <= 100):
        return "SHARE_OUT_OF_RANGE"
    x = {k: exact(v) for k, v in i.items()}
    inc = x["income"]
    basis = x["essentials"] + x["emi"]
    total = basis + x["wants"]
    surplus = inc - total
    available = max(Fraction(0), surplus)
    target = basis * x["emergencyMonths"]
    shortfall = max(Fraction(0), target - x["emergencySavings"])
    to_em = min(shortfall, available * x["emergencyShare"] / 100) if shortfall > 0 else Fraction(0)
    left = max(Fraction(0), inc - basis)
    ref_wants = left * x["wantsShare"] / 100
    ref_save = left - ref_wants
    ref_em = min(shortfall, ref_save * x["emergencyShare"] / 100) if shortfall > 0 else Fraction(0)
    unallocated = surplus - x["investments"]
    return {
        "totalExpenses": total,
        "surplus": surplus,
        "unallocated": unallocated,
        "expensePercent": total * 100 / inc,
        "savingsInvestPercent": available * 100 / inc,
        "investPercent": x["investments"] * 100 / inc,
        "debtPercent": x["emi"] * 100 / inc,
        "emergency.target": target,
        "emergency.shortfall": shortfall,
        "emergency.coverageMonths": x["emergencySavings"] / basis if basis > 0 else None,
        "suggested.available": available,
        "suggested.toEmergency": to_em,
        "suggested.toInvestments": available - to_em,
        "monthsToEmergencyTarget": Fraction(0) if shortfall == 0 else (Fraction(math.ceil(shortfall / to_em)) if to_em > 0 else None),
        "additionalAvailable": max(Fraction(0), unallocated),
        "monthsToGoal": Fraction(math.ceil(x["goal"] / available)) if x["goal"] > 0 and available > 0 else None,
        "plan.savings": max(Fraction(0), unallocated),
        "reference.wants": ref_wants,
        "reference.savings": ref_em,
        "reference.investments": ref_save - ref_em,
    }


def check(path):
    data = json.loads(path.read_text(encoding="utf-8"))
    c = Checker("budget")
    for case in data["cases"]:
        got = plan(case["inputs"])
        for key, expected in case["expected"].items():
            want = None if expected is None else frac(expected)
            c.equal(f"budget {case['name']} {key}", got[key], want)
    for case in data["invalid"]:
        got = plan(case["inputs"])
        c.error(f"budget invalid {case['inputs']}", got if isinstance(got, str) else None, case["expectedError"])
    return c
