"""Percentage Calculator fixtures (docs/specs/percentage-calculator.md)."""

import json
from decimal import Decimal
from fractions import Fraction

from .common import Checker, exact

MAX_ABS = Fraction(10) ** 12


def compute(mode, inputs):
    try:
        values = {key: exact(value) for key, value in inputs.items()}
    except Exception:
        return "NOT_A_NUMBER"
    if any(abs(v) > MAX_ABS for v in values.values()):
        return "OUT_OF_RANGE"
    if mode == "percentOf":
        return values["percent"] * values["value"] / 100
    if mode == "whatPercent":
        if values["whole"] == 0:
            return "DIVISION_BY_ZERO"
        return values["part"] * 100 / values["whole"]
    if mode == "percentChange":
        if values["from"] == 0:
            return "DIVISION_BY_ZERO"
        return (values["to"] - values["from"]) * 100 / abs(values["from"])
    if mode == "increaseBy":
        return values["value"] + values["value"] * values["percent"] / 100
    if mode == "decreaseBy":
        return values["value"] - values["value"] * values["percent"] / 100
    raise ValueError(mode)


def indian_group(digits):
    if len(digits) <= 3:
        return digits
    head, tail = digits[:-3], digits[-3:]
    groups = []
    while len(head) > 2:
        groups.insert(0, head[-2:])
        head = head[:-2]
    if head:
        groups.insert(0, head)
    return ",".join(groups + [tail])


def check(path):
    data = json.loads(path.read_text(encoding="utf-8"))
    c = Checker("percentage")
    for case in data["cases"] + data["invalidInputs"]:
        label = f"{case['mode']} {case['inputs']}"
        if any(isinstance(v, str) for v in case["inputs"].values()):
            actual = "NOT_A_NUMBER"
        else:
            actual = compute(case["mode"], case["inputs"])
        if "expectedError" in case:
            c.error(label, actual, case["expectedError"])
        else:
            c.equal(label, actual, Fraction(case["expected"]))
    for case in data["formatting"]:
        value = case["value"]
        if float(value).is_integer() and abs(value) >= 1000:
            digits = str(int(Fraction(Decimal(repr(value)))))
            sign = "-" if digits.startswith("-") else ""
            c.equal(f"format {value}", sign + indian_group(digits.lstrip("-")), case["expected"])
    return c
