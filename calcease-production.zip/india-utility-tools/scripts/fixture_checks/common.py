"""Shared helpers for the independent fixture checks (exact arithmetic, no floats)."""

from decimal import Decimal
from fractions import Fraction


def exact(value):
    """A JSON number as the exact decimal it was written as, not its binary float."""
    return Fraction(Decimal(repr(value)))


def frac(text):
    """An expected value written as a decimal string or 'a/b' (the parts may be decimals)."""
    if "/" in text:
        numerator, denominator = text.split("/")
        return Fraction(Decimal(numerator)) / Fraction(Decimal(denominator))
    return Fraction(Decimal(text))


class Checker:
    def __init__(self, name):
        self.name = name
        self.count = 0
        self.failures = []

    def equal(self, label, actual, expected):
        self.count += 1
        if actual != expected:
            self.failures.append(f"{self.name}: {label}: fixture says {expected}, exact arithmetic gives {actual}")

    def error(self, label, actual, expected):
        self.count += 1
        if actual != expected:
            self.failures.append(f"{self.name}: {label}: expected error {expected}, derived {actual}")
