"""EMI and SIP fixtures.

EMI: the published formula gives the EMI; the check then runs the loan month by month
with exact fractions (interest = balance × r; principal = EMI − interest), applies any
prepayment right after the given EMI, and confirms the balance closes at zero and the
totals. SIP: every instalment's own growth to the end, in 50-digit decimals.
"""

import json
from decimal import Decimal, getcontext
from fractions import Fraction

from .common import Checker, exact, frac

getcontext().prec = 50
TOLERANCE = Fraction(1, 10**6)


def close(c, label, actual, expected):
    c.count += 1
    if abs(Fraction(actual) - expected) > TOLERANCE:
        c.failures.append(f"{c.name}: {label}: fixture says {float(expected)}, independent value {float(actual)}")


def emi_run(i):
    p, rate, n = exact(i["principal"]), exact(i["rate"]), i["months"]
    r = rate / 1200
    emi = p / n if r == 0 else p * r * (1 + r) ** n / ((1 + r) ** n - 1)
    balance, interest_total, month = p, Fraction(0), 0
    while balance > 0:
        month += 1
        interest = balance * r
        payment = min(emi, balance + interest)
        interest_total += interest
        balance = balance + interest - payment
        if month == i.get("prepayAfter"):
            balance -= exact(i["prepay"])
        if month > 1000:
            raise RuntimeError("schedule does not close")
    return {"emi": emi, "totalInterest": interest_total, "months": month, "closing": balance}


def sip_run(i):
    p = Decimal(str(i["instalment"]))
    annual = Decimal(str(i["annualReturn"]))
    step = Decimal(str(i["stepUp"])) / 100
    rate = annual / 1200 if i["method"] == "divide12" else (1 + annual / 100) ** (Decimal(1) / 12) - 1
    n = i["years"] * 12
    value = invested = Decimal(0)
    for k in range(1, n + 1):
        instalment = p * (1 + step) ** ((k - 1) // 12)
        invested += instalment
        value += instalment * (1 + rate) ** (n - k + 1)
    return {"value": Fraction(value), "invested": Fraction(invested)}


def check(path):
    data = json.loads(path.read_text(encoding="utf-8"))
    c = Checker("emi_sip")
    for case in data["emi"]:
        got = emi_run(case["inputs"])
        c.equal(f"emi {case['inputs']} closes at zero", got["closing"], 0)
        for key, expected in case["expected"].items():
            label = f"emi {case['inputs']} {key}"
            if isinstance(expected, str):
                close(c, label, got[key], frac(expected))
            else:
                c.equal(label, got[key], expected)
        if "reference" in case:
            c.equal(f"emi reference {case['reference']['source']}", round(got["emi"]), case["reference"]["rupees"])
    for case in data["emiInvalid"]:
        i = case["inputs"]
        error = (
            "PRINCIPAL_NOT_POSITIVE" if i["principal"] <= 0
            else "RATE_OUT_OF_RANGE" if not (0 <= i["rate"] <= 50)
            else "TENURE_OUT_OF_RANGE" if not (1 <= i["months"] <= 480)
            else "PREPAYMENT_MONTH_OUT_OF_RANGE" if "prepayAfter" in i and not (1 <= i["prepayAfter"] < i["months"])
            else None
        )
        if error is None and "prepay" in i:
            r = exact(i["rate"]) / 1200
            p = exact(i["principal"])
            emi = p * r * (1 + r) ** i["months"] / ((1 + r) ** i["months"] - 1)
            balance = p
            for _ in range(i["prepayAfter"]):
                balance = balance + balance * r - emi
            error = "PREPAYMENT_TOO_LARGE" if exact(i["prepay"]) >= balance else None
        c.error(f"emi invalid {i}", error, case["expectedError"])
    for case in data["sip"]:
        got = sip_run(case["inputs"])
        for key, expected in case["expected"].items():
            close(c, f"sip {case['inputs']} {key}", got[key], frac(expected))
        if "reference" in case:
            c.equal(f"sip reference {case['reference']['source']}", int(got["value"]), case["reference"]["rupees"])
    for case in data["sipInvalid"]:
        i = case["inputs"]
        error = (
            "INSTALMENT_NOT_POSITIVE" if i["instalment"] <= 0
            else "RETURN_OUT_OF_RANGE" if not (0 <= i["annualReturn"] <= 50)
            else "YEARS_OUT_OF_RANGE" if not (1 <= i["years"] <= 50)
            else "STEP_UP_OUT_OF_RANGE" if not (0 <= i["stepUp"] <= 50)
            else None
        )
        c.error(f"sip invalid {i}", error, case["expectedError"])
    return c
