"""Percentage Hike Calculator fixtures (docs/specs/percentage-hike-calculator.md §4)."""

import json

from .common import Checker, exact, frac


def check(path):
    data = json.loads(path.read_text(encoding="utf-8"))
    c = Checker("hike")
    for case in data["cases"]:
        v = {k: exact(x) for k, x in case["inputs"].items()}
        label = f"{case['mode']} {case['inputs']}"
        if case["mode"] == "byPercent":
            change = v["current"] * v["hike"] / 100
            got = {"change": change, "result": v["current"] + change}
        else:
            change = v["new"] - v["current"]
            got = {"change": change, "percent": change * 100 / v["current"]}
        for key, expected in case["expected"].items():
            c.equal(f"{label} {key}", got[key], frac(expected))
    for case in data["periods"]:
        amount = exact(case["amount"])
        got = amount * 12 if case["from"] == "month" else amount / 12
        c.equal(f"period {case}", got, frac(case["expected"]))
    return c
