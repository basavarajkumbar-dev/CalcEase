"""Date engine and date tool fixtures (docs/specs/date-engine.md).

Independent of the TypeScript code: uses Python's datetime.date (proleptic Gregorian),
dateutil.relativedelta (same month-clamping convention as the spec) and
numpy.busday_count (Monday–Friday, start counted, end not).
"""

import calendar
import json
from datetime import date, timedelta

import numpy as np
from dateutil.relativedelta import relativedelta

from .common import Checker

MIN, MAX = date(1900, 1, 1), date(2199, 12, 31)


def d(text):
    return date.fromisoformat(text)


def check(path):
    data = json.loads(path.read_text(encoding="utf-8"))
    c = Checker("dates")

    for case in data["weekdays"]:
        c.equal(f"weekday {case['date']}", d(case["date"]).isoweekday(), case["isoWeekday"])
    for year in data["leapYears"]["leap"]:
        c.equal(f"leap {year}", calendar.isleap(year), True)
    for year in data["leapYears"]["common"]:
        c.equal(f"common {year}", calendar.isleap(year), False)

    for case in data["difference"]:
        a, b = d(case["first"]), d(case["second"])
        reversed_ = b < a
        start, end = (b, a) if reversed_ else (a, b)
        if case["includeEnd"]:
            end += timedelta(days=1)
        rd = relativedelta(end, start)
        got = {
            "years": rd.years,
            "months": rd.months,
            "days": rd.days,
            "totalDays": (end - start).days,
            "weekdays": int(np.busday_count(start, end)),
            "reversed": reversed_,
        }
        for key, expected in case["expected"].items():
            c.equal(f"difference {case['first']}→{case['second']} {key}", got[key], expected)

    for case in data["age"]:
        birth, as_of = d(case["birth"]), d(case["asOf"])
        rd = relativedelta(as_of, birth)
        total = (as_of - birth).days

        def birthday(year):
            return date(year, birth.month, min(birth.day, calendar.monthrange(year, birth.month)[1]))

        nxt = birthday(as_of.year)
        if nxt < as_of:
            nxt = birthday(as_of.year + 1)
        got = {
            "years": rd.years,
            "months": rd.months,
            "days": rd.days,
            "totalDays": total,
            "totalWeeks": total // 7,
            "nextBirthday": nxt.isoformat(),
            "daysToNextBirthday": (nxt - as_of).days,
            "nextAge": nxt.year - birth.year,
            "bornWeekday": birth.isoweekday(),
        }
        for key, expected in case["expected"].items():
            c.equal(f"age {case['birth']} on {case['asOf']} {key}", got[key], expected)
    for case in data["ageInvalid"]:
        error = "BIRTH_AFTER_DATE" if d(case["asOf"]) < d(case["birth"]) else None
        c.error(f"age invalid {case}", error, case["expectedError"])

    def shifted(case):
        s = case["shift"]
        rd = relativedelta(years=s.get("years", 0), months=s.get("months", 0), weeks=s.get("weeks", 0), days=s.get("days", 0))
        start = d(case["date"])
        months_only = relativedelta(years=s.get("years", 0), months=s.get("months", 0))
        if case["direction"] == "add":
            return start + rd, start + months_only
        return start - rd, start - months_only

    for case in data["shift"]:
        try:
            result, after_months = shifted(case)
        except OverflowError:
            result = after_months = None
        clamped = after_months is not None and after_months.day != d(case["date"]).day
        c.equal(f"shift {case['date']} {case['direction']} {case['shift']} date", result.isoformat(), case["expected"]["date"])
        c.equal(f"shift {case['date']} {case['direction']} {case['shift']} clamped", clamped, case["expected"]["clamped"])
    for case in data["shiftInvalid"]:
        result, _ = shifted(case)
        error = None if MIN <= result <= MAX else "RESULT_OUT_OF_RANGE"
        c.error(f"shift invalid {case}", error, case["expectedError"])
    return c
