"""General Calculator fixtures. Each case's plain-arithmetic 'equivalent' is parsed with
Python's ast module (never eval) and evaluated with exact fractions."""

import ast
import json
from fractions import Fraction

from .common import Checker, frac

OPS = {ast.Add: lambda a, b: a + b, ast.Sub: lambda a, b: a - b, ast.Mult: lambda a, b: a * b, ast.Div: lambda a, b: a / b}


def value(node):
    if isinstance(node, ast.Expression):
        return value(node.body)
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return Fraction(str(node.value))
    if isinstance(node, ast.BinOp) and type(node.op) in OPS:
        return OPS[type(node.op)](value(node.left), value(node.right))
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub):
        return -value(node.operand)
    raise ValueError(f"unsupported: {ast.dump(node)}")


def check(path):
    data = json.loads(path.read_text(encoding="utf-8"))
    c = Checker("calculator")
    for case in data["cases"]:
        got = value(ast.parse(case["equivalent"], mode="eval"))
        c.equal(f"{case['expression']}", got, frac(case["expected"]))
    return c
