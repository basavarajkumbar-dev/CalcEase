"""Lumpsum Calculator fixtures: FV = P × (1 + r/100)^n with exact fractions."""

import json

from .common import Checker, exact, frac


def check(path):
    data = json.loads(path.read_text(encoding="utf-8"))
    c = Checker("lumpsum")
    for case in data["cases"]:
        i = case["inputs"]
        p, r = exact(i["amount"]), exact(i["annualReturn"])
        value = p * (1 + r / 100) ** i["years"]
        got = {"value": value, "gains": value - p}
        for key, expected in case["expected"].items():
            c.equal(f"lumpsum {i} {key}", got[key], frac(expected))
        if "reference" in case:
            c.equal(f"lumpsum reference {case['reference']['source']}", round(value), case["reference"]["rupees"])
    for case in data["invalid"]:
        i = case["inputs"]
        error = (
            "AMOUNT_NOT_POSITIVE" if i["amount"] <= 0
            else "RETURN_OUT_OF_RANGE" if not (0 <= i["annualReturn"] <= 50)
            else "YEARS_OUT_OF_RANGE" if not (float(i["years"]).is_integer() and 1 <= i["years"] <= 50)
            else None
        )
        c.error(f"lumpsum invalid {i}", error, case["expectedError"])
    return c
