"""CTC to In-Hand fixtures (UNDER REVIEW). Slab tables are written out here separately
from the TypeScript rule data, from the same official sources, and all arithmetic is
exact."""

import json
from fractions import Fraction

from .common import Checker, exact, frac

NEW = {"slabs": [(400000, 0), (800000, 5), (1200000, 10), (1600000, 15), (2000000, 20), (2400000, 25), (None, 30)],
       "sd": 75000, "limit": 1200000, "max": 60000, "marginal": True, "pt": False}
OLD = {"slabs": [(250000, 0), (500000, 5), (1000000, 20), (None, 30)],
       "sd": 50000, "limit": 500000, "max": 12500, "marginal": False, "pt": True}
CESS = Fraction(4, 100)
CEILING = 25000


def tax(income, r):
    income = max(Fraction(0), Fraction(income))
    total, lower = Fraction(0), 0
    for upper, rate in r["slabs"]:
        top = income if upper is None else min(income, upper)
        if top > lower:
            total += (Fraction(top) - lower) * Fraction(rate, 100)
        if upper is None or income <= upper:
            break
        lower = upper
    if income <= r["limit"]:
        rebate = min(total, r["max"])
    elif r["marginal"]:
        rebate = max(Fraction(0), total - (income - r["limit"]))
    else:
        rebate = Fraction(0)
    payable = total - rebate
    return {"slabTax": total, "rebate": rebate, "totalTax": payable + payable * CESS, "taxableIncome": income}


def ctc(i):
    r = NEW if i["regime"] == "new" else OLD
    c = exact(i["ctc"])
    basic = c * exact(i["basicPercent"]) / 100
    monthly = {"none": Fraction(0), "capped": min(basic / 12, CEILING), "full": basic / 12}[i["pfMode"]]
    pf = Fraction(monthly) * 12 * Fraction(12, 100)
    gratuity = basic / 12 * Fraction(15, 26) if i.get("gratuityInCtc") else Fraction(0)
    gross = c - (pf if i["employerPfInCtc"] else 0) - gratuity - exact(i["otherEmployerCosts"])
    pt = exact(i["professionalTaxMonthly"]) * 12
    if gross <= pf + pt:
        return "COSTS_TOO_HIGH"
    taxable = gross - r["sd"] - (pt if r["pt"] else 0) - (exact(i["oldRegimeDeductions"]) if i["regime"] == "old" else 0)
    if taxable > 5000000:
        return "ABOVE_SURCHARGE_THRESHOLD"
    t = tax(taxable, r)
    in_hand = gross - pf - pt - t["totalTax"]
    return {**t, "gratuity": gratuity, "employerPf": pf, "employeePf": pf, "gross": gross, "inHandYearly": in_hand, "inHandMonthly": in_hand / 12}


def check(path):
    data = json.loads(path.read_text(encoding="utf-8"))
    c = Checker("ctc")
    for case in data["tax"]:
        got = tax(case["taxable"], NEW if case["regime"] == "new" else OLD)
        for key, expected in case["expected"].items():
            c.equal(f"tax {case['regime']} {case['taxable']} {key}", got[key], frac(expected))
    for case in data["ctc"]:
        got = ctc(case["inputs"])
        for key, expected in case["expected"].items():
            c.equal(f"ctc {case['inputs']['ctc']} {case['inputs']['regime']} {key}", got[key], frac(expected))
    for case in data["invalid"]:
        got = ctc(case["inputs"])
        c.error(f"ctc invalid {case['inputs']['ctc']}", got if isinstance(got, str) else None, case["expectedError"])
    return c
