"""Experience and Notice Period fixtures, with datetime and dateutil.relativedelta."""

import json
from datetime import date, timedelta

from dateutil.relativedelta import relativedelta

from .common import Checker


def d(text):
    return date.fromisoformat(text)


def check(path):
    data = json.loads(path.read_text(encoding="utf-8"))
    c = Checker("career")
    for case in data["experience"]:
        start, end = d(case["joining"]), d(case["end"])
        if case["includeEnd"]:
            end += timedelta(days=1)
        rd = relativedelta(end, start)
        got = {"years": rd.years, "months": rd.months, "days": rd.days, "totalDays": (end - start).days}
        for key, expected in case["expected"].items():
            c.equal(f"experience {case['joining']}→{case['end']} {key}", got[key], expected)
    for case in data["experienceInvalid"]:
        error = "END_BEFORE_JOINING" if d(case["end"]) < d(case["joining"]) else None
        c.error(f"experience invalid {case}", error, case["expectedError"])
    for case in data["notice"]:
        first = d(case["resignation"]) + timedelta(days=0 if case["countResignationDay"] else 1)
        last = first + timedelta(days=case["days"] - 1)
        got = {"lastWorkingDay": last.isoformat()}
        if "today" in case:
            today = d(case["today"])
            got["daysUntilLastDay"] = (last - today).days
            got["daysServed"] = min(case["days"], max(0, (today - first).days + 1))
        for key, expected in case["expected"].items():
            c.equal(f"notice {case['resignation']} +{case['days']} {key}", got[key], expected)
    for case in data["noticeInvalid"]:
        error = None if 1 <= case["days"] <= 365 else "NOTICE_OUT_OF_RANGE"
        c.error(f"notice invalid {case}", error, case["expectedError"])
    return c
