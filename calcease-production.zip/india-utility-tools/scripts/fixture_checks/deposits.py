"""Compound interest, FD and RD fixtures.

Re-derived by a different route from the TypeScript code:
- compound interest with exact fractions when the number of periods is whole;
- FDs quarter by quarter, with quarter dates from dateutil.relativedelta counted from the
  deposit date, and exact fractions;
- RDs by adding up every instalment's own growth, R × (1 + i)^(k/3) for k months to
  maturity, in 50-digit decimals (instead of the closed-form formula);
- published bank examples checked to the rupee.
"""

import json
from datetime import date
from decimal import Decimal, getcontext
from fractions import Fraction

from dateutil.relativedelta import relativedelta

from .common import Checker, exact, frac

getcontext().prec = 50
PER_YEAR = {"yearly": 1, "halfYearly": 2, "quarterly": 4, "monthly": 12}
TOLERANCE = Fraction(1, 10**6)  # fixtures are written to 9 decimal places


def close(c, label, actual, expected):
    c.count += 1
    if abs(Fraction(actual) - expected) > TOLERANCE:
        c.failures.append(f"{c.name}: {label}: fixture says {float(expected)}, independent value {float(actual)}")


def compound(inputs):
    p, r, t = exact(inputs["principal"]), exact(inputs["rate"]), exact(inputs["years"])
    n = PER_YEAR[inputs["compounding"]]
    periods = n * t
    if periods.denominator == 1:
        return p * (1 + r / (100 * n)) ** int(periods)
    growth = (Decimal(1) + Decimal(r.numerator) / Decimal(r.denominator) / (100 * n))
    return Fraction(Decimal(p.numerator) / Decimal(p.denominator) * growth ** (Decimal(periods.numerator) / Decimal(periods.denominator)))


def fd(inputs):
    p, r = exact(inputs["principal"]), exact(inputs["rate"])
    start, maturity = date.fromisoformat(inputs["start"]), date.fromisoformat(inputs["maturity"])
    days = (maturity - start).days
    if maturity < start + relativedelta(months=inputs["simpleBelowMonths"]):
        interest = p * r * days / 36500
        out = {"maturityAmount": p + interest, "interest": interest, "quarters": 0, "brokenDays": days, "simple": True, "totalDays": days}
        if inputs["payout"] == "quarterly":
            out.update(quarterlyPayout=Fraction(0), finalPayout=interest, maturityAmount=p)
        return out
    balance, paid, k = p, Fraction(0), 0
    while start + relativedelta(months=3 * (k + 1)) <= maturity:
        k += 1
        if inputs["payout"] == "quarterly":
            paid += p * r / 400
        else:
            balance += balance * r / 400
    broken = (maturity - (start + relativedelta(months=3 * k))).days
    if inputs["payout"] == "quarterly":
        final = p * r * broken / 36500
        return {"maturityAmount": p, "interest": paid + final, "quarterlyPayout": p * r / 400, "finalPayout": final, "quarters": k, "brokenDays": broken, "simple": False, "totalDays": days}
    amount = balance + balance * r * broken / 36500
    return {"maturityAmount": amount, "interest": amount - p, "quarters": k, "brokenDays": broken, "simple": False, "totalDays": days}


def rd(inputs):
    r = Decimal(str(inputs["rate"]))
    i = r / 400
    months = inputs["months"]
    instalment = Decimal(str(inputs["instalment"]))
    total = sum(instalment * (1 + i) ** (Decimal(k) / 3) for k in range(1, months + 1))
    return {"maturity": Fraction(total), "deposited": Fraction(instalment) * months}


def check(path):
    data = json.loads(path.read_text(encoding="utf-8"))
    c = Checker("deposits")
    for case in data["compound"]:
        close(c, f"compound {case['inputs']}", compound(case["inputs"]), frac(case["expected"]["amount"]))
    for case in data["fd"]:
        got = fd(case["inputs"])
        for key, expected in case["expected"].items():
            label = f"fd {case['inputs']['start']}→{case['inputs']['maturity']} {key}"
            if isinstance(expected, str):
                close(c, label, got[key], frac(expected))
            else:
                c.equal(label, got[key], expected)
        if "reference" in case:
            c.equal(f"fd reference {case['reference']['source']}", round(got["maturityAmount"]), case["reference"]["rupees"])
    for case in data["fdInvalid"]:
        i = case["inputs"]
        start, maturity = date.fromisoformat(i["start"]), date.fromisoformat(i["maturity"])
        error = (
            "PRINCIPAL_NOT_POSITIVE" if i["principal"] <= 0
            else "RATE_OUT_OF_RANGE" if not (0 < i["rate"] <= 20)
            else "TENURE_TOO_SHORT" if (maturity - start).days < 7
            else "TENURE_TOO_LONG" if maturity > start + relativedelta(months=120)
            else None
        )
        c.error(f"fd invalid {i}", error, case["expectedError"])
    for case in data["rd"]:
        got = rd(case["inputs"])
        for key, expected in case["expected"].items():
            close(c, f"rd {case['inputs']} {key}", got[key], frac(expected))
        if "reference" in case:
            c.equal(f"rd reference {case['reference']['source']}", round(got["maturity"]), case["reference"]["rupees"])
    for case in data["rdInvalid"]:
        i = case["inputs"]
        error = (
            "RATE_OUT_OF_RANGE" if not (0 < i["rate"] <= 20)
            else "TENURE_OUT_OF_RANGE" if not (3 <= i["months"] <= 120)
            else "TENURE_NOT_WHOLE_QUARTERS" if i["months"] % 3
            else None
        )
        c.error(f"rd invalid {i}", error, case["expectedError"])
    return c
