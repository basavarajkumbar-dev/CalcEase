"""GST Calculator fixtures (docs/specs/gst-calculator.md §2, §5)."""

import json
from fractions import Fraction

from .common import Checker, exact, frac


def check(path):
    data = json.loads(path.read_text(encoding="utf-8"))
    c = Checker("gst")
    for case in data["cases"]:
        amount = exact(case["inputs"]["amount"])
        rate = exact(case["inputs"]["rate"])
        if case["mode"] == "exclusive":
            base = amount
            gst = base * rate / 100
            total = base + gst
        else:
            total = amount
            base = total * 100 / (100 + rate)
            gst = total - base
        got = {"base": base, "gst": gst, "total": total, "half": gst / 2}
        for key, expected in case["expected"].items():
            c.equal(f"{case['mode']} {case['inputs']} {key}", got[key], frac(expected))
    for case in data["invalid"]:
        amount = exact(case["inputs"]["amount"])
        rate = exact(case["inputs"]["rate"])
        error = "AMOUNT_NOT_POSITIVE" if amount <= 0 else "RATE_OUT_OF_RANGE" if not (0 <= rate <= 100) else None
        c.error(f"invalid {case['inputs']}", error, case["expectedError"])
    return c
