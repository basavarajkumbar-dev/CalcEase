"""Discount Calculator fixtures (docs/specs/discount-calculator.md §4)."""

import json

from .common import Checker, exact, frac


def check(path):
    data = json.loads(path.read_text(encoding="utf-8"))
    c = Checker("discount")
    for case in data["cases"]:
        v = {k: exact(x) for k, x in case["inputs"].items()}
        label = f"{case['mode']} {case['inputs']}"
        mode = case["mode"]
        if mode == "percentOff":
            saving = v["price"] * v["discount"] / 100
            got = {"saving": saving, "final": v["price"] - saving}
        elif mode == "fromSalePrice":
            if v["sale"] > v["price"]:
                c.error(label, "SALE_ABOVE_PRICE", case.get("expectedError"))
                continue
            saving = v["price"] - v["sale"]
            got = {"saving": saving, "percent": saving * 100 / v["price"]}
        elif mode == "stacked":
            final = v["price"] * (1 - v["first"] / 100) * (1 - v["extra"] / 100)
            saving = v["price"] - final
            got = {"final": final, "saving": saving, "percent": saving * 100 / v["price"]}
        else:
            raise ValueError(mode)
        for key, expected in case["expected"].items():
            c.equal(f"{label} {key}", got[key], frac(expected))
    return c
